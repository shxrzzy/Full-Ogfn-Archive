import {
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import User from "../../database/models/User";
import Profiles from "../../database/models/Profiles";

export default {
  data: new SlashCommandBuilder()
    .setName("ogdonator")
    .setDescription("Give a user OG Donator cosmetics!")
    .addStringOption((opt) =>
      opt.setName("user").setDescription("Users Discord ID").setRequired(true),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction: ChatInputCommandInteraction) {
    if (
      !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)
    ) {
      const embed = new EmbedBuilder()
        .setTitle("Zynex")
        .setDescription("You do not have permissions to use this command.")
        .setColor("Red")
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const users = interaction.options.getString("user", true);

    try {
      const user = await User.findOne({ discordId: users });
      if (!user) {
        const embed = new EmbedBuilder()
          .setTitle("Zynex")
          .setDescription("Couldn't find the selected user.")
          .setColor("Red")
          .setTimestamp();

        return await interaction.reply({ embeds: [embed], ephemeral: true });
      }

      const profile = await Profiles.findOne({ accountId: user.accountId });
      if (!profile) {
        const embed = new EmbedBuilder()
          .setTitle("Zynex")
          .setDescription("User is missing a profile!")
          .setColor("Red")
          .setTimestamp();

        return await interaction.reply({ embeds: [embed], ephemeral: true });
      }

      if (!user.hasOG) {
        let athena = profile.profiles["athena"];

        const ogItems = await Bun.file(
          "src/resources/utilities/ogcosmetics.json",
        ).json();

        athena.items = { ...athena.items, ...ogItems };

        await profile.updateOne({
          $set: { "profiles.athena.items": athena.items },
        });

        user.hasOG = true;
        await user.save();
      }

      const embed = new EmbedBuilder()
        .setTitle("Zynex")
        .setDescription("Successfully gave OG Donator cosmetics!")
        .setColor("Green")
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (err) {
      console.error(err);

      const embed = new EmbedBuilder()
        .setTitle("Zynex")
        .setDescription(
          "We ran into an error while giving OG Donator cosmetics, please try again later.",
        )
        .setColor("Red")
        .setTimestamp();

      return await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
