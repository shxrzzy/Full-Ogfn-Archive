node index.js
pause
