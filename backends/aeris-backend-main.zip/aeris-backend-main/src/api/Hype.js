import express from "express";
import mongoose from "mongoose";
import User from "../User/Mongodb/Schema/user.js";
import Profile from "../User/Mongodb/Schema/profiles.js";
import Safety from "../Utils/safety.js";
import log from "../Utils/structs/log.js";

const PORT = 90;
const API_KEY = "84059365-25d6-486f-81f3-04b306828c35";

const connectToMongoDB = async () => {
  try {
    mongoose.set("strictQuery", true);
    await mongoose.connect(Safety.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
  } catch (error) {
    log.error(`MongoDB connection error: ${error.message}`);
    process.exit(1);
  }
};

const app = express();
app.use(express.json());

app.get(
  "/api/v1/rewards/managehype/:username/:reason/:apiKey",
  async (req, res) => {
    const { username, reason, apiKey } = req.params;

    try {
      if (apiKey !== API_KEY) {
        log.warn(`Invalid API key attempt from IP: ${req.ip}`);
        throw new Error(`Invalid API key from IP: ${req.ip}`);
      }
      if (
        ![
          "Elimination",
          "Win",
          "Top 3",
          "Top 7",
          "Top 12",
          "Bus Fare",
        ].includes(reason)
      ) {
        log.warn(`Invalid reason attempt from IP: ${req.ip}: ${reason}`);
        throw new Error(`Invalid reason from IP: ${req.ip}`);
      }

      log.hype(
        `Processing hype request -> Username: ${username}, Reason: ${reason}`
      );

      const user = await User.findOne({ username }).lean();
      if (!user) {
        throw new Error(`User not found: ${username}`);
      }

      const profile = await Profile.findOne({ accountId: user.accountId }).lean();
      if (!profile) {
        throw new Error(`Profile not found for user: ${username}`);
      }

      const attributes = { ...profile.profiles.athena.stats.attributes };
      const currentHype = attributes.arena_hype || 0;
      let amount = 0;
      let removeAmount = 0;

      switch (reason) {
        case "Elimination":
          amount = 20;
          break;
        case "Win":
          amount = 60;
          break;
        case "Top 3":
          amount = 30;
          break;
        case "Top 7":
          amount = 10;
          break;
        case "Top 12":
          amount = 10;
          break;
        case "Bus Fare":
          if (currentHype >= 0 && currentHype < 400) removeAmount = 0;         // Division 1–3
          else if (currentHype >= 400 && currentHype < 800) removeAmount = 10; // Division 4
          else if (currentHype >= 800 && currentHype < 1400) removeAmount = 20; // Division 5
          else if (currentHype >= 1400 && currentHype < 2000) removeAmount = 30; // Division 6
          else if (currentHype >= 2000 && currentHype < 3000) removeAmount = 40; // Division 7
          else if (currentHype >= 3000 && currentHype < 4000) removeAmount = 50; // Division 8
          else if (currentHype >= 4000 && currentHype < 6000) removeAmount = 60; // Division 9
          else if (currentHype >= 6000) removeAmount = 70;                       // Champion
          break;
      }


      const newHype = Math.max(0, currentHype + amount - removeAmount);
      attributes.arena_hype = newHype;

      await Profile.updateOne(
        { accountId: user.accountId },
        { $set: { "profiles.athena.stats.attributes": attributes } }
      );

      const message =
        removeAmount === 0
          ? `Successfully added ${amount} Hype`
          : `Successfully ${amount > 0 ? "added" : "removed"} Hype`;

      log.hype(`${message} for ${username}, new Hype: ${newHype}`);
      res.json({
        message,
        hype: attributes.arena_hype,
      });
    } catch (error) {
      log.error(`ManageHype error for ${username}: ${error.message}`);
      res.status(error.message.includes("not found") ? 404 : 400).json({
        error: error.message,
      });
    }
  }
);

const startServer = async () => {
  await connectToMongoDB();
  app.listen(PORT, () => {
    log.api(`ManageHype server running on port ${PORT}`);
  });
};

startServer().catch((error) => {
  log.error(`Server startup error: ${error.message}`);
  process.exit(1);
});