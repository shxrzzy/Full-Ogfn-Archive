import express from "express";
import mongoose from "mongoose";
import User from "../User/Mongodb/Schema/user.js";
import Profile from "../User/Mongodb/Schema/profiles.js";
import { SendEmptyGift } from "../Utils/Utils.js";
import log from "../Utils/structs/log.js";
import Safety from "../Utils/safety.js";

const PORT = 78;
const API_KEY = "84059365-25d6-486f-81f3-04b306828c35";

const levelData = 
[
  { "Level": 1, "XpToNextLevel": 100, "XpTotal": 0 },
  { "Level": 2, "XpToNextLevel": 200, "XpTotal": 100 },
  { "Level": 3, "XpToNextLevel": 300, "XpTotal": 300 },
  { "Level": 4, "XpToNextLevel": 400, "XpTotal": 600 },
  { "Level": 5, "XpToNextLevel": 500, "XpTotal": 1000 },
  { "Level": 6, "XpToNextLevel": 650, "XpTotal": 1500 },
  { "Level": 7, "XpToNextLevel": 800, "XpTotal": 2150 },
  { "Level": 8, "XpToNextLevel": 950, "XpTotal": 2950 },
  { "Level": 9, "XpToNextLevel": 1100, "XpTotal": 3900 },
  { "Level": 10, "XpToNextLevel": 1250, "XpTotal": 5000 },
  { "Level": 11, "XpToNextLevel": 1400, "XpTotal": 6250 },
  { "Level": 12, "XpToNextLevel": 1550, "XpTotal": 7650 },
  { "Level": 13, "XpToNextLevel": 1700, "XpTotal": 9200 },
  { "Level": 14, "XpToNextLevel": 1850, "XpTotal": 10900 },
  { "Level": 15, "XpToNextLevel": 2000, "XpTotal": 12750 },
  { "Level": 16, "XpToNextLevel": 2150, "XpTotal": 14750 },
  { "Level": 17, "XpToNextLevel": 2300, "XpTotal": 16900 },
  { "Level": 18, "XpToNextLevel": 2450, "XpTotal": 19200 },
  { "Level": 19, "XpToNextLevel": 2600, "XpTotal": 21650 },
  { "Level": 20, "XpToNextLevel": 2750, "XpTotal": 24250 },
  { "Level": 21, "XpToNextLevel": 2900, "XpTotal": 27000 },
  { "Level": 22, "XpToNextLevel": 3050, "XpTotal": 29900 },
  { "Level": 23, "XpToNextLevel": 3200, "XpTotal": 32950 },
  { "Level": 24, "XpToNextLevel": 3350, "XpTotal": 36150 },
  { "Level": 25, "XpToNextLevel": 3500, "XpTotal": 39500 },
  { "Level": 26, "XpToNextLevel": 3650, "XpTotal": 43000 },
  { "Level": 27, "XpToNextLevel": 3800, "XpTotal": 46650 },
  { "Level": 28, "XpToNextLevel": 3950, "XpTotal": 50450 },
  { "Level": 29, "XpToNextLevel": 4100, "XpTotal": 54400 },
  { "Level": 30, "XpToNextLevel": 4250, "XpTotal": 58500 },
  { "Level": 31, "XpToNextLevel": 4400, "XpTotal": 62750 },
  { "Level": 32, "XpToNextLevel": 4550, "XpTotal": 67150 },
  { "Level": 33, "XpToNextLevel": 4700, "XpTotal": 71700 },
  { "Level": 34, "XpToNextLevel": 4850, "XpTotal": 76400 },
  { "Level": 35, "XpToNextLevel": 5000, "XpTotal": 81250 },
  { "Level": 36, "XpToNextLevel": 5150, "XpTotal": 86250 },
  { "Level": 37, "XpToNextLevel": 5300, "XpTotal": 91400 },
  { "Level": 38, "XpToNextLevel": 5450, "XpTotal": 96700 },
  { "Level": 39, "XpToNextLevel": 5600, "XpTotal": 102150 },
  { "Level": 40, "XpToNextLevel": 5800, "XpTotal": 107750 },
  { "Level": 41, "XpToNextLevel": 6000, "XpTotal": 113550 },
  { "Level": 42, "XpToNextLevel": 6200, "XpTotal": 119550 },
  { "Level": 43, "XpToNextLevel": 6400, "XpTotal": 125750 },
  { "Level": 44, "XpToNextLevel": 6600, "XpTotal": 132150 },
  { "Level": 45, "XpToNextLevel": 6800, "XpTotal": 138750 },
  { "Level": 46, "XpToNextLevel": 7000, "XpTotal": 145550 },
  { "Level": 47, "XpToNextLevel": 7200, "XpTotal": 152550 },
  { "Level": 48, "XpToNextLevel": 7400, "XpTotal": 159750 },
  { "Level": 49, "XpToNextLevel": 7600, "XpTotal": 167150 },
  { "Level": 50, "XpToNextLevel": 7800, "XpTotal": 174750 },
  { "Level": 51, "XpToNextLevel": 8100, "XpTotal": 182550 },
  { "Level": 52, "XpToNextLevel": 8400, "XpTotal": 190650 },
  { "Level": 53, "XpToNextLevel": 8700, "XpTotal": 199050 },
  { "Level": 54, "XpToNextLevel": 9000, "XpTotal": 207750 },
  { "Level": 55, "XpToNextLevel": 9300, "XpTotal": 216750 },
  { "Level": 56, "XpToNextLevel": 9600, "XpTotal": 226050 },
  { "Level": 57, "XpToNextLevel": 9900, "XpTotal": 235650 },
  { "Level": 58, "XpToNextLevel": 10200, "XpTotal": 245550 },
  { "Level": 59, "XpToNextLevel": 10500, "XpTotal": 255750 },
  { "Level": 60, "XpToNextLevel": 10800, "XpTotal": 266250 },
  { "Level": 61, "XpToNextLevel": 11200, "XpTotal": 277050 },
  { "Level": 62, "XpToNextLevel": 11600, "XpTotal": 288250 },
  { "Level": 63, "XpToNextLevel": 12000, "XpTotal": 299850 },
  { "Level": 64, "XpToNextLevel": 12400, "XpTotal": 311850 },
  { "Level": 65, "XpToNextLevel": 12800, "XpTotal": 324250 },
  { "Level": 66, "XpToNextLevel": 13200, "XpTotal": 337050 },
  { "Level": 67, "XpToNextLevel": 13600, "XpTotal": 350250 },
  { "Level": 68, "XpToNextLevel": 14000, "XpTotal": 363850 },
  { "Level": 69, "XpToNextLevel": 14400, "XpTotal": 377850 },
  { "Level": 70, "XpToNextLevel": 14800, "XpTotal": 392250 },
  { "Level": 71, "XpToNextLevel": 15300, "XpTotal": 407050 },
  { "Level": 72, "XpToNextLevel": 15800, "XpTotal": 422350 },
  { "Level": 73, "XpToNextLevel": 16300, "XpTotal": 438150 },
  { "Level": 74, "XpToNextLevel": 16800, "XpTotal": 454450 },
  { "Level": 75, "XpToNextLevel": 17300, "XpTotal": 471250 },
  { "Level": 76, "XpToNextLevel": 17800, "XpTotal": 488550 },
  { "Level": 77, "XpToNextLevel": 18300, "XpTotal": 506350 },
  { "Level": 78, "XpToNextLevel": 18800, "XpTotal": 524650 },
  { "Level": 79, "XpToNextLevel": 19300, "XpTotal": 543450 },
  { "Level": 80, "XpToNextLevel": 19800, "XpTotal": 562750 },
  { "Level": 81, "XpToNextLevel": 20800, "XpTotal": 582550 },
  { "Level": 82, "XpToNextLevel": 21800, "XpTotal": 603350 },
  { "Level": 83, "XpToNextLevel": 22800, "XpTotal": 625150 },
  { "Level": 84, "XpToNextLevel": 23800, "XpTotal": 647950 },
  { "Level": 85, "XpToNextLevel": 24800, "XpTotal": 671750 },
  { "Level": 86, "XpToNextLevel": 25800, "XpTotal": 696550 },
  { "Level": 87, "XpToNextLevel": 26800, "XpTotal": 722350 },
  { "Level": 88, "XpToNextLevel": 27800, "XpTotal": 749150 },
  { "Level": 89, "XpToNextLevel": 28800, "XpTotal": 776950 },
  { "Level": 90, "XpToNextLevel": 30800, "XpTotal": 805750 },
  { "Level": 91, "XpToNextLevel": 32800, "XpTotal": 836550 },
  { "Level": 92, "XpToNextLevel": 34800, "XpTotal": 869350 },
  { "Level": 93, "XpToNextLevel": 36800, "XpTotal": 904150 },
  { "Level": 94, "XpToNextLevel": 38800, "XpTotal": 940950 },
  { "Level": 95, "XpToNextLevel": 40800, "XpTotal": 979750 },
  { "Level": 96, "XpToNextLevel": 42800, "XpTotal": 1020550 },
  { "Level": 97, "XpToNextLevel": 45800, "XpTotal": 1063350 },
  { "Level": 98, "XpToNextLevel": 49800, "XpTotal": 1109150 },
  { "Level": 99, "XpToNextLevel": 54800, "XpTotal": 1158950 },
  { "Level": 100, "XpToNextLevel": 0, "XpTotal": 1213750 }
];

const connectToMongoDB = async () => {
  try {
    mongoose.set("strictQuery", true);
    await mongoose.connect(Safety.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
  } catch (error) {
    log.error(`MongoDB connection error: ${error.message}`);
    process.exit(1);
  }
};

const app = express();
app.use(express.json());

app.get(
  "/api/v1/xp/:username/:amount/:apiKey",
  async (req, res) => {
    const { username, amount, apiKey } = req.params;
    const xpAmount = parseInt(amount);

    try {
      if (apiKey !== API_KEY) {
        log.api(`Invalid API key attempt from IP: ${req.ip}`);
        throw new Error(`Invalid API key from IP: ${req.ip}`);
      }
      if (isNaN(xpAmount) || xpAmount <= 0) {
        throw new Error("Invalid XP amount");
      }
      if (xpAmount > 10000) {
        log.api(
          `XP amount ${xpAmount} exceeds limit from IP: ${req.ip}`
        );
        throw new Error(`XP amount exceeds limit from IP: ${req.ip}`);
      }

      log.api(
        `Processing XP request -> Username: ${username}, Amount: ${xpAmount}`
      );

      const user = await User.findOne({ username }).lean();
      if (!user) {
        throw new Error(`User not found: ${username}`);
      }

      const profile = await Profile.findOne({ accountId: user.accountId }).lean();
      if (!profile) {
        throw new Error(`Profile not found for user: ${username}`);
      }

      const attributes = { ...profile.profiles.athena.stats.attributes };
      let currentXp = attributes.xp || 0;
      let currentLevel = attributes.level || 1;

      currentXp += xpAmount;
      attributes.xp = currentXp;

      const nextLevelData = levelData.find(level => level.XpTotal <= currentXp && (levelData[levelData.indexOf(level) + 1]?.XpTotal > currentXp || !levelData[levelData.indexOf(level) + 1]));
      if (nextLevelData) {
        currentLevel = nextLevelData.Level;
        attributes.level = currentLevel;
        log.api(`User ${username} leveled up to ${currentLevel}!`);
      }

      await Profile.updateOne(
        { accountId: user.accountId },
        {
          $set: {
            "profiles.athena.stats.attributes": attributes,
          },
        }
      );

      log.xp(`Added ${xpAmount} XP to ${username}, new level: ${currentLevel}`);
      SendEmptyGift(username, user.accountId);

      res.json({
        message: `Successfully added ${xpAmount} XP, new level: ${currentLevel}`,
      });
    } catch (error) {
      log.api(`XP error for ${username}: ${error.message}`);
      res.status(error.message.includes("not found") ? 404 : 400).json({
        error: error.message,
      });
    }
  }
);

const startServer = async () => {
  await connectToMongoDB();
  app.listen(PORT, () => {
    log.api(`XP server running on port ${PORT}`);
  });
};

startServer().catch((error) => {
  log.api(`Server startup error: ${error.message}`);
  process.exit(1);
});