:start
@echo off
title Inferno
npx concurrently "node src/index.js" "node src/discord/auth/auth.js" "node --no-deprecation src/api/Hype.js" "node --no-deprecation src/api/vbucks.js" "node --no-deprecation src/api/seasonUmbrella.js" "node --no-deprecation src/api/XP.js"
@echo on
goto start