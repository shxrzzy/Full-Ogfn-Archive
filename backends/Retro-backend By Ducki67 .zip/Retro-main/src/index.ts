import type { ServerWebSocket } from "bun";
import { Hono } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";
import { config } from "./config";
import { newMatchId, newSessionId, newTicketId, verifyMmAuthHeader } from "./lib/matchmaker";
import type { TicketPayload } from "./lib/matchmaker";
import { authRoutes } from "./routes/auth";
import { cloudStorageRoutes } from "./routes/cloudstorage";
import { coreRoutes } from "./routes/core";
import { discoveryRoutes } from "./routes/discovery";
import { eosRoutes } from "./routes/eos";
import { profileRoutes } from "./routes/profiles";
import { timelineRoutes } from "./routes/timeline";

const app = new Hono();

app.use("*", logger());
app.use(
  "*",
  cors({
    origin: "*",
    allowMethods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowHeaders: ["Content-Type", "Authorization", "X-Requested-With", "Origin", "Accept"]
  })
);

app.route("/", coreRoutes);
app.route("/", authRoutes);
app.route("/", cloudStorageRoutes);
app.route("/", discoveryRoutes);
app.route("/", eosRoutes);
app.route("/", profileRoutes);
app.route("/", timelineRoutes);

app.notFound((c) => {
  const path = new URL(c.req.url).pathname.toLowerCase();
  const compatPrefixes = [
    "/fortnite/api/",
    "/account/api/",
    "/launcher/api/",
    "/content/api/",
    "/friends/api/",
    "/party/api/",
    "/presence/api/",
    "/entitlement/api/",
    "/eulatracking/api/",
    "/api/v1/",
    "/api/v2/",
    "/epic/",
    "/sdk/",
    "/v1/"
  ];

  if (compatPrefixes.some((prefix) => path.startsWith(prefix))) {
    if (c.req.method === "GET") {
      return c.json({});
    }
    return c.body(null, 204);
  }

  return c.json(
    {
      errorCode: "errors.com.retrov1.common.not_found",
      errorMessage: "Sorry the resource you were trying to find could not be found",
      numericErrorCode: 1004,
      originatingService: "any",
      intent: "prod"
    },
    404
  );
});

// WebSocket router — two kinds of WS connections land here:
//   1. EOS SDK: notifications/lobby/cerberus → stub that accepts + keeps open
//   2. Matchmaker (/matchmaker): legacy mms-player flow with state sequence
type WsData = {
  path: string;
  kind: "matchmaker" | "xmpp" | "stub";
  ticket?: TicketPayload;
  ticketId?: string;
  jid?: string;
  resource?: string;
  authed?: boolean;
};

const MM_PATH = "/matchmaker";

function mmStatus(state: string, extra: Record<string, unknown> = {}) {
  return JSON.stringify({
    name: "StatusUpdate",
    payload: { state, ...extra }
  });
}

async function runMatchmakerFlow(ws: ServerWebSocket<WsData>) {
  const ticket = ws.data.ticket;
  if (!ticket) {
    ws.close(1008, "missing ticket");
    return;
  }

  const ticketId = ws.data.ticketId ?? newTicketId();
  ws.data.ticketId = ticketId;
  const matchId = newMatchId();
  const sessionId = newSessionId();

  console.log(`[mm] ${ticket.accountId} -> playlist=${ticket.playlist} ticket=${ticketId}`);

  ws.send(mmStatus("Connecting"));
  await new Promise((r) => setTimeout(r, 300));

  ws.send(mmStatus("Waiting", { totalPlayers: 1, connectedPlayers: 0 }));
  await new Promise((r) => setTimeout(r, 300));

  ws.send(
    mmStatus("Queued", {
      ticketId,
      queuedPlayers: 1,
      estimatedWaitSec: 1,
      status: {}
    })
  );
  await new Promise((r) => setTimeout(r, 800));

  ws.send(mmStatus("SessionAssignment", { matchId }));
  await new Promise((r) => setTimeout(r, 500));

  ws.send(
    JSON.stringify({
      name: "Play",
      payload: { matchId, sessionId, joinDelaySec: 0 }
    })
  );
  await new Promise((r) => setTimeout(r, 200));

  ws.close(1000, "matched");
}

// Minimal XMPP-over-WebSocket stub. Fortnite XMPP connection is XML framing
// over WS. We don't need a full XMPP server — just enough to satisfy the
// client's auth + bind handshake so it stops logging "Xmpp login failed".
// All routed messages (presence, party, chat) just get acked.
const XMPP_DOMAIN = "prod.ol.epicgames.com";

function xmppHandle(ws: ServerWebSocket<WsData>, frame: string) {
  // <open .../> -> stream start. Reply with our own <open/> + <features/>.
  if (frame.includes("<open ")) {
    const streamId = Math.random().toString(36).slice(2, 18);
    ws.send(
      `<open xmlns="urn:ietf:params:xml:ns:xmpp-framing" from="${XMPP_DOMAIN}" id="${streamId}" version="1.0" xml:lang="en"/>`
    );
    if (!ws.data.authed) {
      // Pre-auth features: SASL mechanisms.
      ws.send(
        `<stream:features xmlns:stream="http://etherx.jabber.org/streams"><mechanisms xmlns="urn:ietf:params:xml:ns:xmpp-sasl"><mechanism>PLAIN</mechanism></mechanisms></stream:features>`
      );
    } else {
      // Post-auth features: bind + session.
      ws.send(
        `<stream:features xmlns:stream="http://etherx.jabber.org/streams"><bind xmlns="urn:ietf:params:xml:ns:xmpp-bind"/><session xmlns="urn:ietf:params:xml:ns:xmpp-session"/></stream:features>`
      );
    }
    return;
  }

  // <auth ...>...</auth> -> SASL PLAIN. Always succeed.
  if (frame.includes("<auth ")) {
    // Try to extract the JID from the base64-encoded SASL payload (PLAIN is
    // \0<authzid>\0<password>). We don't validate; just remember the user.
    const innerMatch = frame.match(/<auth[^>]*>([^<]+)<\/auth>/);
    if (innerMatch?.[1]) {
      try {
        const decoded = Buffer.from(innerMatch[1], "base64").toString("utf8");
        const parts = decoded.split("\0");
        const user = parts[1] || "player";
        ws.data.jid = `${user}@${XMPP_DOMAIN}`;
      } catch {}
    }
    ws.data.authed = true;
    ws.send(`<success xmlns="urn:ietf:params:xml:ns:xmpp-sasl"/>`);
    return;
  }

  // <iq type="set" id="..."><bind><resource>...</resource></bind></iq>
  if (frame.includes("<bind")) {
    const idMatch = frame.match(/id="([^"]+)"/);
    const id = idMatch?.[1] ?? "1";
    const resMatch = frame.match(/<resource[^>]*>([^<]+)<\/resource>/);
    const resource = resMatch?.[1] ?? `V2:Fortnite:WIN::${Math.random().toString(16).slice(2, 10)}`;
    ws.data.resource = resource;
    const fullJid = `${(ws.data.jid ?? "player@" + XMPP_DOMAIN).split("/")[0]}/${resource}`;
    ws.data.jid = fullJid;
    ws.send(
      `<iq xmlns="jabber:client" id="${id}" type="result"><bind xmlns="urn:ietf:params:xml:ns:xmpp-bind"><jid>${fullJid}</jid></bind></iq>`
    );
    return;
  }

  // <iq><session/></iq> -> ack
  if (frame.includes("<session")) {
    const idMatch = frame.match(/id="([^"]+)"/);
    const id = idMatch?.[1] ?? "2";
    ws.send(`<iq xmlns="jabber:client" id="${id}" type="result"/>`);
    return;
  }

  // <iq type="get"><ping/></iq> -> pong
  if (frame.includes("<ping")) {
    const idMatch = frame.match(/id="([^"]+)"/);
    const id = idMatch?.[1] ?? "p";
    ws.send(`<iq xmlns="jabber:client" id="${id}" type="result"/>`);
    return;
  }

  // <presence/> -> echo back so the client thinks broadcast worked
  if (frame.includes("<presence")) {
    const fromJid = ws.data.jid ?? `player@${XMPP_DOMAIN}`;
    ws.send(`<presence xmlns="jabber:client" from="${fromJid}" to="${fromJid}"/>`);
    return;
  }

  // <iq type="get" id="..."><query xmlns="jabber:iq:roster"/></iq> -> empty roster
  if (frame.includes("jabber:iq:roster")) {
    const idMatch = frame.match(/id="([^"]+)"/);
    const id = idMatch?.[1] ?? "r";
    ws.send(`<iq xmlns="jabber:client" id="${id}" type="result"><query xmlns="jabber:iq:roster"/></iq>`);
    return;
  }

  // Generic <iq type="get"|"set"> with no specific handler -> empty result
  if (frame.includes("<iq ")) {
    const idMatch = frame.match(/id="([^"]+)"/);
    const id = idMatch?.[1] ?? "x";
    ws.send(`<iq xmlns="jabber:client" id="${id}" type="result"/>`);
    return;
  }
}

const server = Bun.serve<WsData, never>({
  port: config.PORT,
  hostname: config.HOST,
  fetch(req, srv) {
    const url = new URL(req.url);
    const upgradeHeader = req.headers.get("upgrade")?.toLowerCase();

    if (upgradeHeader === "websocket") {
      let data: WsData = { path: url.pathname, kind: "stub" };

      if (url.pathname === MM_PATH || url.pathname.startsWith(`${MM_PATH}/`)) {
        const authHeader = req.headers.get("authorization") ?? "";
        const ticket = verifyMmAuthHeader(authHeader);
        if (!ticket) {
          return new Response("invalid mm signature", { status: 401 });
        }
        data = { path: url.pathname, kind: "matchmaker", ticket };
      } else {
        // XMPP can hit either /xmpp explicitly or the rewritten xmpp-service-prod
        // host (root path) depending on hosts file routing. Detect by Sec-WebSocket-Protocol
        // = "xmpp" (Fortnite's client sends this) OR explicit path.
        const proto = (req.headers.get("sec-websocket-protocol") ?? "").toLowerCase();
        if (proto.includes("xmpp") || url.pathname === "/" || url.pathname.startsWith("/xmpp")) {
          data = { path: url.pathname, kind: "xmpp" };
        }
      }

      const ok = srv.upgrade(req, { data });
      if (ok) return undefined;
      return new Response("ws upgrade failed", { status: 400 });
    }

    return app.fetch(req, srv);
  },
  websocket: {
    open(ws) {
      console.log(`[ws] open ${ws.data.kind} ${ws.data.path}`);
      if (ws.data.kind === "matchmaker") {
        runMatchmakerFlow(ws).catch((err) => {
          console.error(`[mm] flow error:`, err);
          ws.close(1011, "mm error");
        });
        return;
      }
      if (ws.data.kind === "xmpp") {
        // XMPP clients send the first frame (open) — we don't push anything on connect.
        return;
      }
      // Stub: notifications/lobby/cerberus — accept + keep open.
      ws.send(JSON.stringify({ type: "connected", path: ws.data.path }));
    },
    message(ws, message) {
      if (ws.data.kind === "matchmaker") return;
      const text = typeof message === "string" ? message : message.toString();
      if (ws.data.kind === "xmpp") {
        try { xmppHandle(ws, text); } catch (e) { console.error("[xmpp]", e); }
        return;
      }
      if (text.includes("ping") || text === "PING") {
        ws.send("PONG");
      }
    },
    close(ws, code) {
      console.log(`[ws] close ${ws.data.kind} ${ws.data.path} (${code})`);
    },
    drain() {},
    idleTimeout: 0
  }
});

console.log(`RetroV1 listening on ${server.url}`);