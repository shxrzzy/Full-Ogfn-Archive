import type { Context } from "hono";

export type VersionInfo = {
  version: number;
  versionGlobal: number;
  versionLegacy: string;
  raw: string;
};

const DEFAULT_VERSION: VersionInfo = {
  version: 1.0,
  versionGlobal: 1,
  versionLegacy: "",
  raw: ""
};

function parseFromUserAgent(userAgent: string): VersionInfo {
  // Typical UA: "Fortnite/++Fortnite+Release-32.11-CL-37119230 Windows/..."
  const releaseMatch = userAgent.match(/Release-(\d+(?:\.\d+)?)/i);
  const clMatch = userAgent.match(/CL-([0-9]+)/i);

  if (releaseMatch?.[1]) {
    const version = Number.parseFloat(releaseMatch[1]) || DEFAULT_VERSION.version;
    return {
      version,
      versionGlobal: Math.trunc(version),
      versionLegacy: clMatch?.[1] ?? "",
      raw: userAgent
    };
  }

  // Fallback: any digits.digits sequence
  const loose = userAgent.match(/(\d+(?:\.\d+)?)/);
  if (loose?.[1]) {
    const version = Number.parseFloat(loose[1]) || DEFAULT_VERSION.version;
    return {
      version,
      versionGlobal: Math.trunc(version),
      versionLegacy: clMatch?.[1] ?? "",
      raw: userAgent
    };
  }

  return { ...DEFAULT_VERSION, raw: userAgent };
}

export function getVersionInfo(c: Context): VersionInfo {
  const fromStream = c.req.query("stream") ?? "";
  const fromHeader = c.req.header("user-agent") ?? "";

  const streamInfo = fromStream ? parseFromUserAgent(decodeURIComponent(fromStream)) : null;
  const headerInfo = fromHeader ? parseFromUserAgent(fromHeader) : null;

  if (streamInfo && headerInfo) {
    return streamInfo.version >= headerInfo.version ? streamInfo : headerInfo;
  }
  return streamInfo ?? headerInfo ?? DEFAULT_VERSION;
}

export function parseBuildFloat(input: string | null | undefined): number {
  if (!input) return 0;
  try {
    const decoded = decodeURIComponent(input);
    return parseFromUserAgent(decoded).version;
  } catch {
    return parseFromUserAgent(input).version;
  }
}
