import { createHmac, randomUUID } from "node:crypto";
import { config } from "../config";

// Shared signing key from the canonical 32.11 matchmaker — must match the key
// used in the ticket signer AND the WebSocket verifier, otherwise the game
// rejects the connection during handshake.
const MM_SIGNING_KEY = "ed14ba700b1aeb4103b457c2a43028e0";

export type TicketPayload = {
  accountId: string;
  displayName: string;
  bucketId: string;
  partyPlayerIds: string;
  fillTeam: string;
  playlist: string;
  region: string;
  buildUniqueId: string;
  exp: number;
};

function base64UrlEncode(buf: Buffer): string {
  return buf.toString("base64").replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function base64UrlDecode(value: string): Buffer {
  const padded = value
    .replace(/-/g, "+")
    .replace(/_/g, "/")
    .padEnd(value.length + ((4 - (value.length % 4)) % 4), "=");
  return Buffer.from(padded, "base64");
}

export function signMmPayload(payload: TicketPayload): { payloadB64: string; signature: string } {
  const json = JSON.stringify(payload);
  const payloadB64 = base64UrlEncode(Buffer.from(json, "utf8"));
  const sig = createHmac("sha256", MM_SIGNING_KEY).update(payloadB64).digest();
  return { payloadB64, signature: base64UrlEncode(sig) };
}

export function verifyMmAuthHeader(authHeader: string): TicketPayload | null {
  // Header format: "Epic-Signed mms-player <payload_b64> <signature_b64>"
  const parts = authHeader.split(" ");
  if (parts.length < 4) return null;

  const payloadB64 = parts[2];
  const signatureB64 = parts[3];
  if (!payloadB64 || !signatureB64) return null;

  const expectedSig = createHmac("sha256", MM_SIGNING_KEY).update(payloadB64).digest();
  let provided: Buffer;
  try {
    provided = base64UrlDecode(signatureB64);
  } catch {
    return null;
  }

  if (provided.length !== expectedSig.length) return null;
  let mismatch = 0;
  for (let i = 0; i < expectedSig.length; i++) {
    mismatch |= expectedSig[i]! ^ provided[i]!;
  }
  if (mismatch !== 0) return null;

  try {
    const payload = JSON.parse(base64UrlDecode(payloadB64).toString("utf8")) as TicketPayload;
    const nowSec = Math.floor(Date.now() / 1000);
    if (typeof payload.exp === "number" && payload.exp < nowSec) return null;
    return payload;
  } catch {
    return null;
  }
}

export function buildTicketResponse(accountId: string, displayName: string, bucketId: string, partyPlayerIds: string, fillTeam: string) {
  // bucketId format: <buildUniqueId>:<unused>:<region>:<playlist>
  const state = rememberTicketContext(accountId, bucketId);

  const payload: TicketPayload = {
    accountId,
    displayName,
    bucketId,
    partyPlayerIds,
    fillTeam,
    playlist: state.playlist,
    region: state.region,
    buildUniqueId: state.buildUniqueId,
    exp: Math.floor(Date.now() / 1000) + 5 * 60
  };

  const { payloadB64, signature } = signMmPayload(payload);

  return {
    serviceUrl: config.MATCHMAKER_IP,
    ticketType: "mms-player",
    payload: payloadB64,
    signature
  };
}

export function newTicketId(): string {
  return randomUUID();
}

export function newMatchId(): string {
  return randomUUID();
}

export function newSessionId(): string {
  return randomUUID().replace(/-/g, "");
}

type GameServer = { ip: string; port: number; playlist: string };

function parseGameServers(): GameServer[] {
  const raw = config.GAMESERVERS ?? "";
  return raw
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean)
    .map((entry) => {
      const parts = entry.split(":");
      return {
        ip: parts[0] ?? "127.0.0.1",
        port: Number.parseInt(parts[1] ?? "7777", 10) || 7777,
        playlist: (parts[2] ?? "").toLowerCase()
      };
    });
}

export function gameServerParts(playlist?: string): { ip: string; port: number } {
  const all = parseGameServers();
  if (all.length > 0) {
    if (playlist) {
      const match = all.find((s) => s.playlist === playlist.toLowerCase());
      if (match) return { ip: match.ip, port: match.port };
    }
    const first = all[0]!;
    return { ip: first.ip, port: first.port };
  }
  // Legacy single-server fallback.
  const raw = config.GAMESERVER_IP ?? "127.0.0.1:7777";
  const lastColon = raw.lastIndexOf(":");
  if (lastColon === -1) return { ip: raw, port: 7777 };
  return {
    ip: raw.slice(0, lastColon),
    port: Number.parseInt(raw.slice(lastColon + 1), 10) || 7777
  };
}

// Tiny in-memory map populated when the client requests a ticket. The session
// lookup needs the same buildUniqueId the client sent in its bucketId,
// otherwise the game treats the assigned session as belonging to a different
// build and shows "Session has expired".
type MmAccountState = {
  buildUniqueId: string;
  playlist: string;
  region: string;
};

const MM_STATE = new Map<string, MmAccountState>();

export function rememberTicketContext(accountId: string, bucketId: string): MmAccountState {
  const segments = bucketId.split(":");
  const state: MmAccountState = {
    buildUniqueId: segments[0] ?? "0",
    region: segments[2] ?? "EU",
    playlist: segments[3] ?? "Playlist_DefaultSolo"
  };
  MM_STATE.set(accountId, state);
  return state;
}

export function recallTicketContext(accountId: string): MmAccountState | null {
  return MM_STATE.get(accountId) ?? null;
}
