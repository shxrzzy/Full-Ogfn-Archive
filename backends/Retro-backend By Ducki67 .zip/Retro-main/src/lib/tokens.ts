import { createSecretKey } from "node:crypto";
import { SignJWT, jwtVerify } from "jose";
import { config } from "../config";

type AccessTokenPayload = {
  sub: string;
  dn: string;
  clid: string;
  am: string;
};

const TOKEN_ISSUER = "retrov1";
const TOKEN_AUDIENCE = "fortnite";

const key = createSecretKey(new TextEncoder().encode(config.JWT_SECRET));

export async function signAccessToken(payload: AccessTokenPayload): Promise<string> {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuer(TOKEN_ISSUER)
    .setAudience(TOKEN_AUDIENCE)
    .setIssuedAt()
    .setExpirationTime("24h")
    .sign(key);
}

export async function verifyAccessToken(token: string): Promise<AccessTokenPayload> {
  const verified = await jwtVerify(token, key, {
    issuer: TOKEN_ISSUER,
    audience: TOKEN_AUDIENCE
  });

  return verified.payload as AccessTokenPayload;
}

export function readBearerToken(headerValue: string | undefined): string | null {
  if (!headerValue) return null;
  const value = headerValue.trim();
  if (!value.toLowerCase().startsWith("bearer ")) return null;
  return value.slice(7);
}