import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { config } from "../config";

type JsonRecord = Record<string, unknown>;

function nowIso(): string {
  return new Date().toISOString();
}

function cloneJson<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

async function readJsonFile<T>(filePath: string, fallback: T): Promise<T> {
  try {
    const raw = await readFile(filePath, "utf-8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

async function writeJsonFile<T>(filePath: string, data: T): Promise<void> {
  await mkdir(dirname(filePath), { recursive: true });
  await writeFile(filePath, JSON.stringify(data, null, 2), "utf-8");
}

export function normalizeAccountId(accountId: string): string {
  const normalized = accountId.trim().replace(/[^A-Za-z0-9_-]/g, "_").slice(0, 64);
  return normalized.length > 0 ? normalized : "Player";
}

function profilePath(accountId: string, profileId: string): string {
  return join(process.cwd(), "data", "profiles", accountId, `profile_${profileId}.json`);
}

function lockerPath(accountId: string, version: 3 | 4): string {
  return join(process.cwd(), "data", "profiles", accountId, `lockerv${version}.json`);
}

async function readTemplate(filename: string): Promise<JsonRecord> {
  const templatePath = join(process.cwd(), "config", "profiles", filename);
  return readJsonFile<JsonRecord>(templatePath, {});
}

function stampProfile(profile: JsonRecord, accountId: string, profileId: string): JsonRecord {
  const stamped = cloneJson(profile);
  stamped._id = accountId;
  stamped.accountId = accountId;
  stamped.profileId = profileId;
  if (typeof stamped.created !== "string" || !stamped.created) stamped.created = nowIso();
  stamped.updated = nowIso();
  if (typeof stamped.rvn !== "number") stamped.rvn = 1;
  if (typeof stamped.commandRevision !== "number") stamped.commandRevision = 1;
  return stamped;
}

export async function ensureProfile(accountIdInput: string, profileId: string): Promise<JsonRecord> {
  const accountId = normalizeAccountId(accountIdInput);
  const path = profilePath(accountId, profileId);
  const existing = await readJsonFile<JsonRecord | null>(path, null);
  if (existing) {
    return existing;
  }

  const template = await readTemplate(`profile_${profileId}.json`);
  const profile = stampProfile(template, accountId, profileId);
  await writeJsonFile(path, profile);
  return profile;
}

export async function saveProfile(accountIdInput: string, profileId: string, profile: JsonRecord): Promise<void> {
  const accountId = normalizeAccountId(accountIdInput);
  profile.updated = nowIso();
  await writeJsonFile(profilePath(accountId, profileId), profile);
}

export function bumpProfile(profile: JsonRecord): void {
  const rvn = typeof profile.rvn === "number" ? profile.rvn : 0;
  const commandRevision = typeof profile.commandRevision === "number" ? profile.commandRevision : 0;
  profile.rvn = rvn + 1;
  profile.commandRevision = commandRevision + 1;
  profile.updated = nowIso();
}

export async function ensureBaseProfiles(accountIdInput: string): Promise<void> {
  const accountId = normalizeAccountId(accountIdInput);
  await ensureProfile(accountId, "athena");
  await ensureProfile(accountId, "common_core");
  await ensureProfile(accountId, "collections");

  await seedEconomyDefaults(accountId);

  if (config.GET_EVERY_COSMETIC) {
    await ensureExpandedAthenaProfile(accountId);
    await ensureLocker(accountId, 3);
    await ensureLocker(accountId, 4);
  }
}

async function seedEconomyDefaults(accountId: string): Promise<void> {
  const commonCore = await ensureProfile(accountId, "common_core");
  const items = (commonCore.items as JsonRecord | undefined) ?? {};
  commonCore.items = items;

  const vbucksTemplateId = "Currency:MtxPurchased";
  const currentVbucks = items[vbucksTemplateId] as JsonRecord | undefined;
  if (!currentVbucks) {
    items[vbucksTemplateId] = {
      templateId: vbucksTemplateId,
      quantity: config.STARTER_VBUCKS,
      attributes: {
        platform: "EpicPC"
      }
    };
  } else {
    currentVbucks.templateId = vbucksTemplateId;
    currentVbucks.quantity = config.STARTER_VBUCKS;
  }

  if (config.GOLD_AMOUNT > 0) {
    const goldTemplateId = "Currency:Gold";
    const currentGold = items[goldTemplateId] as JsonRecord | undefined;
    if (!currentGold) {
      items[goldTemplateId] = {
        templateId: goldTemplateId,
        quantity: config.GOLD_AMOUNT,
        attributes: {}
      };
    } else {
      currentGold.templateId = goldTemplateId;
      currentGold.quantity = config.GOLD_AMOUNT;
    }
  }

  await saveProfile(accountId, "common_core", commonCore);
}

async function ensureExpandedAthenaProfile(accountId: string): Promise<void> {
  const current = await ensureProfile(accountId, "athena");
  const currentItems = (current.items as JsonRecord | undefined) ?? {};
  const currentCount = Object.keys(currentItems).length;

  const template = await readTemplate("profile_athena.json");
  const templateItems = (template.items as JsonRecord | undefined) ?? {};
  const templateCount = Object.keys(templateItems).length;

  if (templateCount < 100 || currentCount >= templateCount) {
    return;
  }

  const expanded = stampProfile(template, accountId, "athena");
  await saveProfile(accountId, "athena", expanded);
}

function stampLocker(locker: JsonRecord, accountId: string): JsonRecord {
  const stamped = cloneJson(locker);
  const time = nowIso();

  const activeLoadoutGroup = stamped.activeLoadoutGroup as JsonRecord | undefined;
  if (activeLoadoutGroup) {
    activeLoadoutGroup.accountId = accountId;
    activeLoadoutGroup.creationTime = activeLoadoutGroup.creationTime || time;
    activeLoadoutGroup.updatedTime = time;
  }

  const activeLoadouts = stamped.activeLoadouts as Array<JsonRecord> | undefined;
  if (Array.isArray(activeLoadouts)) {
    for (const entry of activeLoadouts) {
      entry.accountId = accountId;
      entry.creationTime = entry.creationTime || time;
      entry.updatedTime = time;
    }
  }

  return stamped;
}

export async function ensureLocker(accountIdInput: string, version: 3 | 4): Promise<JsonRecord> {
  const accountId = normalizeAccountId(accountIdInput);
  const path = lockerPath(accountId, version);
  const existing = await readJsonFile<JsonRecord | null>(path, null);
  if (existing) {
    return existing;
  }

  const template = await readTemplate(`lockerv${version}.json`);
  const locker = stampLocker(template, accountId);
  await writeJsonFile(path, locker);
  return locker;
}

export async function saveLocker(accountIdInput: string, version: 3 | 4, locker: JsonRecord): Promise<void> {
  const accountId = normalizeAccountId(accountIdInput);
  await writeJsonFile(lockerPath(accountId, version), locker);
}
