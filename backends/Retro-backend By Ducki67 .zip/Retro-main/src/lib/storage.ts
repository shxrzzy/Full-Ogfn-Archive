import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import type { AccountRecord } from "../types";

const dataDir = join(process.cwd(), "data");
const accountsPath = join(dataDir, "accounts.json");

async function readJsonFile<T>(filePath: string, fallback: T): Promise<T> {
  try {
    const raw = await readFile(filePath, "utf-8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

async function writeJsonFile<T>(filePath: string, data: T): Promise<void> {
  await mkdir(dirname(filePath), { recursive: true });
  await writeFile(filePath, JSON.stringify(data, null, 2), "utf-8");
}

export async function getAccounts(): Promise<Record<string, AccountRecord>> {
  return readJsonFile<Record<string, AccountRecord>>(accountsPath, {});
}

export async function upsertAccount(accountId: string, displayName: string): Promise<AccountRecord> {
  const now = new Date().toISOString();
  const accounts = await getAccounts();
  const existing = accounts[accountId];

  const record: AccountRecord = {
    accountId,
    displayName,
    createdAt: existing?.createdAt ?? now,
    lastLoginAt: now
  };

  accounts[accountId] = record;
  await writeJsonFile(accountsPath, accounts);
  return record;
}

export async function getAccount(accountId: string): Promise<AccountRecord | null> {
  const accounts = await getAccounts();
  return accounts[accountId] ?? null;
}