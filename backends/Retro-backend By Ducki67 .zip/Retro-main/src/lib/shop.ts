import { readJsonAsset } from "./assets";

type ShopItem = {
  id: string;
  templateId: string;
  price: number;
  displayAssetPath?: string;
  section?: string;
  displayName?: string;
};
type BundleItem = { templateId: string; quantity: number };
type ShopBundle = {
  id: string;
  displayName: string;
  price: number;
  items: BundleItem[];
  displayAssetPath?: string;
  section?: string;
  // When true (default), also emit each bundle item as an individual catalog
  // entry in the same section so players can buy single items à la carte.
  emitIndividualItems?: boolean;
  // Per-item individual prices when emitted alone. Defaults below.
  individualPriceDefaults?: { character?: number; pickaxe?: number; glider?: number; backpack?: number; wrap?: number; dance?: number; other?: number };
};

type ShopConfig = {
  // Legacy rotator pools (still supported if shopv3 is missing).
  dailyPickCount?: number;
  featuredPickCount?: number;
  dailyPool?: ShopItem[];
  featuredPool?: ShopItem[];
  // New customization layer on top of shopv3.
  bundleRotationCount?: number;
  bundlePool?: ShopBundle[];
  bundles?: ShopBundle[];
  extraOffers?: ShopItem[];
  hideOfferIds?: string[];
  // Hide entire shopv3 sections by AnalyticOfferGroupId (e.g. "IronSpider", "Deadpool&Wolverine").
  hideSectionIds?: string[];
  priceOverrides?: Record<string, number>;
};

type CatalogEntry = Record<string, unknown> & {
  offerId?: string;
  prices?: Array<Record<string, unknown> & { regularPrice?: number; finalPrice?: number; basePrice?: number }>;
};
type Storefront = { name: string; catalogEntries: CatalogEntry[] };
type Catalog = { storefronts: Storefront[]; [k: string]: unknown };

// --- helpers ----------------------------------------------------------------

function seededShuffle<T>(arr: T[], seed: number): T[] {
  const copy = [...arr];
  let s = seed;
  for (let i = copy.length - 1; i > 0; i--) {
    s = (s * 9301 + 49297) % 233280;
    const j = Math.floor((s / 233280) * (i + 1));
    [copy[i], copy[j]] = [copy[j]!, copy[i]!];
  }
  return copy;
}

function todaySeed(): number {
  const d = new Date();
  return d.getUTCFullYear() * 10000 + (d.getUTCMonth() + 1) * 100 + d.getUTCDate();
}

function deriveDisplayAssetPath(templateId: string, section: "Daily" | "Featured" = "Featured"): string {
  const name = templateId.split(":")[1] ?? templateId;
  const prefix = section === "Daily" ? "DA_Daily" : "DA_Featured";
  return `/Game/Catalog/DisplayAssets/${prefix}_${name}.${prefix}_${name}`;
}

// --- entry builders ---------------------------------------------------------

function buildItemEntry(entry: ShopItem, _defaultSection: "Daily" | "Featured", sortPriority: number): CatalogEntry {
  // 32.11 shop UI buckets entries by meta.AnalyticOfferGroupId (the section ID)
  // and orders them via meta.LayoutId = "<sectionId>.<priority>". categories
  // and meta.SectionId are IGNORED by the UI. Section must exist in
  // mpItemShop.shopData.sections — Spotlight, IronSpider, Marvel, FNCS,
  // ChampionsRoad, WheelsAndBoosts, WrapShop, etc.
  const sectionId = entry.section ?? "Spotlight";
  const layoutPriority = 99 - (sortPriority % 99); // higher number = higher in UI
  const itemName = entry.templateId.split(":")[1] ?? entry.templateId;
  const displayAssetPath =
    entry.displayAssetPath ??
    `/Game/Catalog/DisplayAssets/DA_Featured_${itemName}.DA_Featured_${itemName}`;
  const newDisplayAssetPath = `/Game/Catalog/NewDisplayAssets/DAv2_${itemName}.DAv2_${itemName}`;

  return {
    devName: `[VIRTUAL]1 x ${itemName} for ${entry.price} MtxCurrency`,
    offerId: `v2:/${entry.id}`,
    fulfillmentIds: [],
    dailyLimit: -1,
    weeklyLimit: -1,
    monthlyLimit: -1,
    categories: [],
    prices: [
      {
        currencyType: "MtxCurrency",
        currencySubType: "",
        regularPrice: entry.price,
        dynamicRegularPrice: entry.price,
        finalPrice: entry.price,
        saleExpiration: "9999-12-31T23:59:59.999Z",
        basePrice: entry.price
      }
    ],
    meta: {
      NewDisplayAssetPath: newDisplayAssetPath,
      LayoutId: `${sectionId}.${layoutPriority}`,
      TileSize: "Size_1_x_1",
      AnalyticOfferGroupId: sectionId,
      templateId: entry.templateId,
      inDate: "2020-01-01T00:00:00.000Z",
      outDate: "9999-12-31T23:59:59.999Z",
      displayAssetPath
    },
    matchFilter: "",
    filterWeight: 0,
    appStoreId: [],
    requirements: [],
    offerType: "StaticPrice",
    giftInfo: { bIsEnabled: true, forcedGiftBoxTemplateId: "", purchaseRequirements: [], giftRecordIds: [] },
    refundable: true,
    metaInfo: [
      { key: "NewDisplayAssetPath", value: newDisplayAssetPath },
      { key: "LayoutId", value: `${sectionId}.${layoutPriority}` },
      { key: "TileSize", value: "Size_1_x_1" },
      { key: "AnalyticOfferGroupId", value: sectionId },
      { key: "templateId", value: entry.templateId },
      { key: "displayAssetPath", value: displayAssetPath }
    ],
    displayAssetPath,
    itemGrants: [{ templateId: entry.templateId, quantity: 1 }],
    sortPriority,
    catalogGroupPriority: 0,
    title: entry.displayName ?? itemName
  };
}

function buildBundleEntry(bundle: ShopBundle, sortPriority: number): CatalogEntry {
  const sectionId = bundle.section ?? "Spotlight";
  const layoutPriority = 99 - (sortPriority % 99);

  // Bundle tile background — derive from the bundle's first character (or any
  // cosmetic) so the build's pak file actually has the asset. Our own bundle
  // IDs (`bundle.ducki67_locker`, etc.) don't have shipped display assets.
  const hero =
    bundle.items.find((it) => it.templateId.startsWith("AthenaCharacter:"))?.templateId ??
    bundle.items.find((it) => /^Athena(Pickaxe|Glider|Backpack|Dance):/.test(it.templateId))?.templateId ??
    bundle.items[0]?.templateId ?? "";
  const heroName = hero.split(":")[1] ?? "";
  const displayAssetPath =
    bundle.displayAssetPath ??
    (heroName
      ? `/Game/Catalog/DisplayAssets/DA_Featured_${heroName}.DA_Featured_${heroName}`
      : `/Game/Catalog/DisplayAssets/DA_Featured_${bundle.id}.DA_Featured_${bundle.id}`);
  const newDisplayAssetPath = heroName
    ? `/Game/Catalog/NewDisplayAssets/DAv2_${heroName}.DAv2_${heroName}`
    : "";

  return {
    devName: `[VIRTUAL] Bundle ${bundle.displayName} for ${bundle.price} MtxCurrency`,
    offerId: `v2:/${bundle.id}`,
    fulfillmentIds: [],
    dailyLimit: -1,
    weeklyLimit: -1,
    monthlyLimit: -1,
    categories: [],
    prices: [
      {
        currencyType: "MtxCurrency",
        currencySubType: "",
        regularPrice: bundle.price,
        dynamicRegularPrice: bundle.price,
        finalPrice: bundle.price,
        saleExpiration: "9999-12-31T23:59:59.999Z",
        basePrice: bundle.price
      }
    ],
    meta: {
      NewDisplayAssetPath: newDisplayAssetPath,
      LayoutId: `${sectionId}.${layoutPriority}`,
      TileSize: "Size_2_x_2",
      AnalyticOfferGroupId: sectionId,
      bundleName: bundle.displayName,
      templateId: hero,
      inDate: "2020-01-01T00:00:00.000Z",
      outDate: "9999-12-31T23:59:59.999Z",
      displayAssetPath
    },
    matchFilter: "",
    filterWeight: 0,
    appStoreId: [],
    requirements: [],
    offerType: "StaticPrice",
    bundle: { bundleName: bundle.displayName, bundleItemId: bundle.id, regularBasePrice: bundle.price },
    giftInfo: { bIsEnabled: true, forcedGiftBoxTemplateId: "", purchaseRequirements: [], giftRecordIds: [] },
    refundable: true,
    metaInfo: [
      { key: "NewDisplayAssetPath", value: newDisplayAssetPath },
      { key: "LayoutId", value: `${sectionId}.${layoutPriority}` },
      { key: "TileSize", value: "Size_2_x_1" },
      { key: "AnalyticOfferGroupId", value: sectionId },
      { key: "templateId", value: hero },
      { key: "displayAssetPath", value: displayAssetPath }
    ],
    displayAssetPath,
    itemGrants: bundle.items,
    sortPriority,
    catalogGroupPriority: 0,
    title: bundle.displayName
  };
}

// --- main builders ----------------------------------------------------------

async function loadConfig(): Promise<ShopConfig> {
  const cfg = await readJsonAsset<ShopConfig | null>(["config", "shop.json"], null);
  return cfg ?? {};
}

/**
 * Reload-style customization layer. Loads the canonical shopv3 from disk,
 * applies hides, price overrides, extra offers, and rotated bundles, returns
 * the merged catalog. Falls back to a pure rotator-built catalog if shopv3 is
 * missing.
 */
export async function buildCustomShop(): Promise<Catalog> {
  const base = await readJsonAsset<Catalog | null>(["responses", "catalog", "shopv3.json"], null);
  const cfg = await loadConfig();

  if (!base || !Array.isArray(base.storefronts) || base.storefronts.length === 0) {
    return buildRotatedShop();
  }

  // Deep-ish clone storefronts so per-request mutations never leak.
  const storefronts: Storefront[] = base.storefronts.map((sf) => ({
    name: sf.name,
    catalogEntries: sf.catalogEntries.map((e) => ({ ...e, prices: e.prices ? e.prices.map((p) => ({ ...p })) : [] }))
  }));

  const hide = new Set(cfg.hideOfferIds ?? []);
  const hideSections = new Set((cfg.hideSectionIds ?? []).map((s) => s.toLowerCase()));
  const overrides = cfg.priceOverrides ?? {};

  for (const sf of storefronts) {
    sf.catalogEntries = sf.catalogEntries.filter((e) => {
      if (hide.has(String(e.offerId ?? ""))) return false;
      const meta = (e.meta ?? {}) as Record<string, unknown>;
      const sectionId = typeof meta.AnalyticOfferGroupId === "string" ? meta.AnalyticOfferGroupId.toLowerCase() : "";
      if (sectionId && hideSections.has(sectionId)) return false;
      return true;
    });
    for (const entry of sf.catalogEntries) {
      const ov = overrides[String(entry.offerId ?? "")];
      if (typeof ov === "number" && Array.isArray(entry.prices)) {
        for (const p of entry.prices) {
          p.regularPrice = ov;
          p.finalPrice = ov;
          p.basePrice = ov;
        }
      }
    }
  }

  // Append extra offers to the first storefront (BRWeeklyStorefront by convention).
  const extras = cfg.extraOffers ?? [];
  if (extras.length > 0 && storefronts[0]) {
    const startPriority = storefronts[0].catalogEntries.length;
    for (const [i, item] of extras.entries()) {
      storefronts[0].catalogEntries.push(buildItemEntry(item, "Featured", startPriority + i));
    }
  }

  // Bundles — rotate today's picks from bundlePool, plus always include fixed `bundles`.
  const fixedBundles = cfg.bundles ?? [];
  const pool = cfg.bundlePool ?? [];
  const rotateCount = Math.max(0, Math.min(pool.length, cfg.bundleRotationCount ?? 0));
  const todaysBundles = rotateCount > 0
    ? seededShuffle(pool, todaySeed() + 13).slice(0, rotateCount)
    : [];
  const allBundles = [...fixedBundles, ...todaysBundles];

  // Per-item-type defaults for à la carte pricing when items get split from bundles.
  const defaultIndividualPrices = { character: 1500, pickaxe: 800, glider: 800, backpack: 600, wrap: 300, dance: 500, other: 500 };
  function pricePerItem(templateId: string, overrides?: ShopBundle["individualPriceDefaults"]): number {
    const merged = { ...defaultIndividualPrices, ...(overrides ?? {}) };
    if (templateId.startsWith("AthenaCharacter:")) return merged.character;
    if (templateId.startsWith("AthenaPickaxe:")) return merged.pickaxe;
    if (templateId.startsWith("AthenaGlider:")) return merged.glider;
    if (templateId.startsWith("AthenaBackpack:")) return merged.backpack;
    if (templateId.startsWith("AthenaItemWrap:")) return merged.wrap;
    if (templateId.startsWith("AthenaDance:")) return merged.dance;
    return merged.other;
  }

  if (allBundles.length > 0) {
    const bundleEntries = allBundles.map((b, i) => buildBundleEntry(b, i));
    // Inject the bundle into its target section. Add the bundle to the FIRST
    // storefront so its meta.AnalyticOfferGroupId drives where the UI shows it.
    if (storefronts[0]) {
      storefronts[0].catalogEntries.push(...bundleEntries);

      // Auto-emit each bundle item as an individual offer in the same section,
      // priced via the type-default table. Skip Currency: items (can't sell).
      const seenOfferIds = new Set<string>();
      let priority = storefronts[0].catalogEntries.length;
      for (const bundle of allBundles) {
        if (bundle.emitIndividualItems === false) continue;
        for (const grant of bundle.items) {
          if (grant.templateId.startsWith("Currency:")) continue;
          const itemId = `${bundle.section ?? "Spotlight"}.solo.${grant.templateId.split(":")[1] ?? grant.templateId}`.toLowerCase();
          if (seenOfferIds.has(itemId)) continue;
          seenOfferIds.add(itemId);
          storefronts[0].catalogEntries.push(
            buildItemEntry(
              {
                id: itemId,
                templateId: grant.templateId,
                price: pricePerItem(grant.templateId, bundle.individualPriceDefaults),
                section: bundle.section ?? "Spotlight"
              },
              "Featured",
              priority++
            )
          );
        }
      }
    } else {
      storefronts.push({ name: "BRBundlesStorefront", catalogEntries: bundleEntries });
    }
  }

  return {
    ...base,
    storefronts,
    refreshIntervalHrs: (base as Record<string, unknown>).refreshIntervalHrs ?? 24,
    dailyPurchaseHrs: (base as Record<string, unknown>).dailyPurchaseHrs ?? 24,
    expiration: new Date(Date.now() + 30_000).toISOString()
  };
}

/**
 * Pure rotator catalog (no shopv3 base). Used when shopv3 is missing or for
 * environments that want only the small config-defined shop.
 */
export async function buildRotatedShop(): Promise<Catalog> {
  const cfg = await loadConfig();
  const dailyPool = cfg.dailyPool ?? [];
  const featuredPool = cfg.featuredPool ?? [];
  const bundles = [
    ...(cfg.bundles ?? []),
    ...seededShuffle(cfg.bundlePool ?? [], todaySeed() + 13).slice(0, cfg.bundleRotationCount ?? 0)
  ];
  const dailyN = Math.max(0, Math.min(dailyPool.length, cfg.dailyPickCount ?? 6));
  const featuredN = Math.max(0, Math.min(featuredPool.length, cfg.featuredPickCount ?? 4));

  const seed = todaySeed();
  const dailyPicks = seededShuffle(dailyPool, seed).slice(0, dailyN);
  const featuredPicks = seededShuffle(featuredPool, seed + 7).slice(0, featuredN);

  return {
    refreshIntervalHrs: 24,
    dailyPurchaseHrs: 24,
    expiration: new Date(Date.now() + 30_000).toISOString(),
    storefronts: [
      { name: "BRWeeklyStorefront", catalogEntries: featuredPicks.map((e, i) => buildItemEntry(e, "Featured", i)) },
      { name: "BRDailyStorefront", catalogEntries: dailyPicks.map((e, i) => buildItemEntry(e, "Daily", i)) },
      { name: "BRBundlesStorefront", catalogEntries: bundles.map((b, i) => buildBundleEntry(b, i)) },
      { name: "BRSeason32", catalogEntries: [] }
    ]
  };
}
