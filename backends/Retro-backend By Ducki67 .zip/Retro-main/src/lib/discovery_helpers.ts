import { readJsonAsset } from "./assets";

export type DiscoveryEntry = {
  namespace?: string;
  accountId?: string;
  creatorName?: string;
  mnemonic: string;
  linkType: string;
  metadata: Record<string, unknown>;
  version: number;
  active: boolean;
  disabled: boolean;
  created?: string;
  published?: string;
  descriptionTags?: string[];
  moderationStatus?: string;
  lastActivatedDate?: string;
  discoveryIntent?: string;
  linkState?: string;
};

// Hand-picked lobby backgrounds for entries whose `image_url` is a flat tile
// (e.g. set_br_playlists points at the "BATTLE ROYALE" text tile, which looks
// terrible when stretched to fill the lobby). Uses the canonical 32.11 lobby
// keyart (3264x1836) for all BR variants.
const LOBBY_BG_OVERRIDES: Record<string, string> = {
  set_br_playlists:
    "https://cdn2.unrealengine.com/mkart-fnbr-quail-lobby-3264x1836-b157b2252db6.jpg",
  playlist_defaultsolo:
    "https://cdn2.unrealengine.com/mkart-fnbr-quail-lobby-3264x1836-b157b2252db6.jpg",
  playlist_defaultduo:
    "https://cdn2.unrealengine.com/mkart-fnbr-quail-lobby-3264x1836-b157b2252db6.jpg",
  playlist_trios:
    "https://cdn2.unrealengine.com/mkart-fnbr-quail-lobby-3264x1836-b157b2252db6.jpg",
  playlist_defaultsquad:
    "https://cdn2.unrealengine.com/mkart-fnbr-quail-lobby-3264x1836-b157b2252db6.jpg",
  // Reload mode (set_blastberry_playlists) — use the proper blastberry lobby art
  // instead of the "RELOAD" tile graphic that's its image_url.
  set_blastberry_playlists:
    "https://cdn2.unrealengine.com/blastberry-lobby-bg-final-notext-2560x1440-788db0478027.jpg"
};

// Version -> mnemonics to activate.
// Each entry flips the matching playlist to active:true / disabled:false when
// the request's reported build matches the key exactly.
export const PLAYLIST_MANAGER: Record<string, string[]> = {
  "27.11": ["playlist_durian"],
  "32.11": ["playlist_quail"],
  "35.20": ["playlist_ripehoneydew"],
  "37.51": ["playlist_limerock"],
  "38.11": ["playlist_skymango"]
};

export function setPlaylistActive(
  entries: DiscoveryEntry[],
  mnemonic: string,
  active: boolean,
  disabled: boolean
): void {
  const target = entries.find((entry) => entry.mnemonic === mnemonic);
  if (!target) return;
  target.active = active;
  target.disabled = disabled;
}

export function updateMnemonicMetadata(
  entries: DiscoveryEntry[],
  mnemonic: string,
  metadata: Record<string, unknown>
): void {
  const target = entries.find((entry) => entry.mnemonic === mnemonic);
  if (!target) return;
  target.metadata = { ...(target.metadata ?? {}), ...metadata };
}

function pickFigmentSeason(version: number): number | null {
  if (version >= 33.0 && version <= 33.2) return 1;
  if (version >= 33.3 && version <= 34.1) return 2;
  if (version >= 34.2 && version <= 35.2) return 3;
  if (version >= 36.0 && version <= 36.3) return 4;
  if (version >= 37.0 && version <= 37.31) return 5;
  if (version >= 37.4 && version <= 39.0) return 6;
  if (version >= 39.1) return 7;
  return null;
}

export async function applyFigmentOverwrite(
  entries: DiscoveryEntry[],
  version: number
): Promise<void> {
  const season = pickFigmentSeason(version);
  if (season === null) return;

  const overwrite = await readJsonAsset<Record<string, unknown> | null>(
    ["discovery", "mnemonic_overwrite", "figment", `season${season}.json`],
    null
  );
  if (!overwrite) return;

  updateMnemonicMetadata(entries, "set_figment_playlists", overwrite);
}

export async function loadDiscoveryMenuV2(): Promise<DiscoveryEntry[]> {
  const raw = await readJsonAsset<DiscoveryEntry[]>(
    ["discovery", "discoveryMenuV2.json"],
    []
  );
  // Defensive clone so per-request mutations never leak into the shared cache.
  return raw.map((entry) => {
    const metadata = { ...(entry.metadata ?? {}) } as Record<string, unknown>;

    // Pick a lobby background. Priority:
    //   1. Existing lobby_background_image_urls in the JSON
    //   2. Hand-picked override (BR variants get the canonical 32.11 keyart)
    //   3. image_url fallback (works fine for event playlists whose tile IS the keyart)
    if (!metadata.lobby_background_image_urls) {
      const override = LOBBY_BG_OVERRIDES[entry.mnemonic];
      const imageUrl =
        typeof metadata.image_url === "string" ? metadata.image_url : null;
      const fallbackUrl =
        override ??
        imageUrl ??
        (typeof (metadata.background_image_urls as Record<string, unknown>)?.url === "string"
          ? ((metadata.background_image_urls as Record<string, unknown>).url as string)
          : null);
      if (fallbackUrl) {
        metadata.lobby_background_image_urls = { url: fallbackUrl };
      }
    }

    return { ...entry, metadata };
  });
}

export async function loadDiscoveryMenuV1(): Promise<Record<string, unknown>> {
  return readJsonAsset<Record<string, unknown>>(
    ["discovery", "discoveryMenuV1.json"],
    { Panels: [] }
  );
}

// Apply all version-aware activations + metadata mutations to a fresh menu copy.
export async function buildDiscoveryForVersion(
  version: number,
  versionGlobal: number
): Promise<DiscoveryEntry[]> {
  const entries = await loadDiscoveryMenuV2();

  if (version >= 23.0) {
    if (version >= 33.0) {
      setPlaylistActive(entries, "set_figment_playlists", true, false);
      await applyFigmentOverwrite(entries, version);
    }
    if (version >= 30.2) setPlaylistActive(entries, "set_blastberry_playlists", true, false);
    if (version >= 36.1) setPlaylistActive(entries, "set_forbiddenfruit_nobuild_playlists", true, false);
    if (version >= 37.31) setPlaylistActive(entries, "playlist_stridemice", true, false);

    const versionKey = version.toFixed(2);
    const exactMatches = PLAYLIST_MANAGER[versionKey];
    if (exactMatches) {
      for (const mnemonic of exactMatches) {
        setPlaylistActive(entries, mnemonic, true, false);
      }
    }

    if (version >= 38.11) {
      updateMnemonicMetadata(entries, "ref_panel_byepicfeeder_1", {
        ref_id: "CreativeDiscoverySurface_FrontendV2:ByEpicFeeder"
      });
    }
  }

  return entries;
}
