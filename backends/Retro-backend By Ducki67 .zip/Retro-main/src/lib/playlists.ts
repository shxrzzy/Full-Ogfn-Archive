import { readFile } from "node:fs/promises";
import { join } from "node:path";
import type { PlaylistConfig, PlaylistRecord } from "../types";

const DEFAULT_PLAYLIST = "playlist_quail";

const defaultConfig: PlaylistConfig = {
  version: "32.11",
  defaultPlaylist: DEFAULT_PLAYLIST,
  playlists: [
    {
      mnemonic: DEFAULT_PLAYLIST,
      title: "Battle Royale",
      enabled: true,
      ranked: false,
      maxSquadSize: 4,
      tags: ["br"]
    }
  ]
};

export async function loadPlaylistConfig(): Promise<PlaylistConfig> {
  const filePath = join(process.cwd(), "data", "playlists.32.11.json");
  try {
    const raw = await readFile(filePath, "utf-8");
    const parsed = JSON.parse(raw) as Partial<PlaylistConfig>;
    const safePlaylists = Array.isArray(parsed.playlists)
      ? parsed.playlists
          .filter((entry) => entry && typeof entry === "object")
          .map((entry) => {
            const typed = entry as Record<string, unknown>;
            return {
              mnemonic: String(typed.mnemonic ?? DEFAULT_PLAYLIST),
              title: String(typed.title ?? typed.mnemonic ?? "Playlist"),
              enabled: Boolean(typed.enabled ?? true),
              ranked: Boolean(typed.ranked ?? false),
              maxSquadSize: Number(typed.maxSquadSize ?? 4),
              tags: Array.isArray(typed.tags) ? typed.tags.map((tag) => String(tag)) : ["br"]
            };
          })
      : defaultConfig.playlists;

    return {
      version: typeof parsed.version === "string" ? parsed.version : defaultConfig.version,
      defaultPlaylist:
        typeof parsed.defaultPlaylist === "string" || Array.isArray(parsed.defaultPlaylist)
          ? parsed.defaultPlaylist
          : defaultConfig.defaultPlaylist,
      playlists: safePlaylists
    };
  } catch {
    return defaultConfig;
  }
}

export async function getPlaylistByMnemonic(mnemonic: string) {
  const configData = await loadPlaylistConfig();
  return configData.playlists.find((playlist) => playlist.mnemonic === mnemonic) ?? null;
}

export function resolvePrimaryPlaylist(configData: PlaylistConfig): PlaylistRecord {
  const requested = Array.isArray(configData.defaultPlaylist)
    ? configData.defaultPlaylist
    : [configData.defaultPlaylist];

  for (const mnemonic of requested) {
    const match = configData.playlists.find((playlist) => playlist.mnemonic === mnemonic && playlist.enabled);
    if (match) return match;
  }

  const firstEnabled = configData.playlists.find((playlist) => playlist.enabled);
  if (firstEnabled) return firstEnabled;

  return configData.playlists[0] ?? defaultConfig.playlists[0];
}