import { readFile, readdir, stat } from "node:fs/promises";
import { extname, join } from "node:path";
import { createHash } from "node:crypto";

export async function readJsonAsset<T>(pathParts: string[], fallback: T): Promise<T> {
  const filePath = join(process.cwd(), ...pathParts);
  try {
    const raw = await readFile(filePath, "utf-8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export async function readJsonAbsolute<T>(absolutePath: string | null | undefined, fallback: T): Promise<T> {
  if (!absolutePath) {
    return fallback;
  }

  try {
    const raw = await readFile(absolutePath, "utf-8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export async function readTextAsset(pathParts: string[], fallback = ""): Promise<string> {
  const filePath = join(process.cwd(), ...pathParts);
  try {
    return await readFile(filePath, "utf-8");
  } catch {
    return fallback;
  }
}

export type CloudFileEntry = {
  uniqueFilename: string;
  filename: string;
  hash: string;
  hash256: string;
  length: number;
  contentType: string;
  uploaded: string;
  storageType: string;
  storageIds: Record<string, string>;
  doNotCache: boolean;
};

function contentTypeFromFilename(filename: string): string {
  const ext = extname(filename).toLowerCase();
  if (ext === ".ini") return "application/octet-stream";
  if (ext === ".json") return "application/json";
  if (ext === ".txt") return "text/plain";
  return "application/octet-stream";
}

export async function listCloudStorageFiles(): Promise<CloudFileEntry[]> {
  const hotfixDir = join(process.cwd(), "hotfixes");
  let files: string[] = [];

  try {
    files = await readdir(hotfixDir);
  } catch {
    return [];
  }

  const output: CloudFileEntry[] = [];
  for (const file of files) {
    const fullPath = join(hotfixDir, file);
    const fileStat = await stat(fullPath).catch(() => null);
    if (!fileStat || !fileStat.isFile()) {
      continue;
    }

    // Fortnite uses hash + hash256 to decide whether to re-download.
    // Empty hashes make the client think the file is unchanged and skip
    // downloading — so the hotfix never actually applies.
    const contents = await readFile(fullPath).catch(() => Buffer.alloc(0));
    const hash = createHash("sha1").update(contents).digest("hex");
    const hash256 = createHash("sha256").update(contents).digest("hex");

    output.push({
      uniqueFilename: file,
      filename: file,
      hash,
      hash256,
      length: fileStat.size,
      contentType: contentTypeFromFilename(file),
      uploaded: new Date(fileStat.mtimeMs).toISOString(),
      storageType: "S3",
      storageIds: {},
      doNotCache: false
    });
  }

  return output;
}
