import { Hono } from "hono";
import {
  bumpProfile,
  ensureBaseProfiles,
  ensureLocker,
  ensureProfile,
  normalizeAccountId,
  saveLocker,
  saveProfile
} from "../lib/profiles";

type JsonRecord = Record<string, unknown>;

function asRecord(value: unknown): JsonRecord {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return {};
  }
  return value as JsonRecord;
}

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((entry): entry is string => typeof entry === "string");
}

function getProfileResponse(profileId: string, profile: JsonRecord, profileChanges: JsonRecord[]) {
  const rvn = typeof profile.rvn === "number" ? profile.rvn : 1;
  const commandRevision = typeof profile.commandRevision === "number" ? profile.commandRevision : 1;

  return {
    profileRevision: rvn,
    profileId,
    profileChangesBaseRevision: rvn,
    profileChanges,
    serverTime: new Date().toISOString(),
    profileCommandRevision: commandRevision,
    responseVersion: 1
  };
}

function applyMarkItemSeen(profile: JsonRecord, body: JsonRecord): boolean {
  let changed = false;
  const itemIds = asStringArray(body.itemIds);
  const items = asRecord(profile.items);

  for (const itemId of itemIds) {
    const item = asRecord(items[itemId]);
    const attributes = asRecord(item.attributes);
    if (attributes.item_seen !== true) {
      attributes.item_seen = true;
      item.attributes = attributes;
      items[itemId] = item;
      changed = true;
    }
  }

  profile.items = items;
  return changed;
}

function applyFavoriteBatch(profile: JsonRecord, body: JsonRecord): boolean {
  let changed = false;
  const itemIds = asStringArray(body.itemIds);
  const favorite = Boolean(body.itemFavStatus);
  const items = asRecord(profile.items);

  for (const itemId of itemIds) {
    const item = asRecord(items[itemId]);
    const attributes = asRecord(item.attributes);
    if (attributes.favorite !== favorite) {
      attributes.favorite = favorite;
      item.attributes = attributes;
      items[itemId] = item;
      changed = true;
    }
  }

  profile.items = items;
  return changed;
}

function applyBanner(profile: JsonRecord, body: JsonRecord): boolean {
  const icon = String(body.bannerIconId ?? body.homebaseBannerIconId ?? "StandardBanner1");
  const color = String(body.bannerColorId ?? body.homebaseBannerColorId ?? "DefaultColor1");
  const stats = asRecord(profile.stats);
  const attributes = asRecord(stats.attributes);

  const changed = attributes.banner_icon !== icon || attributes.banner_color !== color;
  attributes.banner_icon = icon;
  attributes.banner_color = color;
  stats.attributes = attributes;
  profile.stats = stats;

  const items = asRecord(profile.items);
  const loadout = asRecord(items.sandbox_loadout);
  const loadoutAttrs = asRecord(loadout.attributes);
  loadoutAttrs.banner_icon_template = icon;
  loadoutAttrs.banner_color_template = color;
  loadout.attributes = loadoutAttrs;
  items.sandbox_loadout = loadout;
  profile.items = items;

  return changed;
}

function writeLockerSlot(slots: JsonRecord, category: string, itemToSlot: string, index = 0, variantUpdates: unknown[] = []): boolean {
  const slot = asRecord(slots[category]);
  const existingItems = Array.isArray(slot.items) ? [...slot.items] : [];
  while (existingItems.length <= index) existingItems.push("");
  const prev = typeof existingItems[index] === "string" ? existingItems[index] : "";
  existingItems[index] = itemToSlot;
  slot.items = existingItems;
  if (variantUpdates.length > 0) {
    slot.activeVariants = variantUpdates;
  }
  slots[category] = slot;
  return prev !== itemToSlot;
}

function applyLockerSlot(profile: JsonRecord, body: JsonRecord): boolean {
  // Handles SetCosmeticLockerSlot + EquipBattleRoyaleCustomization (single slot).
  const category = String(body.category ?? body.slotName ?? "Character");
  const itemToSlot = String(body.itemToSlot ?? "");
  if (!itemToSlot) return false;

  const indexWithinSlot = typeof body.indexWithinSlot === "number" ? body.indexWithinSlot : 0;
  const variantUpdates = Array.isArray(body.variantUpdates) ? body.variantUpdates : [];

  const items = asRecord(profile.items);
  const loadout = asRecord(items.sandbox_loadout);
  const attrs = asRecord(loadout.attributes);
  const slotData = asRecord(attrs.locker_slots_data);
  const slots = asRecord(slotData.slots);

  const changed = writeLockerSlot(slots, category, itemToSlot, indexWithinSlot, variantUpdates);

  slotData.slots = slots;
  attrs.locker_slots_data = slotData;
  loadout.attributes = attrs;
  items.sandbox_loadout = loadout;
  profile.items = items;

  return changed;
}

function applyBulkEquip(profile: JsonRecord, body: JsonRecord): boolean {
  // Handles BulkEquipBattleRoyaleCustomization: multiple slot writes in one call.
  // Body shapes seen in the wild:
  //   { loadoutData: { slotMap: { Character: "<id>", Backpack: "<id>", ... } } }
  //   { loadoutData: { dances: [...], itemWraps: [...] } }
  const loadoutData = asRecord(body.loadoutData);
  const slotMap = asRecord(loadoutData.slotMap);

  let changed = false;
  const items = asRecord(profile.items);
  const loadout = asRecord(items.sandbox_loadout);
  const attrs = asRecord(loadout.attributes);
  const slotData = asRecord(attrs.locker_slots_data);
  const slots = asRecord(slotData.slots);

  for (const [category, value] of Object.entries(slotMap)) {
    if (typeof value === "string") {
      changed = writeLockerSlot(slots, category, value) || changed;
    }
  }

  const arrayCategories: Array<[keyof typeof loadoutData, string]> = [
    ["dances", "Dance"],
    ["itemWraps", "ItemWrap"]
  ];
  for (const [key, category] of arrayCategories) {
    const arr = loadoutData[key as string];
    if (!Array.isArray(arr)) continue;
    arr.forEach((value, index) => {
      if (typeof value === "string") {
        changed = writeLockerSlot(slots, category, value, index) || changed;
      }
    });
  }

  slotData.slots = slots;
  attrs.locker_slots_data = slotData;
  loadout.attributes = attrs;
  items.sandbox_loadout = loadout;
  profile.items = items;

  return changed;
}

function applyStatAttribute(profile: JsonRecord, key: string, value: unknown): boolean {
  const stats = asRecord(profile.stats);
  const attributes = asRecord(stats.attributes);
  if (attributes[key] === value) return false;
  attributes[key] = value;
  stats.attributes = attributes;
  profile.stats = stats;
  return true;
}

export const profileRoutes = new Hono();

profileRoutes.post("/fortnite/api/game/v2/profile/:accountId/:source{client|dedicated_server}/:command", async (c) => {
  const accountId = normalizeAccountId(c.req.param("accountId"));
  const command = c.req.param("command");
  const profileId = c.req.query("profileId") ?? "common_core";
  const body = asRecord(await c.req.json().catch(() => ({})));

  await ensureBaseProfiles(accountId);
  const profile = await ensureProfile(accountId, profileId);

  const profileChanges: JsonRecord[] = [];
  let modified = false;

  switch (command) {
    case "QueryProfile":
    case "ClientQuestLogin":
    case "RefreshExpeditions":
    case "GetMcpTimeForLogin":
      profileChanges.push({
        changeType: "fullProfileUpdate",
        profile
      });
      break;
    case "MarkItemSeen":
      modified = applyMarkItemSeen(profile, body);
      break;
    case "SetItemFavoriteStatusBatch":
      modified = applyFavoriteBatch(profile, body);
      break;
    case "SetBattleRoyaleBanner":
      modified = applyBanner(profile, body);
      break;
    case "SetCosmeticLockerSlot":
    case "EquipBattleRoyaleCustomization":
      modified = applyLockerSlot(profile, body);
      break;
    case "BulkEquipBattleRoyaleCustomization":
      modified = applyBulkEquip(profile, body) || applyLockerSlot(profile, body);
      break;
    case "SetCosmeticLockerBanner":
      modified = applyBanner(profile, body);
      break;
    case "SetCosmeticLockerName": {
      const newName = typeof body.name === "string" ? body.name : "";
      if (newName) modified = applyStatAttribute(profile, "locker_name", newName);
      break;
    }
    case "SetMtxPlatform": {
      const platform = typeof body.newPlatform === "string" ? body.newPlatform : "EpicPC";
      modified = applyStatAttribute(profile, "current_mtx_platform", platform);
      break;
    }
    case "SetReceiveGiftsEnabled": {
      const enabled = body.bReceiveGifts !== false;
      modified = applyStatAttribute(profile, "allowed_to_receive_gifts", enabled);
      break;
    }
    case "SetAffiliateName": {
      const affiliate = typeof body.affiliateName === "string" ? body.affiliateName : "";
      modified = applyStatAttribute(profile, "mtx_affiliate", affiliate);
      if (modified) applyStatAttribute(profile, "mtx_affiliate_set_time", new Date().toISOString());
      break;
    }
    case "SetItemFavoriteStatus": {
      // Single-item variant of SetItemFavoriteStatusBatch.
      const single = asRecord(body);
      const itemId = typeof single.targetItemId === "string" ? single.targetItemId : "";
      if (itemId) {
        modified = applyFavoriteBatch(profile, { itemIds: [itemId], itemFavStatus: Boolean(single.bFavorite) });
      }
      break;
    }
    case "SetItemArchivedStatusBatch": {
      const itemIds = asStringArray(body.itemIds);
      const archived = Boolean(body.archived);
      const items = asRecord(profile.items);
      for (const id of itemIds) {
        const item = asRecord(items[id]);
        const attributes = asRecord(item.attributes);
        if (attributes.archived !== archived) {
          attributes.archived = archived;
          item.attributes = attributes;
          items[id] = item;
          modified = true;
        }
      }
      if (modified) profile.items = items;
      break;
    }
    case "RemoveGiftBox": {
      const giftBoxItemId = typeof body.giftBoxItemId === "string" ? body.giftBoxItemId : "";
      const giftBoxItemIds = asStringArray(body.giftBoxItemIds);
      const targets = giftBoxItemId ? [giftBoxItemId, ...giftBoxItemIds] : giftBoxItemIds;
      const items = asRecord(profile.items);
      for (const id of targets) {
        if (items[id]) {
          delete items[id];
          modified = true;
        }
      }
      if (modified) profile.items = items;
      break;
    }
    case "SetCosmeticLockerSlots": {
      // Bulk variant — array of {category, itemToSlot, indexWithinSlot, variantUpdates}.
      const slotList = Array.isArray(body.slots) ? body.slots : [];
      for (const slot of slotList) {
        const rec = asRecord(slot);
        if (typeof rec.category === "string" && typeof rec.itemToSlot === "string") {
          modified = applyLockerSlot(profile, rec) || modified;
        }
      }
      break;
    }
    case "SetHeroCosmeticVariants": {
      // Variant swap (style edit). Applies variant updates to a specific item.
      const itemId = typeof body.itemToSlot === "string" ? body.itemToSlot : "";
      const variantUpdates = Array.isArray(body.variantUpdates) ? body.variantUpdates : [];
      if (itemId && variantUpdates.length > 0) {
        const items = asRecord(profile.items);
        const item = asRecord(items[itemId]);
        const attributes = asRecord(item.attributes);
        const variants = Array.isArray(attributes.variants) ? [...attributes.variants] : [];
        for (const upd of variantUpdates) {
          const updRec = asRecord(upd);
          const channel = typeof updRec.channel === "string" ? updRec.channel : "";
          const active = typeof updRec.active === "string" ? updRec.active : "";
          if (!channel) continue;
          const idx = variants.findIndex((v) => asRecord(v).channel === channel);
          if (idx >= 0) {
            variants[idx] = { ...asRecord(variants[idx]), channel, active };
          } else {
            variants.push({ channel, active, owned: [active] });
          }
          modified = true;
        }
        attributes.variants = variants;
        item.attributes = attributes;
        items[itemId] = item;
        profile.items = items;
      }
      break;
    }
    case "CopyCosmeticLoadout": {
      // Duplicate the active loadout into a new slot. Stored under
      // stats.attributes.loadouts as an array of loadout IDs.
      const stats = asRecord(profile.stats);
      const attrs = asRecord(stats.attributes);
      const loadouts = Array.isArray(attrs.loadouts) ? [...attrs.loadouts] : [];
      const newId = typeof body.targetIndex === "number"
        ? `sandbox_loadout_${body.targetIndex}_${Date.now()}`
        : `sandbox_loadout_${Date.now()}`;
      loadouts.push(newId);
      attrs.loadouts = loadouts;
      stats.attributes = attrs;
      profile.stats = stats;
      modified = true;
      break;
    }
    case "DeleteCosmeticLoadout": {
      const stats = asRecord(profile.stats);
      const attrs = asRecord(stats.attributes);
      const loadouts = Array.isArray(attrs.loadouts) ? [...attrs.loadouts] : [];
      const idx = typeof body.index === "number" ? body.index : -1;
      if (idx >= 0 && idx < loadouts.length) {
        loadouts.splice(idx, 1);
        attrs.loadouts = loadouts;
        stats.attributes = attrs;
        profile.stats = stats;
        modified = true;
      }
      break;
    }
    case "PutModularCosmeticLoadout": {
      // Modern loadout writer (Chapter 5+). Stores the full slot map per loadout.
      const stats = asRecord(profile.stats);
      const attrs = asRecord(stats.attributes);
      const loadoutsRec = asRecord(attrs.modular_loadouts);
      const loadoutId = typeof body.loadoutId === "string" ? body.loadoutId : "default";
      loadoutsRec[loadoutId] = asRecord(body.loadoutData);
      attrs.modular_loadouts = loadoutsRec;
      stats.attributes = attrs;
      profile.stats = stats;
      modified = true;
      break;
    }
    case "SetLoadoutShuffleEnabled":
      modified = applyStatAttribute(profile, "loadout_shuffle_enabled", Boolean(body.bEnabled ?? body.enabled));
      break;
    case "SetRandomCosmeticLoadoutFlag":
      modified = applyStatAttribute(profile, "random_loadout_flag", Boolean(body.bEnabled ?? body.enabled));
      break;
    case "SetForcedIntroPlayed":
      modified = applyStatAttribute(profile, "forced_intro_played", String(body.forcedIntroPlayed ?? "true"));
      break;
    case "SetHardcoreModifier":
      modified = applyStatAttribute(profile, "hardcore_modifier", Boolean(body.bEnabled));
      break;
    case "SetFactionChoice":
      modified = applyStatAttribute(profile, "faction_choice", String(body.factionId ?? ""));
      break;
    case "MarkNewQuestNotificationSent": {
      const itemIds = asStringArray(body.itemIds);
      const items = asRecord(profile.items);
      for (const id of itemIds) {
        const item = asRecord(items[id]);
        const attributes = asRecord(item.attributes);
        if (attributes.sent_new_notification !== true) {
          attributes.sent_new_notification = true;
          item.attributes = attributes;
          items[id] = item;
          modified = true;
        }
      }
      if (modified) profile.items = items;
      break;
    }
    case "UnlockRewardNode": {
      // Battle Pass node unlock — just ack. Real impl would credit rewards.
      const stats = asRecord(profile.stats);
      const attrs = asRecord(stats.attributes);
      const unlockedNodes = Array.isArray(attrs.unlocked_reward_nodes) ? [...attrs.unlocked_reward_nodes] : [];
      const nodeId = typeof body.nodeId === "string" ? body.nodeId : "";
      if (nodeId && !unlockedNodes.includes(nodeId)) {
        unlockedNodes.push(nodeId);
        attrs.unlocked_reward_nodes = unlockedNodes;
        stats.attributes = attrs;
        profile.stats = stats;
        modified = true;
      }
      break;
    }
    case "RefundMtxPurchase": {
      // Credit V-Bucks back. Simplistic — uses body.purchaseId if provided.
      const items = asRecord(profile.items);
      const vbItem = asRecord(items["Currency:MtxPurchased"]);
      if (vbItem) {
        const currentQty = typeof vbItem.quantity === "number" ? vbItem.quantity : 0;
        const refundAmount = typeof body.amount === "number" ? body.amount : 0;
        if (refundAmount > 0) {
          vbItem.quantity = currentQty + refundAmount;
          items["Currency:MtxPurchased"] = vbItem;
          profile.items = items;
          modified = true;
        }
      }
      break;
    }
    case "ExchangeGameCurrencyForBattlePassOffer":
    case "ExchangeGameCurrencyForSeasonPassOffer":
    case "PurchaseCatalogEntry":
    case "GiftCatalogEntry":
    case "SetMatchmakingBucketCheck":
    case "DedicatedServerLogin":
    case "FortRerollDailyQuest":
    case "ClaimMfaEnabled":
    case "IncrementNamedCounterStat":
    case "AthenaPinQuest":
    case "QuestLogin":
    case "RedeemRealMoneyPurchases":
    case "RedeemSTWAccoladeTokens":
    case "RequestRestedStateIncrease":
    case "PopulatePrerolledOffers":
      // No-op acknowledgements — preserves full-profile-update response shape.
      break;
    default:
      // Unknown commands fall through to the full-profile-update response below.
      break;
  }

  if (modified) {
    bumpProfile(profile);
    await saveProfile(accountId, profileId, profile);
    profileChanges.push({
      changeType: "fullProfileUpdate",
      profile
    });
  }

  return c.json(getProfileResponse(profileId, profile, profileChanges));
});

profileRoutes.get("/api/locker/v3/:deploymentId/account/:accountId/items", async (c) => {
  const accountId = normalizeAccountId(c.req.param("accountId"));
  const locker = await ensureLocker(accountId, 3);
  return c.json(locker);
});

profileRoutes.get("/api/locker/v4/:deploymentId/account/:accountId/items", async (c) => {
  const accountId = normalizeAccountId(c.req.param("accountId"));
  const locker = await ensureLocker(accountId, 4);
  return c.json(locker);
});

profileRoutes.put("/api/locker/v4/:deploymentId/account/:accountId/active-loadout-group", async (c) => {
  const accountId = normalizeAccountId(c.req.param("accountId"));
  const body = asRecord(await c.req.json().catch(() => ({})));
  const locker = await ensureLocker(accountId, 4);
  const active = asRecord(locker.activeLoadoutGroup);

  if (body.loadouts && typeof body.loadouts === "object") {
    active.loadouts = body.loadouts;
  }

  if (typeof body.athenaItemId === "string") {
    active.athenaItemId = body.athenaItemId;
  }

  active.updatedTime = new Date().toISOString();
  locker.activeLoadoutGroup = active;
  await saveLocker(accountId, 4, locker);

  return c.json(active);
});
