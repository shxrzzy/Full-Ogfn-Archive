import { Hono } from "hono";
import { loadPlaylistConfig, resolvePrimaryPlaylist } from "../lib/playlists";
import { getVersionInfo, parseBuildFloat } from "../lib/version";
import {
  type DiscoveryEntry,
  buildDiscoveryForVersion,
  loadDiscoveryMenuV1,
  loadDiscoveryMenuV2
} from "../lib/discovery_helpers";

export const discoveryRoutes = new Hono();

// --- panel builders -----------------------------------------------------------

function panelsLegacy() {
  // Pre-30.10 panel layout.
  return [
    {
      panelName: "Homebar",
      panelDisplayName: "Homebar",
      panelSubtitle: null,
      featureTags: ["col:5", "homebar"],
      firstPage: {
        results: [
          {
            lastVisited: null,
            linkCode: "reference_byepicnocompetitive_5",
            isFavorite: false,
            globalCCU: -1,
            lockStatus: "UNLOCKED",
            lockStatusReason: "NONE",
            isVisible: true
          }
        ],
        hasMore: true,
        panelTargetName: null,
        pageMarker: null
      },
      panelType: "CuratedList",
      playHistoryType: null
    },
    {
      panelName: "ByEpicNoCompetitive",
      panelDisplayName: "By Epic",
      panelSubtitle: "Islands created by Epic Games",
      featureTags: ["col:5"],
      firstPage: {
        results: [
          unlocked("playlist_durian"),
          unlocked("set_br_playlists"),
          unlocked("playlist_pilgrimquickplay"),
          unlocked("playlist_juno"),
          unlocked("playlist_beanstalk"),
          { lastVisited: null, ...unlocked("playlist_papaya") }
        ],
        hasMore: true,
        panelTargetName: null,
        pageMarker: null
      },
      panelType: "AnalyticsList",
      playHistoryType: null
    }
  ];
}

function unlocked(linkCode: string) {
  return {
    linkCode,
    isFavorite: false,
    globalCCU: 1,
    lockStatus: "UNLOCKED",
    lockStatusReason: "NONE",
    isVisible: true
  };
}

function bannerPanel(
  panelName: string,
  displayName: string,
  subtitle: string,
  linkCode: string
) {
  return {
    panelName,
    panelDisplayName: displayName,
    panelSubtitle: subtitle,
    featureTags: ["bannerItemRow"],
    firstPage: {
      results: [
        {
          lastVisited: null,
          linkCode,
          isFavorite: false,
          globalCCU: -1,
          lockStatus: "UNLOCKED",
          lockStatusReason: "RATING_THRESHOLD",
          isVisible: true,
          favoriteStatus: "NONE"
        }
      ],
      hasMore: false,
      panelTargetName: null,
      pageMarker: null
    },
    panelType: "CuratedList",
    playHistoryType: null,
    panelContexts: {}
  };
}

function panelsModern(version: number) {
  // 30.10+ panel layout.
  const panels: unknown[] = [
    {
      panelName: "Homebar",
      panelDisplayName: "Homebar",
      panelSubtitle: null,
      featureTags: ["col:5", "homebar"],
      firstPage: {
        results: [
          {
            lastVisited: null,
            linkCode: "ref_panel_byepicfeeder_1",
            isFavorite: false,
            globalCCU: -1,
            lockStatus: "UNLOCKED",
            lockStatusReason: "NONE",
            isVisible: true
          }
        ],
        hasMore: true,
        panelTargetName: null,
        pageMarker: null
      },
      panelType: "CuratedList",
      playHistoryType: null
    },
    {
      panelName: "ByEpicFeeder",
      panelNativeDisplayName: "By Epic",
      panelDisplayName: "By Epic",
      panelSubtitle: null,
      featureTags: ["ForReferenceViewOnly", "col:5", "hasViewAll:true", "horizontalScroll:false"],
      firstPage: {
        results: [
          unlocked("set_br_playlists"),
          unlocked("playlist_pilgrimquickplay"),
          unlocked("playlist_juno"),
          unlocked("playlist_beanstalk"),
          { lastVisited: null, ...unlocked("playlist_papaya") }
        ],
        hasMore: true,
        panelTargetName: null,
        pageMarker: null
      },
      panelType: "AnalyticsList",
      playHistoryType: null
    },
    {
      panelName: "ByEpicConvergenceBlastberry",
      panelNativeDisplayName: "Other Modes By Epic",
      panelDisplayName: "Other Modes By Epic",
      panelSubtitle: null,
      featureTags: ["col:7", "horizontalScroll:false", "hasViewAll:true", "squareTiles:false", "grid:4"],
      firstPage: {
        results: [
          unlocked("campaign"),
          unlocked("set_figment_playlists"),
          unlocked("set_blastberry_playlists"),
          unlocked("set_forbiddenfruit_nobuild_playlists")
        ],
        hasMore: true,
        panelTargetName: null,
        pageMarker: null
      },
      panelType: "AnalyticsList",
      playHistoryType: null
    }
  ];

  // Event-banner panels — version-specific lobby features.
  const stamp = version.toFixed(2);

  if (stamp === "32.11") {
    panels.push(
      bannerPanel("A-Spot", "Remix: The Finale", "Remix: The Finale", "playlist_quail")
    );
  }
  if (stamp === "38.11") {
    panels.push(
      bannerPanel("SkyMango", "Chapter Finale Zero Hour", "Chapter Finale Zero Hour", "playlist_skymango")
    );
  }
  if (stamp === "37.51") {
    panels.push(
      bannerPanel("LimeRock", "Welcome, Our Alien Overlords", "Welcome, Our Alien Overlords", "playlist_limerock")
    );
  }
  if (stamp === "37.31") {
    panels.push(
      bannerPanel("StrideMice", "The Daft Punk Experience", "The Daft Punk Experience", "playlist_stridemice")
    );
  }
  if (stamp === "35.20") {
    panels.push(
      bannerPanel("RipeHoneyDew", "Death Star Sabotage", "Death Star Sabotage", "playlist_ripehoneydew")
    );
  }

  return panels;
}

function defaultModeSets() {
  return {
    set_br_playlists: {
      defaultSubLinkCode: "playlist_defaultsolo",
      subLinkCodes: ["playlist_defaultsolo", "playlist_defaultduo", "playlist_trios"]
    }
  };
}

async function discoveryV3Response(version: number, versionGlobal: number) {
  const panels = version <= 30.1 ? panelsLegacy() : panelsModern(version);
  return {
    panels,
    testCohorts: ["testing"]
  };
}

// --- route handlers -----------------------------------------------------------

// Surface v1 (legacy /fortnite/api/...) — pre-23.00 builds expect discoveryMenuV1.
discoveryRoutes.post("/fortnite/api/game/v2/creative/discovery/surface/:surface", async (c) => {
  const menu = await loadDiscoveryMenuV1();
  return c.json(menu);
});

// Surface v2 — 23.00..30.10 split. Older returns V1 menu, newer returns a small modern panel.
discoveryRoutes.post("/api/v1/discovery/surface/:surface", async (c) => {
  const { version, versionGlobal } = getVersionInfo(c);
  if (version < 23.0) {
    return c.json(await loadDiscoveryMenuV1());
  }

  return c.json({
    panels: [
      {
        PanelName: "ByEpicNoBigBattle6Col",
        Pages: [
          {
            results: [
              { lastVisited: null, linkCode: "set_br_playlists", isFavorite: false, globalCCU: 1 },
              { lastVisited: null, linkCode: "playlist_papaya", isFavorite: false, globalCCU: 1 }
            ],
            hasMore: false
          }
        ]
      }
    ],
    testCohorts: ["testing"]
  });
});

// Surface v3 — modern frontend (30.10+ uses this).
discoveryRoutes.post("/api/v2/discovery/surface/:surface", async (c) => {
  const { version, versionGlobal } = getVersionInfo(c);
  const surface = c.req.param("surface");
  const body = await discoveryV3Response(version, versionGlobal);
  return c.json({
    SurfaceName: surface,
    Panels: body.panels,
    TestCohorts: body.testCohorts,
    ModeSets: defaultModeSets()
  });
});

discoveryRoutes.post("/api/v2/discovery/surface/:surface/page", async (c) => {
  const body = (await c.req.json().catch(() => ({}))) as {
    panelName?: unknown;
    pageMarker?: unknown;
  };
  return c.json({
    surfaceName: c.req.param("surface"),
    panelName: typeof body.panelName === "string" ? body.panelName : null,
    pageMarker: typeof body.pageMarker === "string" ? body.pageMarker : null,
    results: [],
    hasMore: false,
    panelTargetName: null
  });
});

// Mnemonic batch lookup. Older builds want a single object; >=23 expects the full
// discoveryMenuV2 array with version-aware mutations applied.
discoveryRoutes.post("/links/api/fn/mnemonic", async (c) => {
  const { version, versionGlobal } = getVersionInfo(c);
  if (version < 23.0) {
    const v1 = await loadDiscoveryMenuV1();
    const firstPanel = (v1 as { Panels?: Array<{ Pages?: Array<{ results?: Array<{ linkData?: unknown }> }> }> }).Panels?.[0];
    const flat =
      firstPanel?.Pages?.[0]?.results
        ?.map((entry) => entry.linkData)
        .filter(Boolean) ?? [];
    return c.json(flat);
  }

  const entries = await buildDiscoveryForVersion(version, versionGlobal);
  return c.json(entries);
});

// Single mnemonic detail. Game pulls metadata for one playlist by id.
discoveryRoutes.get("/links/api/fn/mnemonic/:playlistId", async (c) => {
  const { version, versionGlobal } = getVersionInfo(c);
  const playlistId = c.req.param("playlistId");

  if (versionGlobal <= 16) {
    return c.body(null, 404);
  }

  if (version < 23.0) {
    const v1 = await loadDiscoveryMenuV1();
    const firstPanel = (v1 as { Panels?: Array<{ Pages?: Array<{ results?: Array<{ linkData?: { mnemonic?: string } & Record<string, unknown> }> }> }> }).Panels?.[0];
    const results = firstPanel?.Pages?.[0]?.results ?? [];
    for (const result of results) {
      if (result.linkData?.mnemonic === playlistId) {
        return c.json(result.linkData);
      }
    }
    return c.body(null, 404);
  }

  const entries = await buildDiscoveryForVersion(version, versionGlobal);
  const match = entries.find((entry) => entry.mnemonic === playlistId);
  if (!match) {
    return c.json({ errorCode: "errors.com.epicgames.common.not_found" }, 404);
  }
  return c.json(match);
});

// Related links — finds siblings via parent_set / sub_link_codes.
discoveryRoutes.get("/links/api/fn/mnemonic/:playlistId/related", async (c) => {
  const { version, versionGlobal } = getVersionInfo(c);
  const playlistId = c.req.param("playlistId");
  const entries = await buildDiscoveryForVersion(version, versionGlobal);
  const target = entries.find((entry) => entry.mnemonic === playlistId);

  const response: {
    parentLinks: DiscoveryEntry[];
    links: Record<string, DiscoveryEntry>;
  } = { parentLinks: [], links: {} };

  if (!target) {
    return c.json(response);
  }

  const targetMeta = target.metadata as Record<string, unknown>;
  const subCodes = Array.isArray(targetMeta.sub_link_codes)
    ? (targetMeta.sub_link_codes as unknown[]).filter((v): v is string => typeof v === "string")
    : null;

  if (subCodes) {
    response.parentLinks.push(target);
    for (const code of subCodes) {
      const child = entries.find((entry) => entry.mnemonic === code);
      if (child) response.links[code] = child;
    }
  } else {
    response.links[target.mnemonic] = target;
    const parentSet = typeof targetMeta.parent_set === "string" ? targetMeta.parent_set : null;
    if (parentSet) {
      const parent = entries.find((entry) => entry.mnemonic === parentSet);
      if (parent) {
        response.parentLinks.push(parent);
        const parentMeta = parent.metadata as Record<string, unknown>;
        const parentSubs = Array.isArray(parentMeta.sub_link_codes)
          ? (parentMeta.sub_link_codes as unknown[]).filter((v): v is string => typeof v === "string")
          : [];
        for (const code of parentSubs) {
          if (response.links[code]) continue;
          const sibling = entries.find((entry) => entry.mnemonic === code);
          if (sibling) response.links[code] = sibling;
        }
      }
    }
  }

  return c.json(response);
});

discoveryRoutes.post("/api/v1/links/favorites/:accountId/check", async (c) => {
  return c.json({ results: [], hasMore: false });
});

discoveryRoutes.post("/api/v1/links/lock-status/:accountId/check", async (c) => {
  const body = (await c.req.json().catch(() => ({}))) as {
    linkCodes?: unknown;
    mnemonics?: unknown;
  };
  const accountId = c.req.param("accountId");
  const candidates = Array.isArray(body.linkCodes)
    ? body.linkCodes
    : Array.isArray(body.mnemonics)
      ? body.mnemonics
      : [];

  const results = candidates
    .filter((entry): entry is string => typeof entry === "string")
    .map((linkCode) => ({
      playerId: accountId,
      accountId,
      mnemonic: linkCode,
      linkCode,
      locked: false,
      lockStatus: "UNLOCKED",
      lockStatusReason: "NONE",
      isVisible: true
    }));

  return c.json({ results, hasMore: false });
});

// --- legacy GET surfaces (kept for compat with some launchers that probe these) ---

discoveryRoutes.get("/discovery/surface/v2/:accountId", async (c) => {
  const { version, versionGlobal } = getVersionInfo(c);
  const playlists = await loadPlaylistConfig();
  const primary = resolvePrimaryPlaylist(playlists);
  const links = await buildDiscoveryForVersion(version, versionGlobal);
  const body = await discoveryV3Response(version, versionGlobal);

  return c.json({
    accountId: c.req.param("accountId"),
    version: "32.11",
    defaultPlaylist: primary.mnemonic,
    links,
    panels: body.panels,
    testCohorts: body.testCohorts
  });
});

discoveryRoutes.get("/discovery/surface/v1/:accountId", async (c) => {
  return c.json(await loadDiscoveryMenuV1());
});
