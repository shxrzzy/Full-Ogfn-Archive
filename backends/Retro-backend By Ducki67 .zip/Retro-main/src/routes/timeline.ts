import { Hono } from "hono";
import { config } from "../config";
import { readJsonAsset } from "../lib/assets";
import { getVersionInfo } from "../lib/version";

export const timelineRoutes = new Hono();

type ActiveEvent = {
  eventType: string;
  activeUntil: string;
  activeSince: string;
};

const FAR_FUTURE = "9999-12-31T23:59:59.999Z";
const FAR_PAST = "2019-12-31T23:59:59.999Z";

function baseEvents(versionGlobal: number): ActiveEvent[] {
  return [
    { eventType: "heard0stone78hole65stick178feet", activeUntil: FAR_FUTURE, activeSince: FAR_PAST },
    { eventType: "RBFI", activeUntil: "9999-12-01T21:10:00.000Z", activeSince: "2020-11-21T07:00:00.000Z" },
    { eventType: `EventFlag.Season${versionGlobal}`, activeUntil: FAR_FUTURE, activeSince: FAR_PAST },
    { eventType: `EventFlag.LobbySeason${versionGlobal}`, activeUntil: FAR_FUTURE, activeSince: "2021-06-05T14:00:00.000Z" },
    { eventType: "Gal_Crashes", activeUntil: "9999-09-14T07:00:00.000Z", activeSince: "2015-09-14T07:00:00.000Z" },
    { eventType: "Papaya_Stage", activeUntil: FAR_FUTURE, activeSince: "2021-06-05T14:00:00.000Z" },
    { eventType: "Papaya_Theater", activeUntil: FAR_FUTURE, activeSince: "2021-06-05T14:00:00.000Z" }
  ];
}

// Chapter 2 Remix map-stage flags, driven by .env (CLYDE_WEEK_STAGE 1-4,
// JUICE_WRLD_POI_STAGE 1-3). Exactly one stage of each is active at a time.
const FLAGS = {
  ClydeWeek1: config.CLYDE_WEEK_STAGE === 1,
  ClydeWeek2: config.CLYDE_WEEK_STAGE === 2,
  ClydeWeek3: config.CLYDE_WEEK_STAGE === 3,
  ClydeWeek4: config.CLYDE_WEEK_STAGE === 4,
  JuiceWRLDPOIStage1: config.JUICE_WRLD_POI_STAGE === 1,
  JuiceWRLDPOIStage2: config.JUICE_WRLD_POI_STAGE === 2,
  JuiceWRLDPOIStage3: config.JUICE_WRLD_POI_STAGE === 3
};

function chapter2RemixEvents(versionGlobal: number): ActiveEvent[] {
  if (versionGlobal !== 32) return [];
  const out: ActiveEvent[] = [];
  const since = "2020-09-09T07:00:00.000Z";
  const until = "9999-09-09T07:00:00.000Z";

  if (FLAGS.ClydeWeek1) {
    out.push({ eventType: "ClydeSeason1", activeUntil: until, activeSince: since });
    out.push({ eventType: "Week1", activeUntil: until, activeSince: since });
  }
  if (FLAGS.ClydeWeek2) {
    out.push({ eventType: "ClydeSeason2Part1", activeUntil: until, activeSince: since });
    out.push({ eventType: "Week2", activeUntil: until, activeSince: since });
  }
  if (FLAGS.ClydeWeek3) {
    out.push({ eventType: "ClydeSeason2Part2", activeUntil: until, activeSince: since });
    out.push({ eventType: "Week3", activeUntil: until, activeSince: since });
  }
  if (FLAGS.ClydeWeek4) {
    out.push({ eventType: "KL1", activeUntil: until, activeSince: since });
    out.push({ eventType: "Week4", activeUntil: until, activeSince: since });
    out.push({ eventType: "ClydeSeason3Part1", activeUntil: until, activeSince: since });
  }
  if (FLAGS.JuiceWRLDPOIStage1) {
    out.push({ eventType: "KL1", activeUntil: until, activeSince: since });
  }
  if (FLAGS.JuiceWRLDPOIStage2) {
    out.push({ eventType: "KL2", activeUntil: until, activeSince: since });
  }
  if (FLAGS.JuiceWRLDPOIStage3) {
    out.push({ eventType: "KL3", activeUntil: until, activeSince: since });
  }

  return out;
}

async function loadKeychain(): Promise<string[]> {
  return readJsonAsset<string[]>(["responses", "keychain.json"], []);
}

async function buildTimelinePayload(version: number, versionGlobal: number) {
  const keychain = await loadKeychain();
  const events = [...baseEvents(versionGlobal), ...chapter2RemixEvents(versionGlobal)];

  return {
    channels: {
      "standalone-store": {},
      "client-matchmaking": {},
      tk: {
        states: [
          {
            validFrom: FAR_PAST,
            activeEvents: [],
            state: { k: keychain }
          }
        ],
        cacheExpire: new Date(Date.now() + 30_000).toISOString()
      },
      "featured-islands": {},
      "community-votes": {},
      "client-events": {
        states: [
          {
            validFrom: FAR_PAST,
            activeEvents: events,
            state: {
              activeStorefronts: [],
              eventNamedWeights: {},
              activeEvents: events,
              seasonNumber: versionGlobal,
              seasonTemplateId: `AthenaSeason:athenaseason${versionGlobal}`,
              matchXpBonusPoints: 0,
              seasonBegin: "2020-04-23T08:00:00.000Z",
              seasonEnd: "9999-04-23T08:00:00.000Z",
              seasonDisplayedEnd: "9999-04-23T08:00:00.000Z",
              weeklyStoreEnd: "9999-04-23T08:00:00.000Z",
              dailyStoreEnd: "9999-04-23T08:00:00.000Z",
              stwEventStoreEnd: "9999-04-23T08:00:00.000Z",
              stwWeeklyStoreEnd: "9999-04-23T08:00:00.000Z",
              sectionStoreEnds: {},
              rmtPromotion: "",
              dailyStoreOpen: "1700-01-01T07:00:00.000Z",
              stwEventStoreOpen: "1700-01-01T07:00:00.000Z",
              stwWeeklyStoreOpen: "1700-01-01T07:00:00.000Z"
            }
          }
        ],
        cacheExpire: new Date(Date.now() + 30_000).toISOString()
      }
    },
    eventsTimeOffsetHrs: 0,
    cacheIntervalMins: 10,
    currentTime: new Date().toISOString()
  };
}

timelineRoutes.get("/fortnite/api/calendar/v1/timeline", async (c) => {
  const { version, versionGlobal } = getVersionInfo(c);
  const payload = await buildTimelinePayload(version, versionGlobal);
  return c.json(payload);
});
