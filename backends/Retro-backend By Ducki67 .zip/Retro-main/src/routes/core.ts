import { Hono } from "hono";
import { decodeJwt } from "jose";
import { config } from "../config";
import { readJsonAsset } from "../lib/assets";
import { buildTicketResponse, gameServerParts, recallTicketContext } from "../lib/matchmaker";
import { buildCustomShop } from "../lib/shop";
import { loadPlaylistConfig, resolvePrimaryPlaylist } from "../lib/playlists";
import { getVersionInfo } from "../lib/version";

export const coreRoutes = new Hono();

const telemetryAck = { status: "OK" };

function accountIdFromBearer(authHeader: string | undefined, fallback: string): string {
  if (!authHeader || !authHeader.toLowerCase().startsWith("bearer ")) return fallback;
  const token = authHeader.slice(7).replace(/^eg1~/i, "");
  try {
    const claims = decodeJwt(token) as { sub?: unknown };
    return typeof claims.sub === "string" ? claims.sub : fallback;
  } catch {
    return fallback;
  }
}

function buildMatchmakingSession(sessionId: string, ownerId: string, accountId: string, fallbackBuildId: string) {
  const state = recallTicketContext(accountId);
  const buildUniqueId = state?.buildUniqueId ?? fallbackBuildId;
  const playlist = state?.playlist ?? "Playlist_DefaultSolo";
  const region = state?.region ?? "EU";
  const { ip, port } = gameServerParts(playlist);

  return {
    id: sessionId,
    ownerId,
    ownerName: "[DS]fortnite-retrov1-mms-player",
    serverName: "[DS]fortnite-retrov1-mms-player",
    serverAddress: ip,
    serverPort: port,
    maxPublicPlayers: 220,
    openPublicPlayers: 175,
    maxPrivatePlayers: 0,
    openPrivatePlayers: 0,
    attributes: {
      REGION_s: region,
      GAMEMODE_s: "FORTATHENA",
      ALLOWBROADCASTING_b: true,
      SUBREGION_s: "GB",
      DCID_s: "FORTNITE-RETROV1-DC",
      tenant_s: "Fortnite",
      MATCHMAKINGPOOL_s: "Any",
      STORMSHIELDDEFENSETYPE_i: 0,
      HOTFIXVERSION_i: 0,
      PLAYLISTNAME_s: playlist,
      SESSIONKEY_s: sessionId.toUpperCase(),
      TENANT_s: "Fortnite",
      BEACONPORT_i: 15009
    },
    publicPlayers: [],
    privatePlayers: [],
    totalPlayers: 1,
    allowJoinInProgress: false,
    shouldAdvertise: false,
    isDedicated: false,
    usesStats: false,
    allowInvites: false,
    usesPresence: false,
    allowJoinViaPresence: true,
    allowJoinViaPresenceFriendsOnly: false,
    buildUniqueId,
    lastUpdated: new Date().toISOString(),
    started: false
  };
}

async function loadFortniteGamePages(): Promise<Record<string, unknown>> {
  return readJsonAsset<Record<string, unknown>>(["responses", "fortnitegame.json"], {});
}

coreRoutes.get("/health", (c) => c.json({ ok: true, service: "RetroV1" }));
coreRoutes.get("/", (c) => c.text("RetroV1 online"));
coreRoutes.get("/unknown", (c) => c.body(null, 204));
coreRoutes.get("/unknown/*", (c) => c.body(null, 204));
coreRoutes.post("/unknown", (c) => c.body(null, 204));
coreRoutes.post("/unknown/*", (c) => c.body(null, 204));
coreRoutes.put("/unknown", (c) => c.body(null, 204));
coreRoutes.put("/unknown/*", (c) => c.body(null, 204));
coreRoutes.patch("/unknown", (c) => c.body(null, 204));
coreRoutes.patch("/unknown/*", (c) => c.body(null, 204));
coreRoutes.delete("/unknown", (c) => c.body(null, 204));
coreRoutes.delete("/unknown/*", (c) => c.body(null, 204));
coreRoutes.options("/unknown", (c) => c.body(null, 204));
coreRoutes.options("/unknown/*", (c) => c.body(null, 204));

coreRoutes.get("/fortnite/api/game/v2/enabled_features", (c) => c.json([]));
coreRoutes.post("/fortnite/api/game/v2/grant_access/:accountId", (c) => c.body(null, 204));
coreRoutes.get("/fortnite/api/game/v2/world/info", (c) => c.json({
  currentTime: new Date().toISOString(),
  matchMakingWindowSize: 5
}));
coreRoutes.post("/fortnite/api/game/v2/tryPlayOnPlatform/account/:accountId", (c) => c.body(null, 204));
coreRoutes.get("/waitingroom/api/waitingroom", (c) => c.body(null, 204));
coreRoutes.get("/fortnite/api/v2/versioncheck/:platform", (c) =>
  c.json({
    type: "NO_UPDATE",
    version: "32.11",
    platform: c.req.param("platform")
  })
);

coreRoutes.post("/datarouter/api/v1/public/data", (c) => c.json(telemetryAck));
coreRoutes.post("/datarouter/api/v1/public/data/clients", (c) => c.json(telemetryAck));
coreRoutes.post("/telemetry/data/datarouter/api/v1/public/data", (c) => c.json(telemetryAck));
coreRoutes.post("/region/check", (c) => c.json({ region: "EU", success: true }));
coreRoutes.get("/region", (c) => c.json({ region: "EU" }));
// motd-target endpoints are defined further down with the full DynamicMotd response.
coreRoutes.post("/api/v1/fortnite-br/channel/interstitials/target", (c) => c.body(null, 204));
coreRoutes.post("/api/v1/:channel/interactions/contentHash", (c) => c.body(null, 204));
coreRoutes.post("/api/v1/fortnite-br/interactions", (c) => c.json({ interactions: [] }));
coreRoutes.get("/api/v2/interactions/latest/:game/:accountId", (c) => c.json({ interactions: [] }));
coreRoutes.get("/api/v2/interactions/aggregated/Fortnite/:accountId", (c) => c.body(null, 204));
coreRoutes.get("/api/v1/players/Fortnite/tokens", (c) => c.json({ tokens: [] }));
coreRoutes.get("/api/v1/lfg/Fortnite/users/:accountId/settings", (c) => c.json({ enabled: false }));
coreRoutes.get("/api/community/v1/fn-client/community-highlights", (c) => c.body(null, 204));
coreRoutes.get("/app_installation/status", (c) => c.json({ status: "ok" }));
coreRoutes.get("/presence/api/v1/_/:accountId/last-online", (c) => c.json({}));
coreRoutes.get("/presence/api/v1/_/:accountId/settings/subscriptions", (c) => c.body(null, 204));
coreRoutes.get("/eulatracking/api/public/agreements/:agreementId/account/:accountId", (c) => c.body(null, 204));
coreRoutes.get("/eulatracking/api/shared/agreements/:agreementId", (c) => c.body(null, 204));
coreRoutes.get("/api/content/v2/launch-data", (c) =>
  c.json({
    activeSubGame: "BR",
    discoverySurface: "CreativeDiscoverySurface_Frontend",
    defaultModeSet: "set_br_playlists",
    generatedAt: new Date().toISOString(),
    contentVersion: "32.11",
    features: {
      enableBattleRoyale: true,
      enableCreative: true,
      enableSTW: false
    },
    launchers: [
      { id: "BR", name: "Battle Royale", enabled: true },
      { id: "Creative", name: "Creative", enabled: true }
    ]
  })
);
// EOS RTC TURN credentials — game polls this regardless of voice config.
// Game logs a deserialize warning when this returns the iceServers wrapper.
// Real shape is a flat list with TTL at top level.
coreRoutes.post("/auth/v1/turn/credentials", (c) =>
  c.json({
    ttl: "86400",
    username: "retrov1",
    password: "retrov1",
    iceServers: [
      { urls: ["stun:stun.l.google.com:19302"] }
    ]
  })
);
coreRoutes.get("/auth/v1/turn/credentials", (c) =>
  c.json({
    ttl: "86400",
    username: "retrov1",
    password: "retrov1",
    iceServers: [
      { urls: ["stun:stun.l.google.com:19302"] }
    ]
  })
);
coreRoutes.put("/profile/play_region", (c) => c.json({}));
coreRoutes.put("/profile/languages", (c) => c.body(null, 204));
coreRoutes.put("/profile/privacy_settings", (c) => c.body(null, 204));
coreRoutes.get("/profile/:accountId", (c) =>
  c.json({
    accountId: c.req.param("accountId"),
    playRegion: "EU",
    languages: ["en"],
    privacySettings: {}
  })
);
coreRoutes.put("/profile/:accountId", (c) => c.body(null, 204));
coreRoutes.get("/launcher/api/public/distributionpoints", (c) => {
  const requestOrigin = new URL(c.req.url).origin;
  return c.json({
    distributions: [
      "https://epicgames-download1.akamaized.net/",
      "https://download.epicgames.com/",
      "https://download2.epicgames.com/",
      "https://download3.epicgames.com/",
      "https://download4.epicgames.com/",
      `${requestOrigin}/`
    ]
  });
});

coreRoutes.get("/launcher/api/public/assets/:platform/:catalogItemId/:appName", (c) => {
  const platform = c.req.param("platform");
  const appName = c.req.param("appName");
  const catalogItemId = c.req.param("catalogItemId");
  const label = c.req.query("label") ?? "Live";

  const isAndroid = platform.toLowerCase() === "android";
  const distribution = isAndroid ? "https://epicgames-download1.akamaized.net/" : `${new URL(c.req.url).origin}/`;
  const manifestPath = isAndroid
    ? "Builds/Fortnite/Content/CloudDir/9O7dGkaFewI7qGElsE2rjSDu5u6jeg.manifest"
    : "Builds/Fortnite/Content/CloudDir/Nexa.manifest";

  return c.json({
    appName,
    labelName: `${label}-${platform}`,
    buildVersion: "retrov1-32.11",
    catalogItemId,
    expires: "9988-09-23T23:59:59.999Z",
    items: {
      MANIFEST: {
        signature: "retrov1",
        distribution,
        path: manifestPath,
        additionalDistributions: []
      }
    },
    assetId: appName
  });
});

coreRoutes.get("/Builds/Fortnite/Content/CloudDir/ChunksV4/:chunknum/:filename", (c) =>
  c.text("", 200, { "content-type": "application/octet-stream" })
);
coreRoutes.get("/Builds/Fortnite/Content/CloudDir/:filename", (c) => {
  const filename = c.req.param("filename");
  if (filename.toLowerCase().endsWith(".manifest")) {
    return c.text("ManifestFileVersion=0\n", 200, { "content-type": "text/plain" });
  }
  return c.text("", 200, { "content-type": "application/octet-stream" });
});

coreRoutes.get("/hotconfigs/v2/livefn.json", async (c) => {
  const cfg = await readJsonAsset<Record<string, unknown>>(["FortniteGameConfig.json"], {});
  return c.json(cfg);
});
coreRoutes.get("/content/api/pages/fortnite-game", async (c) => {
  const pages = await loadFortniteGamePages();
  return c.json(pages);
});

// DynamicMotd panel — top-left lobby billboard. Serves the same content for
// every gameMode/surface variant the client polls.
const motdTargetResponse = {
  contentType: "collection",
  contentId: "retro-br-motd-collection",
  tcId: "00000000-0000-0000-0000-000000000000",
  contentItems: [
    {
      contentHash: "retro-motd-1",
      contentSchemaName: "DynamicMotd",
      contentFields: {
        Buttons: [],
        FullScreenBackground: {
          Image: [
            { width: 1920, height: 1080, url: "https://i.imgur.com/qaSvw7q.png" },
            { width: 960, height: 540, url: "https://i.imgur.com/qaSvw7q.png" }
          ],
          _type: "FullScreenBackground"
        },
        FullScreenBody:
          "An advanced Chapter 2 Remix backend speed runed in 1 week in TypeScript, made by: Ducki67 (@ducki67 on discord)",
        FullScreenTitle: "Retro",
        TeaserBackground: {
          Image: [
            { width: 1024, height: 512, url: "https://i.imgur.com/qaSvw7q.png" }
          ],
          _type: "TeaserBackground"
        },
        TeaserTitle: "Retro",
        VerticalTextLayout: false
      },
      placements: [
        { trackingId: "00000000-0000-0000-0000-000000000000", tag: "Product.BR.Build", position: 0 },
        { trackingId: "00000000-0000-0000-0000-000000000000", tag: "Product.BR.Build.Solo", position: 0 },
        { trackingId: "00000000-0000-0000-0000-000000000000", tag: "Product.Juno", position: 0 },
        { trackingId: "00000000-0000-0000-0000-000000000000", tag: "Product.FNE.Beanstalk", position: 0 },
        { trackingId: "00000000-0000-0000-0000-000000000000", tag: "Product.Sparks.PilgrimQuickplay", position: 0 },
        { trackingId: "00000000-0000-0000-0000-000000000000", tag: "Product.FNE.Unknown", position: 0 }
      ]
    }
  ]
};

coreRoutes.post("/api/v1/:hi/channel/motd/target", (c) => c.json(motdTargetResponse));
coreRoutes.post("/api/v1/:hi/surfaces/:gameMode/target", (c) => c.json(motdTargetResponse));
coreRoutes.get("/content/api/pages/fortnite-game/spark-tracks", (c) =>
  c.json({
    track: {},
    tracks: {},
    lastModified: new Date().toISOString()
  })
);
coreRoutes.get("/content/api/pages/fortnite-game/*", async (c) => {
  const pages = await loadFortniteGamePages();
  return c.json(pages);
});
coreRoutes.get("/content/api/pages/ALL", async (c) => {
  const pages = await loadFortniteGamePages();
  return c.json(pages);
});
coreRoutes.get("/content/api/pages/:pageId", async (c) => {
  const pages = await loadFortniteGamePages();
  return c.json(pages);
});
coreRoutes.get("/content/api/pages/:pageId/*", async (c) => {
  const pages = await loadFortniteGamePages();
  return c.json(pages);
});
coreRoutes.get("/content-controls/:accountId", (c) =>
  c.json({
    accountId: c.req.param("accountId"),
    grants: []
  })
);
coreRoutes.get("/content-controls/:accountId/rules/namespaces/fn", (c) => c.body(null, 204));
coreRoutes.get("/socialban/api/public/v1/:accountId", (c) => c.json({ bans: [] }));
coreRoutes.get("/fortnite/api/game/v2/privacy/account/:accountId", (c) => c.body(null, 204));
coreRoutes.post("/fortnite/api/game/v2/profileToken/verify/:accountId", (c) => c.body(null, 204));
coreRoutes.get("/fortnite/api/game/v2/profileToken/verify/:accountId", (c) => c.body(null, 405));
type CatalogEntryDef = {
  id: string;
  templateId: string;
  price: number;
  category?: string;
  sortPriority?: number;
};

function buildCatalogEntry(entry: CatalogEntryDef) {
  return {
    devName: entry.templateId,
    offerId: `v2:/${entry.id}`,
    fulfillmentIds: [],
    dailyLimit: -1,
    weeklyLimit: -1,
    monthlyLimit: -1,
    categories: entry.category ? [entry.category] : [],
    prices: [
      {
        currencyType: "MtxCurrency",
        currencySubType: "",
        regularPrice: entry.price,
        finalPrice: entry.price,
        saleExpiration: "9999-12-31T23:59:59.999Z",
        basePrice: entry.price
      }
    ],
    meta: { SectionId: "Featured", TileSize: "Normal" },
    matchFilter: "",
    filterWeight: 0,
    appStoreId: [],
    requirements: [{ requirementType: "DenyOnItemOwnership", requiredId: entry.templateId, minQuantity: 1 }],
    offerType: "StaticPrice",
    giftInfo: {
      bIsEnabled: true,
      forcedGiftBoxTemplateId: "",
      purchaseRequirements: [],
      giftRecordIds: []
    },
    refundable: true,
    metaInfo: [
      { key: "SectionId", value: "Featured" },
      { key: "TileSize", value: "Normal" }
    ],
    displayAssetPath: "",
    itemGrants: [{ templateId: entry.templateId, quantity: 1 }],
    sortPriority: entry.sortPriority ?? 0,
    catalogGroupPriority: 0,
    title: entry.templateId.split(":")[1] ?? entry.templateId
  };
}

// A small starter shop. Real shop rotation requires a hotfix system + scheduler;
// this gives a populated SHOP tab on day 1 so users see SOMETHING.
const FEATURED_ENTRIES: CatalogEntryDef[] = [
  { id: "featured.cid_242_athena_commando_f_bullseye", templateId: "AthenaCharacter:CID_242_Athena_Commando_F_Bullseye", price: 1500, category: "Panel 01" },
  { id: "featured.cid_146_athena_commando_f_marshmellospecial", templateId: "AthenaCharacter:CID_146_Athena_Commando_F_MarshmelloSpecial", price: 1500, category: "Panel 02" },
  { id: "featured.cid_113_athena_commando_m_blueace", templateId: "AthenaCharacter:CID_113_Athena_Commando_M_BlueAce", price: 1200, category: "Panel 03" }
];

const DAILY_ENTRIES: CatalogEntryDef[] = [
  { id: "daily.eid_floss", templateId: "AthenaDance:EID_Floss", price: 500, category: "Panel 04" },
  { id: "daily.eid_takethel", templateId: "AthenaDance:EID_TakeTheL", price: 500, category: "Panel 05" },
  { id: "daily.pickaxe_lockjaw", templateId: "AthenaPickaxe:Pickaxe_Lockjaw", price: 800, category: "Panel 06" },
  { id: "daily.bid_004_blackknight", templateId: "AthenaBackpack:BID_004_BlackKnight", price: 1200, category: "Panel 07" }
];

coreRoutes.get("/fortnite/api/storefront/v2/catalog", async (c) => {
  // buildCustomShop layers config/shop.json on top of the canonical shopv3.json:
  // applies hideOfferIds, priceOverrides, extraOffers (classics), and rotates
  // today's bundles from bundlePool. Falls back to pure rotator if shopv3 missing.
  const shop = await buildCustomShop();
  const totalEntries = shop.storefronts.reduce((n, s) => n + s.catalogEntries.length, 0);
  if (totalEntries > 0) return c.json(shop);
  return c.json({
    refreshIntervalHrs: 24,
    dailyPurchaseHrs: 24,
    expiration: new Date(Date.now() + 30_000).toISOString(),
    storefronts: [
      { name: "BRWeeklyStorefront", catalogEntries: FEATURED_ENTRIES.map(buildCatalogEntry) },
      { name: "BRDailyStorefront", catalogEntries: DAILY_ENTRIES.map(buildCatalogEntry) },
      { name: "BRSeason32", catalogEntries: [] }
    ]
  });
});

coreRoutes.get("/api/v1/games/fortnite/tracks/query", async (c) => {
  const playlists = await loadPlaylistConfig();
  const primary = resolvePrimaryPlaylist(playlists);

  return c.json({
    tracks: [
      {
        trackId: primary.mnemonic,
        title: primary.title,
        status: primary.enabled ? "ACTIVE" : "DISABLED",
        startTime: "2020-01-01T00:00:00.000Z",
        endTime: "9999-12-31T23:59:59.999Z"
      }
    ]
  });
});

coreRoutes.get("/api/v1/games/fortnite/tracks/activeBy/:timestamp", async (c) => {
  const playlists = await loadPlaylistConfig();
  const primary = resolvePrimaryPlaylist(playlists);

  return c.json([
    {
      trackId: primary.mnemonic,
      title: primary.title,
      active: primary.enabled,
      asOf: c.req.param("timestamp")
    }
  ]);
});
coreRoutes.get("/fortnite/api/storefront/v2/keychain", async (c) => {
  const keychain = await readJsonAsset<string[]>(["responses", "keychain.json"], []);
  return c.json(keychain);
});
coreRoutes.get("/catalog/api/shared/bulk/offers", (c) => c.json({ offers: [] }));
coreRoutes.get("/entitlement/api/account/:accountId/entitlements", (c) => c.json([]));
coreRoutes.get("/friends/api/public/friends/:accountId", (c) => c.json([]));
coreRoutes.get("/friends/api/public/blocklist/:accountId", (c) => c.json([]));
coreRoutes.get("/friends/api/public/list/fortnite/:accountId/recentPlayers/", (c) => c.json([]));
coreRoutes.get("/friends/api/v1/:accountId/settings", (c) => c.json({ acceptInvites: "public" }));
coreRoutes.get("/friends/api/v1/:accountId/summary", (c) => c.json({
  friends: 0,
  incoming: 0,
  outgoing: 0,
  blocklist: 0
}));
coreRoutes.get("/party/api/v1/Fortnite/user/:accountId", (c) => c.json({ current: [] }));
coreRoutes.get("/party/api/v1/Fortnite/parties", (c) => c.json({ current: [] }));
coreRoutes.post("/party/api/v1/:namespace/parties", (c) => c.json({ id: "retrov1-party", members: [] }));
coreRoutes.post("/party/api/v1/:namespace/user/:accountId/pings/:pingerId", (c) => c.body(null, 204));
coreRoutes.get("/party/api/v1/Fortnite/user/hybrid/settings/privacy", (c) =>
  c.json({
    receiveInvites: "ALL",
    acceptInvites: "ALL"
  })
);
coreRoutes.get("/party/api/v1/Fortnite/user/:accountId/notifications/undelivered/count", (c) => c.json({ count: 0 }));
coreRoutes.get("/fortnite/api/game/v2/matchmakingservice/ticket/player/:accountId", (c) => {
  const accountId = c.req.param("accountId");
  const bucketId = c.req.query("bucketId") ?? "32:0:EU:Playlist_DefaultSolo";
  const partyPlayerIds = c.req.query("partyPlayerIds") ?? accountId;
  const fillTeam = c.req.query("player.option.fillTeam") ?? "";
  return c.json(buildTicketResponse(accountId, accountId, bucketId, partyPlayerIds, fillTeam));
});
coreRoutes.post("/fortnite/api/game/v2/matchmakingservice/ticket/player/:accountId", async (c) => {
  const accountId = c.req.param("accountId");
  const body = (await c.req.json().catch(() => ({}))) as { bucketId?: unknown; partyPlayerIds?: unknown; fillTeam?: unknown };
  const bucketId = typeof body.bucketId === "string" && body.bucketId.length > 0
    ? body.bucketId
    : c.req.query("bucketId") ?? "32:0:EU:Playlist_DefaultSolo";
  const partyPlayerIds = typeof body.partyPlayerIds === "string" ? body.partyPlayerIds : accountId;
  const fillTeam = typeof body.fillTeam === "string" ? body.fillTeam : "";
  return c.json(buildTicketResponse(accountId, accountId, bucketId, partyPlayerIds, fillTeam));
});

// Matchmaking encryption key — game asks for an AES key after session assignment.
coreRoutes.get("/fortnite/api/matchmaking/session/:sessionId/key/:accountId", (c) =>
  c.json({
    accountId: c.req.param("accountId"),
    sessionId: c.req.param("sessionId"),
    key: "AOJEv8uTFmUh7XM2328kq9rlAzeQ5xzWzPIiyKn2s7s="
  })
);
coreRoutes.get("/fortnite/api/matchmaking/session/findPlayer/:id", (c) => c.json([]));
coreRoutes.get("/fortnite/api/matchmaking/session/:sessionId", (c) => {
  const accountId = accountIdFromBearer(c.req.header("authorization"), "Player");
  const versionGlobal = getVersionInfo(c).versionGlobal;
  return c.json(
    buildMatchmakingSession(c.req.param("sessionId"), "retrov1", accountId, String(versionGlobal))
  );
});
coreRoutes.post("/fortnite/api/matchmaking/session/:sessionId/join", (c) => c.body(null, 204));
// Session encryption key — the client polls this AFTER session lookup. Returning
// the session shape here makes the client think the key query failed, so it
// shows "Failed to query session encryption key". Real shape is small.
coreRoutes.get("/fortnite/api/game/v2/matchmaking/account/:accountId/session/:sessionId", (c) =>
  c.json({
    accountId: c.req.param("accountId"),
    sessionId: c.req.param("sessionId"),
    key: "none"
  })
);
// POST .../matchMakingRequest probe (some builds send this before joining)
coreRoutes.post("/fortnite/api/matchmaking/session/matchMakingRequest", (c) => c.json([]));
coreRoutes.get("/fortnite/api/receipts/v1/account/:accountId/receipts", (c) => c.json([]));
coreRoutes.get("/fortnite/api/storeaccess/v1/request_access/:accountId", (c) => c.body(null, 204));
coreRoutes.get("/affiliate/api/public/affiliates/slug/:affiliateName", (c) =>
  c.json({
    id: c.req.param("affiliateName"),
    slug: c.req.param("affiliateName"),
    status: "ACTIVE"
  })
);
coreRoutes.get("/api/statsv2/account/:accountId", (c) => c.json({ startTime: 0, endTime: Date.now(), stats: {} }));
coreRoutes.get("/statsproxy/api/statsv2/account/:accountId", (c) =>
  c.json({
    accountId: c.req.param("accountId"),
    startTime: 0,
    endTime: 999999999999999,
    stats: {}
  })
);
coreRoutes.post("/*/api/statsv2/query", (c) => c.json([]));

coreRoutes.post("/api/v1/assets/Fortnite/*", (c) =>
  c.json({
    FortCreativeDiscoverySurface: {
      meta: { promotion: 1 },
      assets: {}
    }
  })
);

coreRoutes.get("/lightswitch/api/service/bulk/status", (c) =>
  c.json([
    {
      serviceInstanceId: "fortnite",
      status: "UP",
      message: "RetroV1 ready",
      maintenanceUri: null,
      overrideCatalogIds: ["a7f138b2e51945ffbfdacc1af0541053"],
      allowedActions: [],
      banned: false,
      launcherInfoDTO: {
        appName: "Fortnite",
        catalogItemId: "4fe75bbc5a674f4f9b356b5c90567da5",
        namespace: "fn"
      }
    }
  ])
);

coreRoutes.get("/lightswitch/api/service/:serviceId/status", (c) =>
  c.json({
    serviceInstanceId: c.req.param("serviceId"),
    status: "UP",
    message: "RetroV1 ready",
    maintenanceUri: null,
    allowedActions: [],
    banned: false
  })
);

// --- Additional 32.11 client probe endpoints ---------------------------------

// User-level settings (audio, controls etc. handled client-side, server just ack).
coreRoutes.post("/api/v1/user/setting", (c) => c.json({ success: true }));

// Profile preference writes — client persists these but they're informational.
coreRoutes.put("/profile/languages", (c) => c.body(null, 204));
coreRoutes.put("/profile/play_region", (c) => c.body(null, 204));
coreRoutes.put("/profile/privacy_settings", (c) => c.body(null, 204));

// Cooked content packages — used for content delivery; empty is safe.
coreRoutes.get("/api/content/v2/link/:linkId/cooked-content-package", (c) => c.body(null, 204));
coreRoutes.get("/api/content/v4/link/:linkId/cooked-content-package", (c) => c.body(null, 204));

// Worlds (creative islands).
coreRoutes.get("/api/v1/namespace/fn/worlds/accessibleTo/:accountId", (c) => c.json({ worlds: [] }));
coreRoutes.get("/api/v1/namespace/fn/worlds/world/:worldId/session", (c) => c.body(null, 204));
coreRoutes.get("/api/v1/namespace/fn/worlds/world/:worldId/attest/:accountId", (c) =>
  c.json({ accountId: c.req.param("accountId"), accessible: true })
);
coreRoutes.post("/api/v1/namespace/fn/worlds/account/:accountId", (c) => c.json({ worlds: [] }));

// Quests progress.
coreRoutes.get("/api/quest/v3/:deploymentId/progress/account/:accountId", (c) =>
  c.json({ accountId: c.req.param("accountId"), progress: [] })
);

// Tournament/event data — empty arrays so the COMPETE tab loads.
coreRoutes.get("/api/v1/events/Fortnite/download/:accountId", (c) =>
  c.json({
    events: [],
    eventWindows: [],
    templates: [],
    scoreLocationMetadata: []
  })
);
coreRoutes.get("/api/v1/leaderboards/Fortnite/:eventId/:eventWindowId/*", (c) => c.json({ entries: [], liveSessions: {} }));
coreRoutes.get("/api/v1/events/Fortnite/:event/history/:accountId", (c) => c.json([]));
coreRoutes.post("/api/verify/match", (c) => c.body(null, 204));

// User search (used by friend-add UI).
coreRoutes.post("/user/v9/product-users/search", (c) => c.json({ users: [] }));

// Generic getter Neonite stubs.
coreRoutes.get("/api/v1/Fortnite/get", (c) => c.json({}));

// Track progress (sparks/Festival).
coreRoutes.get("/api/v1/games/fortnite/trackprogress/*", (c) =>
  c.json({ progress: {}, lastModified: new Date().toISOString() })
);

// Tracks active-by (Festival).
coreRoutes.get("/api/v1/games/fortnite/tracks/activeBy/*", (c) =>
  c.json({ activeTracks: [], lastModified: new Date().toISOString() })
);

// LFG recent players list.
coreRoutes.get("/api/v1/lfg/Fortnite/users/:accountId/recentPlayers/", (c) => c.json([]));

// Content-controls pin verification — RetroV1 has no parental gating.
coreRoutes.post("/content-controls/:accountId/verify-pin", (c) => c.json({ valid: true }));

// Locker v4 loadout preset writes — preserves chosen preset slot.
coreRoutes.put("/api/locker/v4/:deploymentId/account/:accountId/loadout-group-preset/index/:presetIndex", (c) =>
  c.json({ presetIndex: Number(c.req.param("presetIndex")), updatedTime: new Date().toISOString() })
);
coreRoutes.put("/api/locker/v4/:deploymentId/loadout/:loadoutType/account/:accountId/loadout-preset/index/:presetIndex", (c) =>
  c.json({ presetIndex: Number(c.req.param("presetIndex")), updatedTime: new Date().toISOString() })
);

// Locker v3 loadout preset writes.
coreRoutes.put("/api/locker/v3/:deploymentId/loadout/:loadoutType/account/:accountId/:loadout", (c) =>
  c.json({ updatedTime: new Date().toISOString() })
);
coreRoutes.put("/api/locker/v3/:deploymentId/loadout/:loadoutType/account/:accountId/loadout-preset/index/:presetIndex", (c) =>
  c.json({ presetIndex: Number(c.req.param("presetIndex")), updatedTime: new Date().toISOString() })
);
