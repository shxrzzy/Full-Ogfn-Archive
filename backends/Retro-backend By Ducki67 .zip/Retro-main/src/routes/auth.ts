import { Hono } from "hono";
import type { Context } from "hono";
import { z } from "zod";
import { SignJWT, decodeJwt } from "jose";
import { config } from "../config";
import { ensureBaseProfiles } from "../lib/profiles";
import { getAccount, upsertAccount } from "../lib/storage";
import { readBearerToken, signAccessToken, verifyAccessToken } from "../lib/tokens";

const DEFAULT_CLIENT_ID = "fortnitePCGameClient";

const oauthTokenSchema = z.object({
  grant_type: z.string(),
  username: z.string().optional(),
  account_id: z.string().optional(),
  exchange_code: z.string().optional(),
  refresh_token: z.string().optional(),
  device_id: z.string().optional(),
  code: z.string().optional(),
  client_id: z.string().optional()
});

function normalizeId(value: string): string {
  return value.trim().replace(/\s+/g, "_").slice(0, 64) || "Player";
}

// Email logins (grant_type=password) send the full address as the username,
// e.g. "john@gmail.com". Fortnite uses the username as the in-game display name,
// so keep only the local part before the "@". Matches Neonite/Remix behaviour.
function emailLocalPart(value: string): string {
  const atIndex = value.indexOf("@");
  return atIndex > 0 ? value.slice(0, atIndex) : value;
}

export const authRoutes = new Hono();

authRoutes.post("/account/api/oauth/token", async (c) => {
  const body = oauthTokenSchema.safeParse(await c.req.parseBody());
  if (!body.success) {
    return c.json(
      {
        errorCode: "errors.com.epicgames.common.oauth.invalid_request",
        errorMessage: "Invalid OAuth request body"
      },
      400
    );
  }

  const grantType = body.data.grant_type;
  const usernameName = body.data.username ? emailLocalPart(body.data.username) : undefined;
  const fallbackName = usernameName ?? body.data.account_id ?? body.data.code ?? body.data.exchange_code ?? "Player";
  let accountId = normalizeId(body.data.account_id ?? fallbackName);
  let displayName = normalizeId(usernameName ?? accountId);

  switch (grantType) {
    case "password":
    case "authorization_code":
    case "exchange_code":
    case "device_auth":
    case "client_credentials":
    case "refresh_token":
      break;
    default:
      return c.json(
        {
          errorCode: "errors.com.epicgames.common.oauth.unsupported_grant_type",
          errorMessage: `Unsupported grant_type ${grantType}`
        },
        400
      );
  }

  if (grantType === "refresh_token" && body.data.refresh_token) {
    const rawRefresh = body.data.refresh_token.startsWith("eg1~")
      ? body.data.refresh_token.slice(4)
      : body.data.refresh_token;
    try {
      const decoded = await verifyAccessToken(rawRefresh);
      accountId = normalizeId(decoded.sub);
      displayName = normalizeId(decoded.dn ?? decoded.sub);
    } catch {
      const claims = decodeJwt(rawRefresh);
      const fallbackAccount = typeof claims.sub === "string" ? claims.sub : undefined;
      const fallbackDisplay =
        typeof claims.dn === "string"
          ? claims.dn
          : typeof claims.displayName === "string"
            ? claims.displayName
            : fallbackAccount;

      if (fallbackAccount) {
        accountId = normalizeId(fallbackAccount);
        displayName = normalizeId(fallbackDisplay ?? fallbackAccount);
      }
    }
  }

  const account = await upsertAccount(accountId, displayName);
  await ensureBaseProfiles(account.accountId);
  const token = await signAccessToken({
    sub: account.accountId,
    dn: account.displayName,
    clid: body.data.client_id ?? DEFAULT_CLIENT_ID,
    am: grantType
  });

  const refreshToken = await signAccessToken({
    sub: account.accountId,
    dn: account.displayName,
    clid: body.data.client_id ?? DEFAULT_CLIENT_ID,
    am: "refresh_token"
  });

  const accessExpiresAt = new Date(Date.now() + 86400 * 1000).toISOString();
  const refreshExpiresAt = new Date(Date.now() + 30 * 86400 * 1000).toISOString();

  return c.json({
    access_token: `eg1~${token}`,
    token_type: "bearer",
    expires_in: 86400,
    expires_at: accessExpiresAt,
    refresh_token: `eg1~${refreshToken}`,
    refresh_expires: 2592000,
    refresh_expires_at: refreshExpiresAt,
    accountId: account.accountId,
    account_id: account.accountId,
    client_id: body.data.client_id ?? DEFAULT_CLIENT_ID,
    internal_client: true,
    client_service: "fortnite",
    displayName: account.displayName,
    app: "fortnite",
    in_app_id: account.accountId
  });
});

authRoutes.get("/account/api/oauth/verify", async (c) => {
  const bearer = readBearerToken(c.req.header("authorization"));
  if (!bearer) {
    return c.json({ errorCode: "errors.com.epicgames.common.oauth.invalid_token" }, 401);
  }

  const rawToken = bearer.startsWith("eg1~") ? bearer.slice(4) : bearer;

  try {
    const decoded = await verifyAccessToken(rawToken);
    return c.json({
      token: bearer,
      token_type: "bearer",
      account_id: decoded.sub,
      client_id: decoded.clid,
      display_name: decoded.dn,
      app: "fortnite",
      in_app_id: decoded.sub,
      auth_method: decoded.am,
      active: true
    });
  } catch {
    const claims = decodeJwt(rawToken);
    const accountId = typeof claims.sub === "string" ? claims.sub : "Player";
    const displayName =
      typeof claims.dn === "string"
        ? claims.dn
        : typeof claims.displayName === "string"
          ? claims.displayName
          : accountId;
    const clientId = typeof claims.clid === "string" ? claims.clid : DEFAULT_CLIENT_ID;

    return c.json({
      token: bearer,
      token_type: "bearer",
      account_id: accountId,
      client_id: clientId,
      display_name: displayName,
      app: "fortnite",
      in_app_id: accountId,
      auth_method: "authorization_code",
      active: true
    });
  }
});

authRoutes.delete("/account/api/oauth/sessions/kill", (c) => c.body(null, 204));
authRoutes.delete("/account/api/oauth/sessions/kill/:token", (c) => c.body(null, 204));

function fullAccountInfo(accountId: string, displayName: string) {
  return {
    id: accountId,
    displayName,
    email: `${displayName}@retrov1.local`,
    failedLoginAttempts: 0,
    lastLogin: new Date().toISOString(),
    numberOfDisplayNameChanges: 1,
    dateOfBirth: "1999-01-01",
    ageGroup: "ADULT",
    headless: false,
    country: "US",
    phoneNumber: "",
    company: "RetroV1",
    preferredLanguage: "en",
    lastDisplayNameChange: new Date().toISOString(),
    canUpdateDisplayName: true,
    tfaEnabled: true,
    emailVerified: true,
    minorVerified: false,
    minorExpected: false,
    minorStatus: "NOT_MINOR",
    cabinedMode: false,
    hasHashedEmail: false,
    externalAuths: {}
  };
}

authRoutes.get("/account/api/public/account/:accountId", async (c) => {
  const accountId = c.req.param("accountId");
  const account = (await getAccount(accountId)) ?? {
    accountId,
    displayName: accountId
  };
  return c.json(fullAccountInfo(account.accountId, account.displayName));
});

authRoutes.get("/account/api/public/account", async (c) => {
  const accountId = c.req.query("accountId") ?? "Player";
  const account = (await getAccount(accountId)) ?? {
    accountId,
    displayName: accountId
  };
  return c.json([fullAccountInfo(account.accountId, account.displayName)]);
});

authRoutes.get("/account/api/public/account/:accountId/externalAuths", (c) => c.json([]));

authRoutes.get("/fortnite/api/discovery/accessToken/:accountId", async (c) => {
  const accountId = normalizeId(c.req.param("accountId"));
  const account = await upsertAccount(accountId, accountId);
  await ensureBaseProfiles(account.accountId);

  const token = await signAccessToken({
    sub: account.accountId,
    dn: account.displayName,
    clid: DEFAULT_CLIENT_ID,
    am: "discovery"
  });

  return c.json({
    accountId: account.accountId,
    accessToken: `eg1~${token}`,
    expiresIn: 86400
  });
});

authRoutes.get("/account/api/public/account/displayName/:displayName", async (c) => {
  const displayName = c.req.param("displayName");
  const account = await upsertAccount(normalizeId(displayName), displayName);
  return c.json({
    id: account.accountId,
    displayName: account.displayName,
    externalAuths: {}
  });
});

authRoutes.get("/api/v1/public/accounts", (c) => {
  const accountId = c.req.query("accountId") ?? "Player";
  return c.json({ accounts: [{ accountId, tags: [] }] });
});

authRoutes.get("/account/api/public/account/token", async (c) => {
  const bearer = readBearerToken(c.req.header("authorization"));
  if (!bearer) {
    return c.json({ errorCode: "errors.com.epicgames.common.oauth.invalid_token" }, 401);
  }

  const rawToken = bearer.startsWith("eg1~") ? bearer.slice(4) : bearer;
  try {
    const decoded = await verifyAccessToken(rawToken);
    return c.json({
      account_id: decoded.sub,
      displayName: decoded.dn,
      app: "fortnite"
    });
  } catch {
    return c.json({ errorCode: "errors.com.epicgames.common.oauth.invalid_token" }, 401);
  }
});

authRoutes.get("/account/api/oauth/exchange", async (c) => {
  const bearer = readBearerToken(c.req.header("authorization"));
  if (!bearer) {
    return c.json({ errorCode: "errors.com.epicgames.common.oauth.invalid_token" }, 401);
  }

  const token = bearer.startsWith("eg1~") ? bearer.slice(4) : bearer;
  try {
    const decoded = await verifyAccessToken(token);
    return c.json({
      expiresInSeconds: 300,
      code: `${decoded.sub}:${Date.now()}`,
      creatingClientId: decoded.clid
    });
  } catch {
    return c.json({ errorCode: "errors.com.epicgames.common.oauth.invalid_token" }, 401);
  }
});

async function handlePublicKey(c: Context) {
  const body = await c.req.parseBody();
  const accountId = emailLocalPart(String(body.account_id ?? body.accountId ?? body.username ?? "Player"));
  const key = String(body.key ?? "");

  const token = await new SignJWT({
    account_id: accountId,
    generated: 1731795408,
    key_guid: "2e57bba7-4a7a-423c-b4b4-853acfcf019c",
    kid: "20230621",
    key,
    expiration: "9999-12-31T23:59:59.999Z",
    type: "legacy"
  })
    .setProtectedHeader({ alg: "HS256", kid: "20230621" })
    .sign(new TextEncoder().encode("NexaKey"));

  return c.json({
    key,
    account_id: accountId,
    key_guid: "2e57bba7-4a7a-423c-b4b4-853acfcf019c",
    kid: "20230621",
    expiration: "9999-12-31T23:59:59.999Z",
    jwt: token,
    type: "legacy"
  });
}

authRoutes.post("/publickey/v2/publickey", handlePublicKey);
authRoutes.post("/publickey/v2/publickey/", handlePublicKey);