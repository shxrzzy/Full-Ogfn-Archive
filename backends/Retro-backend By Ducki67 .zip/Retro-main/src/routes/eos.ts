import { Hono } from "hono";
import crypto from "node:crypto";
import { SignJWT, decodeJwt } from "jose";
import { config } from "../config";
import { readJsonAsset } from "../lib/assets";
import { readBearerToken, signAccessToken, verifyAccessToken } from "../lib/tokens";

export const eosRoutes = new Hono();

const eosFeatures = [
  "AntiCheat",
  "Connect",
  "ContentService",
  "Ecom",
  "EpicConnect",
  "Inventories",
  "LockerService",
  "Matchmaking Service",
  "ExchangeCodeCreation",
  "Achievements",
  "Leaderboards",
  "Matchmaking",
  "Metrics",
  "PlayerReports",
  "Sanctions",
  "Stats",
  "TitleStorage",
  "Voice",
  "CommerceService",
  "FNResonanceService",
  "MagpieService",
  "PCBService",
  "QuestService"
];

const eosOrgId = "o-aa83a0a9bc45e98c80c1b1c9d92e9e";
const eosProductId = "prod-fn";
const eosSandboxId = "fn";
const eosDeploymentId = "62a9473a2dca46b29ccf17577fcf42d7";

function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

async function signEosToken(claims: Record<string, unknown>): Promise<string> {
  return new SignJWT(claims)
    .setProtectedHeader({ alg: "HS256", kid: "2022-06-14T06:17:57.047928700Z" })
    .sign(new TextEncoder().encode(process.env.JWT_SECRET ?? "change-me-retrov1"));
}

function decodeJwtClaims(token: string): Record<string, unknown> {
  try {
    return decodeJwt(token);
  } catch {
    return {};
  }
}

function rewriteUrls(value: unknown, httpBase: string, wsBase: string): unknown {
  if (typeof value === "string") {
    return value
      .replace(/https?:\/\/api\.epicgames\.dev/gi, httpBase)
      .replace(/wss?:\/\/api\.epicgames\.dev/gi, wsBase)
      .replace(/wss?:\/\/connect\.epicgames\.dev/gi, wsBase)
      .replace(/wss?:\/\/xmpp-service-prod\.ol\.epicgames\.com/gi, wsBase);
  }
  if (Array.isArray(value)) {
    return value.map((v) => rewriteUrls(v, httpBase, wsBase));
  }
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([k, v]) => [k, rewriteUrls(v, httpBase, wsBase)])
    );
  }
  return value;
}

async function loadFilteredEosConfig() {
  const eosConfig = await readJsonAsset<Record<string, unknown>>(["router", "eos.json"], {});

  const clientSection =
    eosConfig && typeof eosConfig.client === "object" && eosConfig.client !== null
      ? (eosConfig.client as Record<string, unknown>)
      : {};

  const filteredClient = Object.fromEntries(
    Object.entries(clientSection).filter(([key]) => !/anti.?cheat|arc/i.test(key))
  );

  // Rewrite all Epic endpoint URLs in the SDK config to point at us — otherwise
  // the game tries to open WebSockets to api.epicgames.dev and hangs on
  // "Completing Sign-In..." waiting for notifications/lobby connections.
  const httpBase = config.BASE_URL.replace(/\/+$/, "");
  const wsBase = httpBase.replace(/^https?:/i, httpBase.startsWith("https") ? "wss:" : "ws:");

  return rewriteUrls(
    {
      ...eosConfig,
      client: filteredClient
    },
    httpBase,
    wsBase
  ) as Record<string, unknown>;
}

eosRoutes.post("/auth/v1/oauth/token", async (c) => {
  const body = await c.req.parseBody();
  const grantType = asString(body.grant_type, "external_auth");
  const deploymentId = asString(body.deployment_id, eosDeploymentId);
  const nonce = asString(body.nonce, "");

  if (grantType === "client_credentials") {
    const token = await signEosToken({
      clientId: "3e13c5c57f594a578abe516eecb673fe",
      productId: "3fd15bc288014f698cca1a3d1f01c7af",
      iss: "eos",
      env: "prod",
      organizationId: eosOrgId,
      features: eosFeatures,
      deploymentId,
      sandboxId: "183b8244f3d84e71a4d4af08a17f7d9a",
      tokenType: "clientToken",
      exp: 2147483647,
      iat: Math.floor(Date.now() / 1000),
      jti: crypto.randomUUID()
    });

    return c.json({
      access_token: token,
      token_type: "bearer",
      expires_at: "9999-12-31T23:59:59.999Z",
      features: eosFeatures,
      organization_id: eosOrgId,
      product_id: eosProductId,
      sandbox_id: eosSandboxId,
      deployment_id: deploymentId,
      expires_in: 3599
    });
  }

  if (grantType === "refresh_token") {
    const incomingRefresh = asString(body.refresh_token).replace(/^eg1~/i, "");
    let accountId = "Player";
    let displayName = "Player";

    if (incomingRefresh) {
      const claims = decodeJwtClaims(incomingRefresh);
      accountId = asString(claims.sub, asString(claims.account_id, "Player"));
      displayName = asString(claims.dn, asString(claims.displayName, accountId));
    }

    const accessToken = await signEosToken({
      sub: accountId,
      pfsid: "fn",
      iss: "http://retrov1/epic/oauth/v2",
      dn: displayName,
      pfpid: "prod-fn",
      aud: "ec684b8c687f479fadea3cb2ad83f5c6",
      pfdid: deploymentId,
      t: "epic_id_r",
      appid: "fghi4567FNFBKFz3E4TROb0bmPS8h1GW",
      scope: "basic_profile friends_list openid offline_access presence",
      iat: Math.floor(Date.now() / 1000),
      exp: 2147483647,
      jti: crypto.randomUUID()
    });

    const idToken = await signEosToken({
      aud: "ec684b8c687f479fadea3cb2ad83f5c6",
      sub: accountId,
      pfsid: "fn",
      act: {
        pltfm: "other",
        eaid: displayName,
        eat: "epicgames"
      },
      pfdid: deploymentId,
      iss: "http://retrov1/auth/v1/oauth",
      exp: 2147483647,
      iat: Math.floor(Date.now() / 1000),
      tokenType: "idToken",
      pfpid: "prod-fn"
    });

    return c.json({
      access_token: accessToken,
      expires_in: 15552000,
      expires_at: "9999-12-31T23:59:59.999Z",
      token_type: "bearer",
      refresh_token: accessToken,
      refresh_expires: 15552000,
      refresh_expires_at: "9999-12-31T23:59:59.999Z",
      account_id: accountId,
      client_id: "3e13c5c57f594a578abe516eecb673fe",
      internal_client: true,
      client_service: "3fd15bc288014f698cca1a3d1f01c7af",
      scope: ["basic_profile", "friends_list", "openid", "offline_access", "presence"],
      displayName,
      app: "3fd15bc288014f698cca1a3d1f01c7af",
      in_app_id: accountId,
      device_id: "RetroV1",
      product_id: "3fd15bc288014f698cca1a3d1f01c7af",
      sandbox_id: eosSandboxId,
      deployment_id: deploymentId,
      application_id: "fghi4567UG3ZXlhvevzKJI65wfTUoYBC",
      acr: "urn:epic:loa:aal1",
      auth_time: new Date().toISOString(),
      id_token: idToken
    });
  }

  const extToken = asString(body.external_auth_token).replace(/^eg1~/i, "");
  let accountId = asString(body.account_id, "Player");
  let displayName = asString(body.display_name, accountId);

  if (extToken) {
    const claims = decodeJwtClaims(extToken);
    accountId = asString(claims.sub, accountId);
    displayName = asString(claims.dn, displayName);
  }

  const accessToken = await signEosToken({
    clientId: "ec684b8c687f479fadea3cb2ad83f5c6",
    role: "GameClient",
    productId: eosProductId,
    iss: "eos",
    env: "prod",
    nonce,
    organizationId: eosOrgId,
    features: eosFeatures,
    productUserId: accountId,
    organizationUserId: "000185f80b9a4dc3aaf1ca83611c2bf5",
    clientIp: c.req.header("x-forwarded-for") ?? "127.0.0.1",
    deploymentId,
    sandboxId: eosSandboxId,
    tokenType: "userToken",
    exp: 2147483647,
    iat: Math.floor(Date.now() / 1000),
    jti: crypto.randomUUID(),
    account: {
      idp: "epicgames",
      displayName,
      id: accountId,
      plf: "other"
    }
  });

  const idToken = await signEosToken({
    aud: "ec684b8c687f479fadea3cb2ad83f5c6",
    sub: accountId,
    pfsid: "fn",
    act: {
      pltfm: "other",
      eaid: displayName,
      eat: "epicgames"
    },
    pfdid: deploymentId,
    iss: "http://retrov1/auth/v1/oauth",
    exp: 2147483647,
    iat: Math.floor(Date.now() / 1000),
    tokenType: "idToken",
    pfpid: "prod-fn"
  });

  return c.json({
    access_token: accessToken,
    token_type: "bearer",
    expires_at: "9999-12-31T23:59:59.999Z",
    nonce,
    features: eosFeatures,
    organization_id: eosOrgId,
    product_id: eosProductId,
    sandbox_id: eosSandboxId,
    deployment_id: deploymentId,
    organization_user_id: "000185f80b9a4dc3aaf1ca83611c2bf5",
    product_user_id: accountId,
    product_user_id_created: false,
    id_token: idToken,
    expires_in: 3599
  });
});

eosRoutes.get("/epic/id/v2/sdk/accounts", (c) => {
  const accountId = c.req.query("accountId") ?? "Player";
  return c.json([
    {
      accountId,
      displayName: accountId,
      preferredLanguage: "en",
      cabinedMode: false,
      empty: false,
      linkedAccounts: []
    }
  ]);
});

eosRoutes.get("/sdk/v1/default", async (c) => c.json(await loadFilteredEosConfig()));

eosRoutes.get("/sdk/v1/product/prod-fn", async (c) => c.json(await loadFilteredEosConfig()));

const buildEpicSettingsResponse = async () =>
  readJsonAsset<Record<string, unknown>>(["responses", "epic-settings.json"], { values: {} });

eosRoutes.get("/v1/epic-settings/public/users/:accountId/values", async (c) => c.json(await buildEpicSettingsResponse()));
eosRoutes.patch("/v1/epic-settings/public/users/:accountId/values", async (c) => c.json(await buildEpicSettingsResponse()));
eosRoutes.put("/v1/epic-settings/public/users/:accountId/values", async (c) => c.json(await buildEpicSettingsResponse()));
eosRoutes.post("/v1/epic-settings/public/users/:accountId/values", async (c) => c.json(await buildEpicSettingsResponse()));

eosRoutes.get("/epic/friends/v1/:accountId/blocklist", (c) => c.json([]));
eosRoutes.patch("/epic/presence/v1/:gameNsIg/:accountId/presence/:presenceUuid", (c) => c.body(null, 204));
eosRoutes.get("/epic/chat/v1/public/_/users/:accountId/summary", (c) =>
  c.json({
    accountId: c.req.param("accountId"),
    unread: 0,
    conversations: 0
  })
);
eosRoutes.get("/epic/chat/v1/public/_/users/hybrid/conversations", (c) => c.json({ conversations: [] }));
eosRoutes.post("/user/v9/product-users/search", (c) => c.json({ accounts: [] }));
eosRoutes.get("/v2", (c) => c.json({ service: "eos", status: "ok" }));

eosRoutes.post("/epic/oauth/v2/token", async (c) => {
  const body = await c.req.parseBody();
  const deploymentId = asString(body.deployment_id, eosDeploymentId);
  const grantType = asString(body.grant_type, "refresh_token");
  const incomingRefresh = asString(body.refresh_token).replace(/^eg1~/i, "");

  let accountId = asString(body.account_id, "Player");
  let displayName = asString(body.display_name, accountId);

  if (incomingRefresh) {
    const claims = decodeJwtClaims(incomingRefresh);
    accountId = asString(claims.sub, accountId);
    displayName = asString(claims.dn, asString(claims.displayName, displayName));
  }

  const scope = asString(body.scope, "basic_profile friends_list openid presence");
  const clientId = "ec684b8c687f479fadea3cb2ad83f5c6";

  const accessToken = await signEosToken({
    sub: accountId,
    pfsid: "fn",
    iss: "https://api.epicgames.dev/epic/oauth/v1",
    dn: displayName,
    nonce: "n-01/jkXYh/9P5JimUEpSisDyK3Xw=",
    pfpid: "prod-fn",
    sec: 1,
    aud: clientId,
    pfdid: deploymentId,
    t: "epic_id",
    scope,
    appid: "fghi4567FNFBKFz3E4TROb0bmPS8h1GW",
    exp: 2147483647,
    iat: Math.floor(Date.now() / 1000),
    jti: crypto.randomUUID()
  });

  const refreshToken = await signEosToken({
    sub: accountId,
    pfsid: "fn",
    iss: "https://api.epicgames.dev/epic/oauth/v1",
    dn: displayName,
    pfpid: "prod-fn",
    aud: clientId,
    pfdid: deploymentId,
    t: grantType === "refresh_token" ? "epic_id_r" : "epic_id",
    appid: "fghi4567FNFBKFz3E4TROb0bmPS8h1GW",
    scope,
    exp: 2147483647,
    iat: Math.floor(Date.now() / 1000),
    jti: crypto.randomUUID()
  });

  const idToken = await signEosToken({
    sub: accountId,
    pfsid: "fn",
    iss: "https://api.epicgames.dev/epic/oauth/v1",
    dn: displayName,
    nonce: "n-e3Kcqw0hulXkbebFRBL8o5AwL3M=",
    pfpid: "prod-fn",
    aud: clientId,
    pfdid: deploymentId,
    t: "id_token",
    appid: "fghi4567FNFBKFz3E4TROb0bmPS8h1GW",
    exp: 2147483647,
    iat: Math.floor(Date.now() / 1000),
    jti: crypto.randomUUID()
  });

  return c.json({
    scope,
    token_type: "bearer",
    acr: "AAL1",
    access_token: accessToken,
    expires_in: 7200,
    expires_at: "9999-12-31T23:59:59.999Z",
    refresh_token: refreshToken,
    refresh_expires_in: 28800,
    refresh_expires_at: "9999-12-31T23:59:59.999Z",
    account_id: accountId,
    client_id: clientId,
    application_id: "fghi4567FNFBKFz3E4TROb0bmPS8h1GW",
    selected_account_id: accountId,
    id_token: idToken,
    auth_time: new Date().toISOString()
  });
});

eosRoutes.post("/epic/oauth/v2/tokenInfo", async (c) => {
  const authHeader = c.req.header("authorization") ?? "";
  const basicPrefix = "Basic ";

  if (authHeader.startsWith(basicPrefix)) {
    try {
      const decoded = Buffer.from(authHeader.slice(basicPrefix.length), "base64").toString("utf8");
      const [clientId] = decoded.split(":");

      if (!clientId) {
        return c.json({ errorCode: "errors.com.epicgames.common.oauth.invalid_token" }, 401);
      }

      return c.json({
        active: true,
        scope: "basic_profile openid offline_access",
        token_type: "bearer",
        expires_in: 2147483647,
        expires_at: "9999-12-31T23:59:59.999Z",
        account_id: "Player",
        client_id: clientId,
        application_id: "fghi45672f0QV6b6B1KntLd7JR7RFLWc"
      });
    } catch {
      return c.json({ errorCode: "errors.com.epicgames.common.oauth.invalid_token" }, 401);
    }
  }

  const token = readBearerToken(authHeader);
  if (!token) {
    return c.json({ errorCode: "errors.com.epicgames.common.oauth.invalid_token" }, 401);
  }

  try {
    const decoded = await verifyAccessToken(token.startsWith("eg1~") ? token.slice(4) : token);
    return c.json({
      account_id: decoded.sub,
      app: "fortnite",
      client_id: decoded.clid,
      active: true
    });
  } catch {
    return c.json({ errorCode: "errors.com.epicgames.common.oauth.invalid_token" }, 401);
  }
});

eosRoutes.get("/api/v1/public/data/keychain", async (c) => {
  const keychain = await readJsonAsset<string[]>(["responses", "keychain.json"], []);
  return c.json(keychain);
});

eosRoutes.get("/api/v1/public/data/fortnite-game", async (c) => {
  const fortniteGame = await readJsonAsset<Record<string, unknown>>(["responses", "fortnitegame.json"], {});
  return c.json(fortniteGame);
});

eosRoutes.get("/api/v1/public/data/epic-settings", async (c) => {
  const rawSettings = await readJsonAsset<Record<string, unknown>>(["responses", "epic-settings.json"], {});
  return c.json(rawSettings);
});

eosRoutes.get("/router/eos/config", async (c) => {
  return c.json(await loadFilteredEosConfig());
});