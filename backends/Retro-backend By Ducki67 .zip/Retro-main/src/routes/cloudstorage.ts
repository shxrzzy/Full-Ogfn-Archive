import { mkdir, readdir, readFile, stat, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { join, extname } from "node:path";
import { Hono } from "hono";
import { listCloudStorageFiles, readTextAsset } from "../lib/assets";

export const cloudStorageRoutes = new Hono();

// --- System cloudstorage (hotfixes/) ----------------------------------------
cloudStorageRoutes.get("/fortnite/api/cloudstorage/system", async (c) => c.json(await listCloudStorageFiles()));
cloudStorageRoutes.get("/fortnite/api/cloudstorage/system/config", async (c) => c.json(await listCloudStorageFiles()));

cloudStorageRoutes.get("/fortnite/api/cloudstorage/system/:filename", async (c) => {
  const filename = c.req.param("filename");
  const contents = await readTextAsset(["hotfixes", filename], "");
  if (!contents) {
    return c.json({ errorCode: "errors.com.retrov1.cloudstorage.file_not_found" }, 404);
  }
  return c.text(contents, 200, { "content-type": "application/octet-stream" });
});

// --- User cloudstorage (per-account persistent player settings) -------------
// The game PUTs files like ClientSettings.Sav here on every settings change.
// Without persistence, settings reset on every login. We store them on disk
// at data/cloudstorage/<accountId>/<fileName>.

function safeName(name: string): string {
  // Strip path traversal and weird chars. Fortnite filenames are simple.
  return name.replace(/[^A-Za-z0-9._-]/g, "_").slice(0, 128);
}

function userDir(accountId: string): string {
  return join(process.cwd(), "data", "cloudstorage", safeName(accountId));
}

function contentTypeFor(filename: string): string {
  const ext = extname(filename).toLowerCase();
  if (ext === ".sav" || ext === ".bin") return "application/octet-stream";
  if (ext === ".json") return "application/json";
  if (ext === ".txt") return "text/plain";
  return "application/octet-stream";
}

cloudStorageRoutes.get("/fortnite/api/cloudstorage/user/config", async (c) => c.json([]));

cloudStorageRoutes.get("/fortnite/api/cloudstorage/user/:accountId", async (c) => {
  const dir = userDir(c.req.param("accountId"));
  let files: string[] = [];
  try { files = await readdir(dir); } catch { return c.json([]); }

  const entries = [];
  for (const file of files) {
    const full = join(dir, file);
    const st = await stat(full).catch(() => null);
    if (!st?.isFile()) continue;
    const buf = await readFile(full).catch(() => Buffer.alloc(0));
    entries.push({
      uniqueFilename: file,
      filename: file,
      hash: createHash("sha1").update(buf).digest("hex"),
      hash256: createHash("sha256").update(buf).digest("hex"),
      length: st.size,
      contentType: contentTypeFor(file),
      uploaded: new Date(st.mtimeMs).toISOString(),
      storageType: "S3",
      storageIds: {},
      accountId: c.req.param("accountId"),
      doNotCache: false
    });
  }
  return c.json(entries);
});

cloudStorageRoutes.get("/fortnite/api/cloudstorage/user/:accountId/:fileName", async (c) => {
  const filePath = join(userDir(c.req.param("accountId")), safeName(c.req.param("fileName")));
  const buf = await readFile(filePath).catch(() => null);
  if (!buf) return c.text("", 200, { "content-type": "application/octet-stream" });
  return new Response(buf, { headers: { "content-type": contentTypeFor(c.req.param("fileName")) } });
});

cloudStorageRoutes.put("/fortnite/api/cloudstorage/user/:accountId/:fileName", async (c) => {
  const fileName = safeName(c.req.param("fileName"));
  // Reject files that would push storage past a sane cap (1 MB per file).
  const raw = await c.req.arrayBuffer();
  if (raw.byteLength > 1_000_000) {
    return c.json({ errorCode: "errors.com.retrov1.cloudstorage.file_too_large" }, 413);
  }
  const dir = userDir(c.req.param("accountId"));
  await mkdir(dir, { recursive: true }).catch(() => {});
  await writeFile(join(dir, fileName), Buffer.from(raw));
  return c.body(null, 204);
});

cloudStorageRoutes.delete("/fortnite/api/cloudstorage/user/:accountId/:fileName", async (c) => {
  const filePath = join(userDir(c.req.param("accountId")), safeName(c.req.param("fileName")));
  try { await (await import("node:fs/promises")).unlink(filePath); } catch {}
  return c.body(null, 204);
});

// Legacy access-token route some builds hit.
cloudStorageRoutes.get("/api/v1/access/fortnite/cloudstorage/Live/user/:accountId/:fileName", async (c) => {
  const filePath = join(userDir(c.req.param("accountId")), safeName(c.req.param("fileName")));
  const buf = await readFile(filePath).catch(() => null);
  if (!buf) {
    // Fall through to hotfixes for system-side files.
    const contents = await readTextAsset(["hotfixes", c.req.param("fileName")], "");
    return c.text(contents, 200, { "content-type": "application/octet-stream" });
  }
  return new Response(buf, { headers: { "content-type": contentTypeFor(c.req.param("fileName")) } });
});
