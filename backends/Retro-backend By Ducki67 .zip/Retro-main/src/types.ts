export type AccountRecord = {
  accountId: string;
  displayName: string;
  createdAt: string;
  lastLoginAt: string;
};

export type PlaylistRecord = {
  mnemonic: string;
  title: string;
  enabled: boolean;
  ranked: boolean;
  maxSquadSize: number;
  tags: string[];
};

export type PlaylistConfig = {
  version: string;
  defaultPlaylist: string | string[];
  playlists: PlaylistRecord[];
};