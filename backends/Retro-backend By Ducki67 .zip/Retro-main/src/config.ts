import { z } from "zod";
import { readFileSync } from "node:fs";
import { join } from "node:path";

function loadDotEnvValues(): Record<string, string> {
  const envPath = join(process.cwd(), ".env");
  let raw = "";

  try {
    raw = readFileSync(envPath, "utf-8");
  } catch {
    return {};
  }

  const values: Record<string, string> = {};
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;

    const separator = trimmed.indexOf("=");
    if (separator <= 0) continue;

    const key = trimmed.slice(0, separator).trim();
    let value = trimmed.slice(separator + 1).trim();
    if (!(value.startsWith('"') || value.startsWith("'"))) {
      value = value.replace(/\s+#.*$/, "").trim();
    }
    const unquoted =
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
        ? value.slice(1, -1)
        : value;

    values[key] = unquoted;
  }

  return values;
}

function envBooleanWithDefault(defaultValue: boolean) {
  return z
    .preprocess(
      (value) => {
        if (typeof value === "boolean") return value;
        if (typeof value !== "string") return undefined;
        const normalized = value.trim().toLowerCase();
        if (["1", "true", "yes", "on"].includes(normalized)) return true;
        if (["0", "false", "no", "off"].includes(normalized)) return false;
        return undefined;
      },
      z.boolean().optional()
    )
    .transform((value) => value ?? defaultValue);
}

function envIntWithDefault(defaultValue: number, min = 0) {
  return z
    .preprocess(
      (value) => {
        if (typeof value === "number" && Number.isFinite(value)) return value;
        if (typeof value !== "string") return undefined;
        const normalized = value.trim();
        if (!normalized) return undefined;
        const parsed = Number.parseInt(normalized, 10);
        return Number.isNaN(parsed) ? undefined : parsed;
      },
      z.number().int().min(min).optional()
    )
    .transform((value) => value ?? defaultValue);
}

function envStringWithDefault(defaultValue: string, minLength = 1) {
  return z
    .preprocess(
      (value) => {
        if (typeof value !== "string") return undefined;
        const trimmed = value.trim();
        return trimmed.length === 0 ? undefined : trimmed;
      },
      z.string().min(minLength).optional()
    )
    .transform((value) => value ?? defaultValue);
}

const envSchema = z.object({
  PORT: z.coerce.number().default(3551),
  HOST: envStringWithDefault("0.0.0.0"),
  BASE_URL: z
    .preprocess(
      (value) => {
        if (typeof value !== "string") return undefined;
        const trimmed = value.trim();
        return trimmed.length === 0 ? undefined : trimmed;
      },
      z.string().url().optional()
    )
    .transform((value) => value ?? "http://127.0.0.1:3551"),
  JWT_SECRET: envStringWithDefault("change-me-retrov1"),

  // Accounts
  GET_EVERY_COSMETIC: envBooleanWithDefault(true),
  STARTER_VBUCKS: envIntWithDefault(676700),
  GOLD_AMOUNT: envIntWithDefault(5001),

  // Timeline — Chapter 2 Remix map stages (32.11 only). CLYDE_WEEK_STAGE drives
  // the base map progression (1=Base, 2=Spaghetti Grotto, 3=Ice Isle/Shark POI,
  // 4=Catty Corner/Juice WRLD POI); JUICE_WRLD_POI_STAGE drives the Juice WRLD
  // POI build-up (1-3). Out-of-range values simply activate no stage.
  CLYDE_WEEK_STAGE: envIntWithDefault(1, 1),
  JUICE_WRLD_POI_STAGE: envIntWithDefault(3, 1),

  // Matchmaking — GAMESERVERS is the Reload-style mapping (comma-separated
  // ip:port:playlist triples). The matchmaker picks the entry matching the
  // requested playlist; falls back to first entry if no match. GAMESERVER_IP
  // is kept as a single-server fallback.
  GAMESERVER_IP: envStringWithDefault("127.0.0.1:7777", 3),
  GAMESERVERS: envStringWithDefault("127.0.0.1:7777:playlist_defaultsolo,127.0.0.1:7777:playlist_defaultduo,127.0.0.1:7777:playlist_trios,127.0.0.1:7777:playlist_defaultsquad,127.0.0.1:7777:playlist_quail", 1),
  MATCHMAKER_IP: envStringWithDefault("ws://127.0.0.1:5595/matchmaker", 6)
});

const dotEnvValues = loadDotEnvValues();
const envInput: Record<string, unknown> = {
  ...process.env,
  ...dotEnvValues
};

export const config = envSchema.parse(envInput);