# Retro - Backend (V1)

A Fortnite **32.11** backend (Season 32 / Chapter 2 Remix). Made it in a 7 day speedrun written in TypeScript.


Project Built with:

TypeScript + Bun + Hono. No database, no docker, just run it.

> **Note:** for matchmaking to actually work you'll need a compiled Console/Client build of the [Remix GS](https://github.com/plooshi/Remix). there's probably another way to do it but that's how i got it working, so don't be surprised if you don't inject the Client/Console and MM doesn't work.

## Run

Need Bun: https://bun.sh

```bash
bun install
bun run src/index.ts
```

Or run `start.bat` on windows. Defaults to `http://127.0.0.1:5595`.

## Config

Settings are in `.env` (copy from `.env.example`). Stuff like starting V-Bucks, gold, the full locker toggle, and the Remix map stage.

---

Private / educational use. Not affiliated with Epic Games.

Credits: 
- Ducki67 (@ducki67 on discord)
- [NeoniteV2](https://github.com/HybridFNBR/Neonite/tree/main) - for Discovery, Most of the Locker MCP stuff.
- [Plooshi/Sarah](https://github.com/plooshi) for the Remix game server to test the backend with.