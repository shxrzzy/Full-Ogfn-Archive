@echo off
title Starting RetroV1 backend...
REM Start the RetroV1 backend
cd /d "%~dp0"
bun install
bun run check
bun run src/index.ts
title RetroV1 Running!!

if errorlevel 1 (
    echo Failed to start/exited the RetroV1 backend.
    title Failed to Start!!
    pause
) else (
    title RetroV1 Running!!
)
