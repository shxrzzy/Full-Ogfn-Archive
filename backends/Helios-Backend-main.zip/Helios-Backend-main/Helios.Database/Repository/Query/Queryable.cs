﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Repository.Query
{
    internal class Queryable<TEntity> : IQueryable<TEntity>
    {
        private readonly EntityMetadata _metadata;
        private readonly string _connectionString;
        private QuerySpec _querySpec;

        public Queryable(EntityMetadata metadata, string connectionString)
        {
            _metadata = metadata;
            _connectionString = connectionString;
            _querySpec = new QuerySpec(typeof(TEntity));
            Provider = new QueryProvider(metadata, connectionString);
            Expression = Expression.Constant(this);
        }

        public Queryable(QuerySpec querySpec, EntityMetadata metadata, string connectionString)
        {
            _querySpec = querySpec;
            _metadata = metadata;
            _connectionString = connectionString;
            Provider = new QueryProvider(metadata, connectionString);
            Expression = Expression.Constant(this);
        }

        public Type ElementType => typeof(TEntity);
        public Expression Expression { get; }
        public IQueryProvider Provider { get; }

        public IEnumerator<TEntity> GetEnumerator()
        {
            return Provider.Execute<IEnumerable<TEntity>>(Expression).GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        public QuerySpec GetQuerySpec() => _querySpec;
    }
}
