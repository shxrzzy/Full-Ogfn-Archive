﻿using Dapper;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Repository.TypeHandlers
{
    public class StringDictionaryTypeHandler : SqlMapper.TypeHandler<Dictionary<string, string>>
    {
        public override void SetValue(IDbDataParameter parameter, Dictionary<string, string> value)
        {
            parameter.Value = value == null ? "{}" : JsonConvert.SerializeObject(value);
        }

        public override Dictionary<string, string> Parse(object value)
        {
            if (value == null || value == DBNull.Value)
                return new Dictionary<string, string>();

            var json = value.ToString();
            if (string.IsNullOrEmpty(json) || json == "{}")
                return new Dictionary<string, string>();

            try
            {
                return JsonConvert.DeserializeObject<Dictionary<string, string>>(json)
                       ?? new Dictionary<string, string>();
            }
            catch (JsonException)
            {
                return new Dictionary<string, string>();
            }
        }
    }
}
