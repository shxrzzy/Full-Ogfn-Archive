﻿using Dapper;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Repository.TypeHandlers
{
    public class DictionaryTypeHandler : SqlMapper.TypeHandler<Dictionary<string, object>>
    {
        public override void SetValue(IDbDataParameter parameter, Dictionary<string, object> value)
        {
            parameter.Value = value == null ? "{}" : JsonConvert.SerializeObject(value);
        }

        public override Dictionary<string, object> Parse(object value)
        {
            if (value == null || value == DBNull.Value)
                return new Dictionary<string, object>();

            var json = value.ToString();
            if (string.IsNullOrEmpty(json) || json == "{}")
                return new Dictionary<string, object>();

            try
            {
                return JsonConvert.DeserializeObject<Dictionary<string, object>>(json)
                       ?? new Dictionary<string, object>();
            }
            catch (JsonException)
            {
                return new Dictionary<string, object>();
            }
        }
    }
}
