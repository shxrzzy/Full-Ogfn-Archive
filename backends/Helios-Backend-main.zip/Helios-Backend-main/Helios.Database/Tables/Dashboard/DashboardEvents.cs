﻿using Helios.Database.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Tables.Dashboard
{
    [Entity("dashboard_events")]
    public class DashboardEvents : BaseTable
    {
        [Column("event_id")]
        public string EventID { get; set; }
        [Column("name")]
        public string Name { get; set; }

        [Column("description")]
        public string Description { get; set; }
        [Column("image")]
        public string? Image { get; set; }
        [Column("startDate")]
        public string startDate { get; set; }
        [Column("endDate")]
        public string endDate { get; set; }
        [Column("status")]
        public string status { get; set; }
        [Column("format")]
        public string format { get; set; }
        [Column("regions")]
        public string[] regions { get; set; }
        [Column("prizes")]
        public string[] prizes { get; set; }
        [Column("rules")]
        public string[] rules { get; set; }
        [Column("scoring")]
        public string scoring { get; set; }

        [Column("sessions")]
        public string sessions { get; set; }
    }
}
