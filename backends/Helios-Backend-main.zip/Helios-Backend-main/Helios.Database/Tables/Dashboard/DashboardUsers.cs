﻿

using Helios.Database.Attributes;
using System.ComponentModel.DataAnnotations;

namespace Helios.Database.Tables.Dashboard
{
    [Entity("dashboard_users")]
    public class DashboardUsers : BaseTable
    {
        [Column("username")]
        [Required]
        public string Username { get; set; }
        [Column("password")]
        [Required]
        public string Password { get; set; }
        [Column("hwid")]
        public string? Hwid { get; set; } = null;
    }
}
