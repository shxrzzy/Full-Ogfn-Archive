﻿using Helios.Database.Attributes;

namespace Helios.Database.Tables.Solstice;

[Entity("solstice_servers")]
public class SolsticeServers : BaseTable
{
    [Column("sessionId")]
    public string SessionId { get; set; }
    [Column("status")]
    public string Status { get; set; }
    [Column("version")]
    public int Version { get; set; }
    [Column("socketId")]
    public string SocketId { get; set; }
    [Column("identifier")]
    public string Identifier  { get; set; }
    [Column("address")]
    public string Address { get; set; }
    [Column("port")]
    public int Port { get; set; }
    [Column("queue")]
    public string[] Queue { get; set; }
    [Column("matchStarted")]
    public bool MatchStarted { get; set; }
    [Column("region")]
    public string Region { get; set; }
    [Column("userAgent")]
    public string UserAgent { get; set; }
    [Column("matchId")]
    public string MatchId { get; set; }
    [Column("playlist")]
    public string Playlist { get; set; }
    [Column("teamAssignments")]
    public string[] TeamAssignments { get; set; }
    [Column("updatedAt")]
    public DateTime UpdatedAt { get; set; } 
}