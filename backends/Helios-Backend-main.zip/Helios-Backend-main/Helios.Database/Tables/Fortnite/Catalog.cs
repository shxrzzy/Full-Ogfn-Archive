﻿using Helios.Database.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Tables.Fortnite
{
    [Entity("catalog")]
    public class Catalog : BaseTable
    {
        [Column("createdAt")]
        public string CreatedAt { get; set; }
        [Column("storefront")]
        public string Storefront { get; set; }
        [Column("offerId")]
        public string OfferId { get; set; }
        [Column("templateId")]
        public string TemplateId { get; set; }
        [Column("name")]
        public string Name { get; set; }
        [Column("value")]
        public string Value { get; set; }
        [Column("category")]
        public dynamic Category { get; set; }
    }
}
