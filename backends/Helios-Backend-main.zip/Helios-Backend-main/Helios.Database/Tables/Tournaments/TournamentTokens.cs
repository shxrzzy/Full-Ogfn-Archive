﻿using Helios.Database.Attributes;

namespace Helios.Database.Tables.Tournaments;

[Entity("tournament_tokens")]
public class TournamentTokens : BaseTable
{
    [Column("accountId")]
    public string AccountId { get; set; }
    [Column("token")]
    public string Token { get; set; }
    [Column("season")]
    public int Season { get; set; }
}