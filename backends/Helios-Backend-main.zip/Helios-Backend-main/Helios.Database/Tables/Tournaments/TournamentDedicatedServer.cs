﻿using Helios.Database.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Tables.Tournaments
{
    [Entity("tournament_dedicated_server")]
    public class TournamentDedicatedServer : BaseTable
    {
        [Column("accountId")]
        public string AccountId { get; set; }
        [Column("eventId")]
        public string EventId { get; set; }
        [Column("matchIds")]
        public List<string> Matches { get; set; }
        [Column("teamId")]
        public string TeamId { get; set; }
        [Column("teammateIds")]
        public List<string> Teammates { get; set; }
        [Column("pointsEarned")]
        public int PointsEarned { get; set; }
        [Column("season")]
        public int Season { get; set; }
    }
}
