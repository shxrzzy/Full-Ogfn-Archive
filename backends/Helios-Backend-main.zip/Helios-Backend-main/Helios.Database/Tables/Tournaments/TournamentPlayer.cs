﻿using Helios.Database.Attributes;

namespace Helios.Database.Tables.Tournaments;

[Entity("tournament_players")]
public class TournamentPlayer : BaseTable
{
    [Column("accountId")]
    public string AccountId { get; set; }
    
    [Column("pending_payouts")]
    public List<object> PendingPayouts { get; set; }
    
    [Column("pending_penalties")]
    public List<object> PendingPenalties { get; set; }
    
    [Column("persistent_scores")]
    public List<object> PersistentScores { get; set; }
    
    [Column("season")]
    public int Season { get; set; }
}