﻿using Helios.Database.Attributes;

namespace Helios.Database.Tables.Tournaments;

[Entity("tournament_hype_tokens")]
public class TournamentHypeTokens : BaseTable
{
    [Column("accountId")]
    public string AccountId { get; set; }
    [Column("token")]
    public string Token { get; set; }
    [Column("minimum_required_hype")]
    public int MinimumRequiredHype { get; set; }
    [Column("division")]
    public int Division { get; set; }
    [Column("maximum_required_hype")]
    public long MaximumRequiredHype { get; set; }
    [Column("season")]
    public int Season { get; set; }
}