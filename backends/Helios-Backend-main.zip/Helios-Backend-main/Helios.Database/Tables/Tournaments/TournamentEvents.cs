﻿using Helios.Database.Attributes;

namespace Helios.Database.Tables.Tournaments;

[Entity("tournament_events")]
public class TournamentEvents : BaseTable
{
    [Column("announcementTime")]
    public string AnnouncementTime { get; set; }
    [Column("beginTime")]
    public string BeginTime { get; set; }
    [Column("displayDataId")]
    public string DisplayDataId { get; set; }
    [Column("endTime")]
    public string EndTime { get; set; }
    [Column("environment")]
    public string Environment { get; set; }
    [Column("eventGroup")]
    public string EventGroup { get; set; }
    [Column("eventId")]
    public string EventId { get; set; }
    [Column("link")]
    public string Link { get; set; }
    [Column("eventWindows")]
    public List<object> EventWindows { get; set; }
    [Column("platformMappings")]
    public Dictionary<string, object> PlatformMappings { get; set; }
    [Column("platforms")]
    public string[] Platforms { get; set; }
    [Column("regionMappings")]
    public Dictionary<string, string> RegionMappings { get; set; }
    [Column("regions")]
    public string[] Regions { get; set; } 
    [Column("eventMetadata")]
    public Dictionary<string, object> EventMetadata { get; set; }
    [Column("season")]
    public int Season { get; set; }
}