﻿using Helios.Database.Attributes;

namespace Helios.Database.Tables.Tournaments;

[Entity("tournament_scores")]
public class TournamentScores : BaseTable
{
    [Column("accountId")]
    public string AccountId { get; set; }
    [Column("scoringType")]
    public string ScoringType { get; set; }
    [Column("score")]
    public int Score { get; set; }
    [Column("season")]
    public int Season { get; set; }
}