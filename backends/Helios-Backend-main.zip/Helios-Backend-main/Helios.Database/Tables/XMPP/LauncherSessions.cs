﻿using Helios.Database.Attributes;

namespace Helios.Database.Tables.XMPP;

[Entity("launcher_sessions")]
public class LauncherSessions : BaseTable
{
    [Column("socketId")]
    public Guid SocketId { get; set; }

    [Column("subscribedToServers")]
    public bool SubscribedToServers { get; set; }

    [Column("secret")]
    public string Secret { get; set; }
    
    [Column("protocol")]
    public string Protocol  { get; set; }
    
    [Column("accountId")]
    public string AccountId { get; set; }
    
    [Column("displayName")]
    public string DisplayName { get; set; }
    
    [Column("token")]
    public string Token { get; set; }
    [Column("isAuthenticated")]
    public bool IsAuthenticated { get; set; }
    [Column("connectedAt")]
    public DateTime ConnectedAt { get; set; }
}