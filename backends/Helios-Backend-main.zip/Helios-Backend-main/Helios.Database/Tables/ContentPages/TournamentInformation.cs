﻿using Helios.Database.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helios.Database.Tables.ContentPages
{
    [Entity("tournament_information")]
    public class TournamentInformation : BaseTable
    {
        [Column("title_color")]
        public string TitleColor { get; set; }
        [Column("loading_screen_image")]
        public string LoadingScreenImage { get; set; }
        [Column("background_text_color")]
        public string BackgroundTextColor { get; set; }
        [Column("background_right_color")]
        public string BackgroundRightColor { get; set; }
        [Column("poster_back_image")]
        public string PosterBackImage { get; set; }
        [Column("_type")]
        public string Type { get; set; }
        [Column("pin_score_requirement")]
        public int PinScoreRequirement { get; set; }
        [Column("pin_earned_text")]
        public string PinEarnedText { get; set; }
        [Column("tournament_display_id")]
        public string TournamentDisplayId { get; set; }
        [Column("highlight_color")]
        public string HighlightColor { get; set; }
        [Column("schedule_info")]
        public string ScheduleInfo { get; set; }
        [Column("primary_color")]
        public string PrimaryColor { get; set; }
        [Column("flavor_description")]
        public string FlavorDescription { get; set; }
        [Column("poster_front_image")]
        public string PosterFrontImage { get; set; }
        [Column("short_format_title")]
        public string ShortFormatTitle { get; set; }
        [Column("title_line_2")]
        public string TitleLine2 { get; set; }
        [Column("title_line_1")]
        public string TitleLine1 { get; set; }
        [Column("shadow_color")]
        public string ShadowColor { get; set; }
        [Column("details_description")]
        public string DetailsDescription { get; set; }
        [Column("background_left_color")]
        public string BackgroundLeftColor { get; set; }
        [Column("long_format_title")]
        public string LongFormatTitle { get; set; }
        [Column("poster_fade_color")]
        public string PosterFadeColor { get; set; }
        [Column("secondary_color")]
        public string SecondaryColor { get; set; }
        [Column("playlist_tile_image")]
        public string PlaylistTileImage { get; set; }
        [Column("base_color")]
        public string BaseColor { get; set; }
    }
}
