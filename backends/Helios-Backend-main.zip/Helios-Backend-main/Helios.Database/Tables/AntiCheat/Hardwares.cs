﻿using System.ComponentModel.DataAnnotations;
using Helios.Database.Attributes;

namespace Helios.Database.Tables.AntiCheat;

[Entity("hardwares")]
public class Hardwares : BaseTable
{
    [Column("accountId")]
    [Required]
    public string AccountId { get; set; }
    [Column("banned")]
    [Required]
    public bool Banned { get; set; }
    [Column("hwid")]
    [Required]
    public string Hwid { get; set; }
}