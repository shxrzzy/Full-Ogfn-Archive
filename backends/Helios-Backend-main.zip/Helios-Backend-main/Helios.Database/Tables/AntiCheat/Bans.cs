﻿using System;
using System.ComponentModel.DataAnnotations;
using Helios.Database.Attributes;

namespace Helios.Database.Tables.AntiCheat;

[Entity("bans")]
public class Ban : BaseTable
{
    [Column("accountId")]
    [Required]
    [MaxLength(64)]
    public string AccountId { get; set; }

    [Column("reason")]
    [MaxLength(255)]
    public string? Reason { get; set; }

    [Column("isShadowBanned")]
    [Required]
    public bool IsShadowBanned { get; set; }

    [Column("shadowBanReason")]
    [MaxLength(255)]
    public string? ShadowBanReason { get; set; }

    [Column("shadowBanStart")]
    public DateTime? ShadowBanStart { get; set; }

    [Column("shadowBanEnd")]
    public DateTime? ShadowBanEnd { get; set; }

    [Column("isRecentlyUnbanned")]
    [Required]
    public bool IsRecentlyUnbanned { get; set; }

    [Column("unbannedAt")]
    public DateTime? UnbannedAt { get; set; }
}