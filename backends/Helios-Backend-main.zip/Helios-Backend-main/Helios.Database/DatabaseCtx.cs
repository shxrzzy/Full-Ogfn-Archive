﻿using System.Collections.Concurrent;
using System.Reflection;
using Helios.Database.Attributes;
using Npgsql;

namespace Helios.Database;

public class DatabaseCtx : IDisposable
{
    private readonly string _connectionString;
    private readonly ConcurrentDictionary<Type, object> _repositories = new();
    private NpgsqlConnection _connection;
    private readonly SemaphoreSlim _migrationSemaphore = new(1, 1);
    private static readonly object _globalMigrationLock = new();

    /// <summary>
    /// Initializes a new instance of the <see cref="DatabaseCtx"/> class.
    /// </summary>
    /// <param name="connectionString">The connection string to the database.</param>
    public DatabaseCtx(string connectionString)
    {
        _connectionString = connectionString;
    }

    public async Task InitializeAsync()
    {
        try
        {
            _connection = new NpgsqlConnection(_connectionString);
            await _connection.OpenAsync();
            Logger.Info("Database connection established");
            await MigrateTablesAsync();
        }
        catch (Exception ex)
        {
            Logger.Error($"Database initialization failed: {ex.Message}");
            throw;
        }
    }

    public void Initialize()
    {
        InitializeAsync().GetAwaiter().GetResult();
    }

    /// <summary>
    /// Migrates tables based on the registered entities with deadlock prevention.
    /// </summary>
    private async Task MigrateTablesAsync()
    {
        lock (_globalMigrationLock)
        {
            if (_migrationSemaphore.Wait(TimeSpan.FromMinutes(5)))
            {
                try
                {
                    var entityTypes = GetEntityTypes();

                    if (!entityTypes.Any())
                    {
                        Logger.Warn("No entities found for migration");
                        return;
                    }

                    entityTypes = entityTypes.OrderBy(t => t.FullName).ToList();

                    Logger.Info($"Migrating {entityTypes.Count} entities");

                    var results = ProcessEntitiesSequentially(entityTypes);

                    if (results.failures > 0)
                    {
                        Logger.Error($"Migration completed with {results.failures} failures out of {entityTypes.Count} entities");
                    }
                    else
                    {
                        Logger.Info($"All {results.successes} entities migrated successfully");
                    }
                }
                finally
                {
                    _migrationSemaphore.Release();
                }
            }
            else
            {
                throw new TimeoutException("Migration timeout - another process may be running migrations");
            }
        }
    }

    private List<Type> GetEntityTypes()
    {
        var entityTypes = new List<Type>();
        var assemblies = AppDomain.CurrentDomain.GetAssemblies()
            .Where(a => !a.IsDynamic && !string.IsNullOrEmpty(a.Location))
            .Concat(new[] { Assembly.GetExecutingAssembly() })
            .Distinct()
            .ToList();

        foreach (var assembly in assemblies)
        {
            try
            {
                var types = assembly.GetTypes()
                    .Where(t => t.IsClass && !t.IsAbstract &&
                           t.GetCustomAttributes(typeof(EntityAttribute), true).Any())
                    .ToList();

                entityTypes.AddRange(types);
            }
            catch (ReflectionTypeLoadException ex)
            {
                if (ex.Types?.Any(t => t != null) == true)
                {
                    var loadedTypes = ex.Types
                        .Where(t => t != null && t.IsClass && !t.IsAbstract &&
                               t.GetCustomAttributes(typeof(EntityAttribute), true).Any())
                        .ToList();
                    entityTypes.AddRange(loadedTypes);
                }
            }
            catch
            {
            }
        }

        return entityTypes;
    }

    private (int successes, int failures) ProcessEntitiesSequentially(List<Type> entityTypes)
    {
        int successCount = 0;
        int failureCount = 0;

        foreach (var entityType in entityTypes)
        {
            try
            {
                MigrateTableWithRetry(entityType);
                successCount++;
            }
            catch (Exception ex)
            {
                failureCount++;
                Logger.Error($"Failed to migrate {entityType.Name}: {ex.Message}");
            }
        }

        return (successCount, failureCount);
    }

    /// <summary>
    /// Migrates a table with retry logic for deadlock prevention.
    /// </summary>
    private void MigrateTableWithRetry(Type entityType, int maxRetries = 3)
    {
        var entityAttribute = entityType.GetCustomAttribute<EntityAttribute>();
        var tableName = entityAttribute?.TableName;

        if (string.IsNullOrEmpty(tableName))
        {
            throw new InvalidOperationException($"Entity '{entityType.Name}' missing TableName");
        }

        for (int attempt = 1; attempt <= maxRetries; attempt++)
        {
            try
            {
                MigrateTable(entityType);
                return; 
            }
            catch (NpgsqlException ex) when (ex.SqlState == "40P01" && attempt < maxRetries) // Deadlock
            {
                var delay = TimeSpan.FromMilliseconds(100 * attempt * attempt); // Exponential backoff
                Thread.Sleep(delay);
                Logger.Warn($"Deadlock on {tableName}, retry {attempt}/{maxRetries}");
            }
        }
    }

    /// <summary>
    /// Migrates a table based on the specified entity type.
    /// </summary>
    private void MigrateTable(Type entityType)
    {
        var entityAttribute = entityType.GetCustomAttribute<EntityAttribute>();
        var tableName = entityAttribute?.TableName;

        if (!TableExists(tableName))
        {
            CreateTable(entityType);
        }
        else
        {
            UpdateTableIfChanged(entityType);
        }
    }

    /// <summary>
    /// Updates an existing table only if there are changes in the entity definition.
    /// </summary>
    private void UpdateTableIfChanged(Type entityType)
    {
        var tableName = entityType.GetCustomAttribute<EntityAttribute>()?.TableName;

        if (string.IsNullOrEmpty(tableName))
        {
            return;
        }

        try
        {
            var existingColumns = GetExistingColumnsWithTypes(tableName);
            var entityColumns = GetEntityColumnsWithTypes(entityType);

            if (!AreSchemasEqual(existingColumns, entityColumns))
            {
                UpdateTable(entityType, existingColumns, entityColumns);
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Schema update failed for {tableName}: {ex.Message}");
            throw;
        }
    }

    /// <summary>
    /// Updates the table schema to match the entity definition with improved transaction handling.
    /// </summary>
    private void UpdateTable(Type entityType, Dictionary<string, string> existingColumns, Dictionary<string, string> entityColumns)
    {
        var tableName = entityType.GetCustomAttribute<EntityAttribute>()?.TableName;

        if (string.IsNullOrEmpty(tableName))
        {
            return;
        }

        bool needsTableRebuild = entityColumns.Any(column =>
            existingColumns.ContainsKey(column.Key) &&
            existingColumns[column.Key] != column.Value &&
            !CanAlterColumnTypeInPlace(existingColumns[column.Key], column.Value));

        if (needsTableRebuild)
        {
            RebuildTableWithData(entityType, tableName, existingColumns, entityColumns);
        }
        else
        {
            PerformIncrementalUpdates(tableName, existingColumns, entityColumns);
        }
    }

    private void PerformIncrementalUpdates(string tableName, Dictionary<string, string> existingColumns, Dictionary<string, string> entityColumns)
    {
        using var transaction = _connection.BeginTransaction();
        try
        {
            foreach (var column in entityColumns.Where(c => !existingColumns.ContainsKey(c.Key)))
            {
                AddColumnInTransaction(tableName, column.Key, column.Value, transaction);
            }

            foreach (var column in entityColumns.Where(c =>
                existingColumns.ContainsKey(c.Key) &&
                existingColumns[c.Key] != c.Value &&
                CanAlterColumnTypeInPlace(existingColumns[c.Key], c.Value)))
            {
                AlterColumnTypeInTransaction(tableName, column.Key, column.Value, transaction);
            }

            foreach (var column in existingColumns.Where(c =>
                !entityColumns.ContainsKey(c.Key) &&
                c.Key.ToLower() != "id"))
            {
                DropColumnInTransaction(tableName, column.Key, transaction);
            }

            transaction.Commit();
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    /// <summary>
    /// Determines if a column type can be altered in place without data loss.
    /// </summary>
    private bool CanAlterColumnTypeInPlace(string existingType, string newType)
    {
        var safeConversions = new Dictionary<string, List<string>>
        {
            { "smallint", new List<string> { "integer", "bigint", "decimal", "numeric" } },
            { "integer", new List<string> { "bigint", "decimal", "numeric" } },
            { "character varying", new List<string> { "text" } },
            { "varchar", new List<string> { "text" } },
            { "real", new List<string> { "double precision" } },
        };

        existingType = existingType.ToLower();
        newType = newType.ToLower();

        return existingType == newType ||
               (safeConversions.ContainsKey(existingType) &&
                safeConversions[existingType].Contains(newType));
    }

    /// <summary>
    /// Rebuilds a table with its data using optimized approach for deadlock prevention.
    /// </summary>
    private void RebuildTableWithData(Type entityType, string tableName, Dictionary<string, string> existingColumns, Dictionary<string, string> entityColumns)
    {
        string tempTableName = $"{tableName}_temp_{Environment.TickCount}";

        var columns = entityType.GetProperties()
            .Where(p => p.Name != "Id")
            .Select(p => $"{p.GetCustomAttribute<ColumnAttribute>()?.ColumnName ?? p.Name} {GetPostgresType(p.PropertyType)}");

        var primaryKey = "Id SERIAL PRIMARY KEY";
        var createSql = $"CREATE TABLE {tempTableName} ({primaryKey}, {string.Join(", ", columns)});";

        using var transaction = _connection.BeginTransaction();
        try
        {
            ExecuteInTransaction(createSql, transaction);

            var commonColumns = existingColumns.Keys
                .Where(c => entityColumns.ContainsKey(c))
                .ToList();

            if (commonColumns.Any())
            {
                var copyColumns = string.Join(", ", commonColumns);
                var copySql = $"INSERT INTO {tempTableName} (id, {copyColumns}) SELECT id, {copyColumns} FROM {tableName};";
                ExecuteInTransaction(copySql, transaction);
            }

            ExecuteInTransaction($"DROP TABLE {tableName};", transaction);
            ExecuteInTransaction($"ALTER TABLE {tempTableName} RENAME TO {tableName};", transaction);

            var sequenceSql = $"SELECT setval(pg_get_serial_sequence('{tableName}', 'id'), COALESCE((SELECT MAX(id) FROM {tableName}), 1));";
            ExecuteInTransaction(sequenceSql, transaction);

            transaction.Commit();
        }
        catch
        {
            transaction.Rollback();
            try { ExecuteNonQuery($"DROP TABLE IF EXISTS {tempTableName};"); } catch { }
            throw;
        }
    }

    private void ExecuteInTransaction(string sql, NpgsqlTransaction transaction)
    {
        using var command = new NpgsqlCommand(sql, _connection, transaction);
        command.CommandTimeout = 30;
        command.ExecuteNonQuery();
    }

    /// <summary>
    /// Gets the existing columns and their types for a specified table.
    /// </summary>
    private Dictionary<string, string> GetExistingColumnsWithTypes(string tableName)
    {
        var columns = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var sql = "SELECT column_name, data_type FROM information_schema.columns WHERE table_name = @tableName;";

        using var command = new NpgsqlCommand(sql, _connection);
        command.Parameters.AddWithValue("@tableName", tableName);
        using var reader = command.ExecuteReader();

        while (reader.Read())
        {
            columns.Add(reader.GetString(0), reader.GetString(1));
        }

        return columns;
    }

    /// <summary>
    /// Gets the columns and their types for a specified entity.
    /// </summary>
    private Dictionary<string, string> GetEntityColumnsWithTypes(Type entityType)
    {
        var columns = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        foreach (var prop in entityType.GetProperties().Where(p => p.Name.ToLower() != "id"))
        {
            var columnName = prop.GetCustomAttribute<ColumnAttribute>()?.ColumnName ?? prop.Name;
            var postgresType = GetPostgresType(prop.PropertyType);
            columns[columnName] = postgresType;
        }

        return columns;
    }

    /// <summary>
    /// Compares schemas for equality.
    /// </summary>
    private bool AreSchemasEqual(Dictionary<string, string> existingColumns, Dictionary<string, string> entityColumns)
    {
        foreach (var col in entityColumns)
        {
            if (!existingColumns.ContainsKey(col.Key) ||
                !existingColumns[col.Key].Equals(col.Value, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }
        }

        foreach (var col in existingColumns)
        {
            if (col.Key.ToLower() != "id" && !entityColumns.ContainsKey(col.Key))
            {
                return false;
            }
        }

        return true;
    }

    private void AddColumnInTransaction(string tableName, string columnName, string columnType, NpgsqlTransaction transaction)
    {
        if (!ColumnExists(tableName, columnName))
        {
            var sql = $"ALTER TABLE {tableName} ADD COLUMN {columnName} {columnType};";
            ExecuteInTransaction(sql, transaction);
        }
    }

    private void AlterColumnTypeInTransaction(string tableName, string columnName, string newType, NpgsqlTransaction transaction)
    {
        var sql = $"ALTER TABLE {tableName} ALTER COLUMN {columnName} TYPE {newType} USING {columnName}::{newType};";
        ExecuteInTransaction(sql, transaction);
    }

    private void DropColumnInTransaction(string tableName, string columnName, NpgsqlTransaction transaction)
    {
        var sql = $"ALTER TABLE {tableName} DROP COLUMN {columnName};";
        ExecuteInTransaction(sql, transaction);
    }

    /// <summary>
    /// Checks if a column exists in a table.
    /// </summary>
    private bool ColumnExists(string tableName, string columnName)
    {
        var sql = "SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = @tableName AND LOWER(column_name) = LOWER(@columnName));";
        using var command = new NpgsqlCommand(sql, _connection);
        command.Parameters.AddWithValue("@tableName", tableName);
        command.Parameters.AddWithValue("@columnName", columnName);
        return (bool)command.ExecuteScalar();
    }

    /// <summary>
    /// Executes a non-query SQL command.
    /// </summary>
    private void ExecuteNonQuery(string sql)
    {
        using var command = new NpgsqlCommand(sql, _connection);
        command.CommandTimeout = 30;
        command.ExecuteNonQuery();
    }

    /// <summary>
    /// Creates a table for the specified entity type.
    /// </summary>
    private void CreateTable(Type entityType)
    {
        var tableName = entityType.GetCustomAttribute<EntityAttribute>()?.TableName;

        if (string.IsNullOrEmpty(tableName) || TableExists(tableName))
        {
            return;
        }

        var properties = entityType.GetProperties().Where(p => p.Name != "Id").ToList();
        var columns = properties.Select(p =>
        {
            var columnName = p.GetCustomAttribute<ColumnAttribute>()?.ColumnName ?? p.Name;
            var postgresType = GetPostgresType(p.PropertyType);
            return $"{columnName} {postgresType}";
        });

        var primaryKey = "Id SERIAL PRIMARY KEY";
        var columnList = columns.Any() ? $", {string.Join(", ", columns)}" : "";
        var sql = $"CREATE TABLE {tableName} ({primaryKey}{columnList});";

        ExecuteNonQuery(sql);
    }

    /// <summary>
    /// Checks if a table exists in the database.
    /// </summary>
    private bool TableExists(string tableName)
    {
        var sql = "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = @tableName);";
        using var command = new NpgsqlCommand(sql, _connection);
        command.Parameters.AddWithValue("@tableName", tableName);
        return (bool)command.ExecuteScalar();
    }

    /// <summary>
    /// Maps C# types to PostgreSQL types.
    /// </summary>
    private string GetPostgresType(Type type)
    {
        if (type == typeof(System.Dynamic.ExpandoObject) || type == typeof(object))
        {
            return "TEXT";
        }

        if (type.IsArray)
        {
            var elementType = type.GetElementType();
            var postgresType = GetPostgresType(elementType);
            return $"{postgresType}[]";
        }

        var underlyingType = Nullable.GetUnderlyingType(type) ?? type;
        return underlyingType switch
        {
            Type t when t == typeof(string) => "TEXT",
            Type t when t == typeof(int) => "INTEGER",
            Type t when t == typeof(long) => "BIGINT",
            Type t when t == typeof(double) => "DOUBLE PRECISION",
            Type t when t == typeof(float) => "REAL",
            Type t when t == typeof(bool) => "BOOLEAN",
            Type t when t == typeof(DateTime) => "TIMESTAMP",
            Type t when t == typeof(decimal) => "DECIMAL",
            Type t when t == typeof(short) => "SMALLINT",
            Type t when t == typeof(byte) => "BYTEA",
            Type t when t == typeof(char) => "CHAR",
            Type t when t == typeof(Guid) => "UUID",
            Type t when t == typeof(object) => "JSONB",
            _ => "TEXT"
        };
    }

    /// <summary>
    /// Disposes the database connection and cleans up resources.
    /// </summary>
    public void Dispose()
    {
        _migrationSemaphore?.Dispose();
        if (_connection?.State == System.Data.ConnectionState.Open)
        {
            _connection.Close();
            _connection.Dispose();
        }
    }
}