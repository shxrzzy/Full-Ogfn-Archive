﻿using Helios.Database.Tables.XMPP;

namespace Helios.Socket.Events;

public class LauncherConnectedEventArgs : EventArgs
{
    public LauncherSessions Client { get; set; }
}