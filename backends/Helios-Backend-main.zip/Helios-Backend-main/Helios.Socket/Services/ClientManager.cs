﻿using System.Text.Json;
using Fleck;
using Helios.Database.Repository;
using Helios.Database.Tables.XMPP;
using Helios.Socket.Interfaces;
using Microsoft.Extensions.Logging;

namespace Helios.Socket.Services;

public class ClientManager : IClientManager
{
    #region XMPP Client Methods

    public async Task AddClient(ClientSessions client, IWebSocketConnection socket)
    {
        if (socket == null)
            throw new ArgumentNullException(nameof(socket));

        var clientsRepo = WebSocketConfiguration.repositoryPool.For<ClientSessions>();

        var existingClient = await clientsRepo.FindByColumnAsync("accountid", client.AccountId);
        if (existingClient != null)
        {
            Globals._socketConnections.Remove(existingClient.SocketId);
            await clientsRepo.DeleteByColumnAsync("socketid", existingClient.SocketId);
        }

        await clientsRepo.SaveAsync(client).ConfigureAwait(false);
        Globals._socketConnections[client.SocketId] = socket;
    }

    public async Task RemoveClient(string accountId, string protocol)
    {
        if (protocol == "xmpp")
        {
            var clientsRepo = WebSocketConfiguration.repositoryPool.For<ClientSessions>();
            var client = await clientsRepo.FindByColumnAsync("accountid", accountId);
            if (client == null)
            {
                Logger.Error("XMPP Client is null");
                return;
            }

            Globals._socketConnections.Remove(client.SocketId);
            bool deleted = await clientsRepo.DeleteByColumnAsync("accountid", client.AccountId);
            if (!deleted)
            {
                Logger.Warn($"Failed to delete XMPP client with AccountId {client.AccountId}");
            }
            else
            {
                Logger.Info($"Successfully deleted XMPP client with AccountId {client.AccountId}");
            }
        }
        else
        {
            var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();
            var client = await launcherRepo.FindByColumnAsync("accountid", accountId);
            if (client == null)
            {
                Logger.Error("Launcher session is null");
                return;
            }

            Globals._socketConnections.Remove(client.SocketId);
            bool deleted = await launcherRepo.DeleteByColumnAsync("accountid", client.AccountId);
            if (!deleted)
            {
                Logger.Warn($"Failed to delete launcher session with AccountId {client.AccountId}");
            }
            else
            {
                Logger.Info($"Successfully deleted launcher session with AccountId {client.AccountId}");
            }
        }
    }

    public async Task RemoveClient(IWebSocketConnection connection, string protocol)
    {
        if (protocol == "xmpp")
        {
            var clientsRepo = WebSocketConfiguration.repositoryPool.For<ClientSessions>();
            await clientsRepo.DeleteAsync(new ClientSessions { SocketId = connection.ConnectionInfo.Id })
                .ConfigureAwait(false);
            Globals._socketConnections.Remove(connection.ConnectionInfo.Id);
        }
        else
        {
            var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();
            await launcherRepo.DeleteAsync(new LauncherSessions { SocketId = connection.ConnectionInfo.Id })
                .ConfigureAwait(false);
            Globals._socketConnections.Remove(connection.ConnectionInfo.Id);
        }
    }

    public async Task RemoveClient(Guid socketId)
    {
        Globals._socketConnections.Remove(socketId);

        var clientsRepo = WebSocketConfiguration.repositoryPool.For<ClientSessions>();
        bool deletedFromXmpp = await clientsRepo.DeleteByColumnAsync("socketid", socketId);
        if (deletedFromXmpp)
        {
            Logger.Info($"Successfully deleted XMPP client with SocketId {socketId}");
            return;
        }

        var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();
        bool deletedFromLauncher = await launcherRepo.DeleteByColumnAsync("socketid", socketId);
        if (deletedFromLauncher)
        {
            Logger.Info($"Successfully deleted launcher session with SocketId {socketId}");
        }
        else
        {
            Logger.Warn($"Failed to delete client/session with SocketId {socketId} from both repositories");
        }
    }

    public async Task<(bool success, ClientSessions? client)> TryGetClientAsync(string accountId)
    {
        var clientsRepo = WebSocketConfiguration.repositoryPool.For<ClientSessions>();
        var client = await clientsRepo.FindByColumnAsync("accountid", accountId, useCache: false);
        return (client != null, client);
    }

    public async Task<(bool success, ClientSessions? client)> TryGetClientAsync(Guid socketId)
    {
        var clientsRepo = WebSocketConfiguration.repositoryPool.For<ClientSessions>();
        var client = await clientsRepo.FindByColumnAsync("socketid", socketId, useCache: false);
        return (client != null, client);
    }

    public async Task<List<ClientSessions>> ListAllClients()
    {
        var clientsRepo = WebSocketConfiguration.repositoryPool.For<ClientSessions>();
        return await clientsRepo.FindAllByTableAsync();
    }

    #endregion

    #region Launcher Session Methods

    public async Task AddLauncherSession(LauncherSessions launcherSession, IWebSocketConnection socket)
    {
        if (socket == null)
            throw new ArgumentNullException(nameof(socket));

        var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();

        if (!string.IsNullOrEmpty(launcherSession.AccountId))
        {
            var existingSession = await launcherRepo.FindByColumnAsync("accountid", launcherSession.AccountId);
            if (existingSession != null)
            {
                Globals._socketConnections.Remove(existingSession.SocketId);
                await launcherRepo.DeleteByColumnAsync("socketid", existingSession.SocketId);
            }
        }

        await launcherRepo.SaveAsync(launcherSession).ConfigureAwait(false);
        Globals._socketConnections[launcherSession.SocketId] = socket;
    }

    public async Task RemoveLauncherSession(Guid socketId)
    {
        Globals._socketConnections.Remove(socketId);

        var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();

        bool deleted = await launcherRepo.DeleteByColumnAsync("socketid", socketId);
        if (!deleted)
        {
            Logger.Warn($"Failed to delete launcher session with SocketId {socketId}");
        }
        else
        {
            Logger.Info($"Successfully deleted launcher session with SocketId {socketId}");
        }
    }

    public async Task RemoveLauncherSession(string accountId)
    {
        var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();

        var session = await launcherRepo.FindByColumnAsync("accountid", accountId);
        if (session == null)
        {
            Logger.Error($"Launcher session with AccountId {accountId} is null");
            return;
        }

        Globals._socketConnections.Remove(session.SocketId);
        bool deleted = await launcherRepo.DeleteByColumnAsync("accountid", session.AccountId);
        if (!deleted)
        {
            Logger.Warn($"Failed to delete launcher session with AccountId {session.AccountId}");
        }
        else
        {
            Logger.Info($"Successfully deleted launcher session with AccountId {session.AccountId}");
        }
    }

    public async Task<(bool success, LauncherSessions? session)> TryGetLauncherSessionAsync(Guid socketId)
    {
        var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();
        var session = await launcherRepo.FindByColumnAsync("socketid", socketId);
        return (session != null, session);
    }

    public async Task<(bool success, LauncherSessions? session)> TryGetLauncherSessionAsync(string accountId)
    {
        var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();
        var session = await launcherRepo.FindByColumnAsync("accountid", accountId);
        return (session != null, session);
    }

    public async Task<List<LauncherSessions>> ListAllLauncherSessions()
    {
        var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();
        return await launcherRepo.FindAllByTableAsync();
    }

    public async Task UpdateLauncherSession(LauncherSessions session, IWebSocketConnection socket)
    {
        var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();

        try
        {
            await launcherRepo.UpdateAsync(session);

            var existingConnections = Globals._socketConnections.Where(kvp =>
                kvp.Key != session.SocketId &&
                kvp.Value != socket).ToList();

            foreach (var oldConnection in existingConnections)
            {
                try
                {
                    var oldSession = await launcherRepo.FindByColumnAsync("socketid", oldConnection.Key);
                    if (oldSession?.AccountId == session.AccountId)
                    {
                        Logger.Info($"Removing old launcher session connection: {oldConnection.Key}");
                        Globals._socketConnections.Remove(oldConnection.Key, out _);
                        oldConnection.Value?.Close();
                    }
                }
                catch (Exception ex)
                {
                    Logger.Debug($"Error cleaning up old launcher connection: {ex.Message}");
                }
            }

            Logger.Info($"Updated launcher session: {session.SocketId} for account {session.AccountId}");
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to update launcher session {session.SocketId}: {ex.Message}");
            throw;
        }
    }

    #endregion

    #region General Methods

    public async Task<bool> ClientExists(Guid socketId, string protocol)
    {
        if (protocol == "xmpp")
        {
            var clientsRepo = WebSocketConfiguration.repositoryPool.For<ClientSessions>();
            var client = await clientsRepo.FindByColumnAsync("socketid", socketId);
            return client != null;
        }
        else if (protocol == "launcher")
        {
            var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();
            var session = await launcherRepo.FindByColumnAsync("socketid", socketId);
            return session != null;
        }
        else
        {
            var clientsRepo = WebSocketConfiguration.repositoryPool.For<ClientSessions>();
            var client = await clientsRepo.FindByColumnAsync("socketid", socketId);
            if (client != null) return true;

            var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();
            var session = await launcherRepo.FindByColumnAsync("socketid", socketId);
            return session != null;
        }
    }

    public async Task Clear()
    {
        var clientsRepo = WebSocketConfiguration.repositoryPool.For<ClientSessions>();
        var allClients = await clientsRepo.FindAllByTableAsync();
        foreach (var client in allClients)
        {
            Globals._socketConnections.Remove(client.SocketId);
            await clientsRepo.DeleteAsync(client);
        }

        var launcherRepo = WebSocketConfiguration.repositoryPool.For<LauncherSessions>();
        var allSessions = await launcherRepo.FindAllByTableAsync();
        foreach (var session in allSessions)
        {
            Globals._socketConnections.Remove(session.SocketId);
            await launcherRepo.DeleteAsync(session);
        }

        Logger.Info("Cleared all clients and launcher sessions");
    }

    #endregion
}
