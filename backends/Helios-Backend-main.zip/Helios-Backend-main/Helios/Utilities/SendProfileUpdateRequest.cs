using Helios.Configuration;
using Helios.Database.Tables.Profiles;
using Helios.Managers;
using Helios.Utilities.Extensions;
using System.Text.Json;

namespace Helios.Utilities;

public static class SendProfileUpdateRequest
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = false
    };

    public static async Task UpdateAsync(string accountId, string username)
    {
        var profileRepository = Constants.repositoryPool.For<Profiles>();

        var athenaTask = profileRepository.FindByColumnsAsync(new Dictionary<string, object>
        {
            { "accountid", accountId },
            { "profileid", "athena" }
        });

        var commonCoreTask = profileRepository.FindByColumnsAsync(new Dictionary<string, object>
        {
            { "accountid", accountId },
            { "profileid", "common_core" }
        });

        await Task.WhenAll(athenaTask, commonCoreTask);

        var athena = athenaTask.Result;
        var commonCore = commonCoreTask.Result;

        if (athena is null || commonCore is null)
            return;

        athena.Revision++;
        commonCore.Revision++;

        var payloadJson = JsonSerializer.Serialize(new
        {
            type = "com.epicgames.gift.received",
            payload = new { },
            timestamp = DateTime.UtcNow.ToIsoUtcString(),
        }, JsonOptions);

        await Task.WhenAll(
            ProfileManager.UpdateProfileAsync(commonCore),
            ProfileManager.UpdateProfileAsync(athena),
            Constants.GlobalXmppClientService.SendEmptyGiftAsync(accountId, payloadJson)
        );
    }
}
