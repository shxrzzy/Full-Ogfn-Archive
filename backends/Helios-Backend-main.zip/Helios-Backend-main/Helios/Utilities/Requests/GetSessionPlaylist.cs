using Helios.Classes.MatchmakingServers;
using Helios.Configuration;
using Jose;
using RestSharp;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

namespace Helios.Utilities.Requests.GetMatchmakingServers
{
    public class GetSessionPlaylist
    {
        public static async Task<SelectedPlaylist> SelectPlaylistAsync(string region)
        {
            var client = new RestClient($"{Constants.BaseUrl}:{Constants.MatchmakerPort}/crystal/restapi/v1/matchmaking/sessions/playlists/{region}");
            var request = new RestRequest($"{Constants.BaseUrl}:{Constants.MatchmakerPort}/crystal/restapi/v1/matchmaking/sessions/playlists/{region}", Method.Get);

            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", $"Basic {Constants.config.JWTClientSecret}");

            try
            {
                var response = await client.ExecuteAsync<SelectedPlaylist>(request);

                if (response.IsSuccessful)
                    return response.Data ?? new SelectedPlaylist();

                Logger.Error($"Failed to get playlist: {response.ErrorMessage}");
                return new SelectedPlaylist();
            }
            catch (Exception ex)
            {
                Logger.Error($"Error getting matchmaking playlist: {ex.Message} - {ex.StackTrace}");
                return new SelectedPlaylist();
            }
        }
    }
}