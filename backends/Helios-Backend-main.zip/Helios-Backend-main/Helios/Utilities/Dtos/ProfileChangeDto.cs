namespace Helios.Utilities.Dtos;

public readonly record struct ProfileChangeDto(string changeType, object profile)
{
    public static ProfileChangeDto FullUpdate(object profile)
        => new("fullProfileUpdate", profile);
}