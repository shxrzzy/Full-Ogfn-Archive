﻿namespace Helios.Utilities.Errors.HeliosErrors;

public class AntiCheatErrors
{
    private const string Service = "com.helios.anticheat";

    public static ApiError AnticheatDisabled => new(
        "errors.com.epicgames.anticheat.disabled",
        "The anti-cheat system is currently disabled. Please try again later or contact support if the issue persists.",
        Service, 18001, 403);

    public static ApiError NotLoggedIntoAnticheat => new(
        "errors.com.epicgames.anticheat.not_logged_in",
        "You must be logged into the anti-cheat to perform this action. (restart your game)",
        Service, 18002, 401);
    
    public static ApiError MissingAnticheatToken => new(
        "errors.com.epicgames.anticheat.missing_token",
        "Anti-cheat token is missing. Please restart your game client.",
        Service, 18003, 401);

    public static ApiError AnticheatSessionExpired => new(
        "errors.com.epicgames.anticheat.session_expired",
        "Your anti-cheat session has expired. Please reauthenticate.",
        Service, 18004, 401);

    public static ApiError InvalidAnticheatSession => new(
        "errors.com.epicgames.anticheat.invalid_session",
        "Your anti-cheat session is invalid. Please restart your game client.",
        Service, 18005, 401);
}