﻿using Helios.Classes.Launcher;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Database.Tables.Profiles;
using Helios.Database.Tables.Stats;
using Helios.Managers;
using Helios.Utilities.Errors.HeliosErrors;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace Helios.Utilities.Launcher;

public class UserRegistration
{
    private static readonly string DefaultStatsValue = new JsonObject
    {
        { "Kills", 0 },
        { "Wins", 0 },
        { "Top5", 0 },
        { "Top10", 0 },
        { "Top25", 0 }
    }.ToString();

    public static async Task<(bool Success, string AccountId, string DisplayName)> Register(NewRegisteredUser user)
    {
        if (user.Email == null || user.Password == null || user.Username == null)
            throw new ArgumentException("Email, password, and username are required.");

        var userRepository = Constants.repositoryPool.For<User>();
        var loadoutsRepository = Constants.repositoryPool.For<Loadouts>();
        var userBansRepository = Constants.repositoryPool.For<Ban>();
        var statsRepository = Constants.repositoryPool.For<Stats>();

        if (await userRepository.FindAsync(new User { Username = user.Username }) is not null)
            return (false, "", user.Username);

        try
        {
            var newUser = new User
            {
                Email = user.Email,
                Password = user.Password,
                Username = user.Username,
                DiscordId = user.DiscordId,
                AccountId = Guid.NewGuid().ToString(),
                Banned = false,
                AllItemsGranted = false,
                Roles = user.Roles,
                Avatar = user.Avatar,
                Ac = false
            };

            await userRepository.SaveAsync(newUser);

            var profiles = new List<string> { "athena", "common_core" };
            foreach (var profileId in profiles)
            {
                var profile = await ProfileManager.CreateProfileAsync(profileId, newUser.AccountId);
                if (profile != null)
                {
                    Logger.Info($"Successfully created {profileId} profile for account {newUser.AccountId}");
                }
            }

            await loadoutsRepository.SaveAsync(new Loadouts
            {
                AccountId = newUser.AccountId,
                ProfileId = "athena",
                TemplateId = "CosmeticLocker:cosmeticlocker_athena",
                LockerName = "fortniteloadout1",
                BannerId = "",
                BannerColorId = "",
                CharacterId = "AthenaCharacter:CID_001_Athena_Commando_F_Default",
                BackpackId = "",
                GliderId = "AthenaGlider:DefaultGlider",
                DanceId = new string[6] { "", "", "", "", "", "" },
                PickaxeId = "AthenaPickaxe:DefaultPickaxe",
                ItemWrapId = new string[7] { "", "", "", "", "", "", "" },
                ContrailId = "",
                LoadingScreenId = "",
                MusicPackId = ""
            });

            await userBansRepository.SaveAsync(new Ban
            {
                AccountId = newUser.AccountId,
                IsShadowBanned = false,
                IsRecentlyUnbanned = false
            });

            var saveTasks = new List<Task>();

            var statsEntities = CreateStatsEntities(newUser.AccountId, newUser.Username);
            saveTasks.AddRange(statsEntities.Select(stat => statsRepository.SaveAsync(stat)));

            await Task.WhenAll(saveTasks);

            return (true, newUser.AccountId, user.Username);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error creating account: {ex.Message}");
            return (false, "", user.Username);
        }
    }

    private static List<Stats> CreateStatsEntities(string accountId, string username)
    {
        var statTypes = new[] { "Solos", "Duos", "Squads", "Ltms", "Arena" };

        return statTypes.Select(type => new Stats
        {
            AccountId = accountId,
            Username = username,
            MatchesPlayed = 0,
            Type = type,
            Value = JsonSerializer.Serialize(new
            {
                Kills = 0,
                Wins = 0,
                Top5 = 0,
                Top10 = 0,
                Top25 = 0
            })
        }).ToList();
    }
}