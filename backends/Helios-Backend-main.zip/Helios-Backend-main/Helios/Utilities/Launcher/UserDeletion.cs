using Helios.Classes.Launcher;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Database.Tables.Profiles;
using Helios.Database.Tables.Stats;
using Helios.Managers;
using System.Threading.Tasks;

namespace Helios.Utilities.Launcher;

public class UserDeletion
{
    public static async Task<bool> DeleteUser(string accountId)
    {
        if (string.IsNullOrEmpty(accountId))
            throw new ArgumentException("Account ID is required.");

        var userRepository = Constants.repositoryPool.For<User>();
        var loadoutsRepository = Constants.repositoryPool.For<Loadouts>();
        var userBansRepository = Constants.repositoryPool.For<Ban>();
        var statsRepository = Constants.repositoryPool.For<Stats>();
        var hardwaresRepository = Constants.repositoryPool.For<Hardwares>();


        try
        {
            var deleteTasks = new List<Task>
            {
                userRepository.DeleteAsync(new User { AccountId = accountId }),
                loadoutsRepository.DeleteAsync(new Loadouts { AccountId = accountId }),
                userBansRepository.DeleteAsync(new Ban { AccountId = accountId }),
                statsRepository.DeleteAsync(new Stats { AccountId = accountId }),
                hardwaresRepository.DeleteAsync(new Hardwares { AccountId = accountId }),
            };

            var profiles = new List<string> { "athena", "common_core" };
            foreach (var profileId in profiles)
            {
                deleteTasks.Add(ProfileManager.DeleteProfileAsync(profileId, accountId));
            }

            await Task.WhenAll(deleteTasks);

            Logger.Info($"Successfully deleted user account {accountId} and all related data");
            return true;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error deleting account {accountId}: {ex.Message}");
            return false;
        }
    }

    public static async Task<bool> DeleteUserByUsername(string username)
    {
        if (string.IsNullOrEmpty(username))
            throw new ArgumentException("Username is required.");

        var userRepository = Constants.repositoryPool.For<User>();
        var user = await userRepository.FindAsync(new User { Username = username });

        if (user == null)
        {
            Logger.Warn($"User with username {username} not found");
            return false;
        }

        return await DeleteUser(user.AccountId);
    }
}