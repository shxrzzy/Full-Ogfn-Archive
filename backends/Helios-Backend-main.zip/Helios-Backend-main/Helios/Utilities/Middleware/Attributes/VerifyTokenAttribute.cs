﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace Helios.Utilities.Middleware.Attributes;

[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
public class VerifyTokenAttribute : Attribute, IFilterMetadata
{
}
