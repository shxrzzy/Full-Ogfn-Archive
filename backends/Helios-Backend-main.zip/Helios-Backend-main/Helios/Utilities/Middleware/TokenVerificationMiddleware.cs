﻿using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Helios.Utilities.Tokens;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Helios.Utilities.Middleware;

public class TokenVerificationMiddleware
{
    private readonly RequestDelegate _next;

    public TokenVerificationMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var endpoint = context.GetEndpoint();
        var verifyTokenAttribute = endpoint?.Metadata?.GetMetadata<VerifyTokenAttribute>();

        if (verifyTokenAttribute != null)
        {
            var isValid = await VerifyTokenInternal(context, context.Request);
            if (!isValid)
            {
                return;
            }
        }

        await _next(context);
    }

    private static async Task<bool> VerifyTokenInternal(HttpContext context, HttpRequest request)
    {
        if (context.Response.HasStarted)
        {
            Logger.Warn("Response has already started, cannot verify token");
            return false;
        }

        if (!request.Headers.TryGetValue("Authorization", out var authHeader) || string.IsNullOrEmpty(authHeader))
        {
            string route = Constants.ExtractSanitiztedRoute(request.Path);
            AuthenticationErrors.AuthenticationFailed(route).AddVariables([authHeader]).AttachToResponse(context);
            return false;
        }

        string token = authHeader.ToString().Trim();

        if (token.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            token = token.Substring("Bearer ".Length);
        if (token.StartsWith("eg1~"))
            token = token.Substring("eg1~".Length);

        if (token.Count(c => c == '.') != 2)
        {
            Logger.Error($"Malformed token received: {token}");
            if (!context.Response.HasStarted)
                AuthenticationErrors.InvalidToken("Malformed token").AttachToResponse(context);
            return false;
        }

        string accountId;
        try
        {
            var decodedToken = TokenGenerator.DecodeToken(token);
            if (decodedToken == null)
            {
                if (!context.Response.HasStarted)
                    AuthenticationErrors.InvalidToken("Failed to decode token").AttachToResponse(context);
                return false;
            }

            accountId = decodedToken["sub"] as string;
            if (string.IsNullOrEmpty(accountId))
            {
                if (!context.Response.HasStarted)
                    AuthenticationErrors.InvalidToken("Missing subject in token").AttachToResponse(context);
                return false;
            }
        }
        catch (Exception ex)
        {
            Logger.Error("Token decoding error", ex);
            if (!context.Response.HasStarted)
                AuthenticationErrors.InvalidToken("Failed to decode token").AttachToResponse(context);
            return false;
        }

        try
        {
            var uRepo = Constants.repositoryPool.Repo<User>();
            var user = await uRepo().FindByColumnAsync("accountid", accountId);
            if (user is null)
            {
                if (!context.Response.HasStarted)
                    AccountErrors.AccountNotFound(accountId).WithMessage($"User with id {accountId} not found").AttachToResponse(context);
                return false;
            }

            if (user.Banned)
            {
                if (!context.Response.HasStarted)
                    AccountErrors.DisabledAccount.AttachToResponse(context);
                return false;
            }

            var whitelistedUsernames = new[]
            {
                "sigmags",
                "ONBROISAFUCKINGRETARDKYSNWORDFUCKINGGSGSGSGSGSGS",
                "chargedcum",
                "STINKYFUCKINGRETARDNEGAN",
                "TIVANMPISANASTYJEWCRACKER",
                "FUCKUVENTIRETARS11",
                "hoster105",
                "hoster10145",
                "hoster10433245"
            };

            var serverAccountsRepository = Constants.repositoryPool.For<ServerAccounts>();
            var serverAccount = await serverAccountsRepository.FindByColumnAsync("username", user.Username);

            bool isWhitelisted = whitelistedUsernames.Contains(user.Username) || serverAccount != null;

#if !DEBUG
            if (!user.Ac && !isWhitelisted)
            {
                if (!context.Response.HasStarted)
                {
                    AntiCheatErrors.NotLoggedIntoAnticheat.AttachToResponse(context);
                }
                return false;
            }
#endif

            if (!context.Response.HasStarted)
            {
                context.Response.Cookies.Append("AccountId", accountId, new CookieOptions
                {
                    HttpOnly = true,
                    Expires = DateTime.UtcNow.AddDays(7)
                });

                string userJson = JsonSerializer.Serialize(user);
                context.Response.Cookies.Append("User", userJson, new CookieOptions
                {
                    HttpOnly = true,
                    Expires = DateTime.UtcNow.AddDays(7)
                });
            }

            return true;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error verifying token: {ex.Message}", ex);
            if (!context.Response.HasStarted)
                InternalErrors.ServerError.AttachToResponse(context);
            return false;
        }
    }
}