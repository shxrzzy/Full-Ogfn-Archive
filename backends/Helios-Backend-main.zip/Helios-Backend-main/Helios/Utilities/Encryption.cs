﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Helios.Utilities;

public class Encryption
{
    private static readonly int KeySize = 256; 
    private static readonly int BlockSize = 128;
    
     /// <summary>
    /// Encrypts the given plain text using AES-256 encryption.
    /// </summary>
    /// <param name="plainText">The plain text to encrypt.</param>
    /// <param name="key">A 32-character key for AES-256 encryption.</param>
    /// <returns>The encrypted text as a Base64-encoded string.</returns>
    /// <exception cref="ArgumentException">Thrown if the key is not 32 characters long.</exception>
    public static string Encrypt(string plainText, string key)
    {
        if (string.IsNullOrEmpty(plainText))
            throw new ArgumentNullException(nameof(plainText), "Plain text cannot be null or empty.");
        if (key.Length != 32)
            throw new ArgumentException("Key must be 32 characters long for AES-256 encryption.", nameof(key));

        byte[] keyBytes = Encoding.UTF8.GetBytes(key);

        using (Aes aes = Aes.Create())
        {
            aes.KeySize = KeySize;
            aes.BlockSize = BlockSize;
            aes.Key = keyBytes;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            aes.GenerateIV();
            byte[] iv = aes.IV;

            using (ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
            using (MemoryStream ms = new MemoryStream())
            {
                ms.Write(iv, 0, iv.Length);

                using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                {
                    byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
                    cs.Write(plainBytes, 0, plainBytes.Length);
                    cs.FlushFinalBlock();

                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }
    }
    
    /// <summary>
    /// Decrypts the given encrypted text using AES-256 decryption.
    /// </summary>
    /// <param name="cipherText">The encrypted text as a Base64-encoded string.</param>
    /// <param name="key">A 32-character key for AES-256 decryption.</param>
    /// <returns>The decrypted plain text.</returns>
    /// <exception cref="ArgumentException">Thrown if the key is not 32 characters long.</exception>
    public static string Decrypt(string cipherText, string key)
    {
        if (string.IsNullOrEmpty(cipherText))
            throw new ArgumentNullException(nameof(cipherText), "Cipher text cannot be null or empty.");
        if (key.Length != 32)
            throw new ArgumentException("Key must be 32 characters long for AES-256 decryption.", nameof(key));

        byte[] keyBytes = Encoding.UTF8.GetBytes(key);
        byte[] cipherBytes = Convert.FromBase64String(cipherText);

        using (Aes aes = Aes.Create())
        {
            aes.KeySize = KeySize;
            aes.BlockSize = BlockSize;
            aes.Key = keyBytes;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            byte[] iv = new byte[aes.BlockSize / 8];
            Array.Copy(cipherBytes, 0, iv, 0, iv.Length);
            aes.IV = iv;

            using (ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
            using (MemoryStream ms = new MemoryStream(cipherBytes, iv.Length, cipherBytes.Length - iv.Length))
            using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
            using (StreamReader sr = new StreamReader(cs))
            {
                return sr.ReadToEnd();
            }
        }
    }
}