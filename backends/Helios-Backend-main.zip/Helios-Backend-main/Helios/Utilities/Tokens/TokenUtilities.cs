﻿using System;
using System.Text;
using System.Threading.Tasks;
using Helios.Classes.Tokens;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Utilities.Extensions;
using Jose;
using Newtonsoft.Json;

namespace Helios.Utilities.Tokens
{
    public static class TokenUtilities
    {
        private static readonly Random _random = new Random();

        private static async Task<string> CreateTokenAsync(string clientId, string grantType, User user, string type)
        {
            var isAccess = type == "access";
            var expiry = isAccess ? TokenSettings.AccessTokenExpiry : TokenSettings.RefreshTokenExpiry;
            
            var payload = new
            {
                app = "fortnite", 
                sub = user.AccountId,
                dvid = _random.Next(1, 1000000000),
                mver = false,
                clid = clientId,
                dn = user.Username,
                am = type == "access" ? grantType : "refresh",
                p = Guid.NewGuid().ToString(),
                iai = user.AccountId,
                sec = 1,
                clsvc = "fortnite",
                t = "epic_id", 
                ic = true,
                jti = Guid.NewGuid().ToString(),
                creationDate = DateTime.UtcNow.ToIsoUtcString(),
                expiresIn = expiry,
                //
                // pfsid = "fn",
                // iss = "https://api.epicgames.dev/epic/oauth/v1",
                // pfpid = "prod-fn",
                // aud = "ec684b8c687f479fadea3cb2ad83f5c6",
                // pfdid = "62a9473a2dca46b29ccf17577fcf42d7",
                // appid = "fghi4567FNFBKFz3E4TROb0bmPS8h1GW",
                // scope = "basic_profile friends_list openid presence",
            };

            var token = JWT.Encode(payload, Encoding.UTF8.GetBytes(Constants.config.JWTClientSecret), JwsAlgorithm.HS256);

            var tRepo = Constants.repositoryPool.Repo<Database.Tables.Account.Tokens>();
            var tokenEntry = new Database.Tables.Account.Tokens
            {
                Type = $"{type}token",
                AccountId = user.AccountId,
                Token = token
            };

            await tRepo().SaveAsync(tokenEntry); 

            return token;
        }

        public static Task<string> CreateAccessTokenAsync(string clientId, string grantType, User user) =>
            CreateTokenAsync(clientId, grantType, user, "access");

        public static Task<string> CreateRefreshTokenAsync(string clientId, User user) =>
            CreateTokenAsync(clientId, "", user, "refresh");

        public static Task<string> CreatePublicKeyAsync(User user, string type, string keyGuid, string kid, string key)
        {
            var generated = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

            var payload = new
            {
                account_id = user.AccountId,
                generated,
                key_guid = keyGuid,
                kid,
                key,
                expiration = "9999-12-31T23:59:59.999Z",
                type
            };

            var jwt = JWT.Encode(payload, Encoding.UTF8.GetBytes(Constants.config.JWTClientSecret), JwsAlgorithm.HS256);
            return Task.FromResult(jwt);
        }
    }
}
