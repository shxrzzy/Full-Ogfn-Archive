﻿using Helios.Classes.Launcher.Socket;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Jose;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace Helios.Utilities.Tokens;

public class TokenGenerator
{
    private const int TokenLifetimeMinutes = 240;
    private const int RandomBytesForP = 128;
    private const int RandomBytesForJti = 32;

    /// <summary>
    /// Generates a JWT using the provided client ID and client secret.
    /// The token is signed using HMAC SHA-256.
    /// </summary>
    /// <param name="clientId">The client ID used for identification.</param>
    /// <param name="clientSecret">The client secret used for signing the token.</param>
    /// <returns>A string representing the generated JWT.</returns>
    /// <exception cref="ArgumentException">Thrown when clientId or clientSecret is null or empty.</exception>
    public static string GenerateToken(string clientId, string clientSecret)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty.", nameof(clientId));
        if (string.IsNullOrWhiteSpace(clientSecret))
            throw new ArgumentException("Client secret cannot be null or empty.", nameof(clientSecret));

        try
        {
            string p = Convert.ToBase64String(GenerateRandomBytes(RandomBytesForP));
            string jti = BitConverter.ToString(GenerateRandomBytes(RandomBytesForJti)).Replace("-", "")
                .ToLowerInvariant();

            DateTime utcNow = DateTime.UtcNow;
            DateTime expirationTime = utcNow.AddMinutes(TokenLifetimeMinutes);

            var payload = new Dictionary<string, object>
            {
                { "p", p },
                { "clsvc", "fortnite" },
                { "t", "s" },
                { "mver", false },
                { "clid", clientId },
                { "ic", true },
                { "exp", new DateTimeOffset(expirationTime).ToUnixTimeSeconds() },
                { "am", "client_credentials" },
                { "iat", new DateTimeOffset(utcNow).ToUnixTimeSeconds() },
                { "jti", jti },
                { "creation_date", utcNow.ToString("yyyy-MM-dd HH:mm:ss.fffZ") }
            };

            var token = JWT.Encode(payload, Encoding.UTF8.GetBytes(clientSecret), JwsAlgorithm.HS256);
            return token;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error generating token: {ex.Message}");
            throw;
        }
    }
    
    public static string GenerateJwtToken(Claim[] claims, int expires, string secret)
    {
        var GrabBytes = new byte[32];
        RandomNumberGenerator.Fill(GrabBytes);

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));
        var tokenHandler = new JwtSecurityTokenHandler();
        var token = tokenHandler.CreateJwtSecurityToken(new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(claims),
            Expires = DateTime.UtcNow.AddHours(expires),
            SigningCredentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature)
        });

        var tokenString = tokenHandler.WriteToken(token);

        return tokenString;
    }
    
    public static string GenerateToken(string clientId, string clientSecret, string deploymentId)
    {
        if (string.IsNullOrWhiteSpace(clientId))
            throw new ArgumentException("Client ID cannot be null or empty.", nameof(clientId));
        if (string.IsNullOrWhiteSpace(clientSecret))
            throw new ArgumentException("Client secret cannot be null or empty.", nameof(clientSecret));

        try
        {
            string p = Convert.ToBase64String(GenerateRandomBytes(RandomBytesForP));
            string jti = BitConverter.ToString(GenerateRandomBytes(RandomBytesForJti)).Replace("-", "")
                .ToLowerInvariant();

            DateTime utcNow = DateTime.UtcNow;
            DateTime expirationTime = utcNow.AddMinutes(TokenLifetimeMinutes);

            var payload = new Dictionary<string, object>
            {
                { "p", p },
                { "clsvc", "fortnite" },
                { "t", "s" },
                { "mver", false },
                { "clid", clientId },
                { "ic", true },
                { "exp", new DateTimeOffset(expirationTime).ToUnixTimeSeconds() },
                { "am", "client_credentials" },
                { "iat", new DateTimeOffset(utcNow).ToUnixTimeSeconds() },
                { "jti", jti },
                { "creation_date", utcNow.ToString("yyyy-MM-dd HH:mm:ss.fffZ") },
                { "clientId", clientId },
                { "productId", "prod-fn" },
                { "iss", "eos" },
                { "env", "prod" },
                { "features", new List<string>
                {
                    "AntiCheat",
                    "Connect",
                    "ContentService",
                    "Ecom",
                    "EpicConnect",
                    "Inventories",
                    "LockerService",
                    "Matchmaking Service",
                    "ExchangeCodeCreation",
                    "Achievements",
                    "Leaderboards",
                    "Matchmaking",
                    "Metrics",
                    "PlayerReports",
                    "Sanctions",
                    "Stats",
                    "TitleStorage",
                    "Voice"
                } },
                { "deploymentId", deploymentId },
                { "sandboxId", "fn" },
                { "organizationId", RandomHexGenerator.GenerateId() },
                { "tokenType", "clientToken" }
            };

            var token = JWT.Encode(payload, Encoding.UTF8.GetBytes(clientSecret), JwsAlgorithm.HS256);
            return token;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error generating token: {ex.Message}");
            throw;
        }
    }
    
    public static string GenerateEosAccessToken(string accountId, string username)
    {
        string clientSecret = Constants.config.JWTClientSecret;
        
        var payload = new Dictionary<string, object>
        {
            { "sub", accountId },
            { "pfsid", "fn" },
            { "iss", "https://api.epicgames.dev/epic/oauth/v1" },
            { "dn", username },
            { "nonce", "n-01/jkXYh/9P5JimUEpSisDyK3Xw=" },
            { "pfpid", "prod-fn" },
            { "sec", 1 },
            { "aud", "ec684b8c687f479fadea3cb2ad83f5c6" },
            { "pfdid", "62a9473a2dca46b29ccf17577fcf42d7" },
            { "t", "epic_id" },
            { "scope", "basic_profile openid offline_access" },
            { "appid", "fghi4567FNFBKFz3E4TROb0bmPS8h1GW" },
            { "exp", 9668536326 },
            { "iat", 1668529126 },
            { "jti", "c01f29504dcd42f9b68cf55759392928" }
        };


        return JWT.Encode(payload, Encoding.UTF8.GetBytes(clientSecret), JwsAlgorithm.HS256);
    }
    
    public static string GenerateEosIdToken(string accountId, string username)
    {
        string clientSecret = Constants.config.JWTClientSecret;
        
        var payload = new Dictionary<string, object>
        {
            { "aud", "ec684b8c687f479fadea3cb2ad83f5c6" },
            { "sub", accountId }, 
            { "pfsid", "fn" },
            { "act", new Dictionary<string, object>
                {
                    { "pltfm", "other" },
                    { "eaid", accountId },
                    { "eat", "epicgames" }
                }
            },
            { "pfdid", "62a9473a2dca46b29ccf17577fcf42d7" },
            { "iss", "https://api.epicgames.dev/epic/oauth/v1" },
            { "exp", 9668536326 },
            { "tokenType", "idToken" },
            { "iat", 1668529126 },
            { "pfpid", "prod-fn" },
            { "nonce", "n-e3Kcqw0hulXkbebFRBL8o5AwL3M=" },
            { "t", "id_token" },
            { "appid", "fghi4567FNFBKFz3E4TROb0bmPS8h1GW" },
            { "jti", "c01f29504dcd42f9b68cf55759392928" },
            { "dn", username }
        };
        
        return JWT.Encode(payload, Encoding.UTF8.GetBytes(clientSecret), JwsAlgorithm.HS256);
    }

    public static string GenerateEosRefreshToken(string sub, string dn)
    {
        string clientSecret = Constants.config.JWTClientSecret;
        
        var payload = new Dictionary<string, object>
        {
            { "sub", sub }, 
            { "pfsid", "fn" },
            { "iss", "https://api.epicgames.dev/epic/oauth/v1" },
            { "dn", dn }, 
            { "pfpid", "prod-fn" },
            { "aud", "ec684b8c687f479fadea3cb2ad83f5c6" },
            { "pfdid", "62a9473a2dca46b29ccf17577fcf42d7" },
            { "t", "epic_id" },
            { "appid", "fghi4567FNFBKFz3E4TROb0bmPS8h1GW" },
            { "scope", "basic_profile openid offline_access" },
            { "exp", 9668557926 },
            { "iat", 1668529126 },
            { "jti", "c01f29504dcd42f9b68cf55759392928" }
        };
        return JWT.Encode(payload, Encoding.UTF8.GetBytes(clientSecret), JwsAlgorithm.HS256);
    }
    /// <summary>
    /// Decodes a JWT token and returns the claims as a dictionary.
    /// </summary>
    /// <param name="token">The JWT token to decode.</param>
    /// <returns>A dictionary containing the claims of the decoded token.</returns>
    /// <exception cref="ArgumentException">Thrown when token or clientSecret is null or empty.</exception>
    public static IDictionary<string, object> DecodeToken(string token)
    {
        string clientSecret = Constants.config.JWTClientSecret;

        if (string.IsNullOrWhiteSpace(token))
            throw new ArgumentException("Token cannot be null or empty.", nameof(token));
        if (string.IsNullOrWhiteSpace(clientSecret))
            throw new ArgumentException("Client secret cannot be null or empty.", nameof(clientSecret));

        try
        {
            var payload =
                JWT.Decode<IDictionary<string, object>>(token, Encoding.UTF8.GetBytes(clientSecret),
                    JwsAlgorithm.HS256);
            return payload;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error decoding token: {ex.Message}");
            throw;
        }
    }

    public static RequestedUserData DecodeTokenIDK(string token)
    {
        string secret = Constants.config.JWTClientSecret;

        if (string.IsNullOrWhiteSpace(token))
            throw new ArgumentException("Token cannot be null or empty.", nameof(token));
        if (string.IsNullOrWhiteSpace(secret))
            throw new ArgumentException("Client secret cannot be null or empty.", nameof(secret));

        try
        {
            var payload = JWT.Decode<Dictionary<string, object>>(token, Encoding.UTF8.GetBytes(secret), JwsAlgorithm.HS256);

            var user = new RequestedUserData();

            user.Id = payload.TryGetValue("id", out var idObj)
                ? idObj?.ToString() ?? string.Empty
                : string.Empty;

            user.Secret = payload.TryGetValue("hellowelcometocrystalfortnite", out var secretObj)
                ? secretObj?.ToString() ?? string.Empty
                : string.Empty;

            if (payload.TryGetValue("discord", out var discordRaw) && discordRaw != null)
            {
                if (discordRaw is string discordStr)
                {
                    user.Discord = JsonConvert.DeserializeObject<DiscordInfo>(discordStr);
                }
                else
                {
                    var discordJson = JsonConvert.SerializeObject(discordRaw);
                    user.Discord = JsonConvert.DeserializeObject<DiscordInfo>(discordJson);
                }
            }
            else
            {
                user.Discord = new DiscordInfo();
            }

            if (payload.TryGetValue("profile", out var profileRaw) && profileRaw != null)
            {
                if (profileRaw is string profileStr)
                {
                    user.Profile = JsonConvert.DeserializeObject<UserProfile>(profileStr);
                }
                else
                {
                    var profileJson = JsonConvert.SerializeObject(profileRaw);
                    user.Profile = JsonConvert.DeserializeObject<UserProfile>(profileJson);
                }
            }

            if (payload.TryGetValue("roles", out var rolesRaw) && rolesRaw != null)
            {
                if (rolesRaw is string rolesStr)
                {
                    user.Roles = JsonConvert.DeserializeObject<UserRoles>(rolesStr);
                }
                else
                {
                    var rolesJson = JsonConvert.SerializeObject(rolesRaw);
                    user.Roles = JsonConvert.DeserializeObject<UserRoles>(rolesJson);
                }
            }

            return user;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error decoding token: {ex.Message}");
            throw;
        }
    }
    /// <summary>
    /// Generates a cryptographically secure random byte array.
    /// </summary>
    /// <param name="size">The number of random bytes to generate.</param>
    /// <returns>A byte array containing random data.</returns>
    private static byte[] GenerateRandomBytes(int size)
    {
        byte[] randomBytes = new byte[size];
        using (var rng = RandomNumberGenerator.Create())
        {
            rng.GetBytes(randomBytes);
        }
        return randomBytes;
    }
}