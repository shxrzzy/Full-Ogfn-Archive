﻿namespace Helios.Configuration.Services;

public static class WebhostConfiguration
{
    public static void ConfigureWebhosts(ConfigureWebHostBuilder webhosts)
    {
        webhosts.ConfigureKestrel(options =>
        {
            options.AddServerHeader = false;
            options.AllowSynchronousIO = false;
            options.Limits.MaxConcurrentConnections = 500;
            options.Limits.MaxConcurrentUpgradedConnections = 200;
            options.Limits.MaxRequestBodySize = 1024 * 1024;
        });
        webhosts.UseSentry(options =>
        {
            options.Dsn = "https://5e0a61a02e6925815c3fbb25a52a76a8@o4509589483290624.ingest.us.sentry.io/4509589758345216";
#if DEBUG
                options.Debug = false;
#endif
            options.TracesSampleRate = 1.0;

        });
        webhosts.UseUrls(
            Environment.GetEnvironmentVariable("ASPNETCORE_URLS") ?? "http://0.0.0.0:8080"
        );
    }
}