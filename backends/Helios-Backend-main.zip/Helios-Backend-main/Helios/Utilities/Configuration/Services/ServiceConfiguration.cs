﻿using Helios.Classes.Response;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Database.Tables.ContentPages;
using Helios.Database.Tables.Fortnite;
using Helios.Database.Tables.Party;
using Helios.Database.Tables.Profiles;
using Helios.Database.Tables.Solstice;
using Helios.Database.Tables.Stats;
using Helios.Database.Tables.Tournaments;
using Helios.Database.Tables.XMPP;
using Helios.Discord;
using Helios.HTTP.Utilities.Extensions;
using Helios.Interfaces;
using Helios.Managers;
using Helios.Managers.Unreal;
using Helios.Services;
using Helios.Sockets.Hermes;
using Helios.Sockets.IgnisClient;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Exceptions;
using Helios.Utilities.Handlers;
//using Helios.Sockets.XMPP;
using Serilog;
using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Reflection.Metadata;
using System.Threading.RateLimiting;

namespace Helios.Configuration.Services;

public static class ServiceConfiguration
{
    public static async Task ConfigureServices(IServiceCollection services, IWebHostEnvironment env)
    {
        services.AddMemoryCache();
        services.AddControllers();
        services.AddEndpointsApiExplorer();
        services.AddHttpContextAccessor();
        services.AddBodyParser(options =>
        {
            options.MaxBufferSize = 2 * 1024 * 1024;
            options.UsePooledMemory = true;
            options.ThrowOnError = true;
        });

        services.AddScoped<ApiResponseHandler>();
        services.AddSingleton<Bot>();
        //services.AddSingleton<XmppClient>();
        services.AddSingleton<IgnisClient>();
        services.AddSingleton<PartyManager>();
        services.AddSingleton<XmppForwarderClient>();
        //services.AddSingleton<ISolsticeServer, SolsticeServer>();
        //services.AddSingleton<SolsticeClient>();
        // services.AddSingleton<SolsticeServer>();

        services.AddHttpClient();

        services.AddLogging(builder => builder.AddSerilog());

        services.AddRateLimiter(options =>
        {
            options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(
                context =>
                {
                    var clientIp = context.Connection.RemoteIpAddress?.ToString() ?? "unknown";

                    return RateLimitPartition.GetFixedWindowLimiter(
                        clientIp,
                        partition => new FixedWindowRateLimiterOptions
                        {
                            PermitLimit = 40,
                            Window = TimeSpan.FromSeconds(10),
                            QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                            QueueLimit = 0,
                        }
                    );
                }
            );

            options.OnRejected = async (context, token) =>
            {
                context.HttpContext.Response.StatusCode = 429;
                await context.HttpContext.Response.WriteAsync(
                    "Too many requests, Try again later!",
                    token
                );
            };
        });

        services.Configure<ApiResponseOptions>(options =>
        {
            options.ShowDetailedErrors = env.IsDevelopment();
            options.ErrorCodeMapping.Add(typeof(ValidationException), "VALIDATION_ERROR");
            options.ErrorCodeMapping.Add(typeof(NotFoundException), "NOT_FOUND");
        });

        services.AddCors(options =>
        {
            options.AddPolicy("AllowAll", policy =>
            {
                policy.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader();
            });
        });

        services.AddSingleton<UnrealAssetProvider>();

        Constants.repositoryPool.For<ClientSessions>().SetCacheEnabled(false);
        Constants.repositoryPool.For<SolsticeServers>().SetCacheEnabled(false);
        Constants.repositoryPool.For<SolsticeSockets>().SetCacheEnabled(false);
        Constants.repositoryPool.For<Friends>().SetCacheEnabled(false);
        Constants.repositoryPool.For<Items>().SetCacheEnabled(false);
        Constants.repositoryPool.For<TournamentHype>().SetCacheEnabled(false);
        Constants.repositoryPool.For<Catalog>().SetCacheEnabled(false);


        await EnsureAllTablesCreated();
        Log.Information("Database tables verified/created successfully.");

        await PreloadAllRepositories();
        Log.Information("Repository preloading completed successfully.");
    }

    private static async Task EnsureAllTablesCreated()
    {
        try
        {
            var entityTypes = GetAllEntityTypes();

            Log.Information($"Found {entityTypes.Count} entity types to verify/create tables for.");

            foreach (var entityType in entityTypes)
            {
                var tableName = GetTableNameFromEntity(entityType);
                if (!string.IsNullOrEmpty(tableName))
                {
                    Log.Information($"Verified table creation for entity: {entityType.Name} -> Table: {tableName}");
                }

            }

            await Task.Delay(3000);
        }
        catch (Exception ex)
        {
            Log.Error($"Critical error during table creation: {ex.Message}");
            Log.Error($"Stack trace: {ex.StackTrace}");
            throw new InvalidOperationException("Failed to create database tables. Cannot proceed with application startup.", ex);
        }
    }
    private static List<Type> GetAllEntityTypes()
    {
        var entityTypes = new List<Type>();

        var assemblies = AppDomain.CurrentDomain.GetAssemblies()
            .Where(a => !a.IsDynamic &&
                       !string.IsNullOrEmpty(a.Location) &&
                       (a.FullName.Contains("Helios") || a == System.Reflection.Assembly.GetExecutingAssembly()))
            .ToList();

        foreach (var assembly in assemblies)
        {
            try
            {
                var types = assembly.GetTypes()
                    .Where(t => t.IsClass &&
                               !t.IsAbstract &&
                               t.GetCustomAttributes(typeof(Helios.Database.Attributes.EntityAttribute), true).Any())
                    .ToList();

                entityTypes.AddRange(types);

                if (types.Any())
                {
                    Log.Information($"Found {types.Count} entity types in assembly: {assembly.GetName().Name}");
                }
            }
            catch (Exception ex)
            {
                Log.Warning($"Could not examine assembly {assembly.GetName().Name}: {ex.Message}");
            }
        }

        return entityTypes.OrderBy(t => t.FullName).ToList();
    }

    private static string GetTableNameFromEntity(Type entityType)
    {
        var entityAttribute = entityType.GetCustomAttribute<Helios.Database.Attributes.EntityAttribute>();
        return entityAttribute?.TableName;
    }

    private static async Task PreloadAllRepositories()
    {
        var preloadTasks = new List<(string Name, Task Task)>();

        try
        {
            preloadTasks.AddRange(new[]
            {
                ("User", Constants.repositoryPool.For<User>().PreloadAllAsync()),
                ("Profiles", Constants.repositoryPool.For<Profiles>().PreloadAllAsync()),
                ("Items", Constants.repositoryPool.For<Items>().PreloadAllAsync()),
                ("ClientSessions", Constants.repositoryPool.For<ClientSessions>().PreloadAllAsync()),
                ("Loadouts", Constants.repositoryPool.For<Loadouts>().PreloadAllAsync()),
                ("Quests", Constants.repositoryPool.For<Quests>().PreloadAllAsync()),
                ("Invites", Constants.repositoryPool.For<Invites>().PreloadAllAsync()),
                ("Parties", Constants.repositoryPool.For<Parties>().PreloadAllAsync()),
                ("Pings", Constants.repositoryPool.For<Pings>().PreloadAllAsync()),
                ("Tokens", Constants.repositoryPool.For<Tokens>().PreloadAllAsync()),
                ("Friends", Constants.repositoryPool.For<Friends>().PreloadAllAsync()),
                ("SolsticeServers", Constants.repositoryPool.For<SolsticeServers>().PreloadAllAsync()),
                ("SolsticeSockets", Constants.repositoryPool.For<SolsticeSockets>().PreloadAllAsync()),
                ("UserGlobalRegions", Constants.repositoryPool.For<UserGlobalRegions>().PreloadAllAsync()),
                ("TournamentEvents", Constants.repositoryPool.For<TournamentEvents>().PreloadAllAsync()),
                ("TournamentHype", Constants.repositoryPool.For<TournamentHype>().PreloadAllAsync()),
                ("TournamentHypeTokens", Constants.repositoryPool.For<TournamentHypeTokens>().PreloadAllAsync()),
                ("TournamentPlayer", Constants.repositoryPool.For<TournamentPlayer>().PreloadAllAsync()),
                ("TournamentScores", Constants.repositoryPool.For<TournamentScores>().PreloadAllAsync()),
                ("TournamentTeams", Constants.repositoryPool.For<TournamentTeams>().PreloadAllAsync()),
                ("TournamentTemplates", Constants.repositoryPool.For<TournamentTemplates>().PreloadAllAsync()),
                ("TournamentTokens", Constants.repositoryPool.For<TournamentTokens>().PreloadAllAsync()),
                ("TournamentInformation", Constants.repositoryPool.For<TournamentInformation>().PreloadAllAsync()),
                ("Hardwares", Constants.repositoryPool.For<Hardwares>().PreloadAllAsync()),
                ("Ban", Constants.repositoryPool.For<Ban>().PreloadAllAsync()),
                ("Stats", Constants.repositoryPool.For<Stats>().PreloadAllAsync()),
                ("SeasonStats", Constants.repositoryPool.For<SeasonStats>().PreloadAllAsync()),
                ("MatchStats", Constants.repositoryPool.For<MatchStats>().PreloadAllAsync()),
                ("Catalog", Constants.repositoryPool.For<Catalog>().PreloadAllAsync())
            });

            Log.Information($"Starting preload of {preloadTasks.Count} repositories...");

            const int batchSize = 5;
            var batches = preloadTasks
                .Select((task, index) => new { task, index })
                .GroupBy(x => x.index / batchSize)
                .Select(g => g.Select(x => x.task).ToList())
                .ToList();

            int completedCount = 0;
            var failedRepositories = new List<string>();

            foreach (var batch in batches)
            {
                Log.Information($"Processing batch of {batch.Count} repositories...");

                var batchTasks = batch.Select(async item =>
                {
                    try
                    {
                        await item.Task;
                        Log.Information($"Successfully preloaded: {item.Name}");
                        Interlocked.Increment(ref completedCount);
                    }
                    catch (Exception ex)
                    {
                        lock (failedRepositories)
                        {
                            failedRepositories.Add(item.Name);
                        }
                        Log.Error($"Failed to preload {item.Name}: {ex.Message}");
                    }
                }).ToArray();

                await Task.WhenAll(batchTasks);

                if (batches.IndexOf(batch) < batches.Count - 1)
                {
                    await Task.Delay(500);
                }
            }

            Log.Information($"Repository preloading summary: {completedCount}/{preloadTasks.Count} successful");

            if (failedRepositories.Any())
            {
                Log.Warning($"Failed repositories: {string.Join(", ", failedRepositories)}");
            }
        }
        catch (Exception ex)
        {
            Log.Error($"Critical error during repository preloading: {ex.Message}");
            Log.Error($"Stack trace: {ex.StackTrace}");
            throw;
        }
    }


    public static void ConfigureLogging(IServiceCollection services)
    {

    }
}