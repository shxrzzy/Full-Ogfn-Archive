﻿using System.Text;

namespace Helios.Utilities;

public static class RandomHexGenerator
{
    private static readonly Random random = new Random();

    public static string GenerateId()
    {
        var sb = new StringBuilder("o-");
        for (int i = 0; i < 32; i++)
        {
            int value = random.Next(16); 
            sb.Append(value.ToString("x")); 
        }
        return sb.ToString();
    }

}