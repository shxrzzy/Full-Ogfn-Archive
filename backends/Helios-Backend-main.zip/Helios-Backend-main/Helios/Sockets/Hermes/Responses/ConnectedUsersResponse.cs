namespace Helios.Sockets.Hermes.Responses;

public class ConnectedUsersResponse
{
    public int ConnectedUsersCount { get; set; }
    public List<string> Users { get; set; } = new();
}
