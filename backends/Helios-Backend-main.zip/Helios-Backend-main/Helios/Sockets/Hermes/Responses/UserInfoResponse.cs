using System.Text.Json;

namespace Helios.Sockets.Hermes.Responses;

public class UserInfoResponse
{
    public string AccountId { get; set; } = string.Empty;
    public string Jid { get; set; } = string.Empty;
    public bool IsConnected { get; set; }
    public SocketInfo SocketInfo { get; set; } = new();
    public string LastPresenceUpdate { get; set; } = JsonSerializer.Serialize(new UserPresenceInfo());
}

public class SocketInfo
{
    public bool IsAvailable { get; set; }
    public bool HasSocket { get; set; }
}

public class UserPresenceInfo
{
    public string Status { get; set; } = string.Empty;
    public bool Away { get; set; } = false;
}