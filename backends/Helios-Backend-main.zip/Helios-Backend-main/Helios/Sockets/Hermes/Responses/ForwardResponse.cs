using Newtonsoft.Json;

namespace Helios.Sockets.Hermes.Responses;

public class ForwardResponse
{
    [JsonProperty("status")]
    public string Status { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public object? Data { get; set; }
}
