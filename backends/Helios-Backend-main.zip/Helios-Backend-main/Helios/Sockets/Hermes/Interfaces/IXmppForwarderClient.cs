using Helios.Sockets.Hermes.Responses;

namespace Helios.Sockets.Hermes.Interfaces;

public interface IXmppForwarderClient : IDisposable
{
    Task<ConnectedUsersResponse> GetConnectedUsersAsync(CancellationToken cancellationToken = default);
    Task<UserInfoResponse> GetUserAsync(string accountId, CancellationToken cancellationToken = default);
    Task<ForwardResponse> SendEmptyGiftAsync(string accountId, string? customMessage = null, CancellationToken cancellationToken = default);
    Task<ForwardResponse> ForwardMessageAsync(string accountId, string body, CancellationToken cancellationToken = default);
    Task<ForwardResponse> ForwardPresenceAsync(string senderId, string receiverId, bool isOffline, CancellationToken cancellationToken = default);
}