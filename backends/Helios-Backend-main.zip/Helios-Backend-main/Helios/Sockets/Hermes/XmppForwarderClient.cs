using Helios.Configuration;
using Helios.Sockets.Hermes.Exceptions;
using Helios.Sockets.Hermes.Interfaces;
using Helios.Sockets.Hermes.Responses;
using Helios.Utilities;
using RestSharp;
using System.Text;
using System.Text.Json;
using System.Web;

namespace Helios.Sockets.Hermes;

public class XmppForwarderClient : IXmppForwarderClient
{
    private readonly RestClient _restClient;
    private readonly JsonSerializerOptions _jsonOptions;
    private bool _disposed = false;

    public XmppForwarderClient()
    {
        if (string.IsNullOrWhiteSpace(Constants.BaseXmppUrl))
            throw new ArgumentException("BaseXmppUrl cannot be null or empty", nameof(Constants.BaseXmppUrl));

        var options = new RestClientOptions(Constants.BaseXmppUrl.TrimEnd('/'))
        {
            Timeout = Constants.RequestTimeout,
            ThrowOnAnyError = false,
            ConfigureMessageHandler = handler =>
            {
                if (handler is HttpClientHandler httpHandler)
                {
                    httpHandler.UseCookies = false;
                }
                return handler;
            }
        };

        _restClient = new RestClient(options);

        _restClient.AddDefaultHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0");
        _restClient.AddDefaultHeader("Accept", "application/json");
        _restClient.AddDefaultHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        _restClient.AddDefaultHeader("Pragma", "no-cache");

        _jsonOptions = CreateJsonOptions();
    }

    private static JsonSerializerOptions CreateJsonOptions()
    {
        return new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = false,
            DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
        };
    }

    public async Task<ConnectedUsersResponse> GetConnectedUsersAsync(CancellationToken cancellationToken = default)
    {
        var request = new RestRequest("/h/v1/xmpp/connected_users", Method.Get);

        return await ExecuteRequestWithRetryAsync(
            request,
            cancellationToken,
            response => ProcessConnectedUsersResponse(response));
    }

    public async Task<UserInfoResponse> GetUserAsync(string accountId, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(accountId))
            throw new ArgumentException("Account ID cannot be null or empty", nameof(accountId));

        var encodedAccountId = HttpUtility.UrlEncode(accountId);
        var request = new RestRequest($"/h/v1/xmpp/user/{encodedAccountId}", Method.Get);

        return await ExecuteRequestWithRetryAsync(
            request,
            cancellationToken,
            response => ProcessUserInfoResponse(response));
    }

    public async Task<ForwardResponse> SendEmptyGiftAsync(string accountId, string? customMessage = null, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(accountId))
            throw new ArgumentException("Account ID cannot be null or empty", nameof(accountId));

        var encodedAccountId = HttpUtility.UrlEncode(accountId);
        var request = new RestRequest($"/h/v1/xmpp/send-empty-gift/{encodedAccountId}", Method.Post);

        if (!string.IsNullOrWhiteSpace(customMessage))
        {
            request.AddStringBody(customMessage, ContentType.Plain);
        }
        else
        {
            request.AddStringBody(string.Empty, ContentType.Plain);
        }

        return await ExecuteRequestWithRetryAsync(
            request,
            cancellationToken,
            response => ProcessForwardResponse(response));
    }

    public async Task<ForwardResponse> ForwardMessageAsync(string accountId, string body, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(accountId))
            throw new ArgumentException("Account ID cannot be null or empty", nameof(accountId));

        if (string.IsNullOrWhiteSpace(body))
            throw new ArgumentException("Message body cannot be null or empty", nameof(body));

        var encodedAccountId = HttpUtility.UrlEncode(accountId);
        var request = new RestRequest($"/h/v1/xmpp/forward/{encodedAccountId}", Method.Post);
        request.AddStringBody(body, ContentType.Plain);

        return await ExecuteRequestWithRetryAsync(
            request,
            cancellationToken,
            response => ProcessForwardResponse(response));
    }

    public async Task<ForwardResponse> ForwardPresenceAsync(string senderId, string receiverId, bool isOffline, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(senderId))
            throw new ArgumentException("Sender ID cannot be null or empty", nameof(senderId));

        if (string.IsNullOrWhiteSpace(receiverId))
            throw new ArgumentException("Receiver ID cannot be null or empty", nameof(receiverId));

        var encodedSenderId = HttpUtility.UrlEncode(senderId);
        var encodedReceiverId = HttpUtility.UrlEncode(receiverId);
        var offlineParam = isOffline ? "true" : "false";

        var request = new RestRequest($"/h/v1/xmpp/presence/forward/{encodedSenderId}/{encodedReceiverId}/{offlineParam}", Method.Get);

        return await ExecuteRequestWithRetryAsync(
            request,
            cancellationToken,
            response => ProcessForwardResponse(response));
    }

    public async Task<ForwardResponse> DeleteUserAsync(string accountId, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(accountId))
            throw new ArgumentException("Account ID cannot be null or empty", nameof(accountId));

        var encodedAccountId = HttpUtility.UrlEncode(accountId);
        var request = new RestRequest($"/h/v1/xmpp/user/{encodedAccountId}/delete", Method.Get);


        return await ExecuteRequestWithRetryAsync(
            request,
            cancellationToken,
            response => ProcessForwardResponse(response));
    }

    private async Task<T> ExecuteRequestWithRetryAsync<T>(
        RestRequest request,
        CancellationToken cancellationToken,
        Func<RestResponse, T> responseProcessor)
    {
        var lastException = default(Exception);

        for (int attempt = 1; attempt <= Constants.MaxRetryAttempts; attempt++)
        {
            try
            {
                var response = await _restClient.ExecuteAsync(request, cancellationToken);
                return responseProcessor(response);
            }
            catch (Exception ex) when (ShouldRetry(ex, attempt))
            {
                lastException = ex;

                if (attempt < Constants.MaxRetryAttempts)
                {
                    var delay = TimeSpan.FromMilliseconds(Constants.RetryDelay.TotalMilliseconds * Math.Pow(2, attempt - 1));
                    await Task.Delay(delay, cancellationToken);
                }
            }
        }

        throw new XmppForwarderException(
            $"Request failed after {Constants.MaxRetryAttempts} attempts",
            lastException ?? new InvalidOperationException("Unknown error"));
    }

    private static bool ShouldRetry(Exception exception, int attempt)
    {
        return exception switch
        {
            TaskCanceledException => false,
            XmppForwarderException xmppEx when xmppEx.StatusCode >= 400 && xmppEx.StatusCode < 500 => false,
            HttpRequestException => true,
            _ => attempt < 3
        };
    }

    private ForwardResponse ProcessForwardResponse(RestResponse response)
    {
        var content = response.Content ?? string.Empty;

        if (!response.IsSuccessful)
        {
            try
            {
                var errorResponse = JsonSerializer.Deserialize<ErrorResponse>(content, _jsonOptions);
                throw new XmppForwarderException(
                    errorResponse?.Error ?? "Unknown API error",
                    (int)response.StatusCode,
                    errorResponse?.Details);
            }
            catch (JsonException)
            {
                throw new XmppForwarderException(
                    $"HTTP {(int)response.StatusCode}: {content}",
                    (int)response.StatusCode);
            }
        }

        try
        {
            if (content.StartsWith("\"") && content.EndsWith("\""))
            {
                content = JsonSerializer.Deserialize<string>(content, _jsonOptions) ?? string.Empty;
            }

            var result = JsonSerializer.Deserialize<ForwardResponse>(content, _jsonOptions);
            return result ?? throw new XmppForwarderException("Received null response from server");
        }
        catch (JsonException ex)
        {
            throw new XmppForwarderException($"Failed to parse server response: {content}", ex);
        }
    }


    private UserInfoResponse ProcessUserInfoResponse(RestResponse response)
    {
        var content = response.Content ?? string.Empty;

        if (!response.IsSuccessful)
        {
            try
            {
                var errorResponse = JsonSerializer.Deserialize<ErrorResponse>(content, _jsonOptions);
                throw new XmppForwarderException(
                    errorResponse?.Error ?? "Unknown API error",
                    (int)response.StatusCode,
                    errorResponse?.Details);
            }
            catch (JsonException)
            {
                throw new XmppForwarderException(
                    $"HTTP {(int)response.StatusCode}: {content}",
                    (int)response.StatusCode);
            }
        }

        try
        {
            var result = JsonSerializer.Deserialize<UserInfoResponse>(content, _jsonOptions);
            return result ?? throw new XmppForwarderException("Received null response from server");
        }
        catch (JsonException ex)
        {
            throw new XmppForwarderException("Failed to parse user info response", ex);
        }
    }

    private ConnectedUsersResponse ProcessConnectedUsersResponse(RestResponse response)
    {
        var content = response.Content ?? string.Empty;

        if (!response.IsSuccessful)
        {
            try
            {
                var errorResponse = JsonSerializer.Deserialize<ErrorResponse>(content, _jsonOptions);
                throw new XmppForwarderException(
                    errorResponse?.Error ?? "Unknown API error",
                    (int)response.StatusCode,
                    errorResponse?.Details);
            }
            catch (JsonException)
            {
                throw new XmppForwarderException(
                    $"HTTP {(int)response.StatusCode}: {content}",
                    (int)response.StatusCode);
            }
        }

        try
        {
            var result = JsonSerializer.Deserialize<ConnectedUsersResponse>(content, _jsonOptions);
            return result ?? throw new XmppForwarderException("Received null response from server");
        }
        catch (JsonException ex)
        {
            throw new XmppForwarderException("Failed to parse connected users response", ex);
        }
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposed && disposing)
        {
            _restClient?.Dispose();
            _disposed = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
}