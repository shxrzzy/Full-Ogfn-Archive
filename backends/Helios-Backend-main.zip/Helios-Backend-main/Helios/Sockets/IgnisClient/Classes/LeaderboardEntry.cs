namespace Helios.Sockets.IgnisClient.Classes;

public class LeaderboardEntry
{
    public string Username { get; set; }
    public int Hype { get; set; }
    public string AccountId { get; set; }
}
