using Helios.Sockets.IgnisClient.Classes.Interfaces;
using System.Collections.Concurrent;

namespace Helios.Sockets.IgnisClient.Classes;

public class RateLimiter : IRateLimiter, IDisposable
{
    private readonly ConcurrentDictionary<Guid, Queue<DateTime>> _clientMessageTimes = new();
    private readonly Timer _cleanupTimer;
    private readonly int _maxMessagesPerMinute;
    private bool _disposed = false;

    public RateLimiter(int maxMessagesPerMinute = 60)
    {
        _maxMessagesPerMinute = maxMessagesPerMinute;
        _cleanupTimer = new Timer(_ => Cleanup(), null, TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(1));
    }

    public bool IsAllowed(Guid clientId)
    {
        if (_disposed) return false;

        var now = DateTime.UtcNow;
        var cutoff = now.AddMinutes(-1);

        var messageQueue = _clientMessageTimes.GetOrAdd(clientId, _ => new Queue<DateTime>());

        lock (messageQueue)
        {
            while (messageQueue.Count > 0 && messageQueue.Peek() <= cutoff)
            {
                messageQueue.Dequeue();
            }

            if (messageQueue.Count >= _maxMessagesPerMinute)
            {
                return false;
            }

            messageQueue.Enqueue(now);
            return true;
        }
    }

    public void Cleanup()
    {
        if (_disposed) return;

        var cutoff = DateTime.UtcNow.AddMinutes(-2);
        var clientsToRemove = new List<Guid>();

        foreach (var kvp in _clientMessageTimes)
        {
            var queue = kvp.Value;
            lock (queue)
            {
                while (queue.Count > 0 && queue.Peek() <= cutoff)
                {
                    queue.Dequeue();
                }

                if (queue.Count == 0)
                {
                    clientsToRemove.Add(kvp.Key);
                }
            }
        }

        foreach (var clientId in clientsToRemove)
        {
            _clientMessageTimes.TryRemove(clientId, out _);
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _cleanupTimer?.Dispose();
        _clientMessageTimes.Clear();
    }
}