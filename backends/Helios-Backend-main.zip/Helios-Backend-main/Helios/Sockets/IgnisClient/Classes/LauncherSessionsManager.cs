using Fleck;
using Helios.Configuration;
using Helios.Database.Tables.XMPP;
using Helios.Socket;
using Helios.Sockets.IgnisClient.Classes.Interfaces;
using Helios.Utilities;
using System.Collections.Concurrent;

namespace Helios.Sockets.IgnisClient.Classes;

public static class LauncherSessionsManager
{
    private static readonly SemaphoreSlim _sessionLock = new SemaphoreSlim(1, 1);

    public static async Task AddLauncherSession(LauncherSessions launcherSession, IWebSocketConnection socket)
    {
        if (socket == null)
            throw new ArgumentNullException(nameof(socket));

        if (launcherSession?.SocketId == null)
            throw new ArgumentNullException(nameof(launcherSession.SocketId));

        await _sessionLock.WaitAsync();
        try
        {
            var launcherRepo = Constants.repositoryPool.For<LauncherSessions>();

            if (!string.IsNullOrEmpty(launcherSession.AccountId))
            {
                var existingSession = await launcherRepo.FindByColumnAsync("accountid", launcherSession.AccountId);
                if (existingSession != null)
                {
                    Globals._socketConnections.Remove(existingSession.SocketId, out var oldSocket);
                    await launcherRepo.DeleteByColumnAsync("socketid", existingSession.SocketId);

                    if (oldSocket != null && oldSocket != socket)
                    {
                        try
                        {
                            oldSocket.Close();
                        }
                        catch (Exception ex)
                        {
                            Logger.Error($"Error closing old socket: {ex.Message}");
                        }
                    }
                }
            }

            await launcherRepo.SaveAsync(launcherSession).ConfigureAwait(false);

            if (!Globals._socketConnections.TryAdd(launcherSession.SocketId, socket))
            {
                Globals._socketConnections[launcherSession.SocketId] = socket;
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"Error in AddLauncherSession for SocketId {launcherSession?.SocketId}: {ex}");
            throw;
        }
        finally
        {
            _sessionLock.Release();
        }
    }

    public static async Task RemoveLauncherSession(Guid socketId)
    {
        await _sessionLock.WaitAsync();
        try
        {
            Globals._socketConnections.Remove(socketId, out var socket);

            var launcherRepo = Constants.repositoryPool.For<LauncherSessions>();
            bool deleted = await launcherRepo.DeleteByColumnAsync("socketid", socketId);

            if (!deleted)
            {
                Logger.Warn($"Failed to delete launcher session with SocketId {socketId}");
            }
            else
            {
                Logger.Info($"Successfully deleted launcher session with SocketId {socketId}");
            }

            if (socket != null)
            {
                try
                {
                    socket.Close();
                }
                catch (Exception ex)
                {
                    Logger.Debug($"Error closing socket during removal: {ex.Message}");
                }
            }
        }
        finally
        {
            _sessionLock.Release();
        }
    }

    public static async Task RemoveLauncherSession(string accountId)
    {
        if (string.IsNullOrEmpty(accountId))
            return;

        await _sessionLock.WaitAsync();
        try
        {
            var launcherRepo = Constants.repositoryPool.For<LauncherSessions>();
            var session = await launcherRepo.FindByColumnAsync("accountid", accountId);

            if (session == null)
            {
                Logger.Error($"Launcher session with AccountId {accountId} is null");
                return;
            }

            Globals._socketConnections.Remove(session.SocketId, out var socket);

            bool deleted = await launcherRepo.DeleteByColumnAsync("accountid", session.AccountId);
            if (!deleted)
            {
                Logger.Warn($"Failed to delete launcher session with AccountId {session.AccountId}");
            }
            else
            {
                Logger.Info($"Successfully deleted launcher session with AccountId {session.AccountId}");
            }

            if (socket != null)
            {
                try
                {
                    socket.Close();
                }
                catch (Exception ex)
                {
                    Logger.Debug($"Error closing socket during removal: {ex.Message}");
                }
            }
        }
        finally
        {
            _sessionLock.Release();
        }
    }

    public static async Task<(bool success, LauncherSessions? session)> TryGetLauncherSessionAsync(Guid socketId)
    {
        var launcherRepo = Constants.repositoryPool.For<LauncherSessions>();
        var session = await launcherRepo.FindByColumnAsync("socketid", socketId);
        return (session != null, session);
    }

    public static async Task<(bool success, LauncherSessions? session)> TryGetLauncherSessionAsync(string accountId)
    {
        if (string.IsNullOrEmpty(accountId))
            return (false, null);

        var launcherRepo = Constants.repositoryPool.For<LauncherSessions>();
        var session = await launcherRepo.FindByColumnAsync("accountid", accountId);
        return (session != null, session);
    }

    public static async Task<List<LauncherSessions>> ListAllLauncherSessions()
    {
        var launcherRepo = Constants.repositoryPool.For<LauncherSessions>();
        return await launcherRepo.FindAllByTableAsync();
    }

    public static async Task UpdateLauncherSession(LauncherSessions session, IWebSocketConnection socket)
    {
        if (session?.SocketId == null)
            throw new ArgumentNullException(nameof(session));
        if (socket == null)
            throw new ArgumentNullException(nameof(socket));

        await _sessionLock.WaitAsync();
        try
        {
            var launcherRepo = Constants.repositoryPool.For<LauncherSessions>();
            await launcherRepo.UpdateAsync(session);

            var connectionSnapshot = Globals._socketConnections.ToList();
            var connectionsToRemove = new List<Guid>();

            foreach (var kvp in connectionSnapshot)
            {
                if (kvp.Key != session.SocketId)
                {
                    try
                    {
                        var oldSession = await launcherRepo.FindByColumnAsync("socketid", kvp.Key);
                        if (oldSession?.AccountId == session.AccountId)
                        {
                            connectionsToRemove.Add(kvp.Key);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.Debug($"Error checking old launcher connection: {ex.Message}");
                    }
                }
            }

            foreach (var socketIdToRemove in connectionsToRemove)
            {
                Logger.Info($"Removing old launcher session connection: {socketIdToRemove}");
                if (Globals._socketConnections.Remove(socketIdToRemove, out var oldSocket))
                {
                    try
                    {
                        oldSocket?.Close();
                    }
                    catch (Exception ex)
                    {
                        Logger.Debug($"Error closing old connection: {ex.Message}");
                    }
                }
            }

            Globals._socketConnections[session.SocketId] = socket;
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to update launcher session {session.SocketId}: {ex.Message}");
            throw;
        }
        finally
        {
            _sessionLock.Release();
        }
    }
}