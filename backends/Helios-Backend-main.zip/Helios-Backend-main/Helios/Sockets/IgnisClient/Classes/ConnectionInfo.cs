using Fleck;
using Newtonsoft.Json;

namespace Helios.Sockets.IgnisClient.Classes;

public class ConnectionInfo
{
    public IWebSocketConnection Socket { get; set; }
    public DateTime LastActivity { get; set; }
    public DateTime ConnectedAt { get; set; }
    public int FailedSendAttempts { get; set; }
    public bool IsHealthy => FailedSendAttempts < 3 && Socket?.IsAvailable == true;
}
