using Fleck;
using Helios.Configuration;
using Helios.Controllers.Launcher.Launcher;
using Helios.Database.Tables.XMPP;
using Helios.Sockets.IgnisClient.Classes;
using Helios.Utilities;
using Helios.Utilities.Tokens;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Helios.Sockets.IgnisClient;

public static class ClientValidation
{
    public static async Task<bool> ValidateTokenFromQuery(IWebSocketConnection socket)
    {
        if (socket?.ConnectionInfo == null)
        {
            Logger.Error("Socket or ConnectionInfo is null");
            return false;
        }

        var socketId = socket.ConnectionInfo.Id;

        try
        {
            var requestPath = socket.ConnectionInfo.Path;

            string? token = null;
            if (!string.IsNullOrEmpty(requestPath))
            {
                var queryStart = requestPath.IndexOf('?');
                if (queryStart >= 0 && queryStart < requestPath.Length - 1)
                {
                    var queryString = requestPath.Substring(queryStart + 1);
                    var queryParams = ParseQueryString(queryString);
                    queryParams.TryGetValue("token", out token);
                }
            }

            if (string.IsNullOrEmpty(token))
            {
                Logger.Error($"No token provided for client {socketId}");
                return false;
            }

            var decodedToken = TokenGenerator.DecodeTokenIDK(token);
            if (decodedToken == null)
            {
                Logger.Error($"Invalid token format for client {socketId}");
                return false;
            }

            string accountId = decodedToken.Id ?? string.Empty;
            if (string.IsNullOrEmpty(accountId))
            {
                Logger.Error($"No account ID found in token for client {socketId}");
                return false;
            }

            string secret = decodedToken.Secret ?? string.Empty;
            if (string.IsNullOrEmpty(decodedToken.Secret))
            {
                if (!string.IsNullOrEmpty(accountId) && !string.IsNullOrEmpty(decodedToken.Discord?.Id))
                {
                    decodedToken.Secret = LauncherController.GenerateAccountSecret(accountId, decodedToken.Discord.Id);
                    secret = decodedToken.Secret ?? string.Empty;
                }

                if (string.IsNullOrEmpty(secret))
                {
                    Logger.Error($"Unable to generate or retrieve secret for client {socketId}");
                    return false;
                }
            }

            var existingLaunchers = await LauncherSessionsManager.ListAllLauncherSessions();
            var existingLauncher = existingLaunchers?.FirstOrDefault(l => l?.AccountId == accountId);

            if (existingLauncher != null)
            {
                if (existingLauncher.SocketId != socketId)
                {
                    existingLauncher.SocketId = socketId;
                    existingLauncher.Token = token;
                    existingLauncher.Secret = secret;

                    try
                    {
                        await LauncherSessionsManager.UpdateLauncherSession(existingLauncher, socket);
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Failed to update existing launcher session for account {accountId}: {ex.Message}");
                        return false;
                    }
                }
                return true;
            }

            if (socketId == Guid.Empty)
            {
                Logger.Error($"Invalid socket ID (empty GUID) for client");
                return false;
            }

            var newLauncherSession = new LauncherSessions
            {
                SocketId = socketId,
                Protocol = "launcher",
                Token = token,
                AccountId = accountId,
                Secret = secret,
                ConnectedAt = DateTime.UtcNow
            };

            try
            {
                await LauncherSessionsManager.AddLauncherSession(newLauncherSession, socket);
                return true;
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to add new launcher session for account {accountId}: {ex.Message}");
                return false;
            }
        }
        catch (ArgumentException ex)
        {
            Logger.Error($"Invalid argument during token validation for client {socketId}: {ex.Message}");
            return false;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error validating token for client {socketId}: {ex}");
            return false;
        }
    }

    private static Dictionary<string, string> ParseQueryString(string queryString)
    {
        var queryParams = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        if (string.IsNullOrEmpty(queryString))
            return queryParams;

        try
        {
            var pairs = queryString.Split('&', StringSplitOptions.RemoveEmptyEntries);

            foreach (var pair in pairs)
            {
                if (string.IsNullOrWhiteSpace(pair))
                    continue;

                var keyValue = pair.Split('=', 2);
                if (keyValue.Length == 2)
                {
                    try
                    {
                        var key = Uri.UnescapeDataString(keyValue[0]);
                        var value = Uri.UnescapeDataString(keyValue[1]);
                        if (!string.IsNullOrEmpty(key))
                        {
                            queryParams[key] = value;
                        }
                    }
                    catch (UriFormatException ex)
                    {
                        Logger.Error($"Failed to parse query parameter: {pair}, Error: {ex.Message}");
                        continue;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.Debug($"Error parsing query string: {ex.Message}");
        }

        return queryParams;
    }
}