using Fleck;
using Helios.Classes.GameSessions;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Fortnite;
using Helios.Database.Tables.Stats;
using Helios.Database.Tables.Tournaments;
using Helios.Database.Tables.XMPP;
using Helios.Managers;
using Helios.Sockets.IgnisClient.Classes;
using Helios.Sockets.IgnisClient.Classes.Message;
using Helios.Utilities;
using Helios.Utilities.Caching;
using Helios.Utilities.Tokens;
using Newtonsoft.Json;

namespace Helios.Sockets.IgnisClient;

public class MessageHandler
{
    private readonly ConnectionManager _connectionManager;
    private readonly CacheManager _cache = new();

    public MessageHandler(ConnectionManager connectionManager)
    {
        _connectionManager = connectionManager;
    }

    public async Task HandleMessageAsync(IWebSocketConnection socket, string message, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(message) || message.Length > 1024 * 1024)
        {
            await SendError(socket.ConnectionInfo.Id, "Invalid message");
            return;
        }

        try
        {
            var msg = JsonConvert.DeserializeObject<IncomingWebSocketMessage>(message);
            if (msg?.Type == null)
            {
                await SendError(socket.ConnectionInfo.Id, "Invalid format");
                return;
            }

            var (success, client) = await LauncherSessionsManager.TryGetLauncherSessionAsync(socket.ConnectionInfo.Id);
            if (!success || client == null)
            {
                await SendError(socket.ConnectionInfo.Id, "Session not found");
                return;
            }

            using var cts = new CancellationTokenSource(30000);
            await ProcessMessage(socket, client, msg, cts.Token);
        }
        catch (Exception ex)
        {
            Logger.Error($"Message error from {socket.ConnectionInfo.Id}: {ex}");
            await SendError(socket.ConnectionInfo.Id, "Processing failed");
        }
    }

    private async Task ProcessMessage(IWebSocketConnection socket, LauncherSessions client, IncomingWebSocketMessage msg, CancellationToken ct)
    {
        switch (msg.Type.ToLowerInvariant())
        {
            case "ping":
                await SendResponse(socket.ConnectionInfo.Id, "pong", null, msg.MessageId);
                break;
            case "request_user":
                await HandleUserRequest(socket, client, msg);
                break;
            case "request_storefront":
                await HandleStorefrontRequest(socket, client, msg);
                break;
            case "request_leaderboard":
                await HandleLeaderboardRequest(socket, client, msg);
                break;
            case "request_servers":
                await HandleServersRequest(socket, client, msg);
                break;
            case "subscribe_servers":
                await HandleServerSubscription(socket, client, msg);
                break;
            case "unsubscribe_servers":
                await HandleServerUnsubscription(socket, client, msg);
                break;
            default:
                await SendError(socket.ConnectionInfo.Id, $"Unknown type: {msg.Type}", msg.MessageId);
                break;
        }
    }

    private async Task HandleUserRequest(IWebSocketConnection socket, LauncherSessions client, IncomingWebSocketMessage msg)
    {
        if (string.IsNullOrEmpty(client.Token))
        {
            await SendError(socket.ConnectionInfo.Id, "No token", msg.MessageId);
            return;
        }

        var token = TokenGenerator.DecodeTokenIDK(client.Token);
        if (token == null)
        {
            await SendError(socket.ConnectionInfo.Id, "Invalid token", msg.MessageId);
            return;
        }

        var user = await Constants.repositoryPool.For<User>().FindByColumnAsync("accountid", token.Id);
        if (user == null)
        {
            await SendError(socket.ConnectionInfo.Id, "User not found", msg.MessageId);
            return;
        }

        if (client.Protocol == "launcher")
        {
            client.AccountId = token.Id;
            client.Secret = token.Secret;
            client.DisplayName = token.Discord?.DisplayName ?? "Unknown";
            client.IsAuthenticated = true;
            await LauncherSessionsManager.UpdateLauncherSession(client, socket);
        }

        await SendResponse(socket.ConnectionInfo.Id, "user", token, msg.MessageId);
    }

    private async Task HandleStorefrontRequest(IWebSocketConnection socket, LauncherSessions client, IncomingWebSocketMessage msg)
    {
        if (!await ValidateAuth(socket.ConnectionInfo.Id, client, msg.MessageId)) return;

        var catalog = Constants.repositoryPool.For<Catalog>();
        var daily = await StorefrontManager.ExtractItems(catalog, "BRDailyStorefront");
        var featured = await StorefrontManager.ExtractItems(catalog, "BRWeeklyStorefront");

        await SendResponse(socket.ConnectionInfo.Id, "storefront", new { Daily = daily, Featured = featured }, msg.MessageId);
    }

    private async Task HandleLeaderboardRequest(IWebSocketConnection socket, LauncherSessions client, IncomingWebSocketMessage msg)
    {
        if (!await ValidateAuth(socket.ConnectionInfo.Id, client, msg.MessageId)) return;

        var leaderboard = await _cache.GetLeaderboardAsync();
        if (leaderboard?.Any() != true)
        {
            await SendError(socket.ConnectionInfo.Id, "No leaderboard data", msg.MessageId);
            return;
        }

        var payload = new
        {
            data = leaderboard,
            lastUpdated = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            totalEntries = leaderboard.Count
        };

        await SendResponse(socket.ConnectionInfo.Id, "leaderboard", payload, msg.MessageId);
    }

    private async Task HandleServersRequest(IWebSocketConnection socket, LauncherSessions client, IncomingWebSocketMessage msg)
    {
        try
        {
            var sessions = HeliosFastCache.GetByPrefix<MatchmakingSession>("matchmaking_session_")?.Values
                ?.Where(s => s.IsDedicated &&
                             !string.IsNullOrEmpty(s.SessionId) &&
                             s.Attributes?.ContainsKey("PLAYLISTNAME_s") == true &&
                             s.MaxPublicPlayers > 0 &&
                             (s.PublicPlayers?.Count ?? 0) > 0)
                .ToList() ?? new List<MatchmakingSession>();

            var data = sessions.Select(s => new
            {
                Players = Math.Max(0, s.PublicPlayers?.Count ?? 0) - 1,
                SessionId = s.SessionId,
                Playlist = s.Attributes?.GetValueOrDefault("PLAYLISTNAME_s")?.ToString() ?? "",
                CapPlayers = s.MaxPublicPlayers > 0 ? s.MaxPublicPlayers : 50,
                Started = s.Started,
                Region = s.Attributes?.GetValueOrDefault("REGION_s")?.ToString() ?? ""
            }).OrderByDescending(s => s.Players);

            await SendResponse(socket.ConnectionInfo.Id, "servers", new { data }, msg.MessageId);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error handling servers request: {ex.Message}");
            await SendResponse(socket.ConnectionInfo.Id, "servers", new { data = new object[0] }, msg.MessageId);
        }
    }

    private async Task HandleServerSubscription(IWebSocketConnection socket, LauncherSessions client, IncomingWebSocketMessage msg)
    {
        if (!await ValidateAuth(socket.ConnectionInfo.Id, client, msg.MessageId)) return;

        try
        {
            client.SubscribedToServers = true;
            await LauncherSessionsManager.UpdateLauncherSession(client, socket);

            await SendResponse(socket.ConnectionInfo.Id, "servers_subscribed", new { subscribed = true }, msg.MessageId);
            Logger.Info($"Client {socket.ConnectionInfo.Id} subscribed to server updates");
        }
        catch (Exception ex)
        {
            Logger.Error($"Error subscribing to servers: {ex.Message}");
            await SendError(socket.ConnectionInfo.Id, "Subscription failed", msg.MessageId);
        }
    }

    private async Task HandleServerUnsubscription(IWebSocketConnection socket, LauncherSessions client, IncomingWebSocketMessage msg)
    {
        if (!await ValidateAuth(socket.ConnectionInfo.Id, client, msg.MessageId)) return;

        try
        {
            client.SubscribedToServers = false;
            await LauncherSessionsManager.UpdateLauncherSession(client, socket);

            await SendResponse(socket.ConnectionInfo.Id, "servers_unsubscribed", new { subscribed = false }, msg.MessageId);
            Logger.Info($"Client {socket.ConnectionInfo.Id} unsubscribed from server updates");
        }
        catch (Exception ex)
        {
            Logger.Error($"Error unsubscribing from servers: {ex.Message}");
            await SendError(socket.ConnectionInfo.Id, "Unsubscription failed", msg.MessageId);
        }
    }

    private async Task<bool> ValidateAuth(Guid connectionId, LauncherSessions client, string? messageId)
    {
        if (string.IsNullOrEmpty(client.Token))
        {
            await SendError(connectionId, "No token", messageId);
            return false;
        }

        var token = TokenGenerator.DecodeTokenIDK(client.Token);
        if (token == null)
        {
            await SendError(connectionId, "Invalid token", messageId);
            return false;
        }

        var user = await Constants.repositoryPool.For<User>().FindByColumnAsync("accountid", token.Id);
        if (user == null)
        {
            await SendError(connectionId, "User not found", messageId);
            return false;
        }

        return true;
    }

    private async Task SendResponse(Guid connectionId, string type, object? payload, string? messageId)
    {
        var response = new
        {
            type,
            timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            payload,
            id = messageId
        };

        await _connectionManager.SendToClient(connectionId, JsonConvert.SerializeObject(response));
    }

    private async Task SendError(Guid connectionId, string message, string? messageId = null)
    {
        var error = new
        {
            type = "error",
            message,
            timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            id = messageId
        };

        await _connectionManager.SendToClient(connectionId, JsonConvert.SerializeObject(error));
    }
}