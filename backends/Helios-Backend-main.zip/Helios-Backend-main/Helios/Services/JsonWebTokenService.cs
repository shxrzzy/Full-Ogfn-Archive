﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.Collections.Generic;
using System.Text.Json;
using Helios.Configuration;

namespace Helios.Services;

public class JsonWebTokenService
{
    public static string GenerateJwt(IDictionary<string, object> payload)
    {
        string secret = Constants.config.JWTClientSecret;
        
        if (string.IsNullOrEmpty(secret))
        {
            throw new InvalidOperationException("ClientSecret is not set in the configuration.");
        }

        if (payload == null || payload.Count == 0)
        {
            throw new ArgumentException("Payload cannot be null or empty.", nameof(payload));
        }

        var header = new JwtHeader(new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret)),
            SecurityAlgorithms.HmacSha256)
        );

        var claims = new List<System.Security.Claims.Claim>();

        foreach (var kvp in payload)
        {
            if (kvp.Key == null)
            {
                throw new ArgumentException("Payload contains a null key.", nameof(payload));
            }

            if (kvp.Value == null)
            {
                throw new ArgumentException($"Payload key '{kvp.Key}' has a null value.", nameof(payload));
            }

            string claimValue;
            if (kvp.Value is string stringValue)
            {
                claimValue = stringValue;
            }
            else if (kvp.Value.GetType().IsPrimitive || kvp.Value is DateTime || kvp.Value is Guid)
            {
                claimValue = kvp.Value.ToString();
            }
            else
            {
                claimValue = JsonSerializer.Serialize(kvp.Value);
            }

            claims.Add(new System.Security.Claims.Claim(kvp.Key, claimValue));
        }
        
        var payloadToken = new JwtPayload(
            issuer: "helios.services.jwtservice.issuer",
            audience: "helios.services.jwtservice.audience",
            claims: claims,
            notBefore: DateTime.UtcNow,
            expires: DateTime.UtcNow.AddHours(1)
        );

        var token = new JwtSecurityToken(header, payloadToken);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
    
    public static T DecodeJwt<T>(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
        {
            throw new ArgumentException("Token cannot be null or empty.", nameof(token));
        }

        var handler = new JwtSecurityTokenHandler();

        if (!handler.CanReadToken(token))
        {
            throw new ArgumentException("The token is not in a valid JWT format.", nameof(token));
        }

        var jwtToken = handler.ReadJwtToken(token);

        var claims = new Dictionary<string, object>();

        foreach (var claim in jwtToken.Claims)
        {
            try
            {
                claims[claim.Type] = JsonSerializer.Deserialize<object>(claim.Value);
            }
            catch
            {
                claims[claim.Type] = claim.Value;
            }
        }

        var json = JsonSerializer.Serialize(claims);
        return JsonSerializer.Deserialize<T>(json);
    }

    public static string GenerateJwt(IDictionary<string, object> payload, string secret)
    {
        if (string.IsNullOrEmpty(secret))
        {
            throw new InvalidOperationException("ClientSecret is not set in the configuration.");
        }

        if (payload == null || payload.Count == 0)
        {
            throw new ArgumentException("Payload cannot be null or empty.", nameof(payload));
        }

        var header = new JwtHeader(new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret)),
            SecurityAlgorithms.HmacSha256)
        );

        var claims = new List<System.Security.Claims.Claim>();

        foreach (var kvp in payload)
        {
            if (kvp.Key == null)
            {
                throw new ArgumentException("Payload contains a null key.", nameof(payload));
            }

            if (kvp.Value == null)
            {
                throw new ArgumentException($"Payload key '{kvp.Key}' has a null value.", nameof(payload));
            }

            claims.Add(new System.Security.Claims.Claim(kvp.Key, kvp.Value.ToString()));
        }

        var payloadToken = new JwtPayload(
            issuer: "fortmp.services.backend.utilities.jwtservice.issuer",
            audience: "fortmp.services.backend.utilities.jwtservice.audience",
            claims: claims,
            notBefore: DateTime.UtcNow,
            expires: DateTime.UtcNow.AddHours(1)
        );

        var token = new JwtSecurityToken(header, payloadToken);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}