﻿using Discord;
using Discord.WebSocket;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Account;
using Helios.Interfaces;
using Helios.Utilities;
using Helios.Utilities.Profile;
using System.Collections.Concurrent;

namespace Helios.Discord.Commands;

public class GrantAllCommand : ISlashCommand
{
    public string Name => "grantall";
    public string Description => "Grants a user cosmetics.";

    private static readonly ConcurrentDictionary<ulong, DateTime> _ongoingOperations = new();

    public List<SlashCommandOptionBuilder> Options => new List<SlashCommandOptionBuilder>
        {
            new SlashCommandOptionBuilder()
                .WithName("user")
                .WithDescription("The user to grant cosmetics to.")
                .WithType(ApplicationCommandOptionType.User)
                .WithRequired(true),
            new SlashCommandOptionBuilder()
                .WithName("type")
                .WithDescription("The type of cosmetics to grant.")
                .WithType(ApplicationCommandOptionType.String)
                .WithRequired(true)
                .AddChoice("Full Locker", "full_locker")
                .AddChoice("OG Donator Rewards", "og_donator")
                .AddChoice("Crystal Booster Rewards", "crystal_booster")
        };

    public async Task BuildAsync(SocketSlashCommand command)
    {
        await command.DeferAsync(true);

        var socketGuildUser = (SocketGuildUser)command.User;
        var targetUser = (SocketUser)command.Data.Options.First().Value;
        var grantType = (string)command.Data.Options.ElementAt(1).Value;

        var allowedRoles = new[] { "Owner", "Co Owner", "Admin", "Manager", "Developer", "Media Manager", "Founder", "Head Admin" };
        bool hasPermission = socketGuildUser.GuildPermissions.BanMembers ||
                           socketGuildUser.Roles.Any(r => allowedRoles.Contains(r.Name));

        if (!hasPermission)
        {
            await command.FollowupAsync(embed: new EmbedBuilder()
                .WithTitle("Permission Denied")
                .WithDescription("You don't have permission to use this command.")
                .WithColor(Color.Red)
                .Build());
            return;
        }

        if (_ongoingOperations.ContainsKey(targetUser.Id))
        {
            await command.FollowupAsync(embed: new EmbedBuilder()
                .WithTitle("Already Processing")
                .WithDescription($"Already granting cosmetics to <@{targetUser.Id}>.")
                .WithColor(Color.Orange)
                .Build());
            return;
        }

        var userRepository = Constants.repositoryPool.For<User>();
        var registeredUser = await userRepository.FindByColumnAsync("discordid", targetUser.Id.ToString());

        if (registeredUser == null)
        {
            await command.FollowupAsync(embed: new EmbedBuilder()
                .WithTitle("Account Not Found")
                .WithDescription($"<@{targetUser.Id}> doesn't have a registered account.")
                .WithColor(Color.Red)
                .Build());
            return;
        }

        _ongoingOperations[targetUser.Id] = DateTime.UtcNow;

        _ = Task.Run(async () => await ProcessGrant(command, registeredUser, targetUser, grantType));

        var grantTypeName = grantType switch
        {
            "full_locker" => "Full Locker",
            "og_donator" => "OG Donator Rewards",
            "crystal_booster" => "Crystal Booster Rewards",
            _ => "Unknown"
        };

        await command.FollowupAsync(embed: new EmbedBuilder()
            .WithTitle("Processing")
            .WithDescription($"Granting {grantTypeName} to <@{targetUser.Id}>...")
            .WithColor(Color.Gold)
            .Build());
    }

    private async Task ProcessGrant(SocketSlashCommand command, User registeredUser, SocketUser targetUser, string grantType)
    {
        bool grantSuccessful = false;
        bool profileUpdateFailed = false;

        try
        {
            switch (grantType)
            {
                case "full_locker":
                    await ProfileItemGranting.GrantAll(registeredUser.AccountId);
                    break;
                case "og_donator":
                    await ProfileItemGranting.GrantOgDonatorItems(registeredUser.AccountId);
                    break;
                case "crystal_booster":
                    await ProfileItemGranting.GrantBoosterItems(registeredUser.AccountId);
                    break;
                default:
                    throw new ArgumentException($"Unknown grant type: {grantType}");
            }

            grantSuccessful = true;

            try
            {
                await SendProfileUpdateRequest.UpdateAsync(registeredUser.AccountId, registeredUser.Username);
            }
            catch (Exception profileEx)
            {
                profileUpdateFailed = true;
                Logger.Warn($"Profile update failed for {registeredUser.AccountId} (user likely offline): {profileEx.Message}");
            }

            var grantTypeName = grantType switch
            {
                "full_locker" => "Full Locker",
                "og_donator" => "OG Donator Rewards",
                "crystal_booster" => "Crystal Booster Rewards",
                _ => "Unknown"
            };

            var description = $"Successfully granted {grantTypeName} to <@{targetUser.Id}>.";
            if (profileUpdateFailed)
            {
                description += "\n*Note: User was offline, items will appear after next login.*";
            }

            await command.FollowupAsync(embed: new EmbedBuilder()
                .WithTitle("Complete")
                .WithDescription(description)
                .WithColor(Color.Green)
                .Build());
        }
        catch (Exception ex)
        {
            if (grantSuccessful)
            {
                Logger.Warn($"Grant succeeded but profile update failed for {registeredUser.AccountId}: {ex}");
            }
            else
            {
                Logger.Error($"Grant failed for {registeredUser.AccountId}: {ex}");
            }

            await command.FollowupAsync(embed: new EmbedBuilder()
                .WithTitle("Failed")
                .WithDescription($"Failed to grant cosmetics to <@{targetUser.Id}>.")
                .WithColor(Color.Red)
                .Build());
        }
        finally
        {
            _ongoingOperations.TryRemove(targetUser.Id, out _);
        }
    }
}