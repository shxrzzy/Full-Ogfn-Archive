using Discord;
using Discord.WebSocket;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Account;
using Helios.Interfaces;
using Helios.Utilities;
using Helios.Utilities.Profile;
using System.Collections.Concurrent;

namespace Helios.Discord.Commands;

public class GrantVariantsCommand : ISlashCommand
{
    public string Name => "grantvariants";
    public string Description => "Grants missing variants to a user's cosmetics.";

    private static readonly ConcurrentDictionary<ulong, SemaphoreSlim> _userLocks = new();

    public List<SlashCommandOptionBuilder> Options => new List<SlashCommandOptionBuilder>
    {
        new SlashCommandOptionBuilder()
            .WithName("user")
            .WithDescription("The user to grant missing variants to.")
            .WithType(ApplicationCommandOptionType.User)
            .WithRequired(true)
    };

    public async Task BuildAsync(SocketSlashCommand command)
    {
        await command.DeferAsync(true);

        var socketGuildUser = (SocketGuildUser)command.User;
        var targetUser = (SocketUser)command.Data.Options.First().Value;

        var allowedRoles = new[] { "Owner", "Co Owner", "Admin", "Manager", "Developer", "Media Manager", "Founder", "Head Admin", "Lead Support" };
        bool hasPermission = socketGuildUser.GuildPermissions.BanMembers ||
                           socketGuildUser.Roles.Any(r => allowedRoles.Contains(r.Name));

        if (!hasPermission)
        {
            await command.FollowupAsync(embed: new EmbedBuilder()
                .WithTitle("Permission Denied")
                .WithDescription("You don't have permission to use this command.")
                .WithColor(Color.Red)
                .Build());
            return;
        }

        var userLock = _userLocks.GetOrAdd(targetUser.Id, _ => new SemaphoreSlim(1, 1));

        if (!await userLock.WaitAsync(0))
        {
            await command.FollowupAsync(embed: new EmbedBuilder()
                .WithTitle("Already Processing")
                .WithDescription($"Already granting variants to <@{targetUser.Id}>.")
                .WithColor(Color.Orange)
                .Build());
            return;
        }

        try
        {
            var userRepository = Constants.repositoryPool.For<User>();
            var registeredUser = await userRepository.FindByColumnAsync("discordid", targetUser.Id.ToString());

            if (registeredUser == null)
            {
                await command.FollowupAsync(embed: new EmbedBuilder()
                    .WithTitle("Account Not Found")
                    .WithDescription($"<@{targetUser.Id}> doesn't have a registered account.")
                    .WithColor(Color.Red)
                    .Build());
                return;
            }

            _ = Task.Run(async () =>
            {
                try
                {
                    await ProcessGrantSingleUser(command, registeredUser, targetUser);
                }
                catch (Exception ex)
                {
                    Logger.Error($"Grant variants failed for {registeredUser.AccountId}: {ex}");
                    await command.FollowupAsync(embed: new EmbedBuilder()
                        .WithTitle("Failed")
                        .WithDescription($"Failed to grant missing variants to <@{targetUser.Id}>.")
                        .WithColor(Color.Red)
                        .Build());
                }
                finally
                {
                    userLock.Release();
                    _userLocks.TryRemove(targetUser.Id, out _);
                }
            });

            await command.FollowupAsync(embed: new EmbedBuilder()
                .WithTitle("Processing")
                .WithDescription($"Granting missing variants to <@{targetUser.Id}>...")
                .WithColor(Color.Gold)
                .Build());
        }
        catch
        {
            userLock.Release();
            _userLocks.TryRemove(targetUser.Id, out _);
            throw;
        }
    }

    private async Task ProcessGrantSingleUser(SocketSlashCommand command, User registeredUser, SocketUser targetUser)
    {
        await ProfileItemGranting.GrantMissingVariants(registeredUser.AccountId);
        await SendProfileUpdateRequest.UpdateAsync(registeredUser.AccountId, registeredUser.Username);

        await command.FollowupAsync(embed: new EmbedBuilder()
            .WithTitle("Complete")
            .WithDescription($"Successfully granted missing variants to <@{targetUser.Id}>.")
            .WithColor(Color.Green)
            .Build());
    }
}