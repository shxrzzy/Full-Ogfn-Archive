﻿using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace Helios.Controllers.MCP;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/SetCosmeticLockerName")]
public class SetCosmeticLockerName : ControllerBase
{
    private static readonly JsonDocumentOptions JsonOptions = new() { AllowTrailingCommas = true };

    [HttpPost]
    [VerifyToken]
    public async Task<IActionResult> Init([FromRoute] string accountId, [FromQuery] string profileId)
    {
        try
        {
            if (string.IsNullOrEmpty(profileId) || string.IsNullOrEmpty(accountId))
                return MCPErrors.InvalidPayload.Apply(HttpContext);

            var userRepository = Constants.repositoryPool.For<User>();
            var profilesRepository = Constants.repositoryPool.For<Profiles>();
            var userTask = userRepository.FindAsync(new User { AccountId = accountId });
            var profileTask = profilesRepository.FindAsync(new Profiles { ProfileId = profileId, AccountId = accountId });

            JsonDocument json;
            try
            {
                using var memoryStream = new MemoryStream();
                await Request.Body.CopyToAsync(memoryStream);
                memoryStream.Position = 0;
                json = JsonDocument.Parse(memoryStream, JsonOptions);
            }
            catch (JsonException)
            {
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            var root = json.RootElement;

            if (!root.TryGetProperty("lockerItem", out var lockerItemProperty) ||
                !root.TryGetProperty("name", out var lockerNameProperty))
                return MCPErrors.InvalidPayload.Apply(HttpContext);

            string lockerItemId = lockerItemProperty.GetString();
            string newName = lockerNameProperty.GetString();

            if (string.IsNullOrEmpty(lockerItemId) || string.IsNullOrEmpty(newName))
                return MCPErrors.InvalidPayload.Apply(HttpContext);

            var user = await userTask;
            var profile = await profileTask;

            if (user is null || profile is null)
                return AccountErrors.AccountNotFound(accountId).Apply(HttpContext);

            var profileItemsRepository = Constants.repositoryPool.For<Items>();
            var lockerItem = await profileItemsRepository.FindAsync(new Items
            {
                ProfileId = profileId,
                AccountId = accountId,
                TemplateId = lockerItemId
            });

            var profileChanges = new List<object>();
            var updateTasks = new List<Task>();
            bool hasChanges = false;

            if (lockerItem?.Value != null)
            {
                var lockerItemNode = JsonNode.Parse(lockerItem.Value.ToString());

                if (lockerItemNode?["locker_name"] != null)
                {
                    lockerItemNode["locker_name"] = newName;
                    lockerItem.Value = lockerItemNode.ToJsonString();
                    updateTasks.Add(profileItemsRepository.UpdateAsync(lockerItem));

                    profileChanges.Add(new
                    {
                        changeType = "itemAttrChanged",
                        itemId = lockerItemId,
                        attributeName = "locker_name",
                        attributeValue = newName
                    });

                    hasChanges = true;
                }
            }

            if (hasChanges)
            {
                profile.Revision++;
                updateTasks.Add(ProfileManager.UpdateProfileAsync(profile));
                await Task.WhenAll(updateTasks);
            }

            return Ok(ProfileResponseManager.Generate(profile, profileChanges, profileId));
        }
        catch (Exception ex)
        {
            Logger.Error($"An error occurred in SetCosmeticLockerName: {ex.Message}", ex);
            return InternalErrors.ServerError
                .WithMessage($"An error occurred while processing the request: {ex.Message}")
                .Apply(HttpContext);
        }
    }
}