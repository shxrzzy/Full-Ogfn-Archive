using System.Buffers;
using System.Text.Json;
using System.Threading.Tasks;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Database.Tables.Tournaments;
using Helios.Managers;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace Helios.Controllers.MCP.Tournaments;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{accountId}/dedicated_server/SendPayoutRewards")]
public class SendPayoutRewards : ControllerBase
{
    private static readonly JsonDocumentOptions JsonOptions = new() { AllowTrailingCommas = true };

    [HttpPost]
    //[VerifyToken]
    public async Task<IActionResult> Init([FromRoute] string accountId, [FromQuery] string profileId)
    {
        var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
        if (apiKey != Constants.ValidApiKey)
            return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);

        if (profileId is null || accountId is null || profileId != "athena")
            return MCPErrors.InvalidPayload.Apply(HttpContext);

        return NoContent();
    }
}