using System.Buffers;
using System.Text.Json;
using System.Threading.Tasks;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Database.Tables.Tournaments;
using Helios.Managers;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace Helios.Controllers.MCP.Tournaments;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{accountId}/dedicated_server/SendEventMatchResults")]
public class SendEventMatchResults : ControllerBase
{
    private static readonly JsonDocumentOptions JsonOptions = new() { AllowTrailingCommas = true };

    [HttpPost]
    //[VerifyToken]
    public async Task<IActionResult> Init([FromRoute] string accountId, [FromQuery] string profileId)
    {
        var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
        if (apiKey != Constants.ValidApiKey)
            return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);

        if (profileId is null || accountId is null || profileId != "athena")
            return MCPErrors.InvalidPayload.Apply(HttpContext);

        if (Request.ContentLength == null || Request.ContentLength <= 0)
            return MCPErrors.InvalidPayload.WithMessage("Request body cannot be empty.").Apply(HttpContext);

        if (Request.ContentLength > 1024 * 1024)
            return MCPErrors.InvalidPayload.WithMessage("Request body too large.").Apply(HttpContext);

        var contentType = Request.ContentType;
        if (string.IsNullOrEmpty(contentType) || !contentType.Contains("application/json"))
            return MCPErrors.InvalidPayload.WithMessage("Content-Type must be application/json.").Apply(HttpContext);

        JsonDocument json;
        try
        {
            if (Request.ContentLength.HasValue && Request.ContentLength.Value < 4096)
            {
                byte[] buffer = ArrayPool<byte>.Shared.Rent((int)Request.ContentLength.Value);
                try
                {
                    int bytesRead = await Request.Body.ReadAsync(buffer, 0, (int)Request.ContentLength.Value);
                    if (bytesRead == 0)
                        return MCPErrors.InvalidPayload.WithMessage("Empty request body.").Apply(HttpContext);

                    json = JsonDocument.Parse(buffer.AsMemory(0, bytesRead), JsonOptions);
                }
                finally
                {
                    ArrayPool<byte>.Shared.Return(buffer);
                }
            }
            else
            {
                using var memoryStream = new MemoryStream();
                await Request.Body.CopyToAsync(memoryStream);
                if (memoryStream.Length == 0)
                    return MCPErrors.InvalidPayload.WithMessage("Empty request body.").Apply(HttpContext);

                memoryStream.Position = 0;
                json = JsonDocument.Parse(memoryStream, JsonOptions);
            }
        }
        catch (JsonException ex)
        {
            return MCPErrors.InvalidPayload.WithMessage($"Invalid JSON format: {ex.Message}").Apply(HttpContext);
        }

        try
        {
            var root = json.RootElement;
            if (!root.TryGetProperty("eventId", out var eventIdProp) ||
                !root.TryGetProperty("matchHistory", out var matchHistoryProp) ||
                !root.TryGetProperty("teammateIds", out var teammateIdsProp) ||
                !root.TryGetProperty("eliminations", out var eliminationsProp) ||
                !root.TryGetProperty("placement", out var placementProp) ||
                !root.TryGetProperty("pointsEarned", out var pointsEarnedProp) ||
                !root.TryGetProperty("sessionId", out var sessionIdProp) ||
                !root.TryGetProperty("timeAlive", out var timeAliveProp))
            {
                return MCPErrors.InvalidPayload.WithMessage("Missing required fields").Apply(HttpContext);
            }

            string eventId = eventIdProp.GetString();
            if (string.IsNullOrEmpty(eventId))
                return MCPErrors.InvalidPayload.WithMessage("EventId cannot be empty.").Apply(HttpContext);

            var matches = matchHistoryProp.EnumerateArray().Select(m => m.GetString()).Where(m => !string.IsNullOrEmpty(m)).ToList();
            if (matches.Count == 0)
                return MCPErrors.InvalidPayload.WithMessage("Match history cannot be empty.").Apply(HttpContext);

            var teammates = teammateIdsProp.EnumerateArray().Select(x => x.GetString()).Where(x => !string.IsNullOrEmpty(x)).ToList();
            int eliminations = eliminationsProp.GetInt32();
            int placement = placementProp.GetInt32();
            int pointsEarned = pointsEarnedProp.GetInt32();
            int timeAlive = timeAliveProp.GetInt32();

            string sessionId = sessionIdProp.GetString();
            if (string.IsNullOrEmpty(sessionId))
                return MCPErrors.InvalidPayload.WithMessage("SessionId cannot be empty.").Apply(HttpContext);

            var userRepository = Constants.repositoryPool.For<User>();
            var dedicatedServerRepository = Constants.repositoryPool.For<TournamentDedicatedServer>();
            var tournamentHistoryRepository = Constants.repositoryPool.For<TournamentHistory>();

            var user = await userRepository.FindAsync(new User { AccountId = accountId });
            if (user == null) return AccountErrors.AccountNotFound(accountId).Apply(HttpContext);

            var dedicatedPlayer = await dedicatedServerRepository.FindByColumnAsync("accountId", accountId);
            var playerHistory = await tournamentHistoryRepository.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "accountId", accountId },
                { "eventId", eventId }
            });

            if (dedicatedPlayer == null)
            {
                dedicatedPlayer = new TournamentDedicatedServer
                {
                    AccountId = accountId,
                    EventId = eventId,
                    Matches = new List<string>(matches),
                    TeamId = Guid.NewGuid().ToString().Replace("-", ""),
                    Teammates = teammates,
                    PointsEarned = 0,
                    Season = Constants.CurrentVersion
                };
                await dedicatedServerRepository.SaveAsync(dedicatedPlayer);
            }

            if (playerHistory == null)
            {
                playerHistory = new TournamentHistory
                {
                    AccountId = accountId,
                    EventId = eventId,
                    TeamId = dedicatedPlayer.TeamId,
                    TeamElimsStatIndex = new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 },
                    PlacementStatIndex = new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 },
                    VictoryRoyaleStatIndex = new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 },
                    TimeAliveStatIndex = new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 },
                    MatchesPlayedStatIndex = new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 },
                    Season = Constants.CurrentVersion
                };
                await tournamentHistoryRepository.SaveAsync(playerHistory);
            }

            playerHistory.TeamElimsStatIndex.TimesAchieved += 1;
            playerHistory.PlacementStatIndex.TimesAchieved += placement;

            playerHistory.TimeAliveStatIndex.TimesAchieved += 1;
            playerHistory.TimeAliveStatIndex.PointsEarned += timeAlive;

            playerHistory.MatchesPlayedStatIndex.TimesAchieved += 1;

            playerHistory.SessionEndTimes[sessionId] = DateTime.UtcNow.ToIsoUtcString();

            if (placement == 1)
            {
                playerHistory.VictoryRoyaleStatIndex.TimesAchieved += 1;
                playerHistory.VictoryRoyaleStatIndex.PointsEarned += pointsEarned;
            }

            dedicatedPlayer.PointsEarned += pointsEarned;
            dedicatedPlayer.Matches.AddRange(matches);

            var updateTasks = new List<Task>
            {
                tournamentHistoryRepository.UpdateAsync(playerHistory),
                dedicatedServerRepository.UpdateAsync(dedicatedPlayer)
            };

            foreach (var teammateId in teammates.Where(t => t != accountId))
            {
                var teamMember = await dedicatedServerRepository.FindByColumnAsync("accountId", teammateId);
                var teamHistory = await tournamentHistoryRepository.FindByColumnsAsync(new Dictionary<string, object>
                {
                    { "accountId", teammateId },
                    { "eventId", eventId }
                });

                if (teamMember == null)
                {
                    teamMember = new TournamentDedicatedServer
                    {
                        AccountId = teammateId,
                        EventId = eventId,
                        Matches = new List<string>(matches),
                        TeamId = dedicatedPlayer.TeamId,
                        Teammates = dedicatedPlayer.Teammates,
                        PointsEarned = 0,
                        Season = Constants.CurrentVersion
                    };
                    await dedicatedServerRepository.SaveAsync(teamMember);
                }

                if (teamHistory == null)
                {
                    teamHistory = new TournamentHistory
                    {
                        AccountId = teammateId,
                        EventId = eventId,
                        TeamId = dedicatedPlayer.TeamId,
                        TeamElimsStatIndex = new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 },
                        PlacementStatIndex = new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 },
                        VictoryRoyaleStatIndex = new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 },
                        TimeAliveStatIndex = new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 },
                        MatchesPlayedStatIndex = new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 },
                        Season = Constants.CurrentVersion
                    };
                    await tournamentHistoryRepository.SaveAsync(teamHistory);
                }

                teamMember.PointsEarned += pointsEarned;
                teamMember.Matches.AddRange(matches);

                teamHistory.TeamElimsStatIndex.TimesAchieved += 1;
                teamHistory.PlacementStatIndex.TimesAchieved += placement;

                teamHistory.TimeAliveStatIndex.TimesAchieved += 1;
                teamHistory.TimeAliveStatIndex.PointsEarned += timeAlive;

                teamHistory.SessionEndTimes[sessionId] = DateTime.UtcNow.ToIsoUtcString();
                teamHistory.MatchesPlayedStatIndex.TimesAchieved += 1;

                if (placement == 1)
                {
                    teamHistory.VictoryRoyaleStatIndex.TimesAchieved += 1;
                    teamHistory.VictoryRoyaleStatIndex.PointsEarned += pointsEarned;
                }

                updateTasks.Add(tournamentHistoryRepository.UpdateAsync(teamHistory));
                updateTasks.Add(dedicatedServerRepository.UpdateAsync(teamMember));
            }

            await Task.WhenAll(updateTasks);
            return NoContent();
        }
        catch (Exception ex)
        {
            return InternalErrors.ServerError
                .WithMessage($"Processing error: {ex.Message}")
                .Apply(HttpContext);
        }
        finally
        {
            json?.Dispose();
        }
    }
}