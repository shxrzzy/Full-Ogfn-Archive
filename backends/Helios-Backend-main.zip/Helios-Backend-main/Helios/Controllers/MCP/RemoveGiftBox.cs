using System;
using System.Buffers;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Helios.Controllers.MCP;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{accountId}/client/RemoveGiftBox")]
public class RemoveGiftBox : ControllerBase
{
    private const int MaxRequestSize = 8192;
    private const int MaxGiftBoxItems = 50;

    private static readonly JsonDocumentOptions JsonOptions = new()
    {
        AllowTrailingCommas = true,
        MaxDepth = 10
    };

    [HttpPost]
    [VerifyToken]
    public async Task<IActionResult> Init([FromRoute] string accountId, [FromQuery] string profileId)
    {
        if (string.IsNullOrWhiteSpace(profileId) || string.IsNullOrWhiteSpace(accountId))
            return MCPErrors.InvalidPayload.Apply(HttpContext);

        if (Request.ContentLength > MaxRequestSize)
            return MCPErrors.InvalidPayload.WithMessage("Request too large").Apply(HttpContext);

        var userRepository = Constants.repositoryPool.For<User>();
        var profilesRepository = Constants.repositoryPool.For<Profiles>();
        var profileItemsRepository = Constants.repositoryPool.For<Items>();

        var user = await userRepository.FindByColumnAsync("accountid", accountId);
        if (user == null)
            return AccountErrors.AccountNotFound(accountId)
                .WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);

        var profile = await profilesRepository.FindByColumnsAsync(new Dictionary<string, object>
        {
            { "profileid", profileId },
            { "accountid", accountId }
        });

        if (profile == null)
            return MCPErrors.ProfileNotFound(profileId).Apply(HttpContext);
       
        List<string> giftBoxItemIds;
        try
        {
            giftBoxItemIds = await ParseGiftBoxItemIds();
        }
        catch (JsonException)
        {
            return MCPErrors.InvalidPayload.WithMessage("Invalid JSON").Apply(HttpContext);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error parsing request: {ex}");
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        if (giftBoxItemIds.Count == 0)
            return MCPErrors.InvalidPayload.WithMessage("No items to remove").Apply(HttpContext);

        if (giftBoxItemIds.Count > MaxGiftBoxItems)
            return MCPErrors.InvalidPayload.WithMessage($"Too many items (max {MaxGiftBoxItems})").Apply(HttpContext);

        var profileChanges = new List<object>();
        var deletionTasks = giftBoxItemIds.Select(async itemId =>
        {
            await profileItemsRepository.DeleteAsync(new Items { AccountId = user.AccountId, TemplateId = itemId });
            profileChanges.Add(new { changeType = "itemRemoved", itemId });
        });

        await Task.WhenAll(deletionTasks);

        if (profileChanges.Count > 0)
        {
            profile.Revision++;
            await ProfileManager.UpdateProfileAsync(profile);
        }

        return Ok(ProfileResponseManager.Generate(profile, profileChanges, profileId));
    }

    private async Task<List<string>> ParseGiftBoxItemIds()
    {
        JsonDocument json;

        if (Request.ContentLength.HasValue && Request.ContentLength.Value < 4096)
        {
            var buffer = ArrayPool<byte>.Shared.Rent((int)Request.ContentLength.Value);
            try
            {
                var bytesRead = await Request.Body.ReadAsync(buffer, 0, (int)Request.ContentLength.Value);
                json = JsonDocument.Parse(buffer.AsMemory(0, bytesRead), JsonOptions);
            }
            finally
            {
                ArrayPool<byte>.Shared.Return(buffer);
            }
        }
        else
        {
            using var memoryStream = new MemoryStream();
            await Request.Body.CopyToAsync(memoryStream);
            memoryStream.Position = 0;
            json = JsonDocument.Parse(memoryStream, JsonOptions);
        }

        using (json)
        {
            var root = json.RootElement;
            var itemIds = new HashSet<string>();

            if (root.TryGetProperty("giftBoxItemId", out var singleItem) &&
                singleItem.ValueKind == JsonValueKind.String)
            {
                var id = singleItem.GetString();
                if (!string.IsNullOrWhiteSpace(id))
                    itemIds.Add(id);
            }

            if (root.TryGetProperty("giftBoxItemIds", out var multipleItems) &&
                multipleItems.ValueKind == JsonValueKind.Array)
            {
                foreach (var element in multipleItems.EnumerateArray())
                {
                    if (element.ValueKind == JsonValueKind.String)
                    {
                        var id = element.GetString();
                        if (!string.IsNullOrWhiteSpace(id))
                            itemIds.Add(id);
                    }
                }
            }

            return itemIds.ToList();
        }
    }
}