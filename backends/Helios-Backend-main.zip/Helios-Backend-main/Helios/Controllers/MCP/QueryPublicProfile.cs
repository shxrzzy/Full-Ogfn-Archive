using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Database.Tables.Stats;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace Helios.Controllers.MCP;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{username}/dedicated_server/QueryPublicProfile")]
public class QueryPublicProfile : ControllerBase
{
    private const int MaxRequestSize = 8192;

    [HttpPost]
    public async Task<IActionResult> Init([FromRoute] string username, [FromQuery] string profileId)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(profileId) || string.IsNullOrWhiteSpace(username))
            {
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            if (profileId != "athena")
                return MCPErrors.TemplateNotFound.Apply(HttpContext);

            if (Request.ContentLength > MaxRequestSize)
            {
                return MCPErrors.InvalidPayload.WithMessage("Request too large").Apply(HttpContext);
            }

            var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
            if (apiKey != Constants.ValidApiKey)
            {
                return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);
            }

            var userRepository = Constants.repositoryPool.For<User>();
            var profilesRepository = Constants.repositoryPool.For<Profiles>();
            var itemsRepository = Constants.repositoryPool.For<Items>();

            var userTask = userRepository.FindByColumnAsync("username", username);
            var user = await userTask;

            if (user == null)
            {
                return AccountErrors.AccountNotFound(username)
                    .WithMessage($"User with id {username} not found")
                    .Apply(HttpContext);
            }

            var profileTask = profilesRepository.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "profileid", profileId },
                { "accountid", user.AccountId }
            });

            var victoryCrownTask = itemsRepository.FindByColumnsAsync(new Dictionary<string, object>
            {
                ["accountid"] = user.AccountId,
                ["profileid"] = "athena",
                ["templateid"] = "VictoryCrown:defaultvictorycrown"
            });

            await Task.WhenAll(profileTask, victoryCrownTask);

            var profile = profileTask.Result;
            if (profile == null)
            {
                return MCPErrors.ProfileNotFound(profileId).Apply(HttpContext);
            }

            var profileChanges = new List<object>();

            object victoryCrownData;
            var victoryCrownItem = victoryCrownTask.Result;

            if (victoryCrownItem?.Value != null)
            {
                try
                {
                    var crownJson = JObject.Parse(victoryCrownItem.Value);
                    var crownAccountData = crownJson["victory_crown_account_data"];

                    victoryCrownData = crownAccountData != null ? new
                    {
                        has_victory_crown = (bool)(crownAccountData["has_victory_crown"] ?? false),
                        total_victory_crowns_bestowed_count = (int)(crownAccountData["total_victory_crowns_bestowed_count"] ?? 0),
                        total_royal_royales_achieved_count = (int)(crownAccountData["total_royal_royales_achieved_count"] ?? 0),
                        data_is_valid_for_mcp = (bool)(crownAccountData["data_is_valid_for_mcp"] ?? true),
                        victory_crown_level = (int)(crownAccountData["victory_crown_level"] ?? 0)
                    } : GetDefaultVictoryCrownData();
                }
                catch
                {
                    victoryCrownData = GetDefaultVictoryCrownData();
                }
            }
            else
            {
                victoryCrownData = GetDefaultVictoryCrownData();
            }

            if (profileChanges.Count > 0)
            {
                profile.Revision++;
                await ProfileManager.UpdateProfileAsync(profile);
            }

            var response = new List<object>
            {
                new { victoryCrownData }
            };

            return Ok(ProfileResponseManager.Generate(profile, response, profileId));
        }
        catch (ArgumentException)
        {
            return MCPErrors.InvalidPayload.WithMessage("Invalid request parameters").Apply(HttpContext);
        }
        catch (InvalidOperationException)
        {
            return MCPErrors.InvalidPayload.WithMessage("Invalid operation").Apply(HttpContext);
        }
        catch (TimeoutException)
        {
            return InternalErrors.UnknownError.WithMessage("Service temporarily unavailable").Apply(HttpContext);
        }
        catch (Exception)
        {
            return InternalErrors.ServerError.WithMessage("An unexpected error occurred").Apply(HttpContext);
        }
    }

    private static object GetDefaultVictoryCrownData()
    {
        return new
        {
            has_victory_crown = false,
            total_victory_crowns_bestowed_count = 0,
            total_royal_royales_achieved_count = 0,
            data_is_valid_for_mcp = true,
            victory_crown_level = 0
        };
    }
}