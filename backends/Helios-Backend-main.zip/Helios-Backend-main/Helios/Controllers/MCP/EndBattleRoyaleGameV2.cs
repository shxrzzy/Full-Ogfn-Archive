using Helios.Classes.AthenaSeason;
using Helios.Classes.GlobalDBInterfaces;
using Helios.Classes.MCP;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Database.Tables.Stats;
using Helios.Database.Tables.Tournaments;
using Helios.Managers;
using Helios.Managers.Helpers;
using Helios.Utilities;
using Helios.Utilities.Caching;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Helios.Utilities.Profile;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Buffers;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text.Json;

namespace Helios.Controllers.MCP;

[ApiController]
[Route("/fortnite/api/game/v2/profile/{username}/dedicated_server/EndBattleRoyaleGameV2")]
public class EndBattleRoyaleGameV2 : ControllerBase
{
    private static readonly JsonDocumentOptions JsonOptions = new() { AllowTrailingCommas = true };

    private static readonly int CURRENCY_PER_ELIMINATION = 100;
    private static readonly int CURRENCY_FOR_WIN = 200;

    [HttpPost]
    public async Task<IActionResult> Init([FromRoute] string username, [FromQuery] string profileId)
    {
        try
        {
            var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
            if (apiKey != Constants.ValidApiKey)
                return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);

            if (profileId is null || username is null || profileId != "athena")
                return MCPErrors.InvalidPayload.Apply(HttpContext);

            JsonDocument json;
            try
            {
                if (Request.ContentLength.HasValue && Request.ContentLength.Value < 4096)
                {
                    byte[] buffer = ArrayPool<byte>.Shared.Rent((int)Request.ContentLength.Value);
                    try
                    {
                        int bytesRead = await Request.Body.ReadAsync(buffer, 0, (int)Request.ContentLength.Value);
                        json = JsonDocument.Parse(buffer.AsMemory(0, bytesRead), JsonOptions);
                    }
                    finally { ArrayPool<byte>.Shared.Return(buffer); }
                }
                else
                {
                    using var memoryStream = new MemoryStream();
                    await Request.Body.CopyToAsync(memoryStream);
                    memoryStream.Position = 0;
                    json = JsonDocument.Parse(memoryStream, JsonOptions);
                }
            }
            catch (Exception)
            {
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            if (!json.RootElement.TryGetProperty("Placement", out var placementProperty) || !placementProperty.TryGetInt32(out var placement) ||
                !json.RootElement.TryGetProperty("Eliminations", out var eliminationsProperty) || !eliminationsProperty.TryGetInt32(out var eliminations) ||
                !json.RootElement.TryGetProperty("XP", out var xpProperty) || !xpProperty.TryGetInt32(out var matchXp) ||
                !json.RootElement.TryGetProperty("Playlist", out var playlistProperty) || !json.RootElement.TryGetProperty("IsEvent", out var IsEventProperty))
            {
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            string playlist = playlistProperty.GetString();
            if (string.IsNullOrEmpty(playlist))
                return MCPErrors.InvalidPayload.Apply(HttpContext);

            bool isEvent = IsEventProperty.GetBoolean();

            List<object> notifications = new();
            List<object> profileChanges = new();

            try
            {
                var userRepo = Constants.repositoryPool.For<User>();
                var profilesRepo = Constants.repositoryPool.For<Profiles>();
                var itemsRepo = Constants.repositoryPool.For<Items>();
                var seasonStatsRepo = Constants.repositoryPool.For<SeasonStats>();
                var statsRepo = Constants.repositoryPool.For<Stats>();
                var matchStatsRepo = Constants.repositoryPool.For<MatchStats>();

                var user = await userRepo.FindByColumnAsync("username", username);
                if (user == null)
                    return AccountErrors.AccountNotFound(username).WithMessage($"User with username {username} not found").Apply(HttpContext);

                var profile = await profilesRepo.FindByColumnsAsync(new Dictionary<string, object> { { "accountid", user.AccountId }, { "profileid", profileId } });
                if (profile == null)
                    return MCPErrors.TemplateNotFound.Apply(HttpContext);

                var itemQueries = new[]
                {
                    ("xp", profileId),
                    ("book_purchased", profileId),
                    ("book_level", profileId),
                    ("book_xp", profileId),
                    ("level", profileId),
                    ("accountLevel", profileId),
                    ("battlestars", profileId),
                    ("battlestars_season_total", profileId),
                    ("Currency:MtxPurchased", "common_core")
                };

                var itemTasks = itemQueries.Select(async query =>
                {
                    var item = await itemsRepo.FindByColumnsAsync(new Dictionary<string, object>
                    {
                        { "accountid", user.AccountId },
                        { "profileid", query.Item2 },
                        { "templateid", query.Item1 }
                    });
                    return new { TemplateId = query.Item1, Item = (object)item };
                }).ToList();

                var currentSeason = int.Parse(Constants.config.CurrentVersion.Split(".")[0]);
                var seasonXp = await seasonStatsRepo.FindByColumnsAsync(new Dictionary<string, object>
                {
                    { "accountid", user.AccountId },
                    { "season", currentSeason },
                    { "type", "seasonXp" }
                });
                if (seasonXp == null)
                    return MCPErrors.TemplateNotFound.WithMessage("'seasonXp' not found in 'SeasonStats'.").Apply(HttpContext);

                var allItemResults = await Task.WhenAll(itemTasks);

                var items = new Dictionary<string, object>();
                foreach (var result in allItemResults)
                    if (result.Item != null) items[result.TemplateId] = result.Item;

                if (!items.ContainsKey("xp") || !items.ContainsKey("book_purchased") || !items.ContainsKey("book_level") ||
                    !items.ContainsKey("book_xp") || !items.ContainsKey("level") || !items.ContainsKey("accountLevel"))
                {
                    return MCPErrors.TemplateNotFound.WithMessage("Required items not found in profile.").Apply(HttpContext);
                }

                var xp = (Items)items["xp"];
                var book_purchased = (Items)items["book_purchased"];
                var book_level = (Items)items["book_level"];
                var book_xp = (Items)items["book_xp"];
                var currentLevel = (Items)items["level"];
                var accountLevel = (Items)items["accountLevel"];
                var currency = items.ContainsKey("Currency:MtxPurchased") ? (Items)items["Currency:MtxPurchased"] : null;
                var battlestars = items.ContainsKey("battlestars") ? (Items)items["battlestars"] : null;
                var battleStarsSeasonTotal = items.ContainsKey("battlestars_season_total") ? (Items)items["battlestars_season_total"] : null;

                if (battlestars == null)
                {
                    battlestars = new Items
                    {
                        AccountId = user.AccountId,
                        IsAttribute = true,
                        Quantity = 1,
                        ProfileId = "athena",
                        TemplateId = "battlestars",
                        Value = "0"
                    };
                    await itemsRepo.SaveAsync(battlestars);
                }

                if (battleStarsSeasonTotal == null)
                {
                    battleStarsSeasonTotal = new Items
                    {
                        AccountId = user.AccountId,
                        IsAttribute = true,
                        Quantity = 1,
                        ProfileId = "athena",
                        TemplateId = "battlestars_season_total",
                        Value = "0"
                    };
                    await itemsRepo.SaveAsync(battleStarsSeasonTotal);
                }

                var currentXp = JsonConvert.DeserializeObject<int>(seasonXp.Value) + Math.Max(0, matchXp);
                var bookPurchased = JsonConvert.DeserializeObject<bool>(book_purchased.Value);
                var bookXpValue = JsonConvert.DeserializeObject<int>(book_xp.Value);
                var level = JsonConvert.DeserializeObject<int>(currentLevel.Value);
                var accLevel = JsonConvert.DeserializeObject<int>(accountLevel.Value);
                var bookLevelValue = JsonConvert.DeserializeObject<int>(book_level.Value);

                int battlestarsValue = 0;
                if (!string.IsNullOrEmpty(battlestars.Value))
                {
                    if (!int.TryParse(battlestars.Value, out battlestarsValue))
                    {
                        battlestarsValue = 0;
                    }
                }

                int battlestarsSeasonTotalValue = 0;
                if (!string.IsNullOrEmpty(battleStarsSeasonTotal.Value))
                {
                    if (!int.TryParse(battleStarsSeasonTotal.Value, out battlestarsSeasonTotalValue))
                    {
                        battlestarsSeasonTotalValue = 0;
                    }
                }

                int currencyReward = 0;
                currencyReward += eliminations * CURRENCY_PER_ELIMINATION;
                if (placement == 1)
                {
                    currencyReward += CURRENCY_FOR_WIN;
                }

                if (currency == null)
                {
                    currency = new Items
                    {
                        AccountId = user.AccountId,
                        IsAttribute = true,
                        Quantity = currencyReward,
                        ProfileId = "common_core",
                        TemplateId = "Currency:MtxPurchased",
                        Value = null
                    };
                    await itemsRepo.SaveAsync(currency);
                }
                else
                {
                    currency.Quantity += currencyReward;
                }

                notifications.Add(new
                {
                    type = "CurrencyEarned",
                    primary = true,
                    currencyType = "MtxPurchased",
                    amount = currencyReward,
                });

                profileChanges.Add(new
                {
                    changeType = "itemQuantityChanged",
                    itemId = "Currency:MtxPurchased",
                    quantity = currency.Quantity
                });

                TournamentHype hypeToUpdate = null;
                if (isEvent)
                {
                    if (!json.RootElement.TryGetProperty("TournamentInfo", out var tournamentInfo))
                    {
                        return MCPErrors.InvalidPayload.WithMessage("TournamentInfo is required for event matches.").Apply(HttpContext);
                    }

                    string tournamentType = null;
                    string tournamentId = null;
                    int pointsGained = 0;
                    int startingPlayerCount = 0;

                    if (tournamentInfo.TryGetProperty("TournamentType", out var tournamentTypeProperty))
                        tournamentType = tournamentTypeProperty.GetString();

                    if (tournamentInfo.TryGetProperty("TournamentId", out var tournamentIdProperty))
                        tournamentId = tournamentIdProperty.GetString();

                    if (tournamentInfo.TryGetProperty("PointsGained", out var pointsGainedProperty) &&
                        pointsGainedProperty.TryGetInt32(out var value))
                        pointsGained = value;

                    if (tournamentInfo.TryGetProperty("StartingPlayerCount", out var startingPlayerCountProperty) &&
                           startingPlayerCountProperty.TryGetInt32(out var stpcVal))
                        startingPlayerCount = stpcVal;

                    if (string.IsNullOrEmpty(tournamentType) || string.IsNullOrEmpty(tournamentId))
                        return MCPErrors.InvalidPayload.WithMessage("TournamentType and TournamentId are required in TournamentInfo.").Apply(HttpContext);

                    var tournamentTokensRepository = Constants.repositoryPool.For<TournamentTokens>();
                    var tournamentHypeRepository = Constants.repositoryPool.For<TournamentHype>();

                    if (tournamentType?.Contains("NormalHype") == true)
                    {
                        var existingHype = await tournamentHypeRepository.FindByColumnsAsync(new Dictionary<string, object>
                        {
                            { "accountid", user.AccountId },
                            { "season", currentSeason },
                            { "type", tournamentType }
                        });

                        if (existingHype == null)
                        {
                            existingHype = new TournamentHype
                            {
                                AccountId = user.AccountId,
                                Season = currentSeason,
                                Type = tournamentType,
                                Hype = 0
                            };
                            await tournamentHypeRepository.SaveAsync(existingHype);
                        }

                        var currentScore = existingHype.Hype;
                        int updatedScore = currentScore;
                        int placementPoints = 0;

                        if (pointsGained > 0)
                        {
                            updatedScore += pointsGained;
                        }

                        if (startingPlayerCount > 0 && placement > 0)
                        {
                            if (placement == 1)
                                placementPoints = 30;
                            else if (placement <= 2)
                                placementPoints = 25;
                            else if (placement <= 5)
                                placementPoints = 20;
                            else if (placement <= 10)
                                placementPoints = 15;
                            else if (placement <= 25)
                                placementPoints = 10;
                            else if (placement <= 50)
                                placementPoints = 5;

                            updatedScore += placementPoints;
                        }

                        existingHype.Hype = Math.Max(0, updatedScore);
                        hypeToUpdate = existingHype;

                        if (updatedScore > currentScore)
                        {
                            var divisions = EventsManager.CreateDivisionRequirements(Constants.CurrentVersion);
                            if (divisions?.Any() == true)
                            {
                                var existingTokens = await tournamentTokensRepository.FindAllByColumnsAsync(new Dictionary<string, object>
                                {
                                    { "accountid", user.AccountId },
                                    { "season", currentSeason }
                                });

                                var existingTokenSet = new HashSet<string>(
                                    existingTokens.Where(t => !string.IsNullOrEmpty(t.Token))
                                               .Select(t => t.Token),
                                    StringComparer.OrdinalIgnoreCase
                                );

                                foreach (var division in divisions)
                                {
                                    if (updatedScore < division.RequiredPoints)
                                        continue;

                                    if (currentScore >= division.RequiredPoints)
                                        continue;

                                    if (string.IsNullOrEmpty(division.Token) || existingTokenSet.Contains(division.Token))
                                        continue;

                                    var newToken = new TournamentTokens
                                    {
                                        AccountId = user.AccountId,
                                        Season = currentSeason,
                                        Token = division.Token
                                    };

                                    await tournamentTokensRepository.SaveAsync(newToken);
                                    existingTokenSet.Add(division.Token);

                                    notifications.Add(new
                                    {
                                        type = "DivisionAdvancement",
                                        primary = true,
                                        division = division.Token,
                                        requiredPoints = division.RequiredPoints
                                    });
                                }
                            }
                        }

                        if (updatedScore != currentScore)
                        {
                            notifications.Add(new
                            {
                                type = "HypeEarned",
                                primary = false,
                                hypeGained = updatedScore - currentScore,
                                currentHype = updatedScore,
                                tournamentType = tournamentType
                            });
                        }
                    }
                }

                var rewardHelper = new RewardHelper(profileChanges, notifications);

                if (!bookPurchased && !user.AllItemsGranted)
                {
                    book_purchased.Value = "true";
                    book_level.Value = "1";
                    bookLevelValue = 1;

                    if (HeliosFastCache.TryGet("BookXpScheduleFree", out List<RewardItem> freeReward) &&
                        HeliosFastCache.TryGet("BookXpSchedulePaid", out List<RewardItem> paidReward))
                    {
                        var firstRewards = freeReward.Concat(paidReward).Where(x => x.Tier == 1).ToList();
                        var lootList = firstRewards.Select(r => new LootList { ItemType = r.TemplateId, ItemGuid = r.TemplateId, Quantity = r.Quantity }).ToList();

                        var rewardTasks = firstRewards.Select(reward => BattlepassHelper.HandleRewardAsync(reward, HttpContext, rewardHelper, currency, profileChanges, user.AccountId));
                        var giftBoxTask = itemsRepo.SaveAsync(new Items
                        {
                            AccountId = user.AccountId,
                            IsAttribute = false,
                            Quantity = 1,
                            ProfileId = "common_core",
                            TemplateId = "GiftBox:GB_BattlePassPurchased",
                            Value = JsonConvert.SerializeObject(new { fromAccountId = "Server", lootList })
                        });

                        await Task.WhenAll(rewardTasks);
                        await giftBoxTask;

                        foreach (var reward in firstRewards)
                        {
                            profileChanges.Add(new
                            {
                                changeType = "itemAdded",
                                itemId = reward.TemplateId,
                                item = new
                                {
                                    templateId = reward.TemplateId,
                                    attributes = new { item_seen = false, level = 1, variants = new List<Variants>(), favorite = false },
                                    quantity = reward.Quantity
                                }
                            });
                        }

                        notifications.Add(new
                        {
                            type = "BattlePassPurchased",
                            primary = true,
                            lootReceived = firstRewards.Count
                        });
                    }
                }

                if (HeliosFastCache.TryGet("BookXpScheduleFree", out List<RewardItem> freeRewardItems) &&
                    HeliosFastCache.TryGet("BookXpSchedulePaid", out List<RewardItem> paidRewardItems) &&
                    HeliosFastCache.TryGet("SeasonXpCurve", out List<SeasonXpCurve> seasonXpCurve) &&
                    HeliosFastCache.TryGet("SeasonXpScheduleFree", out List<AthenaBattleStars> athenaBattleStars))
                {
                    int xpToDistribute = currentXp;

                    while (xpToDistribute > 0 && !(currentSeason < 11 && (level >= 100 || bookLevelValue >= 100)))
                    {
                        var currentSeasonLevel = seasonXpCurve.FirstOrDefault(x => x.Level == level);
                        if (currentSeasonLevel == null || xpToDistribute < currentSeasonLevel.XpToNextLevel) break;

                        var starsToGrant = athenaBattleStars.FirstOrDefault(x => x.Level == level);
                        if (starsToGrant == null)
                            break;

                        int xpToNextLevel = currentSeasonLevel.XpToNextLevel;

                        if (xpToDistribute >= xpToNextLevel)
                        {
                            if (currentSeason < 11 && level >= 100) break;

                            level++;
                            accLevel++;
                            bookLevelValue++;
                            bookXpValue = (bookXpValue + starsToGrant.Amount) % 10;

                            battlestarsValue += starsToGrant.Amount;
                            battlestarsSeasonTotalValue += starsToGrant.Amount;

                            xpToDistribute -= xpToNextLevel;

                            currentXp -= xpToNextLevel;

                            if (currentXp >= xpToNextLevel)
                            {
                                currentXp = xpToNextLevel - 1;
                            }

                            currentXp %= 10;

                            if (!user.AllItemsGranted)
                            {
                                var tierRewards = paidRewardItems.Concat(freeRewardItems).Where(r => r.Tier == bookLevelValue).ToList();
                                var rewardTasks = tierRewards.Select(reward => BattlepassHelper.HandleRewardAsync(reward, HttpContext, rewardHelper, currency, profileChanges, user.AccountId));
                                await Task.WhenAll(rewardTasks);

                                foreach (var reward in tierRewards)
                                {
                                    profileChanges.Add(new
                                    {
                                        changeType = "itemAdded",
                                        itemId = reward.TemplateId,
                                        item = new
                                        {
                                            templateId = reward.TemplateId,
                                            attributes = new { item_seen = false, variants = new List<Variants>(), favorite = false },
                                            quantity = reward.Quantity
                                        }
                                    });

                                    notifications.Add(new
                                    {
                                        type = "BattlePassRewardUnlocked",
                                        primary = false,
                                        itemType = reward.TemplateId,
                                        itemGuid = reward.TemplateId,
                                        quantity = reward.Quantity,
                                        level = bookLevelValue,
                                    });
                                }

                                if (level <= 100 && notifications.Count > 0)
                                {
                                    await itemsRepo.SaveAsync(new Items
                                    {
                                        AccountId = user.AccountId,
                                        IsAttribute = false,
                                        Quantity = 1,
                                        ProfileId = "common_core",
                                        TemplateId = "GiftBox:GB_BattlePass",
                                        Value = JsonConvert.SerializeObject(new { fromAccountId = "Server", lootList = notifications })
                                    });
                                }
                            }

                            if (currentSeason < 11 && level > 100)
                            {
                                level = 100;
                                bookLevelValue = 100;
                                currentXp = 0;
                                break;
                            }
                        }
                        else break;
                    }
                }

                accountLevel.Value = JsonConvert.SerializeObject(accLevel);
                book_level.Value = JsonConvert.SerializeObject(bookLevelValue);
                currentLevel.Value = JsonConvert.SerializeObject(level);
                xp.Value = JsonConvert.SerializeObject(currentXp);
                seasonXp.Value = JsonConvert.SerializeObject(currentXp);
                book_xp.Value = JsonConvert.SerializeObject(bookXpValue);
                battlestars.Value = JsonConvert.SerializeObject(battlestarsValue);
                battleStarsSeasonTotal.Value = JsonConvert.SerializeObject(battlestarsSeasonTotalValue);

                profileChanges.Add(new
                {
                    changeType = "itemAttrChanged",
                    itemId = "xp",
                    attributeName = "xp",
                    attributeValue = currentXp
                });

                profileChanges.Add(new
                {
                    changeType = "itemAttrChanged",
                    itemId = "book_level",
                    attributeName = "level",
                    attributeValue = bookLevelValue
                });

                profileChanges.Add(new
                {
                    changeType = "itemAttrChanged",
                    itemId = "book_xp",
                    attributeName = "xp",
                    attributeValue = bookXpValue
                });

                profileChanges.Add(new
                {
                    changeType = "itemAttrChanged",
                    itemId = "level",
                    attributeName = "level",
                    attributeValue = level
                });

                profileChanges.Add(new
                {
                    changeType = "itemAttrChanged",
                    itemId = "accountLevel",
                    attributeName = "level",
                    attributeValue = accLevel
                });

                profileChanges.Add(new
                {
                    changeType = "itemAttrChanged",
                    itemId = "battlestars",
                    attributeName = "level",
                    attributeValue = battlestarsValue
                });

                profileChanges.Add(new
                {
                    changeType = "itemAttrChanged",
                    itemId = "battlestars_season_total",
                    attributeName = "level",
                    attributeValue = battlestarsSeasonTotalValue
                });

                if (bookPurchased)
                {
                    profileChanges.Add(new
                    {
                        changeType = "itemAttrChanged",
                        itemId = "book_purchased",
                        attributeName = "book_purchased",
                        attributeValue = true
                    });
                }

                var updateTasks = new List<Task>
                {
                    itemsRepo.UpdateAsync(xp),
                    itemsRepo.UpdateAsync(book_purchased),
                    itemsRepo.UpdateAsync(book_level),
                    itemsRepo.UpdateAsync(book_xp),
                    itemsRepo.UpdateAsync(currentLevel),
                    itemsRepo.UpdateAsync(accountLevel),
                    seasonStatsRepo.UpdateAsync(seasonXp),
                    itemsRepo.UpdateAsync(battlestars),
                    itemsRepo.UpdateAsync(battleStarsSeasonTotal),
                    matchStatsRepo.SaveAsync(new MatchStats
                    {
                        AccountId = user.AccountId,
                        Kills = eliminations,
                        Xp = currentXp,
                        Placement = placement,
                        Playlist = playlist,
                        CreatedAt = DateTime.UtcNow
                    })
                };

                if (currency != null)
                {
                    updateTasks.Add(itemsRepo.UpdateAsync(currency));
                }

                if (hypeToUpdate != null)
                {
                    var tournamentHypeRepository = Constants.repositoryPool.For<TournamentHype>();
                    updateTasks.Add(tournamentHypeRepository.UpdateAsync(hypeToUpdate));
                }

                string playlistLower = playlist.ToLower();
                string selectedType = playlistLower.Contains("showdownalt") ? "Arena" :
                                      playlistLower.Contains("solo") ? "Solos" :
                                      playlistLower.Contains("duo") ? "Duos" :
                                      playlistLower.Contains("squad") ? "Squads" :
                                      null;

                if (!string.IsNullOrEmpty(selectedType))
                {
                    var stats = await statsRepo.FindByColumnsAsync(new Dictionary<string, object> { { "accountid", user.AccountId }, { "type", selectedType } });
                    if (stats != null)
                    {
                        stats.MatchesPlayed++;

                        var options = new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true,
                            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                        };
                        var deserializedStatsValue = System.Text.Json.JsonSerializer.Deserialize<DB_Stats>(stats.Value, options);
                        deserializedStatsValue.Kills += eliminations;

                        if (placement <= 5) deserializedStatsValue.Top5++;
                        if (placement <= 10) deserializedStatsValue.Top10++;
                        if (placement <= 25) deserializedStatsValue.Top25++;

                        if (placement == 1)
                        {
                            deserializedStatsValue.Wins++;

                            var seasonUmbrellas = new Dictionary<int, string>
                            {
                                { 1, "AthenaGlider:Umbrella_Season_01" }, { 2, "AthenaGlider:Umbrella_Season_02" }, { 3, "AthenaGlider:Umbrella_Season_03" },
                                { 4, "AthenaGlider:Umbrella_Season_04" }, { 5, "AthenaGlider:Umbrella_Season_05" }, { 6, "AthenaGlider:Umbrella_Season_06" },
                                { 7, "AthenaGlider:Umbrella_Season_07" }, { 8, "AthenaGlider:Umbrella_Season_08" }, { 9, "AthenaGlider:Umbrella_Season_09" },
                                { 10, "AthenaGlider:Umbrella_Season_10" }, { 11, "AthenaGlider:Umbrella_Season_11" }, { 12, "AthenaGlider:Umbrella_Season_12" },
                                { 13, "AthenaGlider:Umbrella_Season_13" }, { 14, "AthenaGlider:Umbrella_Season_14" }, { 15, "AthenaGlider:Umbrella_Season_15" },
                                { 16, "AthenaGlider:Umbrella_Season_16" }, { 17, "AthenaGlider:Umbrella_Season_17" }, { 18, "AthenaGlider:Umbrella_Season_18" },
                                { 19, "AthenaGlider:Umbrella_Season_19" }
                            };

                            var playlistRewards = new Dictionary<string, string>
                            {
                                { "Solos", "AthenaGlider:Solo_Umbrella" }, { "Duos", "AthenaGlider:Duo_Umbrella" }, { "Squads", "AthenaGlider:Squad_Umbrella" }
                            };

                            var defaultItemValue = JsonConvert.SerializeObject(new { item_seen = false, variants = new List<Variants>(), favorite = false });
                            var victoryTasks = new List<Task>();

                            if (seasonUmbrellas.TryGetValue(currentSeason, out string seasonalReward))
                            {
                                var existingSeasonalReward = await itemsRepo.FindByColumnsAsync(new Dictionary<string, object>
                                {
                                    { "accountid", user.AccountId }, { "profileid", "athena" }, { "templateid", seasonalReward }
                                });

                                if (existingSeasonalReward == null)
                                {
                                    victoryTasks.Add(itemsRepo.SaveAsync(new Items
                                    {
                                        AccountId = user.AccountId,
                                        ProfileId = "athena",
                                        TemplateId = seasonalReward,
                                        Quantity = 1,
                                        IsAttribute = false,
                                        Value = defaultItemValue
                                    }));

                                    profileChanges.Add(new
                                    {
                                        changeType = "itemAdded",
                                        itemId = seasonalReward,
                                        item = new
                                        {
                                            templateId = seasonalReward,
                                            attributes = new { item_seen = false, variants = new List<Variants>(), favorite = false },
                                            quantity = 1
                                        }
                                    });
                                }
                            }

                            if (playlistRewards.TryGetValue(selectedType, out string playlistReward))
                            {
                                var existingItem = await itemsRepo.FindByColumnsAsync(new Dictionary<string, object>
                                {
                                    { "accountid", user.AccountId }, { "profileid", "athena" }, { "templateid", playlistReward }
                                });

                                if (existingItem == null)
                                {
                                    victoryTasks.Add(itemsRepo.SaveAsync(new Items
                                    {
                                        AccountId = user.AccountId,
                                        ProfileId = "athena",
                                        TemplateId = playlistReward,
                                        Quantity = 1,
                                        IsAttribute = false,
                                        Value = defaultItemValue
                                    }));

                                    profileChanges.Add(new
                                    {
                                        changeType = "itemAdded",
                                        itemId = playlistReward,
                                        item = new
                                        {
                                            templateId = playlistReward,
                                            attributes = new { item_seen = false, variants = new List<Variants>(), favorite = false },
                                            quantity = 1
                                        }
                                    });

                                    victoryTasks.Add(itemsRepo.SaveAsync(new Items
                                    {
                                        AccountId = user.AccountId,
                                        ProfileId = "common_core",
                                        TemplateId = "GiftBox:GB_SeasonFirstWin",
                                        Quantity = 1,
                                        IsAttribute = false,
                                        Value = JsonConvert.SerializeObject(new
                                        {
                                            fromAccountId = "Server",
                                            lootList = new List<LootList> { new LootList { ItemType = playlistReward, ItemGuid = playlistReward, Quantity = 1 } }
                                        })
                                    }));

                                    notifications.Add(new
                                    {
                                        type = "GiftBoxReceived",
                                        primary = true,
                                        giftBoxType = "GB_SeasonFirstWin",
                                    });
                                }
                            }

                            if (victoryTasks.Count > 0)
                            {
                                updateTasks.AddRange(victoryTasks);
                            }
                        }

                        stats.Value = System.Text.Json.JsonSerializer.Serialize(deserializedStatsValue, options);
                        updateTasks.Add(statsRepo.UpdateAsync(stats));
                    }
                }

                var existingVictoryCrown = await itemsRepo.FindByColumnsAsync(new Dictionary<string, object>
                {
                    ["accountid"] = user.AccountId,
                    ["profileid"] = "athena",
                    ["templateid"] = "VictoryCrown:defaultvictorycrown"
                });

                if (existingVictoryCrown == null)
                {
                    if (placement == 1)
                    {
                        var crownItemValue = JsonConvert.SerializeObject(new
                        {
                            victory_crown_account_data = new
                            {
                                total_victory_crowns_bestowed_count = 1,
                                total_royal_royales_achieved_count = 1,
                                has_victory_crown = true,
                                data_is_valid_for_mcp = true,
                                victory_crown_level = 1
                            },
                            level = 1
                        });

                        var defaultItemValue = JsonConvert.SerializeObject(new { item_seen = false, variants = new List<Variants>(), favorite = false });

                        updateTasks.Add(itemsRepo.SaveAsync(new Items
                        {
                            AccountId = user.AccountId,
                            ProfileId = "athena",
                            TemplateId = "VictoryCrown:defaultvictorycrown",
                            Quantity = 1,
                            IsAttribute = false,
                            Value = crownItemValue
                        }));

                        updateTasks.Add(itemsRepo.SaveAsync(new Items
                        {
                            AccountId = user.AccountId,
                            ProfileId = "athena",
                            TemplateId = "AthenaDance:EID_Coronet",
                            Quantity = 1,
                            IsAttribute = false,
                            Value = defaultItemValue
                        }));

                        var baseAttributes = new { item_seen = false, variants = Array.Empty<Variants>(), favorite = false };

                        profileChanges.Add(new
                        {
                            changeType = "itemAdded",
                            itemId = "VictoryCrown:defaultvictorycrown",
                            item = new
                            {
                                templateId = "VictoryCrown:defaultvictorycrown",
                                attributes = baseAttributes,
                                quantity = 1
                            }
                        });

                        profileChanges.Add(new
                        {
                            changeType = "itemAdded",
                            itemId = "AthenaDance:EID_Coronet",
                            item = new
                            {
                                templateId = "AthenaDance:EID_Coronet",
                                attributes = baseAttributes,
                                quantity = 1
                            }
                        });
                    }
                }
                else
                {
                    var attributes = JObject.Parse(existingVictoryCrown.Value ?? "{}");

                    if (attributes["victory_crown_account_data"] == null || attributes["victory_crown_account_data"].Type != JTokenType.Object)
                    {
                        attributes["victory_crown_account_data"] = new JObject
                        {
                            ["total_victory_crowns_bestowed_count"] = 0,
                            ["total_royal_royales_achieved_count"] = 0,
                            ["has_victory_crown"] = false,
                            ["data_is_valid_for_mcp"] = true,
                            ["victory_crown_level"] = 0
                        };
                    }

                    var crownData = (JObject)attributes["victory_crown_account_data"];
                    bool currentlyHasCrown = (bool)(crownData["has_victory_crown"] ?? false);
                    int currentCrownLevel = (int)(crownData["victory_crown_level"] ?? 0);

                    if (placement == 1)
                    {
                        crownData["total_royal_royales_achieved_count"] = (int)(crownData["total_royal_royales_achieved_count"] ?? 0) + 1;

                        if (!currentlyHasCrown)
                        {
                            if (currentCrownLevel > 0)
                            {
                                crownData["has_victory_crown"] = true;

                                notifications.Add(new
                                {
                                    type = "VictoryCrownEarned",
                                    primary = true,
                                    level = currentCrownLevel,
                                });
                            }
                            else
                            {
                                crownData["total_victory_crowns_bestowed_count"] = (int)(crownData["total_victory_crowns_bestowed_count"] ?? 0) + 1;
                                crownData["has_victory_crown"] = true;
                                crownData["victory_crown_level"] = 1;

                                notifications.Add(new
                                {
                                    type = "VictoryCrownEarned",
                                    primary = true,
                                    level = 1,
                                });
                            }
                        }
                        else
                        {
                            crownData["total_victory_crowns_bestowed_count"] = (int)(crownData["total_victory_crowns_bestowed_count"] ?? 0) + 1;
                            crownData["victory_crown_level"] = currentCrownLevel + 1;

                            notifications.Add(new
                            {
                                type = "VictoryCrownLevelUp",
                                primary = true,
                                level = currentCrownLevel + 1,
                            });
                        }
                    }
                    else if (currentlyHasCrown)
                    {
                        crownData["has_victory_crown"] = false;

                        notifications.Add(new
                        {
                            type = "VictoryCrownLost",
                            primary = false
                        });
                    }

                    existingVictoryCrown.Value = attributes.ToString(Formatting.None);
                    updateTasks.Add(itemsRepo.UpdateAsync(existingVictoryCrown));

                    profileChanges.Add(new
                    {
                        changeType = "itemAttrChanged",
                        itemId = existingVictoryCrown.TemplateId,
                        attributeName = "victory_crown_account_data",
                        attributeValue = crownData
                    });
                }

                try
                {
                    await Task.WhenAll(updateTasks);
                }
                catch (Exception)
                {
                }

                if (profileChanges.Count > 0)
                {
                    profile.Revision++;
                    await ProfileManager.UpdateProfileAsync(profile);
                }

                var response = new List<object>
                {
                    new
                    {
                        playlistId = playlist,
                        totalXPAccum = matchXp,
                        matchStats = new
                        {
                            xpStats = new[]
                            {
                                new
                                {
                                    stat = "Total",
                                    Xp = matchXp,
                                    count = 1
                                }
                            }
                        }
                    }
                };

                if (placement == 1)
                {
                    int crownCount = 1;
                    int royaleCount = 1;
                    int crownLevel = 1;

                    if (existingVictoryCrown != null)
                    {
                        var crownJson = JObject.Parse(existingVictoryCrown.Value);
                        crownCount = (int)(crownJson["victory_crown_account_data"]?["total_victory_crowns_bestowed_count"] ?? 1);
                        royaleCount = (int)(crownJson["victory_crown_account_data"]?["total_royal_royales_achieved_count"] ?? 1);
                        crownLevel = (int)(crownJson["victory_crown_account_data"]?["victory_crown_level"] ?? 1);
                    }

                    response.Add(new
                    {
                        crownData = new
                        {
                            victory_crown_account_data = new
                            {
                                total_victory_crowns_bestowed_count = crownCount,
                                total_royal_royales_achieved_count = royaleCount,
                                has_victory_crown = true,
                                victory_crown_level = crownLevel
                            }
                        }
                    });
                }

                await SendProfileUpdateRequest.UpdateAsync(user.AccountId, user.Username);
                return Ok(ProfileResponseManager.Generate(profile, response, profileId));
            }
            catch (Exception ex)
            {
                return InternalErrors.ServerError.WithMessage("Failed to finalize profile updates.").Apply(HttpContext);
            }
        }
        catch (Exception ex)
        {
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }
}