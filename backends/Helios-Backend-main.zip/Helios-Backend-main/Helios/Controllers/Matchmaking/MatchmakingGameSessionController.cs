﻿using Helios.Classes.MatchmakingServers;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Solstice;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;

namespace Helios.Controllers.Matchmaking;

[ApiController]
[Route("/fortnite/api/gamesession/")]
public class MatchmakingGameSessionController : ControllerBase
{
    [HttpPost("v1/account/{accountId}/token/{sessionId}")]
    [VerifyToken]
    public async Task<IActionResult> GetGameSessionToken(string accountId, string sessionId)
    {
        var userRepository = Constants.repositoryPool.For<User>();
        var tokensRepository = Constants.repositoryPool.For<Tokens>();
        
        var user = await userRepository.FindByColumnAsync("accountid", accountId);
                    
        if (user == null)
        {
            return AccountErrors.AccountNotFound(accountId)
                .WithMessage($"User with id {accountId} not found")
                .Apply(HttpContext);
        }

        if (user.Banned)
        {
            return AccountErrors.DisabledAccount.Apply(HttpContext);
        }

        Servers server = await ServerManager.GetServerBySessionIdAsync(sessionId);

        if (server == null)
            return MatchmakingErrors.UnknownSession
                .WithMessage($"Server by sessionId '{sessionId}' does not exist.").Apply(HttpContext);

        var gameSessionToken = await tokensRepository.FindByColumnsAsync(new Dictionary<string, object>
        {
            { "accountid", user.AccountId },
            { "type", "gamesession" }
        });
        if (gameSessionToken == null)
            return AuthenticationErrors.InvalidToken("GameSession token not found.").Apply(HttpContext);

        string tokenValue = gameSessionToken.Token;

        await tokensRepository.DeleteAsync(new Tokens { AccountId = user.AccountId, Type = "gamesession" });

        return Ok(new
        {
            token = tokenValue,
        });
    }
}