using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Database.Tables.Dashboard;
using Helios.Database.Tables.Profiles;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Launcher;
using Helios.Utilities.Profile;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Helios.Controllers.Dashboard;

[ApiController]
[Route("/dashboard/api/auth/")]
public class DashboardAuthController : ControllerBase
{
    public class AdminUser
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string? Hwid { get; set; } = null;
    }

    [HttpPost("register")]
    //   { username: "moderator", password: "mod123", hwid: null },
    public async Task<IActionResult> RegisterAsync()
    {
        var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
        if (apiKey != Constants.ValidApiKey)
            return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);

        AdminUser? body;
        try
        {
            body = await HttpContext.Request.ReadFromJsonAsync<AdminUser>();
        }
        catch
        {
            Logger.Warn("Failed to deserialize request body.");
            return BasicErrors.BadRequest.WithMessage("Failed to deserialize body.").Apply(HttpContext);
        }

        if (body is null ||
            string.IsNullOrWhiteSpace(body.Username) ||
            string.IsNullOrWhiteSpace(body.Password))
        {
            return BasicErrors.BadRequest.WithMessage("Invalid request").Apply(HttpContext);
        }

        var dashboardUsersRepository = Constants.repositoryPool.For<DashboardUsers>();

        if (await dashboardUsersRepository.FindAsync(new DashboardUsers { Username = body.Username }) is not null)
        {
            return BasicErrors.BadRequest.WithMessage("User already exists").Apply(HttpContext);
        }

        if (body.Hwid is not null)
            return BasicErrors.BadRequest.WithMessage("Hwid is not supported for dashboard users").Apply(HttpContext);

        try
        {
            var (hashedPassword, salt) = PasswordHasher.HashPassword(body.Password);
            var newUser = new DashboardUsers
            {
                Username = body.Username,
                Password = hashedPassword,
                Hwid = null
            };
            await dashboardUsersRepository.SaveAsync(newUser);
            return Ok(new { message = "User registered successfully" });
        }
        catch (Exception ex)
        {
            Logger.Error($"Error during user registration: {ex.Message}");
            return InternalErrors.ServerError.WithMessage("An error occurred while registering the user").Apply(HttpContext);
        }
    }

    [HttpPost("login")]
    //   { username: "moderator", password: "mod123", hwid: "12344dad" },
    public async Task<IActionResult> LoginAsync()
    {
        var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
        if (apiKey != Constants.ValidApiKey)
            return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);
        AdminUser? body;
        try
        {
            body = await HttpContext.Request.ReadFromJsonAsync<AdminUser>();
        }
        catch
        {
            Logger.Warn("Failed to deserialize request body.");
            return BasicErrors.BadRequest.WithMessage("Failed to deserialize body.").Apply(HttpContext);
        }
        if (body is null ||
            string.IsNullOrWhiteSpace(body.Username) ||
            string.IsNullOrWhiteSpace(body.Password))
        {
            return BasicErrors.BadRequest.WithMessage("Invalid request").Apply(HttpContext);
        }

        var dashboardUsersRepository = Constants.repositoryPool.For<DashboardUsers>();
        var user = await dashboardUsersRepository.FindAsync(new DashboardUsers { Username = body.Username });
        if (user is null || !PasswordHasher.VerifyPassword(body.Password, user.Password))
            return AccountErrors.AccountNotFound("").WithMessage("Invalid username or password").Apply(HttpContext);

        if (string.IsNullOrEmpty(user.Hwid))
        {
            user.Hwid = body.Hwid;
            await dashboardUsersRepository.UpdateAsync(user);
        }
        //else if (user.Hwid != body.Hwid)
        //{
        //    return AccountErrors.DisabledAccount.WithMessage("Account is locked to a different device. Contact support if this is your device.").Apply(HttpContext);
        //}

        return Ok(new { message = "Login successful" });
    }
}