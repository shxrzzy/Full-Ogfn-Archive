using Helios.Classes.ContentPages;
using Helios.Classes.Errors;
using Helios.Classes.Tournaments;
using Helios.Classes.Tournaments.DBInterfaces;
using Helios.Classes.Tournaments.Requests;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Database.Tables.ContentPages;
using Helios.Database.Tables.Dashboard;
using Helios.Database.Tables.Fortnite;
using Helios.Database.Tables.Profiles;
using Helios.Database.Tables.Tournaments;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Launcher;
using Helios.Utilities.Profile;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text.Json;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Helios.Controllers.Dashboard;

[ApiController]
[Route("/dashboard/api/tournaments")]
public class DashboardTournamentsController : ControllerBase
{
    private readonly Dictionary<string, string> regionMap = new Dictionary<string, string>
    {
        { "NA-East", "NAE" },
        { "Europe", "EU" },

        // maybe? in the future
        { "NA-Central", "NAC" },
        { "NA-West", "NAW" },
        { "Asia", "ASIA" },
        { "Oceania", "OCE" },
        { "Brazil", "BR" },
        { "Middle East", "ME" }
    };
    private static readonly JsonSerializerSettings _jsonSettings = new()
    {
        ContractResolver = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver()
    };


    [HttpPost("createTournament")]
    public async Task<IActionResult> CreateTournament()
    {
        if (!IsAuthorized())
            return DashboardErrors.UnauthorizedAccess.WithMessage("Invalid API key.").Apply(HttpContext);

        try
        {
            using var reader = new StreamReader(Request.Body);
            var requestBody = await reader.ReadToEndAsync();

            var tournament = JsonConvert.DeserializeObject<CreateTournamentRequestBody>(requestBody, _jsonSettings);

            if (tournament == null)
                return DashboardErrors.InvalidPayload
                    .WithMessage("Invalid tournament data provided.")
                    .Apply(HttpContext);

            var saveTasks = new List<Task>(4)
            {
                SaveTournamentDisplayInfoAsync(tournament.DisplayInfo),
                SaveTournamentTemplateInfoAsync(tournament.TemplateInfo, tournament.SEASON),
                SaveTournamentEventInfoAsync(tournament.EventInfo, tournament.SEASON, tournament.TemplateInfo)
            };

            if (!string.IsNullOrEmpty(tournament.backendID))
            {
                var dashboardData = CreateDashboardData(tournament);
                var _repositories = Constants.repositoryPool.For<DashboardEvents>();
                saveTasks.Add(_repositories.SaveAsync(dashboardData));
            }

            await Task.WhenAll(saveTasks);

            return NoContent();
        }
        catch (System.Text.Json.JsonException jsonEx)
        {
            Logger.Error($"JSON Deserialization Error: {jsonEx.Message}");
            return DashboardErrors.InvalidPayload
                .WithMessage("Invalid JSON format in request body.")
                .Apply(HttpContext);
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to create tournament: {ex}");
            return InternalErrors.ServerError
                .WithMessage("An error occurred while creating the tournament.")
                .Apply(HttpContext);
        }
    }

    [HttpGet]
    public async Task<IActionResult> FetchTournaments()
    {
        var dashboardEventsRepository = Constants.repositoryPool.For<DashboardEvents>();

        if (!IsAuthorized())
            return DashboardErrors.UnauthorizedAccess.WithMessage("Invalid API key.").Apply(HttpContext);

        try
        {
            var data = await dashboardEventsRepository.FindAllByTableAsync();

            return Ok(data);
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to fetch tournaments: {ex}");
            return InternalErrors.ServerError.WithMessage("Failed to fetch tournaments").Apply(HttpContext);
        }
    }

    private bool IsAuthorized()
    {
        return Request.Headers.TryGetValue("X-Api-Key", out var apiKeyValues) &&
               apiKeyValues.Count > 0 &&
               apiKeyValues[0] == Constants.ValidApiKey;
    }

    private DashboardEvents CreateDashboardData(CreateTournamentRequestBody tournament)
    {
        tournament.sessions ??= new();
        tournament.sessions.AddRange(tournament.EventInfo.EventWindows.Select(eventWindow => new TournamentSessions
        {
            Date = eventWindow.CountdownBeginTime,
            StartTime = eventWindow.BeginTime,
            EndTime = eventWindow.EndTime
        }));

        return new DashboardEvents
        {
            EventID = tournament.backendID,
            Name = tournament.name,
            Description = tournament.description,
            Image = tournament.image,
            startDate = tournament.StartDate,
            endDate = tournament.EndDate,
            status = tournament.Status,
            format = tournament.Format,
            regions = tournament.Regions.ToArray(),
            prizes = tournament.Prizes.ToArray(),
            rules = tournament.Rules.ToArray(),
            scoring = JsonConvert.SerializeObject(new List<object>()),
            sessions = JsonConvert.SerializeObject(tournament.sessions),
        };
    }

    private Task SaveTournamentDisplayInfoAsync(TournamentDisplayInfo displayInfo)
    {
        var tournamentInformationRepository = Constants.repositoryPool.For<Helios.Database.Tables.ContentPages.TournamentInformation>();

        var tournamentInfo = new Helios.Database.Tables.ContentPages.TournamentInformation
        {
            TitleColor = displayInfo.TitleColor,
            LoadingScreenImage = displayInfo.LoadingScreenImage,
            BackgroundTextColor = displayInfo.BackgroundTextColor,
            BackgroundLeftColor = displayInfo.BackgroundLeftColor,
            BackgroundRightColor = displayInfo.BackgroundRightColor,
            PosterBackImage = displayInfo.PosterBackImage,
            Type = "TournamentDisplayInfo",
            TournamentDisplayId = displayInfo.TournamentDisplayId,
            HighlightColor = displayInfo.HighlightColor,
            ScheduleInfo = displayInfo.ScheduleInfo,
            PrimaryColor = displayInfo.PrimaryColor,
            FlavorDescription = displayInfo.FlavorDescription,
            PosterFrontImage = displayInfo.PosterFrontImage,
            ShortFormatTitle = "",
            TitleLine1 = displayInfo.TitleLine1,
            TitleLine2 = displayInfo.TitleLine2,
            ShadowColor = displayInfo.ShadowColor,
            DetailsDescription = displayInfo.DetailsDescription,
            LongFormatTitle = "",
            PosterFadeColor = displayInfo.PosterFadeColor,
            SecondaryColor = displayInfo.SecondaryColor,
            PlaylistTileImage = displayInfo.PlaylistTileImage,
            BaseColor = displayInfo.BaseColor,
            PinScoreRequirement = displayInfo.PinScoreRequirement,
            PinEarnedText = displayInfo.PinEarnedText
        };

        return tournamentInformationRepository.SaveAsync(tournamentInfo);
    }

    private Task SaveTournamentTemplateInfoAsync(TournamentTemplateInfo templateInfo, int Season)
    {
        var tournamentTemplatesRepository = Constants.repositoryPool.For<TournamentTemplates>();

        var tournamentInfo = new TournamentTemplates
        {
            EventId = templateInfo.EventId,
            TournamentId = templateInfo.TournamentId,
            PlaylistId = templateInfo.PlaylistId,
            MatchCap = templateInfo.MatchCap,
            TiebreakerFormula = JsonConvert.SerializeObject(new object()),
            EventTemplateId = templateInfo.EventTemplateId,
            ScoringRules = JsonConvert.SerializeObject(templateInfo.ScoringRules ?? new List<DB_ScoringRules>()), 
            PayoutTable = JsonConvert.SerializeObject(new List<object>()),
            LiveSessionAttributes = JsonConvert.SerializeObject(new List<object>()), 
            ClampsToZero = templateInfo.ClampsToZero,
            OnlyScoreTopN = templateInfo.OnlyScoreTopN,
            Season = Season
        };

        return tournamentTemplatesRepository.SaveAsync(tournamentInfo);
    }

    private Task SaveTournamentEventInfoAsync(TournamentEventInfo eventInfo, int Season, TournamentTemplateInfo templateInfo)
    {
        var eventRepository = Constants.repositoryPool.For<Helios.Database.Tables.Tournaments.TournamentEvents>();

        Dictionary<string, object> eventMetadata;

        try
        {
            eventMetadata = JsonConvert.DeserializeObject<Dictionary<string, object>>(eventInfo.Metadata);
        }
        catch (Exception ex)
        {
            Logger.Error($"Error deserializing event info: {ex.Message}");
            eventMetadata = new();
        }

        // todo: add diff support in the future
        eventInfo.EventWindows.ForEach(window => window.EventTemplateId = templateInfo.TournamentId);
        eventInfo.Regions = eventInfo.Regions.Select(region => regionMap.TryGetValue(region, out string value) ? value : region).ToList();

        var tournamentInfo = new Helios.Database.Tables.Tournaments.TournamentEvents
        {
            EventId = eventInfo.EventId,
            BeginTime = eventInfo.AnnouncementTime,
            EndTime = eventInfo.EndTime,
            DisplayDataId = eventInfo.DisplayDataId,
            EventGroup = eventInfo.EventGroup,
            AnnouncementTime = eventInfo.AnnouncementTime,
            Regions = eventInfo.Regions.ToArray(),
            RegionMappings = new Dictionary<string, string>(),
            Platforms = eventInfo.Platforms.ToArray(),
            PlatformMappings = new Dictionary<string, object>(),
            EventMetadata = eventMetadata, 
            EventWindows = eventInfo.EventWindows.Cast<object>().ToList(),
            Season = Season,
        };

        return eventRepository.SaveAsync(tournamentInfo);
    }
}