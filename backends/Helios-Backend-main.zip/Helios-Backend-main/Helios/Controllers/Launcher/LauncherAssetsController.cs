﻿using Helios.Configuration;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Microsoft.AspNetCore.Mvc;

namespace Helios.Controllers.Launcher;

[ApiController]
[Route("/launcher/api/public/")]
public class LauncherAssetsController : ControllerBase
{
    [HttpGet("distributionpoints")]
    public IActionResult GetDistributionPoints()
    {
        return Ok(new
        {
            distributions = new string[]
            {
                $"http://127.0.0.1:{HttpContext.Request.Host.Port}",
                "https://download.epicgames.com/",
                "https://epicgames-download1.akamaized.net/",
                "https://fastly-download.epicgames.com/"
            }
        });
    }
    
    [HttpGet("assets/{platform}/{catalogItemId}/{appName}")]
    public async Task<IActionResult> GetLauncherAssets(string platform, string catalogItemId, string appName)
    {
        var Label = HttpContext.Request.Query["label"];

        var signature = Guid.NewGuid().ToString();
        
        if (!Request.Headers.TryGetValue("User-Agent", out var userAgent) || string.IsNullOrWhiteSpace(userAgent))
            return InternalErrors.InvalidUserAgent.Apply(HttpContext);

        var userAgentInfo = await UserAgentParser.ParseAsync(userAgent);
        if (userAgentInfo == null)
            return InternalErrors.InvalidUserAgent.WithMessage("Failed to parse User-Agent.").Apply(HttpContext); 

        return Ok(new
        {
            appName,
            labelName = $"{Label}-{platform}",
            buildVersion = $"++Fortnite+Release-{userAgentInfo.Season}-CL-{userAgentInfo.Netcl}-Windows",
            catalogItemId,
            expires = DateTime.Parse("9999-12-31T23:59:59.999Z", null, System.Globalization.DateTimeStyles.RoundtripKind),
            items = new
            {
                MANIFEST = new
                {
                    signature,
                    distribution = $"http://127.0.0.1:{HttpContext.Request.Host.Port}",
                    path = $"Builds/Fortnite/Content/CloudDir/Helios.manifest",
                    additionalDistributions = new string[] { }
                }
            },
            assetId = appName
        });
    }
}