using System.Text;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Utilities.Errors.HeliosErrors;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using Discord;
using Helios.Database.Tables.XMPP;
using Helios.Socket;
using Helios.Utilities;

namespace Helios.Controllers.AntiCheat;

[ApiController]
[Route("/api/v1/")]
public class AntiCheatApiController : ControllerBase
{

    [HttpGet("checkUser/{username}")]
    public async Task<IActionResult> CheckUserById(string username)
    {
        var userRepository = Constants.repositoryPool.For<User>(false);
        var user = await userRepository.FindByColumnAsync("username", username);

        if (user == null)
        {
            Logger.Debug($"User with accountId {username} not found.");
            return Content("Invalid", "text/plain");
        }

        if (user.Ac == false || !user.Ac)
        {
            Logger.Debug($"User with accountId {username} is not signed into ac.");
            return Content("Invalid", "text/plain");
        }

        if (user.Banned || user.Banned == true)
            return Content("Invalid", "text/plain");

        return Content("Valid", "text/plain");
    }
}