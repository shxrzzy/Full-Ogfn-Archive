﻿using Helios.Classes;
using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Concurrent;
using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Helios.Controllers;

[ApiController]
public class DiscoveryController : ControllerBase
{
    private readonly IMemoryCache _cache;
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = null
    };
    
    private static readonly ConcurrentDictionary<string, (string content, DateTime lastModified)> FileCache = new();
    
    private static readonly object DefaultDiscoveryResponse = new
    {
        Panels = new[]
        {
            new
            {
                PanelName = "ByEpicNoBigBattle6Col",
                Pages = new[]
                {
                    new
                    {
                        results = new[]
                        {
                            DiscoveryManager.CreatePlaylist("playlist_defaultsolo",
                                "https://cdn2.unrealengine.com/solo-1920x1080-1920x1080-89393d12cea1.png"),
                                DiscoveryManager.CreatePlaylist("playlist_defaultduo",
                                "https://cdn2.unrealengine.com/duos-1920x1080-1920x1080-ae45aba9bfc7.png"),

                            DiscoveryManager.CreatePlaylist("playlist_playgroundv2",
                                "https://cdn2.unrealengine.com/fneco-28-00-creative-discovertiles-keyart-1920x1080-1920x1080-51c98fe78d7a.jpg"),
                        },
                        hasMore = false
                    }
                }
            }
        },
        TestCohorts = new[] { "Crystal" },
        ModeSets = new { }
    };

    private static readonly object SurfaceV1Response = new
    {
        panels = new[]
        {
            new
            {
                PanelName = "ByEpicNoBigBattle6Col",
                Pages = new[]
                {
                    new
                    {
                        results = new[]
                        {
                            new
                            {
                                lastVisited = (string?)null,
                                linkCode = "playlist_defaultsolo",
                                isFavorite = false,
                                globalCCU = 1
                            },
                            new
                            {
                                lastVisited = (string?)null,
                                linkCode = "playlist_defaultduo",
                                isFavorite = false,
                                globalCCU = 1
                            },
                            new
                            {
                                lastVisited = (string?)null,
                                linkCode = "playlist_trios",
                                isFavorite = false,
                                globalCCU = 1
                            },
                            new
                            {
                                lastVisited = (string?)null,
                                linkCode = "playlist_defaultsquad",
                                isFavorite = false,
                                globalCCU = 1
                            }
                        },
                        hasMore = false
                    }
                }
            }
        },
        testCohorts = new[] { "Crystal" }
    };

    private static readonly Lazy<string> DefaultDiscoveryJson = new(() => 
        JsonSerializer.Serialize(DefaultDiscoveryResponse, JsonOptions));
    
    private static readonly Lazy<string> SurfaceV1Json = new(() => 
        JsonSerializer.Serialize(SurfaceV1Response, JsonOptions));

    public DiscoveryController(IMemoryCache cache)
    {
        _cache = cache;
    }

    [HttpPost("/fortnite/api/game/v2/creative/discovery/surface/{accountId}")]
    public async Task<IActionResult> PostCreativeDiscoverySurface(string accountId, [FromHeader(Name = "User-Agent")] string userAgent)
    {
        try
        {
            Response.ContentType = "application/json";

            if (userAgent is null)
                return InternalErrors.InvalidUserAgent.Apply(HttpContext);

            var parsedUserAgent = UserAgentParser.Parse(userAgent);

            var cacheKey = $"user_{accountId}";
            User user;
            try
            {
                user = await _cache.GetOrCreateAsync(cacheKey, async entry =>
                {
                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5);
                    var userRepository = Constants.repositoryPool.For<User>();
                    return await userRepository.FindByColumnAsync("accountid", accountId);
                });
            }
            catch (Exception ex)
            {
                return InternalErrors.DatabaseError
                    .WithMessage($"Failed to retrieve user: {ex.Message}")
                    .Apply(HttpContext);
            }

            if (user == null)
                return AccountErrors.AccountNotFound(accountId)
                    .WithMessage($"User with id {accountId} not found")
                    .Apply(HttpContext);

            if (user.Banned)
                return AccountErrors.DisabledAccount.Apply(HttpContext);

            try
            {
                if (parsedUserAgent.Season >= 19)
                {
                    return Content(DefaultDiscoveryJson.Value, "application/json");
                }

                var playlists = new[]
                {
                    DiscoveryManager.CreatePlaylist("playlist_defaultsolo", "https://cdn2.unrealengine.com/solo-1920x1080-1920x1080-89393d12cea1.png"),
                    DiscoveryManager.CreatePlaylist("playlist_defaultduo", "https://cdn2.unrealengine.com/duos-1920x1080-1920x1080-ae45aba9bfc7.png"),
                    DiscoveryManager.CreatePlaylist("playlist_trios", "https://cdn2.unrealengine.com/trios-1920x1080-1920x1080-d5054bb9691a.jpg"),
                    DiscoveryManager.CreatePlaylist("playlist_defaultsquad", "https://cdn2.unrealengine.com/squads-1920x1080-1920x1080-095c0732502e.jpg")
                };

                var response = new
                {
                    Panels = new[]
                    {
                        new
                        {
                            PanelName = "ByEpicWoven",
                            Pages = new[]
                            {
                                new
                                {
                                    results = playlists,
                                    hasMore = false
                                }
                            }
                        }
                    },
                    TestCohorts = new[] { "Crystal" },
                    ModeSets = new { }
                };

                var options = new JsonSerializerOptions { PropertyNamingPolicy = null };
                string json = JsonSerializer.Serialize(response, options);
                return Content(json, "application/json");
            }
            catch (Exception ex)
            {
                return InternalErrors.SerializationError
                    .WithMessage($"Failed to serialize response: {ex.Message}")
                    .Apply(HttpContext);
            }
        }
        catch (Exception ex)
        {
            return InternalErrors.ServerError
                .WithMessage($"Unexpected error: {ex.Message}")
                .Apply(HttpContext);
        }
    }

    [HttpPost("/api/v1/assets/Fortnite/{release}/{netcl}")]
    public async Task<IActionResult> HandleDiscovery([FromHeader(Name = "User-Agent")] string userAgent)
    {
        try
        {
            Response.ContentType = "application/json";

            if (userAgent is null)
                return InternalErrors.InvalidUserAgent.Apply(HttpContext);

            var parsedUserAgent = UserAgentParser.Parse(userAgent);

            string filePath;
            try
            {
                if (parsedUserAgent.Season > 19)
                {
                    filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Discovery", "discovery_assetsv2.json");
                    //if (parsedUserAgent.Season >= 24)
                    //{

                    //}
                }
                else
                {
                    filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Discovery", "discovery_assetsv1.json");
                }

                string cachedContent = await GetCachedFileContent(filePath);
                if (cachedContent == null)
                    return BasicErrors.NotFound.WithMessage("File not found").Apply(HttpContext);

                return Content(cachedContent, "application/json");
            }
            catch (Exception ex)
            {
                return InternalErrors.UnknownError
                    .WithMessage($"Failed to handle discovery file: {ex.Message}")
                    .Apply(HttpContext);
            }
        }
        catch (Exception ex)
        {
            return InternalErrors.ServerError
                .WithMessage($"Unexpected error: {ex.Message}")
                .Apply(HttpContext);
        }
    }

    [HttpGet("/api/v1/assets/Fortnite/{release}/{netcl}/FortPlaylistAthena/{playlist}")]
    public async Task<IActionResult> GetPlaylistAssets(string release, string netcl, string playlist, [FromQuery] int revision)
    {
        try
        {
            Response.ContentType = "application/json";
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Discovery", "playlist_assets.json");

            string cachedContent;
            try
            {
                cachedContent = await GetCachedFileContent(filePath);
                if (cachedContent == null)
                    return BasicErrors.NotFound.WithMessage("File not found").Apply(HttpContext);
            }
            catch (Exception ex)
            {
                return InternalErrors.UnknownError
                    .WithMessage($"Failed to read playlist assets: {ex.Message}")
                    .Apply(HttpContext);
            }

            PlaylistResponse response;
            try
            {
                response = JsonSerializer.Deserialize<PlaylistResponse>(cachedContent);
                if (response == null)
                    return InternalErrors.DeserializationError
                        .WithMessage("Failed to deserialize playlist response")
                        .Apply(HttpContext);
            }
            catch (Exception ex)
            {
                return InternalErrors.DeserializationError
                    .WithMessage($"Failed to deserialize playlist: {ex.Message}")
                    .Apply(HttpContext);
            }

            try
            {
                response.Meta.Revision = revision;
                response.Meta.HeadRevision = revision;
                response.Meta.RevisedAt = DateTime.UtcNow.ToIsoUtcString();
                response.Meta.PromotedAt = DateTime.UtcNow.ToIsoUtcString();

                response.PlaylistAssetData.BEnableBackfillDuringWarmupPhase = true;
                response.PlaylistAssetData.BAllowBackfill = true;

                if (playlist.Contains("Duo"))
                {
                    response.PlaylistAssetData.MaxTeamSize = "2";
                    response.PlaylistAssetData.UIDisplayName.NativeString = "Duos";
                    response.PlaylistAssetData.RichPresenceAssetName = "duos";

                    for (int i = 0; i < response.PlaylistAssetData.ModifierList.Count; i++)
                    {
                        if (response.PlaylistAssetData.ModifierList[i].Contains("GameplayMod_Phoebe_DM_Solo"))
                        {
                            response.PlaylistAssetData.ModifierList[i] = response.PlaylistAssetData.ModifierList[i].Replace("GameplayMod_Phoebe_DM_Solo", "GameplayMod_Phoebe_DM_Duo");
                            break;
                        }
                    }
                }
                else if (playlist.Contains("Squad"))
                {
                    response.PlaylistAssetData.MaxTeamSize = "4";
                    response.PlaylistAssetData.UIDisplayName.NativeString = "Squads";
                    response.PlaylistAssetData.RichPresenceAssetName = "squads";
                }

                response.PlaylistAssetData.PlaylistName = playlist;
                response.PlaylistAssetData.PrimaryAssetId = $"FortPlaylistAthena:{playlist}";

                return Ok(response);
            }
            catch (Exception ex)
            {
                return InternalErrors.SerializationError
                    .WithMessage($"Failed to process playlist data: {ex.Message}")
                    .Apply(HttpContext);
            }
        }
        catch (Exception ex)
        {
            return InternalErrors.ServerError
                .WithMessage($"Unexpected error: {ex.Message}")
                .Apply(HttpContext);
        }
    }

    [HttpPost("/api/v1/discovery/surface/{accountId}")]
    public IActionResult SurfaceV1()
    {
        Response.ContentType = "application/json";
        return Content(SurfaceV1Json.Value, "application/json");
    }

    [HttpPost("/links/api/fn/mnemonic")]
    //[VerifyToken]
    public async Task<IActionResult> GetPlaylists()
    {
        try
        {
            var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Discovery", "discovery_frontend.json");

            string content;
            try
            {
                content = await GetCachedFileContent(filePath);
                if (content == null)
                    return BasicErrors.NotFound.WithMessage("File not found").Apply(HttpContext);
            }
            catch (Exception ex)
            {
                return InternalErrors.UnknownError
                    .WithMessage($"Failed to read discovery file: {ex.Message}")
                    .Apply(HttpContext);
            }

            return Content(content, "application/json");
        }
        catch (Exception ex)
        {
            return InternalErrors.ServerError
                .WithMessage($"Unexpected error: {ex.Message}")
                .Apply(HttpContext);
        }
    }

    [HttpGet("/links/api/fn/mnemonic/{playlistId}")]
    [VerifyToken]
    public async Task<IActionResult> GetPlaylistById(string playlistId)
    {
        try
        {
            var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Discovery", "discovery_frontend.json");

            string content;
            try
            {
                content = await GetCachedFileContent(filePath);
                if (content == null)
                    return BasicErrors.NotFound
                        .WithMessage("File 'discovery_frontend.json' not found.")
                        .Apply(HttpContext);
            }
            catch (Exception ex)
            {
                return InternalErrors.UnknownError
                    .WithMessage($"Failed to read discovery file: {ex.Message}")
                    .Apply(HttpContext);
            }

            JArray discoveryArray;
            try
            {
                var cacheKey = $"discovery_array_{filePath}";
                discoveryArray = await _cache.GetOrCreateAsync(cacheKey, async entry =>
                {
                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(10);
                    return JArray.Parse(content);
                });
            }
            catch (Exception ex)
            {
                return InternalErrors.DeserializationError
                    .WithMessage($"Failed to parse discovery data: {ex.Message}")
                    .Apply(HttpContext);
            }

            try
            {
                var matchedItem = discoveryArray
                    .Where(item => item["mnemonic"]?.ToString() == playlistId)
                    .FirstOrDefault();

                if (matchedItem != null)
                {
                    Response.ContentType = "application/json";
                    return Content(matchedItem.ToString(Formatting.None), "application/json");
                }

                return BasicErrors.NotFound
                    .WithMessage($"Mnemonic '{playlistId}' not found in discovery_frontend.json.")
                    .Apply(HttpContext);
            }
            catch (Exception ex)
            {
                return InternalErrors.UnknownError
                    .WithMessage($"Failed to handle playlist request: {ex.Message}")
                    .Apply(HttpContext);
            }
        }
        catch (Exception ex)
        {
            return InternalErrors.ServerError
                .WithMessage($"Unexpected error: {ex.Message}")
                .Apply(HttpContext);
        }
    }

    [HttpGet("/fortnite/api/discovery/accessToken/{version}")]
    public IActionResult GetDiscoveryToken(string version)
    {
        var pattern = @"^\+\+Fortnite\+Release-\d+\.\d+$";
        if (!Regex.IsMatch(version, pattern))
            return BasicErrors.BadRequest.WithMessage("Invalid version format.").Apply(HttpContext);

        var randomBytes = new byte[32];
        using (var rng = RandomNumberGenerator.Create())
        {
            rng.GetBytes(randomBytes);
        }
        var token = Convert.ToBase64String(randomBytes);


        return Ok(new
        {
            branchName = version,
            appId = "Fortnite",
            token
        });
    }

    [HttpPost("/api/v1/links/lock-status/{accountId}/check")]
    public async Task<IActionResult> CheckLinksLockStatus(string accountId)
    {
        string requestBody = await new StreamReader(Request.Body).ReadToEndAsync();

        JObject requestData;
        try
        {
            requestData = JObject.Parse(requestBody);
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        var results = new List<object>();

        if (requestData["linkCodes"] != null && requestData["linkCodes"].Type == JTokenType.Array)
        {
            foreach (var linkCode in requestData["linkCodes"])
            {
                results.Add(new
                {
                    playerId = accountId,
                    linkCode = (string)linkCode,
                    lockStatus = "UNLOCKED",
                    lockStatusReason = "NONE",
                    isVisible = true
                });
            }
        }

        var response = new
        {
            results,
            hasMore = false
        };

        return Ok(response);
    }

    [HttpPost("/api/v2/discovery/surface/{page}")]
    public async Task<IActionResult> GetDiscoverySurfacePage(string page)
    {
        if (page == "CreativeDiscoverySurface_Frontend")
        {
            var response = new
            {
                Panels = new object[]
                {
                new
                {
                    PanelName = "Homebar_V1",
                    FeatureTags = new[] { "col:5", "homebar" },
                    FirstPage = new
                    {
                        results = new object[]
                        {
                            new
                            {
                                lastVisited = (string)null,
                                linkCode = "playlist_playgroundv2",
                                isFavorite = false,
                                globalCCU = 1,
                                lockStatus = "UNLOCKED",
                                lockStatusReason = "NONE",
                                isVisible = true
                            },
                            new
                            {
                                lastVisited = (string)null,
                                linkCode = "playlist_defaultsolo",
                                isFavorite = false,
                                globalCCU = 1,
                                lockStatus = "UNLOCKED",
                                lockStatusReason = "NONE",
                                isVisible = true
                            },
                            new
                            {
                                lastVisited = (string)null,
                                linkCode = "playlist_defaultduo",
                                isFavorite = false,
                                globalCCU = 1,
                                lockStatus = "UNLOCKED",
                                lockStatusReason = "NONE",
                                isVisible = true
                            },
                            new
                            {
                                lastVisited = (string)null,
                                linkCode = "playlist_trios",
                                isFavorite = false,
                                globalCCU = 1,
                                lockStatus = "UNLOCKED",
                                lockStatusReason = "NONE",
                                isVisible = true
                            },
                            new
                            {
                                lastVisited = (string)null,
                                linkCode = "playlist_defaultsquad",
                                isFavorite = false,
                                globalCCU = 1,
                                lockStatus = "UNLOCKED",
                                lockStatusReason = "NONE",
                                isVisible = true
                            }
                        },
                        hasMore = false,
                        panelTargetName = (string)null
                    },
                    PanelType = "CuratedList",
                    PlayHistoryType = (string)null
                },
                new
                {
                    PanelName = "ByEpicWoven",
                    FeatureTags = new[] { "col:5" },
                    FirstPage = new
                    {
                        results = new object[]
                        {
                            new
                            {
                                lastVisited = (string)null,
                                linkCode = "playlist_playgroundv2",
                                isFavorite = false,
                                globalCCU = 1,
                                lockStatus = "UNLOCKED",
                                lockStatusReason = "NONE",
                                isVisible = true
                            },
                            new
                            {
                                lastVisited = (string)null,
                                linkCode = "playlist_defaultsolo",
                                isFavorite = false,
                                globalCCU = 1,
                                lockStatus = "UNLOCKED",
                                lockStatusReason = "NONE",
                                isVisible = true
                            },
                            new
                            {
                                lastVisited = (string)null,
                                linkCode = "playlist_defaultduo",
                                isFavorite = false,
                                globalCCU = 1,
                                lockStatus = "UNLOCKED",
                                lockStatusReason = "NONE",
                                isVisible = true
                            },
                            new
                            {
                                lastVisited = (string)null,
                                linkCode = "playlist_trios",
                                isFavorite = false,
                                globalCCU = 1,
                                lockStatus = "UNLOCKED",
                                lockStatusReason = "NONE",
                                isVisible = true
                            },
                            new
                            {
                                lastVisited = (string)null,
                                linkCode = "playlist_defaultsquad",
                                isFavorite = false,
                                globalCCU = 1,
                                lockStatus = "UNLOCKED",
                                lockStatusReason = "NONE",
                                isVisible = true
                            }
                        },
                        hasMore = false,
                        panelTargetName = (string)null
                    },
                    Pages = new object[]
                    {
                        new
                        {
                            results = new object[]
                            {
                                new
                                {
                                    linkData = new
                                    {
                                        @namespace = "fn",
                                        accountId = "epic",
                                        creatorName = "Epic",
                                        mnemonic = "playlist_playgroundv2",
                                        linkType = "BR:Playlist",
                                        version = 95,
                                        active = false,
                                        disabled = true,
                                        created = "2021-10-01T00:56:41.202Z",
                                        published = "2021-08-03T15:27:18.172Z",
                                        moderationStatus = "Approved",
                                        discoveryIntent = "PUBLIC",
                                        descriptionTags = new string[0],
                                        metadata = new
                                        {
                                            blog_category = "creative",
                                            image_url = "https://cdn2.unrealengine.com/fneco-28-00-creative-discovertiles-keyart-1920x1080-1920x1080-51c98fe78d7a.jpg",
                                            image_urls = new
                                            {
                                                url_s = "https://cdn2.unrealengine.com/fneco-28-00-creative-discovertiles-keyart-480x270-480x270-93a3c0ed804d.jpg",
                                                url_xs = "https://cdn2.unrealengine.com/fneco-28-00-creative-discovertiles-keyart-256x144-256x144-b0dbc3859925.jpg",
                                                url_m = "https://cdn2.unrealengine.com/fneco-28-00-creative-discovertiles-keyart-640x480-640x480-927979371ccd.jpg",
                                                url = "https://cdn2.unrealengine.com/fneco-28-00-creative-discovertiles-keyart-1920x1080-1920x1080-51c98fe78d7a.jpg"
                                            },
                                            matchmaking = new
                                            {
                                                override_playlist = "playlist_playgroundv2"
                                            },
                                            video_vuid = "pOQbjpyNSnZNptoned",
                                            title = "Creative",
                                            alt_title = new
                                            {
                                                de = "Kreativmodus",
                                                ru = "Творческий режим",
                                                ko = "포크리",
                                                pt_BR = "Modo Criativo",
                                                zh_hans = "创意模式",
                                                en = "Creative",
                                                it = "Modalità Creativa",
                                                fr = "Mode Créatif",
                                                zh_CN = "",
                                                es = "Modo Creativo",
                                                es_MX = "Modo Creativo",
                                                zh = "",
                                                ar = "الإبداعي",
                                                zh_Hant = "",
                                                ja = "クリエイティブ",
                                                pl = "Tryb kreatywny",
                                                es_419 = "Modo Creativo",
                                                tr = "Kreatif"
                                            },
                                            alt_tagline = new
                                            {
                                                de = "Suche andere Spieler, um mit ihnen die besten Spiele der Community zu spielen!",
                                                ru = "Объединяйтесь с другими игроками, чтобы вместе проходить лучшие игры, созданные сообществом!",
                                                ko = "커뮤니티가 제작한 인기 게임들을 다른 플레이어들과 함께 플레이해 보세요!",
                                                pt_BR = "Entre em grupos com outros jogadores und divirta-se nos melhores jogos criados pela comunidade!",
                                                zh_hans = "匹配其他玩家，共同畅玩由社区创作的优质游戏！",
                                                it = "Usa il Matchmaking per trovare giocatori e divertirti con i migliori giochi della community!",
                                                fr = "Lancez le matchmaking et jouez aux meilleurs jeux créés par la communauté !",
                                                es = "¡Únete a otros y juega a los mejores modos creados por la comunidad!",
                                                ar = "نظّم المواجهة مع الآخرين والعب أفضل الألعاب التي صنعها المجتمع!",
                                                ja = "他のプレイヤーとマッチメイキングして、コミュニティ制作の最高のゲームをプレイしよう！",
                                                pl = "Dobierz innych graczy i razem wypróbujcie najlepsze gry autorstwa graczy!",
                                                es_419 = "¡Emparéjate con otros y juega los mejores modos creados por la comunidad!",
                                                tr = "Diğer oyuncularla eşleşerek topluluğun hazırladığı en güzel oyunları oyna!"
                                            },
                                            product_tag = "Product.FNE.Hub",
                                            feature_flags = new[] { "bypass_rating_check" },
                                            tagline = "Matchmake with others and play the best games made by the community!",
                                            square_image_urls = new
                                            {
                                                url = "https://cdn2.unrealengine.com/fneco-28-00-creative-discovertiles-keyart-480x480-480x480-02fed98ce8b8.jpg"
                                            }
                                        }
                                    },
                                    lastVisited = (string)null,
                                    linkCode = "playlist_playgroundv2",
                                    isFavorite = false
                                },
                                new
                                {
                                    linkData = new
                                    {
                                        @namespace = "fn",
                                        accountId = "epic",
                                        creatorName = "Epic",
                                        mnemonic = "playlist_defaultsolo",
                                        linkType = "BR:Playlist",
                                        version = 95,
                                        active = true,
                                        disabled = false,
                                        created = "2021-10-01T00:56:43.870Z",
                                        published = "2023-11-03T08:26:11.189Z",
                                        moderationStatus = "Unmoderated",
                                        descriptionTags = new string[0],
                                        metadata = new
                                        {
                                            alt_title = new
                                            {
                                                de = "Solo",
                                                ru = "В одиночку",
                                                ko = "솔로",
                                                pt_BR = "Solo",
                                                en = "Solo",
                                                it = "Singolo",
                                                fr = "Solo",
                                                zh_CN = "",
                                                es = "En solitario",
                                                es_MX = "En solitario",
                                                zh = "",
                                                ar = "فردي",
                                                zh_Hant = "",
                                                ja = "ソロ",
                                                pl = "Solo",
                                                es_419 = "En solitario",
                                                tr = "Tekli"
                                            },
                                            image_url = "https://static.wikia.nocookie.net/fortnite/images/c/c7/Solo_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                            product_tag = "Product.BR.Build.Solo",
                                            image_urls = new
                                            {
                                                url_s = "https://static.wikia.nocookie.net/fortnite/images/c/c7/Solo_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url_xs = "https://static.wikia.nocookie.net/fortnite/images/c/c7/Solo_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url_m = "https://static.wikia.nocookie.net/fortnite/images/c/c7/Solo_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url = "https://static.wikia.nocookie.net/fortnite/images/c/c7/Solo_%28C4S2%29_-_Gamemode_-_Fortnite.jpg"
                                            },
                                            matchmaking = new
                                            {
                                                override_playlist = "playlist_defaultsolo"
                                            },
                                            title = "Solo"
                                        }
                                    },
                                    lastVisited = (string)null,
                                    linkCode = "playlist_defaultsolo",
                                    isFavorite = false
                                },
                                new
                                {
                                    linkData = new
                                    {
                                        @namespace = "fn",
                                        accountId = "epic",
                                        creatorName = "Epic",
                                        mnemonic = "playlist_defaultduo",
                                        linkType = "BR:Playlist",
                                        version = 95,
                                        active = true,
                                        disabled = false,
                                        created = "2021-10-01T00:56:46.389Z",
                                        published = "2023-11-03T08:25:34.690Z",
                                        moderationStatus = "Unmoderated",
                                        descriptionTags = new string[0],
                                        metadata = new
                                        {
                                            alt_title = new
                                            {
                                                de = "Duo",
                                                ru = "Парные сражения",
                                                ko = "듀오",
                                                pt_BR = "Duplas",
                                                en = "Duo",
                                                it = "Coppie",
                                                fr = "Duos",
                                                zh_CN = "",
                                                es = "Dúos",
                                                es_MX = "En dúo",
                                                zh = "",
                                                ar = "ثنائي",
                                                zh_Hant = "",
                                                ja = "デュオ",
                                                pl = "Pary",
                                                es_419 = "En dúo",
                                                tr = "Çiftli"
                                            },
                                            image_url = "https://static.wikia.nocookie.net/fortnite/images/c/cb/Duos_%28Ranked_-_C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                            product_tag = "Product.BR.Build.Duo",
                                            image_urls = new
                                            {
                                                url_s = "https://static.wikia.nocookie.net/fortnite/images/c/cb/Duos_%28Ranked_-_C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url_xs = "https://static.wikia.nocookie.net/fortnite/images/c/cb/Duos_%28Ranked_-_C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url_m = "https://static.wikia.nocookie.net/fortnite/images/c/cb/Duos_%28Ranked_-_C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url = "https://static.wikia.nocookie.net/fortnite/images/c/cb/Duos_%28Ranked_-_C4S2%29_-_Gamemode_-_Fortnite.jpg"
                                            },
                                            matchmaking = new
                                            {
                                                override_playlist = "playlist_defaultduo"
                                            },
                                            title = "Duo"
                                        }
                                    },
                                    lastVisited = (string)null,
                                    linkCode = "playlist_defaultduo",
                                    isFavorite = false
                                },
                                new
                                {
                                    linkData = new
                                    {
                                        @namespace = "fn",
                                        accountId = "epic",
                                        creatorName = "Epic",
                                        mnemonic = "playlist_trios",
                                        linkType = "BR:Playlist",
                                        version = 95,
                                        active = true,
                                        disabled = false,
                                        created = "2021-10-01T00:56:45.053Z",
                                        published = "2023-11-03T08:28:43.403Z",
                                        moderationStatus = "Unmoderated",
                                        descriptionTags = new string[0],
                                        metadata = new
                                        {
                                            alt_title = new
                                            {
                                                de = "Trio",
                                                ru = "Трио",
                                                ko = "트리오",
                                                pt_BR = "Trios",
                                                en = "Trio",
                                                it = "Terzetti",
                                                fr = "Trios",
                                                zh_CN = "",
                                                es = "Tríos",
                                                es_MX = "En trío",
                                                zh = "",
                                                ar = "ثلاثي",
                                                zh_Hant = "",
                                                ja = "トリオ",
                                                pl = "Trójki",
                                                es_419 = "En trío",
                                                tr = "Üçlü"
                                            },
                                            image_url = "https://static.wikia.nocookie.net/fortnite/images/7/7c/Trios_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                            product_tag = "Product.BR.Build.Trio",
                                            image_urls = new
                                            {
                                                url_s = "https://static.wikia.nocookie.net/fortnite/images/7/7c/Trios_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url_xs = "https://static.wikia.nocookie.net/fortnite/images/7/7c/Trios_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url_m = "https://static.wikia.nocookie.net/fortnite/images/7/7c/Trios_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url = "https://static.wikia.nocookie.net/fortnite/images/7/7c/Trios_%28C4S2%29_-_Gamemode_-_Fortnite.jpg"
                                            },
                                            matchmaking = new
                                            {
                                                override_playlist = "playlist_trios"
                                            },
                                            title = "Trio"
                                        }
                                    },
                                    lastVisited = (string)null,
                                    linkCode = "playlist_trios",
                                    isFavorite = false
                                },
                                new
                                {
                                    linkData = new
                                    {
                                        @namespace = "fn",
                                        accountId = "epic",
                                        creatorName = "Epic",
                                        mnemonic = "playlist_defaultsquad",
                                        linkType = "BR:Playlist",
                                        version = 95,
                                        active = true,
                                        disabled = false,
                                        created = "2021-10-01T00:56:42.938Z",
                                        published = "2023-11-03T08:25:06.100Z",
                                        moderationStatus = "Unmoderated",
                                        descriptionTags = new string[0],
                                        metadata = new
                                        {
                                            alt_title = new
                                            {
                                                de = "Team",
                                                ru = "Бои отрядов",
                                                ko = "스쿼드",
                                                pt_BR = "Esquadrões",
                                                en = "Squad",
                                                it = "Squadre",
                                                fr = "Sections",
                                                zh_CN = "",
                                                es = "Escuadrones",
                                                es_MX = "En escuadrón",
                                                zh = "",
                                                ar = "فِرق",
                                                zh_Hant = "",
                                                ja = "スクワッド",
                                                pl = "Oddziały",
                                                es_419 = "En escuadrón",
                                                tr = "Ekipli"
                                            },
                                            image_url = "https://static.wikia.nocookie.net/fortnite/images/a/ab/Squads_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                            product_tag = "Product.BR.Build.Squad",
                                            image_urls = new
                                            {
                                                url_s = "https://static.wikia.nocookie.net/fortnite/images/a/ab/Squads_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url_xs = "https://static.wikia.nocookie.net/fortnite/images/a/ab/Squads_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url_m = "https://static.wikia.nocookie.net/fortnite/images/a/ab/Squads_%28C4S2%29_-_Gamemode_-_Fortnite.jpg",
                                                url = "https://static.wikia.nocookie.net/fortnite/images/a/ab/Squads_%28C4S2%29_-_Gamemode_-_Fortnite.jpg"
                                            },
                                            tagline = "",
                                            matchmaking = new
                                            {
                                                override_playlist = "playlist_defaultsquad"
                                            },
                                            title = "Squad"
                                        }
                                    },
                                    lastVisited = (string)null,
                                    linkCode = "playlist_defaultsquad",
                                    isFavorite = false
                                }
                            },
                            hasMore = false
                        }
                    },
                    PanelType = "AnalyticsList",
                    PlayHistoryType = (string)null
                }
                },
                TestCohorts = new[] { "Crystal" },
                ModeSets = new { }
            };

            var options = new JsonSerializerOptions { PropertyNamingPolicy = null };
            string json = JsonSerializer.Serialize(response, options);
            return Content(json, "application/json");
        }

        return BasicErrors.NotFound.WithMessage($"Page {page} not found.").Apply(HttpContext);
    }

    [HttpGet("/links/api/fn/mnemonic/{playlist}/related")]
    //[VerifyToken]
    public async Task<IActionResult> GetRelatedPlaylists(string playlist)
    {
        try
        {
            var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Discovery", "discovery_frontend.json");

            string content;
            try
            {
                content = await GetCachedFileContent(filePath);
                if (content == null)
                    return BasicErrors.NotFound
                        .WithMessage("File 'discovery_frontend.json' not found.")
                        .Apply(HttpContext);
            }
            catch (Exception ex)
            {
                return InternalErrors.UnknownError
                    .WithMessage($"Failed to read discovery file: {ex.Message}")
                    .Apply(HttpContext);
            }

            JArray discoveryArray;
            try
            {
                var cacheKey = $"discovery_array_{filePath}";
                discoveryArray = await _cache.GetOrCreateAsync(cacheKey, async entry =>
                {
                    entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(10);
                    return JArray.Parse(content);
                });
            }
            catch (Exception ex)
            {
                return InternalErrors.DeserializationError
                    .WithMessage($"Failed to parse discovery data: {ex.Message}")
                    .Apply(HttpContext);
            }

            try
            {
                var parentLinks = new object[0];
                var links = new Dictionary<string, JToken>();

                if (!string.IsNullOrEmpty(playlist))
                {
                    var matchedItem = discoveryArray
                        .Where(item => item["mnemonic"]?.ToString() == playlist)
                        .FirstOrDefault();

                    if (matchedItem != null)
                    {
                        links[playlist] = matchedItem;
                    }
                }

                var response = new
                {
                    parentLinks = parentLinks,
                    links = links
                };

                Response.ContentType = "application/json";
                string json = JsonConvert.SerializeObject(response, Formatting.None);
                return Content(json, "application/json");
            }
            catch (Exception ex)
            {
                return InternalErrors.UnknownError
                    .WithMessage($"Failed to process related playlists request: {ex.Message}")
                    .Apply(HttpContext);
            }
        }
        catch (Exception ex)
        {
            return InternalErrors.ServerError
                .WithMessage($"Unexpected error: {ex.Message}")
                .Apply(HttpContext);
        }
    }

    [HttpPost("/api/v1/links/favorites/{accountId}/check")]
    public IActionResult GetLinksFavorites(string accountId)
    {
        return Ok(new
        {
            results = new object[] { },
            hasMore = false
        });
    }

    private async Task<string?> GetCachedFileContent(string filePath)
    {
        try
        {
            if (!System.IO.File.Exists(filePath))
                return null;

            var fileInfo = new FileInfo(filePath);
            var lastModified = fileInfo.LastWriteTime;

            if (FileCache.TryGetValue(filePath, out var cached) && cached.lastModified >= lastModified)
            {
                return cached.content;
            }

            string content;
            try
            {
                content = await System.IO.File.ReadAllTextAsync(filePath);
            }
            catch (Exception ex)
            {
                return null;
            }

            FileCache.AddOrUpdate(filePath, (content, lastModified), (key, oldValue) => (content, lastModified));
            return content;
        }
        catch (Exception)
        {
            return null;
        }
    }
}