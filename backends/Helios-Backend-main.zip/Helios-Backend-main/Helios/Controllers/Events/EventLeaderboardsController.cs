using Helios.Classes.Tournaments;
using Helios.Classes.Tournaments.DBInterfaces;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Tournaments;
using Helios.Managers;
using Helios.Sockets.IgnisClient.Classes;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Middleware.Attributes;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Org.BouncyCastle.Utilities.Collections;
using Sentry.Protocol;
using System.Text.RegularExpressions;
using static Org.BouncyCastle.Asn1.Cmp.Challenge;

namespace Helios.Controllers.Events;

[ApiController]
[Route("/api/v1/leaderboards/{appId}/")]
public class EventLeaderboardController : ControllerBase
{
    private readonly Repository<TournamentDedicatedServer> eventDedicatedServers;
    private readonly Repository<TournamentHistory> eventHistoryRepository;
    private readonly Repository<Database.Tables.Account.User> userRepository;

    public EventLeaderboardController()
    {
        eventDedicatedServers = Constants.repositoryPool.For<TournamentDedicatedServer>();
        eventHistoryRepository = Constants.repositoryPool.For<TournamentHistory>();
        userRepository = Constants.repositoryPool.For<Database.Tables.Account.User>();
    }

    [HttpGet("{eventId}/{windowId}/{accountId}")]
    public async Task<IActionResult> GetEventLeaderboardForAccount(string eventId, string windowId, string accountId)
    {
        try
        {
            if (string.IsNullOrEmpty(accountId))
                return AccountErrors.AccountNotFound(accountId)
                    .WithMessage($"User with id {accountId} not found")
                    .Apply(HttpContext);

            if (string.IsNullOrEmpty(eventId) || string.IsNullOrEmpty(windowId))
                return BasicErrors.BadRequest.WithMessage("Invalid request.").Apply(HttpContext);

            var userAgent = Request.Headers["User-Agent"].ToString();
            if (string.IsNullOrEmpty(userAgent))
                return InternalErrors.InvalidUserAgent.Apply(HttpContext);

            var userAgentInfo = UserAgentParser.Parse(userAgent);
            if (userAgentInfo == null)
                return InternalErrors.InvalidUserAgent.Apply(HttpContext);

            var tasks = new Task[]
            {
                userRepository.FindByColumnAsync("accountid", accountId),
                eventDedicatedServers.FindAllByColumnsAsync(new Dictionary<string, object> { { "eventid", eventId } }),
                eventHistoryRepository.FindAllByColumnsAsync(new Dictionary<string, object>
                {
                    { "accountid", accountId },
                    { "eventid", eventId }
                })
            };

            await Task.WhenAll(tasks);

            var user = await (Task<User>)tasks[0];
            var dedicatedPlayers = await (Task<List<TournamentDedicatedServer>>)tasks[1];
            var playerHistory = await (Task<List<TournamentHistory>>)tasks[2];

            if (user == null)
                return AccountErrors.AccountNotFound(accountId)
                    .WithMessage($"User with id {accountId} not found")
                    .Apply(HttpContext);

            if (user.Banned)
                return AccountErrors.DisabledAccount.Apply(HttpContext);

            if (dedicatedPlayers == null || dedicatedPlayers.Count == 0)
                return Ok(new List<object>());

            if (playerHistory == null || playerHistory.Count == 0)
                return Ok(new List<object>());

            var historyLookup = new Dictionary<string, TournamentHistory>();
            foreach (var history in playerHistory)
            {
                historyLookup[history.AccountId] = history;
            }
            var leaderboardEntries = new List<dynamic>();

            foreach (var player in dedicatedPlayers)
            {
                historyLookup.TryGetValue(player.AccountId, out var historyEntry);

                var placementStat = historyEntry?.PlacementStatIndex ?? new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 };
                var teamElimsStat = historyEntry?.TeamElimsStatIndex ?? new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 };
                var victoryRoyaleStat = historyEntry?.VictoryRoyaleStatIndex ?? new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 };
                var timeAliveStat = historyEntry?.TimeAliveStatIndex ?? new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 };
                var matchesPlayedStat = historyEntry?.MatchesPlayedStatIndex ?? new DB_EventStatIndex { TimesAchieved = 0, PointsEarned = 0 };

                var sessionHistory = (player.Matches ?? new List<string>()).Select(sessionId => new
                {
                    sessionId,
                    endTime = historyEntry?.SessionEndTimes?.GetValueOrDefault(sessionId) ?? DateTime.UtcNow.ToIsoUtcString(),
                    trackedStats = new Dictionary<string, DB_EventStatIndex>
                    {
                        { $"PLACEMENT_STAT_INDEX:{placementStat.PointsEarned}", placementStat },
                        { $"TEAM_ELIMS_STAT_INDEX:{teamElimsStat.PointsEarned}", teamElimsStat },
                        { $"VICTORY_ROYALE_STAT:{victoryRoyaleStat.PointsEarned}", victoryRoyaleStat },
                        { $"TIME_ALIVE_STAT:{timeAliveStat.PointsEarned}", timeAliveStat },
                        { $"MATCHES_PLAYED_STAT:{matchesPlayedStat.TimesAchieved}", matchesPlayedStat }
                    }
                }).ToList();

                leaderboardEntries.Add(new
                {
                    accountId = player.AccountId,
                    teamAccountIds = player.Teammates ?? new List<string>(),
                    pointsEarned = player.PointsEarned,
                    sessionHistory,
                    teamId = player.TeamId,
                    placementStat,
                    teamElimsStat,
                    victoryRoyaleStat
                });
            }

            leaderboardEntries = leaderboardEntries
                .OrderByDescending(e => e.pointsEarned)
                .ToList();

            int totalPlayers = leaderboardEntries.Count;
            var finalEntries = new List<object>();

            for (int i = 0; i < totalPlayers; i++)
            {
                var entry = leaderboardEntries[i];
                int rank = i + 1;
                double percentile = ((double)(totalPlayers - i) / totalPlayers) * 100;

                finalEntries.Add(new
                {
                    gameId = "Fortnite",
                    eventId,
                    eventWindowId = windowId,
                    teamAccountIds = entry.teamAccountIds,
                    pointsEarned = entry.pointsEarned,
                    score = entry.pointsEarned,
                    rank,
                    percentile = Math.Round(percentile, 2),
                    tokens = new List<string>
                    {
                        "GroupIdentity_GeoIdentity_australia",
                        "GroupIdentity_GeoIdentity_canada",
                        "GroupIdentity_GeoIdentity_global",
                        "GroupIdentity_GeoIdentity_ireland",
                        "GroupIdentity_GeoIdentity_spain",
                        "GroupIdentity_GeoIdentity_unitedstates"
                    },
                    teamId = entry.teamId,
                    liveSessionId = string.Empty,
                    pointBreakdown = new Dictionary<string, DB_EventStatIndex>
                    {
                        { $"PLACEMENT_STAT_INDEX:{entry.placementStat.PointsEarned}", entry.placementStat },
                        { $"TEAM_ELIMS_STAT_INDEX:{entry.teamElimsStat.PointsEarned}", entry.teamElimsStat },
                        { $"VICTORY_ROYALE_STAT:{entry.victoryRoyaleStat.PointsEarned}", entry.victoryRoyaleStat }
                    },
                    sessionHistory = entry.sessionHistory
                });
            }

            return Ok(new
            {
                gameId = "Fortnite",
                eventId,
                eventWindowId = windowId,
                page = 0,
                totalPages = 1,
                updatedTime = DateTime.UtcNow.ToIsoUtcString(),
                entries = finalEntries,
                liveSessions = new Dictionary<string, object>()
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Error while fetching leaderboard: {ex}");
            return InternalErrors.ServerError.WithMessage("Internal Server Error").Apply(HttpContext);
        }
    }
}
