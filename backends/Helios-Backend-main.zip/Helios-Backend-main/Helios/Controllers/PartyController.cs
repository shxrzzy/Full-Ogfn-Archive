﻿using Helios.Classes.Party.SquadAssignments;
using Helios.Classes.Storefront;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Party;
using Helios.Database.Tables.XMPP;
using Helios.Managers;
using Helios.Socket;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Extensions;
using Helios.Utilities.Middleware.Attributes;
using Helios.Utilities.Tokens;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Runtime;
using System.Text.Json;
using System.Xml.Linq;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Helios.Controllers;

[ApiController]
[Route("/party/api/v1/")]
public class PartyController : ControllerBase
{
    private Repository<Parties> pRepo = Constants.repositoryPool.For<Parties>(false);
    private Repository<Invites> iRepo = Constants.repositoryPool.For<Invites>(false);
    private Repository<Friends> fRepo = Constants.repositoryPool.For<Friends>(false);
    private Repository<Pings> pingsRepo = Constants.repositoryPool.For<Pings>(false);
    private Repository<User> uRepo = Constants.repositoryPool.For<User>(false);

    private static T? SafeDeserialize<T>(string? json) where T : class
    {
        if (string.IsNullOrEmpty(json))
            return default(T);

        try
        {
            return JsonSerializer.Deserialize<T>(json);
        }
        catch (System.Text.Json.JsonException ex)
        {
            Logger.Error($"Failed to deserialize JSON: {ex.Message}. JSON: {json}");
            return default(T);
        }
        catch (Exception ex)
        {
            Logger.Error($"Unexpected error during JSON deserialization: {ex.Message}");
            return default(T);
        }
    }

    [HttpGet("Fortnite/user/{accountId}")]
    public async Task<IActionResult> GetUser(string accountId)
    {
        try
        {
            var parties = await pRepo.FindAllByTableAsync();

            var currentParties = parties
                .Where(p => !string.IsNullOrEmpty(p.Members))
                .Where(p =>
                {
                    try
                    {
                        var members = SafeDeserialize<List<PartyMember>>(p.Members);
                        return members?.Any(m => m.AccountId == accountId) == true;
                    }
                    catch
                    {
                        return false;
                    }
                })
                .ToList();

            var invites = await iRepo.FindAllAsync(new Invites { SentBy = accountId });
            var pings = await pingsRepo.FindAllAsync(new Pings { SentBy = accountId });

            var formattedInvites = invites.Select(x => new
            {
                party_id = x.PartyId,
                meta = SafeDeserialize<Dictionary<string, string>>(x.Meta) ?? new Dictionary<string, string>(),
                sent_by = x.SentBy,
                sent_to = x.SentTo,
                sent_at = x.SentAt,
                updated_at = x.UpdatedAt,
                expires_at = x.ExpiresAt,
                status = x.Status,
            });

            var formattedPings = pings.Select(x => new
            {
                sent_by = x.SentBy,
                sent_to = x.SentTo,
                sent_at = x.SentAt,
                meta = SafeDeserialize<Dictionary<string, string>>(x.Meta) ?? new Dictionary<string, string>(),
                expires_at = x.ExpiresAt
            });

            return Ok(new
            {
                current = currentParties,
                pending = Array.Empty<object>(),
                invites = formattedInvites,
                pings = formattedPings
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Error getting user {accountId}: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    [HttpPost("Fortnite/parties")]
    public async Task<IActionResult> CreateOrUpdateParty()
    {
        try
        {
            string requestBody = await new StreamReader(Request.Body).ReadToEndAsync();
            JObject? requestData;

            try
            {
                requestData = JObject.Parse(requestBody);
            }
            catch
            {
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            string timestamp = DateTime.UtcNow.ToIsoUtcString();
            var joinInfo = requestData["join_info"];
            if (joinInfo == null)
                return MCPErrors.InvalidPayload.WithMessage("Missing join_info.").Apply(HttpContext);

            var connectionId = joinInfo.SelectToken("connection.id")?.ToString();
            if (string.IsNullOrEmpty(connectionId))
                return MCPErrors.InvalidPayload.WithMessage("Missing connection.id.").Apply(HttpContext);

            var accountId = connectionId.Split("@prod")[0];
            var yieldLeadership = joinInfo.SelectToken("connection.yield_leadership")?.Value<bool>() ?? false;
            var joinInfoMeta = joinInfo.SelectToken("meta") is JToken metaToken
                ? PartyManager.ConvertJTokenToObject(metaToken)
                : joinInfo.SelectToken("meta")?.ToObject<Dictionary<string, object>>() ?? new Dictionary<string, object>();

            var joinInfoConnectionMeta = joinInfo.SelectToken("connection.meta") is JToken connMetaToken
                ? PartyManager.ConvertJTokenToObject(connMetaToken)
                : joinInfo.SelectToken("connection.meta")?.ToObject<Dictionary<string, object>>() ?? new Dictionary<string, object>();

            var partyMemberConnection = new PartyMemberConnection
            {
                Id = connectionId,
                ConnectedAt = timestamp,
                UpdatedAt = timestamp,
                YieldLeadership = yieldLeadership,
                Meta = joinInfoConnectionMeta
            };

            var partyMember = new PartyMember
            {
                AccountId = accountId,
                Meta = joinInfoMeta,
                Connections = JsonSerializer.Serialize(new List<PartyMemberConnection> { partyMemberConnection }),
                Revision = 0,
                UpdatedAt = timestamp,
                JoinedAt = timestamp,
                Role = "CAPTAIN"
            };

            string partyId = Guid.NewGuid().ToString().Replace("-", "");

            var config = requestData["config"]?.ToObject<Dictionary<string, dynamic>>() ?? new Dictionary<string, dynamic>();
            var meta = requestData["meta"]?.ToObject<Dictionary<string, string>>() ?? new Dictionary<string, string>();

            var newParty = new Parties
            {
                PartyId = partyId,
                CreatedAt = timestamp,
                UpdatedAt = timestamp,
                Config = JsonSerializer.Serialize(config),
                Members = JsonSerializer.Serialize(new List<PartyMember> { partyMember }),
                Meta = JsonSerializer.Serialize(meta),
                Applicants = Array.Empty<string>(),
                Revision = 0,
                Intentions = Array.Empty<string>()
            };

            await pRepo.SaveAsync(newParty);

            return Ok(new
            {
                id = partyId,
                created_at = timestamp,
                updated_at = timestamp,
                config,
                members = new List<object>
                {
                    new
                    {
                        account_id = accountId,
                        meta = joinInfoMeta,
                        connections = new List<PartyMemberConnection> { partyMemberConnection },
                        revision = 0,
                        updated_at = timestamp,
                        joined_at = timestamp,
                        role = "CAPTAIN"
                    }
                },
                meta,
                invites = Array.Empty<Invites>(),
                applicants = Array.Empty<string>(),
                revision = 0,
                intentions = Array.Empty<string>()
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Error creating party: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    [HttpGet("Fortnite/parties/{partyId}")]
    public async Task<IActionResult> GetPartyById(string partyId)
    {
        try
        {
            var party = await pRepo.FindByColumnAsync("partyid", partyId, useCache: false);

            if (party == null)
            {
                Logger.Error($"Party {partyId} not found.");
                return PartyErrors.PartyNotFound.WithMessage($"Party {partyId} does not exist.").Apply(HttpContext);
            }

            var partyConfig = SafeDeserialize<Dictionary<string, dynamic>>(party.Config) ?? new Dictionary<string, dynamic>();
            var members = SafeDeserialize<List<PartyMember>>(party.Members) ?? new List<PartyMember>();
            var meta = SafeDeserialize<Dictionary<string, string>>(party.Meta) ?? new Dictionary<string, string>();

            var memberAccountIds = members.Select(m => m.AccountId).ToList();
            var invites = memberAccountIds.Any()
                ? await iRepo.FindAllByColumnAsync("sentby", memberAccountIds, useCache: false)
                : new List<Invites>();

            var memberList = members.Select(member => new
            {
                account_id = member.AccountId,
                meta = member.Meta,
                connections = SafeDeserialize<List<PartyMemberConnection>>(member.Connections) ?? new List<PartyMemberConnection>(),
                revision = member.Revision,
                updated_at = member.UpdatedAt,
                joined_at = member.JoinedAt,
                role = member.Role
            }).ToList();

            return Ok(new
            {
                id = party.PartyId,
                created_at = party.CreatedAt,
                updated_at = party.UpdatedAt,
                config = partyConfig,
                members = memberList,
                meta,
                invites,
                applicants = party.Applicants,
                revision = party.Revision,
                intentions = party.Intentions
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Error getting party {partyId}: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    [HttpPatch("Fortnite/parties/{partyId}")]
    public async Task<IActionResult> ModifyFortniteParty(string partyId)
    {
        try
        {
            var party = await pRepo.FindByColumnAsync("partyid", partyId);
            if (party == null)
                return PartyErrors.PartyNotFound.Apply(HttpContext);

            JObject? requestData;
            try
            {
                requestData = JObject.Parse(await new StreamReader(Request.Body).ReadToEndAsync());
            }
            catch
            {
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            var partyConfig = SafeDeserialize<Dictionary<string, JsonElement>>(party.Config) ?? new Dictionary<string, JsonElement>();
            var config = requestData["config"]?.ToObject<Dictionary<string, object>>();
            if (config != null)
            {
                foreach (var (key, value) in config)
                {
                    partyConfig[key] = JsonSerializer.SerializeToElement(value);
                }
            }

            var partyMeta = SafeDeserialize<Dictionary<string, object>>(party.Meta) ?? new Dictionary<string, object>();
            var meta = requestData["meta"];

            var metaDelete = meta?["delete"]?.Values<string>().ToList();
            if (metaDelete?.Any() == true)
            {
                foreach (var key in metaDelete)
                {
                    partyMeta.Remove(key);
                }
            }

            var metaUpdate = meta?["update"]?.ToObject<Dictionary<string, string>>();
            if (metaUpdate?.Any() == true)
            {
                foreach (var (key, value) in metaUpdate)
                {
                    if (key.EndsWith("Time_s") && DateTime.TryParse(value, out DateTime parsedTime))
                    {
                        partyMeta[key] = parsedTime.ToIsoUtcString();
                    }
                    else
                    {
                        partyMeta[key] = value;
                    }
                }
            }

            party.Meta = JsonSerializer.Serialize(partyMeta);
            party.Config = JsonSerializer.Serialize(partyConfig);
            party.Revision++;
            party.UpdatedAt = DateTime.UtcNow.ToIsoUtcString();

            await pRepo.UpdateAsync(party);

            var members = SafeDeserialize<List<PartyMember>>(party.Members) ?? new List<PartyMember>();
            var captain = members.FirstOrDefault(x => x.Role == "CAPTAIN");

            var messageTemplate = new
            {
                captain_id = captain?.AccountId,
                party_state_updated = metaUpdate ?? new Dictionary<string, string>(),
                party_state_removed = metaDelete ?? new List<string>(),
                party_privacy_type = partyConfig.TryGetValue("joinability", out var j) ? j.GetString() : null,
                party_type = partyConfig.TryGetValue("type", out var t) ? t.GetString() : "DEFAULT",
                party_sub_type = partyMeta.TryGetValue("urn:epic:cfg:party-type-id_s", out var st) ? st?.ToString() : null,
                max_number_of_members = partyConfig.TryGetValue("max_size", out var ms) ? ms.GetInt32() : 16,
                invite_ttl_seconds = partyConfig.TryGetValue("invite_ttl", out var ttl) ? ttl.GetInt32() : 14400,
                updated_at = party.UpdatedAt,
                created_at = party.CreatedAt,
                ns = "Fortnite",
                party_id = party.PartyId,
                sent = DateTime.UtcNow.ToIsoUtcString(),
                revision = party.Revision,
                type = "com.epicgames.social.party.notification.v0.PARTY_UPDATED"
            };

            var messageJson = JsonConvert.SerializeObject(messageTemplate);
            foreach (var member in members)
            {
                try
                {
                    await Constants.GlobalXmppClientService.ForwardMessageAsync(member.AccountId, messageJson);
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed to send party update notification to {member.AccountId}: {ex.Message}");
                }
            }

            return Ok();
        }
        catch (Exception ex)
        {
            Logger.Error($"Error modifying party {partyId}: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    [HttpPatch("Fortnite/parties/{partyId}/members/{accountId}/meta")]
    public async Task<IActionResult> ModifyFortnitePartyMeta(string partyId, string accountId)
    {
        try
        {
            var party = await pRepo.FindByColumnAsync("partyid", partyId);
            if (party == null)
                return PartyErrors.PartyNotFound.WithMessage($"Party {partyId} does not exist.").Apply(HttpContext);

            string requestBody = await new StreamReader(Request.Body).ReadToEndAsync();
            JObject? requestData;
            try
            {
                requestData = JObject.Parse(requestBody);
            }
            catch
            {
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            var metaDelete = requestData["delete"]?.ToObject<List<string>>() ?? new List<string>();
            var metaUpdate = requestData["update"]?.ToObject<Dictionary<string, object>>();

            var partyMembers = SafeDeserialize<List<PartyMember>>(party.Members) ?? new List<PartyMember>();
            var member = partyMembers.FirstOrDefault(m => m.AccountId == accountId);
            if (member == null)
                return PartyErrors.MemberNotFound.WithMessage($"Member {accountId} not found in party {partyId}.").Apply(HttpContext);

            var currentTime = DateTime.UtcNow;
            string isoTime = currentTime.ToIsoUtcString();

            member.Meta ??= new Dictionary<string, object>();

            foreach (var key in metaDelete)
            {
                member.Meta.Remove(key);
            }

            if (metaUpdate != null)
            {
                foreach (var (key, value) in metaUpdate)
                {
                    member.Meta[key] = value;
                }
            }

            member.UpdatedAt = isoTime;
            member.Revision++;

            party.Members = JsonSerializer.Serialize(partyMembers);
            party.UpdatedAt = isoTime;
            party.Revision++;
            await pRepo.UpdateAsync(party);

            var memberDn = member.Meta.TryGetValue("urn:epic:member:dn_s", out var dn) ? dn?.ToString() : null;
            var messageBody = new
            {
                account_id = accountId,
                account_dn = memberDn,
                member_state_updated = metaUpdate ?? new Dictionary<string, object>(),
                member_state_removed = metaDelete,
                member_state_overridden = new { },
                party_id = party.PartyId,
                updated_at = isoTime,
                sent = isoTime,
                revision = member.Revision,
                ns = "Fortnite",
                type = "com.epicgames.social.party.notification.v0.MEMBER_STATE_UPDATED"
            };

            string jsonBody = JsonConvert.SerializeObject(messageBody);

            foreach (var partyMember in partyMembers)
            {
                try
                {
                    await Constants.GlobalXmppClientService.ForwardMessageAsync(partyMember.AccountId, jsonBody);
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed to send member state update notification to {partyMember.AccountId}: {ex.Message}");
                }
            }

            return Ok();
        }
        catch (Exception ex)
        {
            Logger.Error($"Error modifying party member meta for {accountId} in party {partyId}: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    [HttpPost("Fortnite/parties/{partyId}/members/{accountId}/join")]
    public async Task<IActionResult> JoinFortniteParty(string partyId, string accountId)
    {
        try
        {
            var party = await pRepo.FindByColumnAsync("partyid", partyId);
            if (party == null)
            {
                Logger.Error($"Party {partyId} does not exist.");
                return PartyErrors.PartyNotFound.WithMessage($"Party {partyId} does not exist.").Apply(HttpContext);
            }

            string requestBody;
            using (var reader = new StreamReader(Request.Body))
            {
                requestBody = await reader.ReadToEndAsync();
            }

            JObject? requestData;
            try
            {
                requestData = JObject.Parse(requestBody);
            }
            catch
            {
                return MCPErrors.InvalidPayload.Apply(HttpContext);
            }

            string timestamp = DateTime.UtcNow.ToIsoUtcString();

            var connectionInfo = requestData["connection"];
            if (connectionInfo == null)
                return MCPErrors.InvalidPayload.WithMessage("Missing connection object.").Apply(HttpContext);

            string? connectionId = connectionInfo["id"]?.ToString();
            if (string.IsNullOrEmpty(connectionId))
                return MCPErrors.InvalidPayload.WithMessage("Missing connection.id.").Apply(HttpContext);

            string memberId = connectionId.Split("@prod")[0];

            var memberMeta = requestData["meta"] is JToken token1
                ? PartyManager.ConvertJTokenToObject(token1)
                : new Dictionary<string, object>();

            var memberConnectionMeta = connectionInfo["meta"] is JToken token2
                ? PartyManager.ConvertJTokenToObject(token2)
                : new Dictionary<string, object>();

            var partyMemberConnection = new PartyMemberConnection
            {
                Id = connectionId,
                ConnectedAt = timestamp,
                UpdatedAt = timestamp,
                YieldLeadership = false,
                Meta = memberConnectionMeta
            };

            var deserializedPartyMembers = SafeDeserialize<List<PartyMember>>(party.Members) ?? new List<PartyMember>();

            deserializedPartyMembers = deserializedPartyMembers.Where(member => member.AccountId != memberId).ToList();

            var newMember = new PartyMember
            {
                AccountId = memberId,
                Meta = memberMeta,
                Connections = JsonSerializer.Serialize(new List<PartyMemberConnection> { partyMemberConnection }),
                Revision = 0,
                UpdatedAt = timestamp,
                JoinedAt = timestamp,
                Role = "MEMBER"
            };

            deserializedPartyMembers.Add(newMember);

            var partyMeta = SafeDeserialize<Dictionary<string, object>>(party.Meta) ?? new Dictionary<string, object>();

            string squadAssignmentsKey = partyMeta.ContainsKey("Default:RawSquadAssignments_j")
                ? "Default:RawSquadAssignments_j"
                : "RawSquadAssignments_j";

            string rawJson = partyMeta.TryGetValue(squadAssignmentsKey, out var rawObj) && rawObj != null
                ? rawObj.ToString()
                : "{\"RawSquadAssignments\":[]}";

            var squadAssignments = JsonConvert.DeserializeObject<SquadAssignmentsWrapper>(rawJson)
                                   ?? new SquadAssignmentsWrapper();

            if (!squadAssignments.RawSquadAssignments.Any(sa => sa.memberId == memberId))
            {
                squadAssignments.RawSquadAssignments.Add(new SquadAssignment
                {
                    memberId = memberId,
                    absoluteMemberIdx = deserializedPartyMembers.Count - 1
                });
            }

            partyMeta[squadAssignmentsKey] = JsonConvert.SerializeObject(squadAssignments);

            party.Members = JsonSerializer.Serialize(deserializedPartyMembers);
            party.Meta = JsonSerializer.Serialize(partyMeta);
            party.Revision++;
            party.UpdatedAt = timestamp;

            await pRepo.UpdateAsync(party);

            var partyCaptain = deserializedPartyMembers.FirstOrDefault(x => x.Role == "CAPTAIN");
            var partyConfig = SafeDeserialize<Dictionary<string, object>>(party.Config) ?? new Dictionary<string, object>();
            string privacyType = partyConfig.TryGetValue("joinability", out var joinabilityObj)
                ? joinabilityObj?.ToString() ?? "PUBLIC"
                : "PUBLIC";

            partyMeta.TryGetValue("urn:epic:cfg:party-type-id_s", out var subTypeObj);
            string? partySubType = subTypeObj?.ToString();

            var memberJoinedMessage = new
            {
                account_id = memberId,
                account_dn = memberMeta.GetValueOrDefault("urn:epic:member:dn_s", ""),
                connection = new
                {
                    connected_at = timestamp,
                    id = connectionId,
                    meta = memberConnectionMeta,
                    updated_at = timestamp
                },
                joined_at = timestamp,
                member_state_updated = memberMeta,
                ns = "Fortnite",
                party_id = party.PartyId,
                revision = 0,
                sent = timestamp,
                type = "com.epicgames.social.party.notification.v0.MEMBER_JOINED",
                updated_at = timestamp,
            };

            var partyUpdatedMessage = new
            {
                captain_id = partyCaptain?.AccountId,
                created_at = party.CreatedAt,
                invite_ttl_seconds = 14400,
                max_number_of_members = 16,
                ns = "Fortnite",
                party_id = party.PartyId,
                party_privacy_type = privacyType,
                party_state_overriden = new object(),
                party_state_removed = Array.Empty<string>(),
                party_state_updated = new Dictionary<string, object>
                {
                    { squadAssignmentsKey, JsonConvert.SerializeObject(squadAssignments) }
                },
                party_sub_type = partySubType,
                party_type = "DEFAULT",
                revision = party.Revision,
                sent = timestamp,
                type = "com.epicgames.social.party.notification.v0.PARTY_UPDATED",
                updated_at = timestamp,
            };

            string jsonMemberJoined = JsonConvert.SerializeObject(memberJoinedMessage, Formatting.Indented);
            string jsonPartyUpdated = JsonConvert.SerializeObject(partyUpdatedMessage, Formatting.Indented);

            foreach (var member in deserializedPartyMembers)
            {
                try
                {
                    await Constants.GlobalXmppClientService.ForwardMessageAsync(member.AccountId, jsonMemberJoined);
                    await Constants.GlobalXmppClientService.ForwardMessageAsync(member.AccountId, jsonPartyUpdated);
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed to send party join notifications to {member.AccountId}: {ex.Message}");
                }
            }

            return Ok(new
            {
                status = "JOINED",
                party_id = party.PartyId
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Error joining party {partyId} for member {accountId}: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }
    [HttpDelete("Fortnite/parties/{partyId}/members/{accountId}")]
    public async Task<IActionResult> RemovePartyMember(string partyId, string accountId)
    {
        try
        {
            var party = await pRepo.FindByColumnAsync("partyid", partyId);
            if (party == null)
            {
                Logger.Error($"Party {partyId} does not exist.");
                return PartyErrors.PartyNotFound
                    .WithMessage($"Party {partyId} does not exist.")
                    .Apply(HttpContext);
            }

            string timestamp = DateTime.UtcNow.ToIsoUtcString();
            var partyMembers = SafeDeserialize<List<PartyMember>>(party.Members) ?? new List<PartyMember>();

            int memberIndex = partyMembers.FindIndex(x => x.AccountId == accountId);
            if (memberIndex == -1)
            {
                return PartyErrors.MemberNotFound
                    .WithMessage($"Member {accountId} not found in party {partyId}.")
                    .Apply(HttpContext);
            }

            partyMembers.RemoveAt(memberIndex);
            party.Revision++;
            party.UpdatedAt = timestamp;

            var memberLeftBody = JsonConvert.SerializeObject(new
            {
                account_id = accountId,
                member_state_update = new { },
                party_id = party.PartyId,
                sent = timestamp,
                revision = party.Revision,
                ns = "Fortnite",
                type = "com.epicgames.social.party.notification.v0.MEMBER_LEFT"
            });

            foreach (var member in partyMembers)
            {
                try
                {
                    await Constants.GlobalXmppClientService.ForwardMessageAsync(member.AccountId, memberLeftBody);
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed to notify {member.AccountId} of member leaving: {ex.Message}");
                }
            }

            var partyMeta = SafeDeserialize<Dictionary<string, object>>(party.Meta) ?? new();
            string assignmentKey = partyMeta.ContainsKey("Default:RawSquadAssignments_j")
                ? "Default:RawSquadAssignments_j"
                : "RawSquadAssignments_j";

            SquadAssignmentsWrapper? rawSquadAssignment = null;
            if (partyMeta.TryGetValue(assignmentKey, out var squadJson) && squadJson is string rawJson && !string.IsNullOrWhiteSpace(rawJson))
            {
                rawSquadAssignment = JsonConvert.DeserializeObject<SquadAssignmentsWrapper>(rawJson);
                if (rawSquadAssignment?.RawSquadAssignments != null)
                {
                    rawSquadAssignment.RawSquadAssignments.RemoveAll(x => x.memberId == accountId);
                    partyMeta[assignmentKey] = JsonConvert.SerializeObject(rawSquadAssignment);
                }
            }

            var captain = partyMembers.FirstOrDefault(x => x.Role == "CAPTAIN");
            if (captain == null && partyMembers.Count > 0)
            {
                captain = partyMembers[0];
                captain.Role = "CAPTAIN";

                var captainMessageBody = JsonConvert.SerializeObject(new
                {
                    account_id = captain.AccountId,
                    member_state_update = new { },
                    ns = "Fortnite",
                    party_id = party.PartyId,
                    revision = party.Revision,
                    sent = timestamp,
                    type = "com.epicgames.social.party.notification.v0.MEMBER_NEW_CAPTAIN"
                });

                foreach (var member in partyMembers)
                {
                    try
                    {
                        await Constants.GlobalXmppClientService.ForwardMessageAsync(member.AccountId, captainMessageBody);
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Failed to notify {member.AccountId} of new captain: {ex.Message}");
                    }
                }
            }

            if (partyMembers.Count > 0)
            {
                party.Meta = JsonSerializer.Serialize(partyMeta);
                party.Members = JsonSerializer.Serialize(partyMembers);
                await pRepo.UpdateAsync(party);

                var partyConfig = SafeDeserialize<Dictionary<string, JsonElement>>(party.Config) ?? new();
                string privacyType = partyConfig.TryGetValue("joinability", out var joinability)
                    ? joinability.GetString() ?? "PUBLIC"
                    : "PUBLIC";

                string partySubType = partyMeta.TryGetValue("urn:epic:cfg:party-type-id_s", out var subType)
                    ? subType?.ToString()
                    : null;

                var updateBody = JsonConvert.SerializeObject(new
                {
                    captain_id = captain?.AccountId,
                    created_at = party.CreatedAt,
                    invite_ttl_seconds = 14400,
                    max_number_of_members = partyConfig.TryGetValue("max_size", out var ms) ? ms.GetInt32() : 16,
                    ns = "Fortnite",
                    party_id = party.PartyId,
                    party_privacy_type = privacyType,
                    party_state_overriden = new { },
                    party_state_removed = new List<string>(),
                    party_state_updated = new Dictionary<string, object>
                    {
                        { assignmentKey, JsonConvert.SerializeObject(rawSquadAssignment) }
                    },
                    party_sub_type = partySubType,
                    party_type = "DEFAULT",
                    revision = party.Revision,
                    sent = timestamp,
                    type = "com.epicgames.social.party.notification.v0.PARTY_UPDATED",
                    updated_at = party.UpdatedAt
                });

                foreach (var member in partyMembers)
                {
                    try
                    {
                        await Constants.GlobalXmppClientService.ForwardMessageAsync(member.AccountId, updateBody);
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Failed to send PARTY_UPDATED to {member.AccountId}: {ex.Message}");
                    }
                }
            }
            else
            {
                await pRepo.DeleteByColumnAsync("partyid", party.PartyId);
            }

            return Ok();
        }
        catch (Exception ex)
        {
            Logger.Error($"Error removing member {accountId} from party {partyId}: {ex}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    [HttpPost("Fortnite/parties/{partyId}/members/{accountId}/promote")]
    public async Task<IActionResult> PromotePartyMember(string partyId, string accountId)
    {
        var party = await pRepo.FindByColumnAsync("partyid", partyId);
        if (party == null)
            return PartyErrors.PartyNotFound.WithMessage($"Party {partyId} does not exist.").Apply(HttpContext);

        var partyMembers = JsonSerializer.Deserialize<List<PartyMember>>(party.Members);
        int newCaptainIndex = partyMembers.FindIndex(x => x.AccountId == accountId);

        if (newCaptainIndex == -1)
            return PartyErrors.MemberNotFound.WithMessage($"Member {accountId} not found in party {partyId}.")
                .Apply(HttpContext);

        int currentCaptainIndex = partyMembers.FindIndex(x => x.Role == "CAPTAIN");
        if (currentCaptainIndex != -1)
            partyMembers[currentCaptainIndex].Role = "MEMBER";

        partyMembers[newCaptainIndex].Role = "CAPTAIN";

        string timestamp = DateTime.Now.ToIsoUtcString();
        party.Members = JsonSerializer.Serialize(partyMembers);
        party.UpdatedAt = timestamp;
        party.Revision++;
        await pRepo.UpdateAsync(party);

        var messageBody = new
        {
            account_id = accountId,
            member_state_update = new { },
            ns = "Fortnite",
            party_id = party.PartyId,
            revision = party.Revision,
            sent = timestamp,
            type = "com.epicgames.social.party.notification.v0.MEMBER_NEW_CAPTAIN"
        };
        string jsonBody = JsonConvert.SerializeObject(messageBody);

        foreach (var member in partyMembers)
        {
            try
            {
                await Constants.GlobalXmppClientService.ForwardMessageAsync(member.AccountId, jsonBody);
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to send promotion notification to {member.AccountId}: {ex.Message}");
            }
        }

        return Ok();
    }

    [HttpPost("Fortnite/parties/{partyId}/invites/{accountId}")]
    [VerifyToken]
    public async Task<IActionResult> InviteMemberToParty(string partyId, string accountId)
    {
        var party = await pRepo.FindByColumnAsync("partyid", partyId);
        if (party == null)
            return PartyErrors.PartyNotFound.WithMessage($"Party {partyId} does not exist.").Apply(HttpContext);

        Dictionary<string, object> meta;
        try
        {
            using var reader = new StreamReader(Request.Body);
            var requestBody = await reader.ReadToEndAsync();
            var requestData = JObject.Parse(requestBody);
            meta = requestData is JToken token ? PartyManager.ConvertJTokenToObject(token) : new Dictionary<string, object>();
        }
        catch
        {
            return MCPErrors.InvalidPayload.Apply(HttpContext);
        }

        if (!HttpContext.Request.Cookies.TryGetValue("User", out var userJson) || string.IsNullOrEmpty(userJson))
            return AccountErrors.AccountNotFound(HttpContext.Request.Cookies["AccountId"] ?? "unknown").Apply(HttpContext);

        var user = JsonSerializer.Deserialize<User>(userJson);
        var timestamp = DateTime.UtcNow.ToIsoUtcString();
        var expiryTime = DateTime.Parse(timestamp).AddHours(1).ToIsoUtcString();

        var newInvite = new Invites
        {
            PartyId = party.PartyId,
            SentBy = user.AccountId,
            Meta = JsonSerializer.Serialize(meta),
            SentTo = accountId,
            SentAt = timestamp,
            UpdatedAt = timestamp,
            ExpiresAt = expiryTime,
            Status = "SENT"
        };

        await iRepo.SaveAsync(newInvite);

        party.UpdatedAt = timestamp;
        await pRepo.UpdateAsync(party);

        var partyMembers = JsonSerializer.Deserialize<List<PartyMember>>(party.Members);
        var inviter = partyMembers.FirstOrDefault(x => x.AccountId == user.AccountId);
        if (inviter == null)
            return AccountErrors.AccountNotFound(user.AccountId).WithMessage($"Inviter {user.AccountId} not found.").Apply(HttpContext);

        var friends = await fRepo.FindAllAsync(new Friends { AccountId = user.AccountId });
        if (!friends.Any())
            return AccountErrors.AccountNotFound(accountId)
                .WithMessage($"Friends for user {accountId} not found.")
                .Apply(HttpContext);

        var friendAccounts = friends.Where(f => f.Status == "ACCEPTED").Select(f => f.FriendId).ToHashSet();
        var friendsInParty = partyMembers.Where(m => friendAccounts.Contains(m.AccountId)).Select(m => m.AccountId).ToList();

        var messageBody = new
        {
            expires = expiryTime,
            meta,
            ns = "Fortnite",
            party_id = party.PartyId,
            inviter_dn = inviter.Meta.GetValueOrDefault("urn:epic:member:dn_s", ""),
            invitee_id = user.AccountId,
            memebrs_count = partyMembers.Count,
            sent_at = timestamp,
            updated_by = timestamp,
            friends_ids = friendsInParty,
            sent = timestamp,
            type = "com.epicgames.social.party.notification.v0.INITIAL_INVITE"
        };

        try
        {
            await Constants.GlobalXmppClientService.ForwardMessageAsync(accountId, JsonConvert.SerializeObject(messageBody));
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to send invite notification to {accountId}: {ex.Message}");
        }

        return Ok();
    }

    [HttpPost("Fortnite/user/{accountId}/pings/{pingerId}")]
    public async Task<IActionResult> CreatePing(string accountId, string pingerId)
    {
        var ping = await pingsRepo.FindAsync(new Pings { SentTo = accountId, SentBy = pingerId });
        if (ping != null)
            await pingsRepo.DeleteAsync(new Pings { SentTo = accountId, SentBy = pingerId });

        var now = DateTime.UtcNow;
        var expiryTime = now.AddHours(1);

        var newPing = new Pings
        {
            SentBy = pingerId,
            SentTo = accountId,
            SentAt = now.ToIsoUtcString(),
            ExpiresAt = expiryTime.ToIsoUtcString(),
            Meta = "{}"
        };
        await pingsRepo.SaveAsync(newPing);

        var user = await uRepo.FindByColumnAsync("accountid", pingerId);
        if (user == null)
            return AccountErrors.AccountNotFound(accountId).Apply(HttpContext);

        try
        {
            await Constants.GlobalXmppClientService.ForwardMessageAsync(accountId, JsonConvert.SerializeObject(new
            {
                expires = newPing.ExpiresAt,
                meta = new Dictionary<string, string>(),
                ns = "Fortnite",
                pinger_dn = user.Username,
                pinger_id = pingerId,
                sent = newPing.SentAt,
                type = "com.epicgames.social.party.notification.v0.PING"
            }));
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to send ping notification to {accountId}: {ex.Message}");
        }

        return Ok(new
        {
            sent_by = newPing.SentBy,
            sent_to = newPing.SentTo,
            sent_at = newPing.SentAt,
            expires_at = newPing.ExpiresAt,
            meta = new Dictionary<string, string>()
        });
    }

    [HttpPost("/party/api/v1/Fortnite/user/{accountId}/pings/{pingerId}/join")]
    public async Task<IActionResult> JoinPartyFromPing(string accountId, string pingerId)
    {
        if (string.IsNullOrWhiteSpace(accountId) || string.IsNullOrWhiteSpace(pingerId))
        {
            return BadRequest(new { error = "AccountId and PingerId are required." });
        }

        try
        {
            var ping = await pingsRepo.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "sentto", accountId },
                { "sentby", pingerId }
            });

            if (ping == null)
            {
                return PartyErrors.PingNotFound
                    .WithMessage($"No ping from {pingerId} to {accountId} found.")
                    .Apply(HttpContext);
            }

            string requestBody;
            using (var reader = new StreamReader(Request.Body))
            {
                requestBody = await reader.ReadToEndAsync();
            }

            if (string.IsNullOrWhiteSpace(requestBody))
            {
                return MCPErrors.InvalidPayload
                    .WithMessage("Request body is required.")
                    .Apply(HttpContext);
            }

            JObject requestData;
            try
            {
                requestData = JObject.Parse(requestBody);
            }
            catch (System.Text.Json.JsonException ex)
            {
                Logger.Error($"Failed to parse request JSON: {ex.Message}");
                return MCPErrors.InvalidPayload
                    .WithMessage("Invalid JSON format.")
                    .Apply(HttpContext);
            }

            var connectionInfo = requestData["connection"];
            if (connectionInfo == null)
            {
                return MCPErrors.InvalidPayload
                    .WithMessage("Missing connection object.")
                    .Apply(HttpContext);
            }

            string connectionId = connectionInfo["id"]?.ToString();
            if (string.IsNullOrWhiteSpace(connectionId))
            {
                return MCPErrors.InvalidPayload
                    .WithMessage("Missing connection id.")
                    .Apply(HttpContext);
            }

            var parties = await pRepo.FindAllByTableAsync();
            if (parties == null)
            {
                Logger.Error("Failed to retrieve parties from database");
                return InternalErrors.ServerError.Apply(HttpContext);
            }

            var partyWithMembers = new List<(Parties Party, List<PartyMember> Members)>();

            foreach (var party in parties)
            {
                try
                {
                    var members = string.IsNullOrEmpty(party.Members)
                        ? new List<PartyMember>()
                        : JsonSerializer.Deserialize<List<PartyMember>>(party.Members) ?? new List<PartyMember>();

                    partyWithMembers.Add((party, members));
                }
                catch (System.Text.Json.JsonException ex)
                {
                    Logger.Error($"Failed to deserialize members for party {party.PartyId}: {ex.Message}");
                    partyWithMembers.Add((party, new List<PartyMember>()));
                }
            }

            var partyByMemberIdLookup = new Dictionary<string, (Parties Party, List<PartyMember> Members)>();
            foreach (var (party, members) in partyWithMembers)
            {
                foreach (var member in members)
                {
                    if (!string.IsNullOrWhiteSpace(member?.AccountId))
                    {
                        partyByMemberIdLookup[member.AccountId] = (party, members);
                    }
                }
            }

            if (!partyByMemberIdLookup.TryGetValue(ping.SentBy, out var match))
            {
                return PartyErrors.PingNotFound
                    .WithMessage($"No party found for ping sender {pingerId}.")
                    .Apply(HttpContext);
            }

            bool isAlreadyMember = match.Members.Any(m => m?.AccountId == accountId);
            if (isAlreadyMember)
            {
                return Ok(new { status = "JOINED", party_id = match.Party.PartyId });
            }

            string timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ");
            string memberId = connectionId?.Split("@prod")[0] ?? accountId;

            var memberMeta = requestData["meta"] is JToken metaToken
                ? PartyManager.ConvertJTokenToObject(metaToken) ?? new Dictionary<string, object>()
                : new Dictionary<string, object>();

            var memberConnectionMeta = connectionInfo["meta"] is JToken connMetaToken
                ? PartyManager.ConvertJTokenToObject(connMetaToken) ?? new Dictionary<string, object>()
                : new Dictionary<string, object>();

            var partyMemberConnection = new PartyMemberConnection
            {
                Id = connectionId,
                ConnectedAt = timestamp,
                UpdatedAt = timestamp,
                YieldLeadership = false,
                Meta = memberConnectionMeta
            };

            List<PartyMember> deserializedPartyMembers;
            try
            {
                deserializedPartyMembers = JsonSerializer.Deserialize<List<PartyMember>>(match.Party.Members ?? "[]")
                                         ?? new List<PartyMember>();
            }
            catch (System.Text.Json.JsonException ex)
            {
                Logger.Error($"Failed to deserialize party members: {ex.Message}");
                deserializedPartyMembers = new List<PartyMember>();
            }

            deserializedPartyMembers = deserializedPartyMembers
                .Where(member => member?.AccountId != accountId)
                .ToList();

            var newMember = new PartyMember
            {
                AccountId = memberId,
                Meta = memberMeta,
                Connections = JsonSerializer.Serialize(new List<PartyMemberConnection> { partyMemberConnection }),
                Revision = 0,
                UpdatedAt = timestamp,
                JoinedAt = timestamp,
                Role = "MEMBER"
            };

            deserializedPartyMembers.Add(newMember);

            Dictionary<string, object> partyMeta;
            try
            {
                partyMeta = string.IsNullOrEmpty(match.Party.Meta)
                    ? new Dictionary<string, object>()
                    : JsonConvert.DeserializeObject<Dictionary<string, object>>(match.Party.Meta)
                      ?? new Dictionary<string, object>();
            }
            catch (System.Text.Json.JsonException ex)
            {
                Logger.Error($"Failed to deserialize party meta: {ex.Message}");
                partyMeta = new Dictionary<string, object>();
            }

            string squadAssignmentsKey = partyMeta.ContainsKey("Default:RawSquadAssignments_j")
                ? "Default:RawSquadAssignments_j"
                : "RawSquadAssignments_j";

            string rawJson = partyMeta.TryGetValue(squadAssignmentsKey, out var rawObj) && rawObj != null
                ? rawObj.ToString()
                : "{\"RawSquadAssignments\":[]}";

            SquadAssignmentsWrapper squadAssignments;
            try
            {
                squadAssignments = JsonConvert.DeserializeObject<SquadAssignmentsWrapper>(rawJson)
                                  ?? new SquadAssignmentsWrapper();
            }
            catch (System.Text.Json.JsonException ex)
            {
                Logger.Error($"Failed to deserialize squad assignments: {ex.Message}");
                squadAssignments = new SquadAssignmentsWrapper();
            }

            squadAssignments.RawSquadAssignments ??= new List<SquadAssignment>();

            if (!squadAssignments.RawSquadAssignments.Any(sa => sa?.memberId == memberId))
            {
                squadAssignments.RawSquadAssignments.Add(new SquadAssignment
                {
                    memberId = memberId,
                    absoluteMemberIdx = Math.Max(0, deserializedPartyMembers.Count - 1)
                });
            }

            var partyMember = deserializedPartyMembers.FirstOrDefault(m => m?.AccountId == accountId);
            if (partyMember == null)
            {
                return PartyErrors.MemberNotFound
                    .WithMessage($"Member {accountId} not found in party {match.Party.PartyId}.")
                    .Apply(HttpContext);
            }

            partyMember.Revision++;

            try
            {
                partyMeta[squadAssignmentsKey] = JsonSerializer.Serialize(squadAssignments);
                match.Party.Meta = JsonSerializer.Serialize(partyMeta);
                match.Party.Members = JsonSerializer.Serialize(deserializedPartyMembers);
                match.Party.Revision++;
                match.Party.UpdatedAt = timestamp;
            }
            catch (System.Text.Json.JsonException ex)
            {
                Logger.Error($"Failed to serialize party data: {ex.Message}");
                return InternalErrors.ServerError.Apply(HttpContext);
            }

            try
            {
                await pRepo.UpdateAsync(match.Party);
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to update party in database: {ex.Message}");
                return InternalErrors.ServerError.Apply(HttpContext);
            }

            var partyCaptain = deserializedPartyMembers.FirstOrDefault(x => x?.Role == "CAPTAIN");

            Dictionary<string, object> partyConfig;
            try
            {
                partyConfig = JsonSerializer.Deserialize<Dictionary<string, object>>(match.Party.Config ?? "{}")
                             ?? new Dictionary<string, object>();
            }
            catch (System.Text.Json.JsonException ex)
            {
                Logger.Error($"Failed to deserialize party config: {ex.Message}");
                partyConfig = new Dictionary<string, object>();
            }

            string privacyType = partyConfig.TryGetValue("joinability", out var joinabilityObj)
                ? joinabilityObj?.ToString() ?? "PUBLIC"
                : "PUBLIC";

            partyMeta.TryGetValue("urn:epic:cfg:party-type-id_s", out var subTypeObj);
            string partySubType = subTypeObj?.ToString();

            var memberJoinedMessage = new
            {
                account_id = memberId,
                account_dn = memberMeta.GetValueOrDefault("urn:epic:member:dn_s", ""),
                connection = new
                {
                    connected_at = timestamp,
                    id = connectionId,
                    meta = memberConnectionMeta,
                    updated_at = timestamp
                },
                joined_at = timestamp,
                member_state_updated = memberMeta,
                ns = "Fortnite",
                party_id = match.Party.PartyId,
                revision = 0,
                sent = timestamp,
                type = "com.epicgames.social.party.notification.v0.MEMBER_JOINED",
                updated_at = timestamp,
            };

            var partyUpdatedMessage = new
            {
                captain_id = partyCaptain?.AccountId,
                created_at = match.Party.CreatedAt,
                invite_ttl_seconds = 14400,
                max_number_of_members = 16,
                ns = "Fortnite",
                party_id = match.Party.PartyId,
                party_privacy_type = privacyType,
                party_state_overriden = new object(),
                party_state_removed = Array.Empty<string>(),
                party_state_updated = new Dictionary<string, object>
                {
                    { squadAssignmentsKey, JsonConvert.SerializeObject(squadAssignments) }
                },
                party_sub_type = partySubType,
                party_type = "DEFAULT",
                revision = match.Party.Revision,
                sent = timestamp,
                type = "com.epicgames.social.party.notification.v0.PARTY_UPDATED",
                updated_at = timestamp,
            };

            try
            {
                string jsonMemberJoined = JsonConvert.SerializeObject(memberJoinedMessage, Formatting.Indented);
                string jsonPartyUpdated = JsonConvert.SerializeObject(partyUpdatedMessage, Formatting.Indented);

                var notificationTasks = new List<Task>();

                foreach (var member in deserializedPartyMembers.Where(m => m?.AccountId != null))
                {
                    notificationTasks.Add(SendNotificationSafeAsync(member.AccountId, jsonMemberJoined));
                    notificationTasks.Add(SendNotificationSafeAsync(member.AccountId, jsonPartyUpdated));
                }

                await Task.WhenAll(notificationTasks);
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to send party notifications: {ex.Message}");
            }

            try
            {
                await pingsRepo.DeleteAsync(ping);
            }
            catch (Exception ex)
            {
                Logger.Error($"Failed to delete ping: {ex.Message}");
            }

            return Ok(new
            {
                status = "JOINED",
                party_id = match.Party.PartyId
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Unexpected error in JoinPartyFromPing: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }

    private async Task SendNotificationSafeAsync(string accountId, string message)
    {
        try
        {
            await Constants.GlobalXmppClientService.ForwardMessageAsync(accountId, message);
        }
        catch (Exception ex)
        {
            Logger.Error($"Failed to send notification to {accountId}: {ex.Message}");
        }
    }

    [HttpGet("Fortnite/user/{accountId}/pings/{pingerId}/parties")]
    public async Task<IActionResult> GetPartyFromPing(string accountId, string pingerId)
    {
        if (string.IsNullOrWhiteSpace(accountId) || string.IsNullOrWhiteSpace(pingerId))
        {
            return BadRequest(new { error = "AccountId and PingerId are required." });
        }

        try
        {
            var parties = await pRepo.FindAllByTableAsync();
            if (parties == null)
            {
                Logger.Error("Failed to retrieve parties from database");
                return InternalErrors.ServerError.Apply(HttpContext);
            }

            var queriedPings = await pingsRepo.FindAllByColumnsAsync(new Dictionary<string, object>
            {
                { "sentto", accountId },
                { "sentby", pingerId }
            });

            if (queriedPings == null || !queriedPings.Any())
            {
                queriedPings = new List<Pings> { new Pings { SentBy = pingerId } };
            }

            var partyWithMembers = new List<(Parties Party, List<PartyMember> Members)>();

            foreach (var party in parties)
            {
                try
                {
                    var members = string.IsNullOrEmpty(party.Members)
                        ? new List<PartyMember>()
                        : JsonSerializer.Deserialize<List<PartyMember>>(party.Members) ?? new List<PartyMember>();

                    partyWithMembers.Add((party, members));
                }
                catch (System.Text.Json.JsonException ex)
                {
                    Logger.Error($"Failed to deserialize members for party {party.PartyId}: {ex.Message}");
                    partyWithMembers.Add((party, new List<PartyMember>()));
                }
            }

            var partyByMemberIdLookup = new Dictionary<string, (Parties Party, List<PartyMember> Members)>();
            foreach (var (party, members) in partyWithMembers)
            {
                foreach (var member in members.Where(m => !string.IsNullOrWhiteSpace(m?.AccountId)))
                {
                    partyByMemberIdLookup[member.AccountId] = (party, members);
                }
            }

            var allMemberIds = new HashSet<string>();
            var result = new List<object>();

            foreach (var ping in queriedPings.Where(p => p != null))
            {
                if (!partyByMemberIdLookup.TryGetValue(ping.SentBy, out var match))
                    continue;

                var (party, members) = match;

                foreach (var member in members.Where(m => !string.IsNullOrWhiteSpace(m?.AccountId)))
                {
                    allMemberIds.Add(member.AccountId);
                }

                Dictionary<string, dynamic> partyConfig;
                try
                {
                    partyConfig = string.IsNullOrEmpty(party.Config)
                        ? new Dictionary<string, dynamic>()
                        : JsonSerializer.Deserialize<Dictionary<string, dynamic>>(party.Config) ?? new Dictionary<string, dynamic>();
                }
                catch (System.Text.Json.JsonException ex)
                {
                    Logger.Error($"Failed to deserialize party config for party {party.PartyId}: {ex.Message}");
                    partyConfig = new Dictionary<string, dynamic>();
                }

                Dictionary<string, string> meta;
                try
                {
                    meta = string.IsNullOrEmpty(party.Meta)
                        ? new Dictionary<string, string>()
                        : JsonSerializer.Deserialize<Dictionary<string, string>>(party.Meta) ?? new Dictionary<string, string>();
                }
                catch (System.Text.Json.JsonException ex)
                {
                    Logger.Error($"Failed to deserialize party meta for party {party.PartyId}: {ex.Message}");
                    meta = new Dictionary<string, string>();
                }

                var memberList = members.Where(m => m != null).Select(member =>
                {
                    List<PartyMemberConnection> connections;
                    try
                    {
                        connections = string.IsNullOrEmpty(member.Connections)
                            ? new List<PartyMemberConnection>()
                            : JsonSerializer.Deserialize<List<PartyMemberConnection>>(member.Connections) ?? new List<PartyMemberConnection>();
                    }
                    catch (System.Text.Json.JsonException ex)
                    {
                        Logger.Error($"Failed to deserialize connections for member {member.AccountId}: {ex.Message}");
                        connections = new List<PartyMemberConnection>();
                    }

                    return new
                    {
                        account_id = member.AccountId,
                        meta = member.Meta ?? new Dictionary<string, object>(),
                        connections = connections,
                        revision = member.Revision,
                        updated_at = member.UpdatedAt,
                        joined_at = member.JoinedAt,
                        role = member.Role ?? "MEMBER"
                    };
                }).ToList();

                IEnumerable<Invites> allInvites;
                try
                {
                    allInvites = allMemberIds.Any()
                        ? await iRepo.FindAllByColumnAsync("sentby", allMemberIds.ToList(), useCache: false) ?? Enumerable.Empty<Invites>()
                        : Enumerable.Empty<Invites>();
                }
                catch (Exception ex)
                {
                    Logger.Error($"Failed to retrieve invites: {ex.Message}");
                    allInvites = Enumerable.Empty<Invites>();
                }


                result.Add(new
                {
                    id = party.PartyId,
                    created_at = party.CreatedAt,
                    updated_at = party.UpdatedAt,
                    config = partyConfig,
                    members = memberList,
                    applicants = new List<object>(),
                    meta = meta,
                    invites = allInvites,
                    revision = party.Revision
                });
            }

            return Ok(result);
        }
        catch (Exception ex)
        {
            Logger.Error($"Unexpected error in GetPartyFromPing: {ex.Message}");
            return InternalErrors.ServerError.Apply(HttpContext);
        }
    }
}