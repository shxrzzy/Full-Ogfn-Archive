﻿using Helios.Classes.Storefront;
using Helios.Configuration;
using Helios.Database.Repository;
using Helios.Database.Tables.Fortnite;
using Helios.Managers;
using Helios.Utilities.Errors.HeliosErrors;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace Helios.Controllers;

[ApiController]
[Route("/fortnite/api/storefront/v2/")]
public class StorefrontController : ControllerBase
{
    [HttpGet("keychain")]
    public async Task<IActionResult> GetKeychain()
    {
        Response.ContentType = "application/json";

        var keychainFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "keychain.json");
        if (!System.IO.File.Exists(keychainFile))
            return BasicErrors.NotFound.WithMessage("File not found.").Apply(HttpContext);

        var json = System.IO.File.ReadAllText(keychainFile);
        return Content(json, "application/json");
    }

    [HttpGet("catalog")]
    public async Task<IActionResult> GetCatalog()
    {
        var repository = Constants.repositoryPool.For<Catalog>();

        var storefrontNames = new[] { "BRDailyStorefront", "BRWeeklyStorefront" };
        var items = await repository.FindAllByColumnAsync("storefront", storefrontNames);

        var groupedItems = items
            .GroupBy(item => item.Storefront)
            .ToDictionary(g => g.Key, g => g.ToList());

        var formattedStorefronts = storefrontNames.AsParallel()
            .Select(name => new Storefronts
            {
                Name = name,
                CatalogEntries = StorefrontManager.Format(groupedItems.GetValueOrDefault(name) ?? new List<Catalog>())
            })
            .ToList();

        return Ok(new
        {
            refreshIntervalHrs = 24,
            dailyPurchaseHrs = 24,
            expiration = "9999-12-31T00:00:00.000Z",
            storefronts = formattedStorefronts,
        });
    }
}