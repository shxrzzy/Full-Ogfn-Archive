﻿using Helios.Configuration;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.AntiCheat;
using Helios.Database.Tables.Profiles;
using Helios.Database.Tables.Tournaments;
using Helios.Managers;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Launcher;
using Helios.Utilities.Profile;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Helios.Controllers.Admin;

[ApiController]
[Route("skibidi/api/")]
public class AdminApiController : ControllerBase
{
    public class NewRegisteredUser
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string Username { get; set; }
        public string DiscordId { get; set; }
    }

    [HttpPost("register")]
    public async Task<IActionResult> RegisterAsync()
    {
        var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
        if (apiKey != Constants.ValidApiKey)
            return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);

        NewRegisteredUser? body;
        try
        {
            body = await HttpContext.Request.ReadFromJsonAsync<NewRegisteredUser>();
        }
        catch
        {
            Logger.Warn("Failed to deserialize request body.");
            return BadRequest(new { error = "failed to deserialize body." });
        }

        if (body is null ||
            string.IsNullOrWhiteSpace(body.Email) ||
            string.IsNullOrWhiteSpace(body.Password) ||
            string.IsNullOrWhiteSpace(body.Username) ||
            string.IsNullOrWhiteSpace(body.DiscordId))
        {
            return BadRequest(new { error = "invalid request" });
        }

        var userRepository = Constants.repositoryPool.For<User>();
        var loadoutsRepository = Constants.repositoryPool.For<Loadouts>();
        var userBansRepository = Constants.repositoryPool.For<Ban>();
        var serverAccountsRepository = Constants.repositoryPool.For<ServerAccounts>();

        if (await userRepository.FindAsync(new User { Username = body.Username }) is not null)
        {
            return BadRequest(new { error = "user already exists" });
        }

        try
        {
            var (password, _) = PasswordHasher.HashPassword(body.Password);
            var user = new User
            {
                Email = body.Email,
                Password = password,
                Username = body.Username,
                DiscordId = body.DiscordId,
                AccountId = Guid.NewGuid().ToString(),
                Banned = false,
                AllItemsGranted = false,
                Ac = false
            };

            await userRepository.SaveAsync(user);

            var serverAccount = new ServerAccounts
            {
                Email = body.Email,
                Password = password,
                Username = body.Username,
                DiscordId = body.DiscordId,
                AccountId = Guid.NewGuid().ToString()
            };
            await serverAccountsRepository.SaveAsync(serverAccount);

            var profiles = new List<string> { "athena", "common_core" };
            foreach (var profileId in profiles)
            {
                var profile = await ProfileManager.CreateProfileAsync(profileId, user.AccountId);
                if (profile != null)
                {
                    Logger.Info($"Successfully created {profileId} profile for account {user.AccountId}");
                }
            }

            await loadoutsRepository.SaveAsync(new Loadouts
            {
                AccountId = user.AccountId,
                ProfileId = "athena",
                TemplateId = "CosmeticLocker:cosmeticlocker_athena",
                LockerName = "fortniteloadout1",
                BannerId = "",
                BannerColorId = "",
                CharacterId = "AthenaCharacter:CID_001_Athena_Commando_F_Default",
                BackpackId = "",
                GliderId = "AthenaGlider:DefaultGlider",
                DanceId = new string[6] { "", "", "", "", "", "" },
                PickaxeId = "AthenaPickaxe:DefaultPickaxe",
                ItemWrapId = new string[7] { "", "", "", "", "", "", "" },
                ContrailId = "",
                LoadingScreenId = "",
                MusicPackId = ""
            });

            await userBansRepository.SaveAsync(new Ban
            {
                AccountId = user.AccountId,
                IsShadowBanned = false,
                IsRecentlyUnbanned = false
            });

            return Ok(new
            {
                Success = true,
                Message = "Successfully created account",
            });
        }
        catch (Exception ex)
        {
            Logger.Error($"Error creating account: {ex.Message}");
            return StatusCode(500);
        }
    }

    [HttpDelete("delete")]
    public async Task<IActionResult> DeleteByDiscordIdAsync([FromQuery] string discordId)
    {
        var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
        if (apiKey != Constants.ValidApiKey)
            return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);

        if (string.IsNullOrWhiteSpace(discordId))
            return BadRequest(new { error = "discordId is required" });

        var userRepository = Constants.repositoryPool.For<User>();
        var loadoutsRepository = Constants.repositoryPool.For<Loadouts>();
        var userBansRepository = Constants.repositoryPool.For<Ban>();
        var profilesRepository = Constants.repositoryPool.For<Profiles>();

        try
        {
            var user = await userRepository.FindByColumnAsync("discordid", discordId);
            if (user == null)
                return NotFound(new { error = "user not found" });

            var accountId = user.AccountId;
            if (!await UserDeletion.DeleteUser(accountId))
                return StatusCode(500, new { error = "failed to delete user" });

            return Ok(new { Success = true, Message = "User and related data deleted successfully." });
        }
        catch (Exception ex)
        {
            Logger.Error($"Error deleting user by DiscordId: {ex.Message}");
            return StatusCode(500);
        }
    }

    [HttpDelete("deleteByAccountId")]
    public async Task<IActionResult> DeleteByAccountIdAsync([FromQuery] string accountId)
    {
        var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
        if (apiKey != Constants.ValidApiKey)
            return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);

        if (string.IsNullOrWhiteSpace(accountId))
            return BadRequest(new { error = "accountId is required" });


        try
        {
            if (!await UserDeletion.DeleteUser(accountId))
                return StatusCode(500, new { error = "failed to delete user" });

            return Ok(new { Success = true, Message = "User and related data deleted successfully." });
        }
        catch (Exception ex)
        {
            Logger.Error($"Error deleting user by AccountId: {ex.Message}");
            return StatusCode(500);
        }
    }

    [HttpPost("grantAll")]
    public async Task<IActionResult> GrantAllItemsAsync([FromQuery] string discordId)
    {
        var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
        if (apiKey != Constants.ValidApiKey)
            return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);

        if (string.IsNullOrWhiteSpace(discordId))
            return BadRequest(new { error = "discordId is required" });

        var userRepository = Constants.repositoryPool.For<User>();
        var user = await userRepository.FindAsync(new User { DiscordId = discordId });

        if (user == null)
            return NotFound(new { error = "user not found" });

        _ = Task.Run(async () =>
        {
            try
            {
                await ProfileItemGranting.GrantAll(user.AccountId);
            }
            catch (Exception ex)
            {
                Logger.Error($"GrantAll background task failed: {ex.Message}");
            }
        });

        return Ok(new { Success = true, Message = "Granted." });
    }

    [HttpPost("resetAllVbucks")]
    public async Task<IActionResult> ResetAllVbucksAsync()
    {
        var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
        if (apiKey != Constants.ValidApiKey)
            return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);

        try
        {
            var profileItemsRepository = Constants.repositoryPool.For<Items>();
            var currency = await profileItemsRepository.FindAllByColumnAsync("templateid", new[] { "Currency:MtxPurchased" });

            Logger.Info($"Found {currency.Count()} MtxCurrency items to reset");
            int updated = 0;
            foreach (var item in currency)
            {
                item.Quantity = 0;
                await profileItemsRepository.UpdateAsync(item);
                updated++;
            }

            Logger.Info($"Successfully reset {updated} MtxCurrency items to 0");

            return NoContent();
        }
        catch (Exception ex)
        {
            Logger.Error($"Error resetting MtxCurrency: {ex.Message}");
            return StatusCode(500, new { error = "Failed to reset MtxCurrency" });
        }
    }

    [HttpPost("resetAllScores")]
    public async Task<IActionResult> ResetAllScoresAsync()
    {
        var apiKey = Request.Headers["X-Api-Key"].FirstOrDefault();
        if (apiKey != Constants.ValidApiKey)
            return BasicErrors.BadRequest.WithMessage("Invalid key.").Apply(HttpContext);
        try
        {
            var repo1 = Constants.repositoryPool.For<TournamentHype>();
            var repo2 = Constants.repositoryPool.For<TournamentHypeTokens>();
            var repo3 = Constants.repositoryPool.For<TournamentPlayer>();
            var repo4 = Constants.repositoryPool.For<TournamentTokens>();

            var entities1 = await repo1.FindAllByTableAsync(limit: null);
            var entities2 = await repo2.FindAllByTableAsync(limit: null);
            var entities3 = await repo3.FindAllByTableAsync(limit: null);
            var entities4 = await repo4.FindAllByTableAsync(limit: null);

            var count1 = entities1.Any() ? await repo1.BulkDeleteAsync(entities1) : 0;
            var count2 = entities2.Any() ? await repo2.BulkDeleteAsync(entities2) : 0;
            var count3 = entities3.Any() ? await repo3.BulkDeleteAsync(entities3) : 0;
            var count4 = entities4.Any() ? await repo4.BulkDeleteAsync(entities4) : 0;

            var totalDeleted = count1 + count2 + count3 + count4;

            Logger.Info($"Successfully reset all tournament data. Deleted {totalDeleted} records total.");
            return NoContent();
        }
        catch (Exception ex)
        {
            Logger.Error($"Error resetting tournament data: {ex.Message}");
            return StatusCode(500, new { error = "Failed to reset tournament data" });
        }
    }
}