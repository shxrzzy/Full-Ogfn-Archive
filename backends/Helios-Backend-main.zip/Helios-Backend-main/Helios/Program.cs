﻿using CommunityToolkit.HighPerformance;
using Helios.Configuration;
using Helios.Configuration.Services;
using Helios.Database.Tables.Account;
using Helios.Discord;
using Helios.Managers;
using Helios.Managers.Unreal;
using Helios.Services;
using Helios.Sockets.Hermes;
using Helios.Sockets.IgnisClient;
using Helios.Utilities;
using Helios.Utilities.Errors.HeliosErrors;
using Helios.Utilities.Middleware;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.HttpOverrides;
using Serilog;
using System.Diagnostics;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;

namespace Helios
{
    public class Program
    {
        static async Task Main(string[] args)
        {
            var dbInitTask = Task.Run(() => Constants.dbContext.Initialize());

            var builder = WebApplication.CreateBuilder(new WebApplicationOptions
            {
                Args = args,
                ApplicationName = typeof(Program).Assembly.FullName,
                WebRootPath = "wwwroot"
            });

            builder.WebHost.ConfigureKestrel(options =>
            {
                options.AddServerHeader = false;
                options.AllowSynchronousIO = false;
            });

            await ServiceConfiguration.ConfigureServices(builder.Services, builder.Environment);
            LoggingConfiguration.ConfigureLogging(builder.Logging, builder.Configuration, builder.Environment);
            WebhostConfiguration.ConfigureWebhosts(builder.WebHost);

            await dbInitTask;

            var app = builder.Build();

            //var xmppClient = app.Services.GetRequiredService<XmppClient>();
            //await xmppClient.StartAsync();
            //Constants.GlobalXmppClientService = xmppClient;

            var xmppForwarder = app.Services.GetRequiredService<XmppForwarderClient>();
            Constants.GlobalXmppClientService = xmppForwarder;

            var ignisClient = app.Services.GetRequiredService<IgnisClient>();
            await ignisClient.StartAsync();

            var partyManager = app.Services.GetRequiredService<PartyManager>();
            await partyManager.InitializeAsync();

            var discordBot = app.Services.GetRequiredService<Bot>();

            Constants.GlobalPartyManagerService = partyManager;

            // var solsticeServer = app.Services.GetRequiredService<SolsticeServer>();
            // await solsticeServer.StartAsync();

            //var solsticeClient = app.Services.GetRequiredService<SolsticeClient>();
            //await solsticeClient.StartServer();

            Task fileProviderTask = InitializeFileProvider(app);

            app.UseForwardedHeaders(new ForwardedHeadersOptions
            {
                ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto,
            });

            app.UseHttpsRedirection();
            app.UseCors("AllowAll");
            app.UseAuthorization();
            app.UseRouting();

            app.UseMiddleware<RequestLoggingMiddleware>();
            app.UseMiddleware<ErrorHandlingMiddleware>();
            app.UseMiddleware<TokenVerificationMiddleware>();

            app.UseSentryTracing();

            app.UseExceptionHandler(errorApp =>
            {
                errorApp.Run(async context =>
                {
                    var exceptionHandlerPathFeature = context.Features.Get<IExceptionHandlerPathFeature>();
                    var exception = exceptionHandlerPathFeature?.Error;

                    Logger.Error($"Unhandled exception: {exception}");

                    context.Response.StatusCode = 500;
                    context.Response.ContentType = "application/json";

                    InternalErrors.ServerError.Apply(context);
                });
            });

            // Status code pages for 404, 405, etc.
            app.UseStatusCodePages(async context =>
            {
                var response = context.HttpContext.Response;
                var request = context.HttpContext.Request;
                var requestPath = request.Path.ToString();

                if (response.HasStarted)
                    return;

                switch (response.StatusCode)
                {
                    case 404:
                        response.ContentType = "application/json";
                        if (requestPath.Contains("/fortnite/api/game/v2/profile"))
                        {
                            MCPErrors.OperationNotFound.AttachToResponse(context.HttpContext);
                            return;
                        }
                        else
                        {
                            BasicErrors.NotFound.AttachToResponse(context.HttpContext);
                            return;
                        }

                    case 405:
                        response.ContentType = "application/json";
                        BasicErrors.MethodNotAllowed.AttachToResponse(context.HttpContext);
                        return;
                }
            });

            app.UseMiddleware<TokenVerificationMiddleware>();

            app.MapControllers();

            try
            {
                await fileProviderTask;
                await Constants.FileProvider.GetAthenaSeasonsAsync();
            }
            catch (Exception ex)
            {
                Logger.Error($"[UnrealAssetProvider] Initialization completed with errors: {ex}");
            }

            var hotfixesCsv = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "hotfixes.csv");
            var importService = new CloudStorageImportService();
            await importService.ImportFromCsvIfEmptyAsync(hotfixesCsv);

            Logger.Info($"Helios is running on: {builder.Configuration["ASPNETCORE_URLS"]}");
            AppDomain.CurrentDomain.ProcessExit += (_, __) => discordBot.Dispose();

            var botTask = discordBot.RunAsync(Constants.config.DiscordBotToken);
            var webAppTask = app.RunAsync();

            await Task.WhenAll(botTask, webAppTask);
        }

        private static async Task InitializeFileProvider(WebApplication app)
        {
            try
            {
                Constants.FileProvider = app.Services.GetRequiredService<UnrealAssetProvider>();
                await Constants.FileProvider.InitializeAsync();
                await Constants.FileProvider.LoadAllCosmeticsAsync(CancellationToken.None);
            }
            catch (Exception ex)
            {
                Logger.Error($"[UnrealAssetProvider] Initialization failed: {ex}");
                throw;
            }
        }
    }
}