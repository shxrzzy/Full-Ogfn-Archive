﻿using Helios.Classes.Storefront;
using Helios.Classes.Storefront.Dashboard.FortniteAPI;
using Helios.Database.Repository;
using Helios.Database.Tables.Fortnite;
using Helios.Managers.Storefront;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace Helios.Managers
{
    public class LauncherShopItem
    {
        public string Id { get; set; } = "Unknown";
        public int Price { get; set; }
    }

    public class FormattedStorefront
    {
        public string Name { get; set; }
        public StorefrontEntry Value { get; set; }
    }

    public class StorefrontManager
    {
        public static List<StorefrontEntry> Format(List<Catalog> entries)
        {
            return entries.Select(entry => JsonConvert.DeserializeObject<StorefrontEntry>(entry.Value)).ToList();
        }

        public static async Task<FormattedStorefront?> FindItemByOfferId(Repository<Catalog> repository, string offerId)
        {
            var catalogData = await repository.FindByColumnAsync("offerid", offerId);
            if (catalogData == null || string.IsNullOrEmpty(catalogData.Value))
                return null;

            return new FormattedStorefront
            {
                Name = catalogData.Name,
                Value = JsonConvert.DeserializeObject<StorefrontEntry>(catalogData.Value)
            };
        }

        public static StorefrontEntry New(JSONResponse item, int itemPrice, string section)
        {
            if (item == null || string.IsNullOrEmpty(item?.Type.BackendValue) || string.IsNullOrEmpty(item?.Id))
                throw new ArgumentNullException(nameof(item));

            var entry = CreateBaseEntry(item, section, itemPrice);

            void AddOrUpdateMetaInfo(string key, string value)
            {
                var existing = entry.MetaInfo.FirstOrDefault(meta => meta.Key == key);
                if (existing != null)
                {
                    existing.Value = value;
                }
                else
                {
                    entry.MetaInfo.Add(new() { Key = key, Value = value });
                }
            }

            bool isFeatured = section == "featured";

            if (isFeatured)
            {
                entry.DisplayAssetPath = StorefrontItemManager.SetDisplayAsset($"DA_Featured_{item.Id}");
                entry.NewDisplayAssetPath = StorefrontItemManager.SetNewDisplayAssetPath(item.Id);

                entry.Meta.DisplayAssetPath = entry.DisplayAssetPath;
                entry.Meta.NewDisplayAssetPath = entry.NewDisplayAssetPath;
                entry.Meta.LayoutId = "Featured.99";
                entry.Meta.TileSize = "Normal";
                entry.Meta.SectionId = "Featured";
                entry.Meta.AnalyticOfferGroupId = "Featured";

                if (item.Backpack != null)
                {
                    StorefrontItemManager.AddItemGrant(entry, item.Backpack.Type.BackendValue, item.Backpack.Id);
                    StorefrontItemManager.AddRequirement(entry, item.Backpack.Type.BackendValue, item.Backpack.Id);
                }

                AddOrUpdateMetaInfo("DisplayAssetPath", entry.DisplayAssetPath);
                AddOrUpdateMetaInfo("NewDisplayAssetPath", entry.NewDisplayAssetPath);
                AddOrUpdateMetaInfo("TileSize", "Normal");
                AddOrUpdateMetaInfo("SectionId", "Featured");
            }
            else
            {
                entry.DisplayAssetPath = "";
                entry.NewDisplayAssetPath = "";

                entry.Meta.DisplayAssetPath = "";
                entry.Meta.NewDisplayAssetPath = "";
                entry.Meta.LayoutId = "Daily.99";
                entry.Meta.TileSize = "Small";
                entry.Meta.SectionId = "Daily";
                entry.Meta.AnalyticOfferGroupId = "";

                AddOrUpdateMetaInfo("DisplayAssetPath", "");
                AddOrUpdateMetaInfo("NewDisplayAssetPath", "");
                AddOrUpdateMetaInfo("TileSize", "Small");
                AddOrUpdateMetaInfo("SectionId", "Daily");
            }

            entry.GiftInfo.PurchaseRequirements = entry.Requirements;

            return entry;
        }

        private static StorefrontEntry CreateBaseEntry(JSONResponse item, string section, int price)
        {
            return new StorefrontEntry
            {
                OfferId = $"{item.Type.BackendValue}:{item.Id}",
                OfferType = "StaticPrice",
                DevName = $"[VIRTUAL] 1x {item.Type.BackendValue}:{item.Id} for {price} MtxCurrency",
                ItemGrants = new List<ItemGrant>
                {
                    new() { TemplateId = $"{item.Type.BackendValue}:{item.Id}", Quantity = 1 }
                },
                Requirements = new List<Requirement>
                {
                    StorefrontItemManager.DefaultRequirements(item.Type.BackendValue, item.Id)
                },
                Categories = item.Set != null ? new List<string> { item.Set.BackendValue } : new List<string>(),
                MetaInfo = StorefrontItemManager.DefaultMetaInfo,
                Prices = new List<Price>
                {
                    new()
                    {
                        CurrencyType = "MtxCurrency",
                        CurrencySubType = "Currency",
                        DynamicRegularPrice = price,
                        SaleExpiration = "9999-12-31T23:59:59.999Z",
                        BasePrice = price,
                        RegularPrice = price,
                        FinalPrice = price
                    }
                },
                GiftInfo = new GiftInfo
                {
                    BIsEnabled = true,
                    ForcedGiftBoxTemplateId = string.Empty,
                    PurchaseRequirements = new List<Requirement>(),
                    GiftRecordIds = new List<string>()
                },
                Meta = StorefrontItemManager.DefaultMeta,
                DisplayAssetPath = StorefrontItemManager.SetDisplayAsset($"DA_Daily_{item.Id}"),
                NewDisplayAssetPath = "",
                Refundable = true,
                Title = "",
                Description = "",
                ShortDescription = "",
                AppStoreId = new List<string>(),
                FulfillmentIds = new List<object>(),
                DailyLimit = -1,
                WeeklyLimit = -1,
                MonthlyLimit = -1,
                SortPriority = 0,
                CatalogGroupPriority = 0,
                FilterWeight = 0,
                BannerOverride = "",
                MatchFilter = "",
                AdditionalGrants = new List<ItemGrant>()
            };
        }


        public static async Task<List<LauncherShopItem>> ExtractItems(Repository<Catalog> repository, string storefront)
        {
            var selectedStorefronts = await repository.FindAllByColumnAsync("storefront", new[] { storefront });
            if (selectedStorefronts == null || !selectedStorefronts.Any())
                return new();

            var items = new List<LauncherShopItem>();

            foreach (var storefrontEntry in selectedStorefronts)
            {
                if (string.IsNullOrEmpty(storefrontEntry.Value))
                    continue;

                StorefrontEntry? deserialized;
                try
                {
                    deserialized = System.Text.Json.JsonSerializer.Deserialize<StorefrontEntry>(storefrontEntry.Value);
                }
                catch (Exception ex)
                {
                    continue;
                }

                if (deserialized == null)
                    continue;

                items.AddRange(new[] {
                    new LauncherShopItem
                    {
                        Id = deserialized.OfferId ?? "Unknown",
                        Price = deserialized.Prices?.FirstOrDefault()?.FinalPrice ?? 0
                    }
                });
            }

            return items;
        }
    }
}