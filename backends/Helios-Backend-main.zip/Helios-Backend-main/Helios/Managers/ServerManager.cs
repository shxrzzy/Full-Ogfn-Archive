using Helios.Classes.MatchmakingServers;
using Helios.Classes.Storefront;
using Helios.Database.Repository;
using Helios.Utilities.Requests.GetMatchmakingServers;
using Microsoft.AspNetCore.Hosting.Server;
using Newtonsoft.Json;

namespace Helios.Managers
{
    public class ServerManager
    {
        public static async Task<Servers?> GetServerBySessionIdAsync(string sessionId)
        {
            Servers? server = await GetMatchmakingServers.GetServerById(sessionId);
            return server;
        }
        public static async Task<Servers?> GetDedicatedServerBySessionIdAsync(string sessionId)
        {
            Servers? server = await GetMatchmakingServers.GetDedicatedServerById(sessionId);
            return server;
        }
        public static async Task<SelectedPlaylist> GetPlaylistByRegion(string region)
        {
            SelectedPlaylist playlist = await GetSessionPlaylist.SelectPlaylistAsync(region);
            return playlist;
        }
    }
}