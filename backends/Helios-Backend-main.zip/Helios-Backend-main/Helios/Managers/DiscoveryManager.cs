﻿namespace Helios.Managers;

public static class DiscoveryManager
{
    public static object CreatePlaylist(string mnemonic, string image)
    {
        return new
        {
            linkData = new
            {
                @namespace = "fn",
                mnemonic = mnemonic,
                linkType = "BR:Playlist",
                active = true,
                disabled = false,
                version = 1,
                moderationStatus = "Unmoderated",
                accountId = "epic",
                creatorName = "Epic",
                descriptionTags = new string[] { },
                metadata = new
                {
                    image_url = image,
                    matchmaking = new
                    {
                        override_playlist = mnemonic
                    }
                }
            },
            lastVisited = (object)null,
            linkCode = mnemonic,
            isFavorite = false
        };
    }
}