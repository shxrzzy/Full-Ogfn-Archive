﻿using Helios.Classes.MCP.Response;
using Helios.Database.Tables.Profiles;
using Helios.Utilities.Caching;
using Helios.Utilities.Extensions;

namespace Helios.Managers
{
    public class ProfileResponseManager
    {
        public static BaseMCPResponse Generate(Profiles profile, IEnumerable<object> changes, string profileId)
        {
            return GenerateBaseResponse(profile, changes.ToList(), profileId);
        }

        private static BaseMCPResponse GenerateBaseResponse(Profiles profile, List<object> changes, string profileId)
        {
            return new BaseMCPResponse
            {
                ProfileRevision = profile.Revision,
                ProfileId = profileId,
                ProfileChangesBaseRevision = profile.Revision - 1,
                ProfileChanges = changes,
                ProfileCommandRevision = profile.Revision,
                ServerTime = DateTime.UtcNow.ToIsoUtcString(),
                ResponseVersion = 1
            };
        }

        public static PurchaseResponse GeneratePurchaseResponse(
            Profiles profile,
            Profiles athenaProfile,
            IEnumerable<object> changes,
            IEnumerable<object> multiUpdates,
            IEnumerable<object> notifications,
            string profileId)
        {
            return new PurchaseResponse
            {
                ProfileRevision = profile.Revision,
                ProfileId = profileId,
                ProfileChangesBaseRevision = profile.Revision - 1,
                ProfileChanges = changes.ToList(),
                ProfileCommandRevision = profile.Revision,
                Notifications = new List<object>
                {
                    new
                    {
                        type = "CatalogPurchase",
                        primary = true,
                        lootResult = new
                        {
                            items = notifications.ToList()
                        }
                    }
                },
                MultiUpdate = new List<MultiUpdate>
                {
                    GenerateMultiUpdate(athenaProfile, multiUpdates.ToList(), "athena")
                },
                ServerTime = DateTime.UtcNow.ToIsoUtcString(),
                ResponseVersion = 1
            };
        }

        private static MultiUpdate GenerateMultiUpdate(Profiles profile, List<object> changes, string profileId)
        {
            return new MultiUpdate
            {
                ProfileRevision = profile.Revision,
                ProfileId = profileId,
                ProfileChangesBaseRevision = profile.Revision - 1,
                ProfileChanges = changes,
                ProfileCommandRevision = profile.Revision
            };
        }
    }
}
