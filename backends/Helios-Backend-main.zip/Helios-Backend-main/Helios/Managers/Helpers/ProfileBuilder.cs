﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using Helios.Classes.MCP;
using Helios.Classes.Caching;
using Helios.Database.Tables.Account;
using Helios.Database.Tables.Profiles;
using Helios.Utilities;
using Helios.Utilities.Caching;
using Helios.Utilities.Extensions;

namespace Helios.Managers.Helpers;

public class ProfileBuilder : MCPProfile
{
    private static readonly JsonDocumentOptions JsonOptions = new()
    {
        AllowTrailingCommas = true,
        MaxDepth = 64
    };

    private static readonly JsonSerializerOptions SerializerOptions = new()
    {
        MaxDepth = 64,
        AllowTrailingCommas = true
    };

    private static readonly TimeSpan CacheDuration = TimeSpan.FromMinutes(30);

    private const string LoadoutKeyword = "loadout";
    private const string CosmeticLockerType = "CosmeticLocker:cosmeticlocker_athena";
    private const string EmptyJson = "{}";

    private static long _totalInstances = 0;
    private static long _activeInstances = 0;

    private Dictionary<string, JsonElement> _attributesDict;

    public ProfileBuilder(string accountId, Profiles profile, User user, List<Items> profileItems)
    {
        if (string.IsNullOrWhiteSpace(accountId))
            throw new ArgumentException("Account ID cannot be null or empty", nameof(accountId));

        if (profile == null)
            throw new ArgumentNullException(nameof(profile));

        if (profileItems == null)
            throw new ArgumentNullException(nameof(profileItems));

        Interlocked.Increment(ref _totalInstances);
        Interlocked.Increment(ref _activeInstances);

        try
        {
            var timestamp = DateTime.UtcNow.ToIsoUtcString();
            Created = Updated = timestamp;

            SetupCoreProfile(accountId, profile, profileItems.Count);
            GenerateItems(profileItems);
        }
        catch
        {
            Interlocked.Decrement(ref _activeInstances);
            throw;
        }
    }

    private void SetupCoreProfile(string accountId, Profiles profile, int itemCount)
    {
        Rvn = Math.Max(0, profile.Revision);
        WipeNumber = 1;
        AccountId = accountId;
        ProfileId = profile.ProfileId ?? string.Empty;
        Version = "no_version";
        CommandRevision = Math.Max(0, profile.Revision);

        var itemCapacity = Math.Max(16, itemCount);
        var attributeCapacity = Math.Max(8, itemCount / 4);

        Items = new Dictionary<string, dynamic>(itemCapacity);

        _attributesDict = new Dictionary<string, JsonElement>(attributeCapacity);

        Stats = new StatsContainer { attributes = _attributesDict };
    }

    private void GenerateItems(List<Items> profileItems)
    {
        if (profileItems.Count == 0) return;

        const int batchSize = 100;

        for (int batchStart = 0; batchStart < profileItems.Count; batchStart += batchSize)
        {
            int batchEnd = Math.Min(batchStart + batchSize, profileItems.Count);

            for (int i = batchStart; i < batchEnd; i++)
            {
                var item = profileItems[i];

                if (item == null ||
                    string.IsNullOrWhiteSpace(item.TemplateId) ||
                    string.IsNullOrWhiteSpace(item.Value))
                {
                    continue;
                }

                try
                {
                    if (item.IsAttribute)
                    {
                        HandleAttribute(item);
                    }
                    else
                    {
                        HandleItem(item);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error($"Error processing item {item.TemplateId}: {ex.Message}");
                }
            }

            if (batchEnd < profileItems.Count)
            {
                GC.Collect(0, GCCollectionMode.Optimized);
            }
        }
    }

    private void HandleItem(Items item)
    {
        var parsed = ParseJson(item.Value);

        if (!parsed.HasValue)
        {
            var fixedJson = TryFixJson(item.Value);
            if (fixedJson != null)
            {
                parsed = ParseJson(fixedJson);
            }
        }

        bool isLoadout = item.TemplateId.Contains(LoadoutKeyword, StringComparison.OrdinalIgnoreCase);
        string templateId = isLoadout ? CosmeticLockerType : item.TemplateId;

        int quantity = Math.Max(0, item.Quantity);

        JsonElement attributes;

        if (parsed.HasValue && parsed.Value.ValueKind == JsonValueKind.Object && parsed.Value.EnumerateObject().Any())
        {
            attributes = parsed.Value;
        }
        else
        {
            attributes = CreateDefaultAttributes(item.TemplateId);
        }

        Items[item.TemplateId] = new
        {
            attributes,
            templateId,
            quantity
        };
    }

    private void HandleAttribute(Items item)
    {
        var parsed = ParseJson(item.Value);
        if (!parsed.HasValue) return;

        try
        {
            var fixedAttribute = FixNumericStrings(parsed.Value);

            _attributesDict[item.TemplateId] = fixedAttribute;
        }
        catch (Exception ex)
        {
            Logger.Error($"Error handling attribute {item.TemplateId}: {ex.Message}");
        }
    }

    private JsonElement FixNumericStrings(JsonElement element)
    {
        if (element.ValueKind != JsonValueKind.Object && element.ValueKind != JsonValueKind.Array)
        {
            return element.Clone();
        }

        try
        {
            var fixedValue = FixNumbers(element);
            var json = JsonSerializer.Serialize(fixedValue, SerializerOptions);

            using var doc = JsonDocument.Parse(json, JsonOptions);
            return doc.RootElement.Clone();
        }
        catch (JsonException)
        {
            return element.Clone();
        }
    }

    private object FixNumbers(JsonElement element)
    {
        switch (element.ValueKind)
        {
            case JsonValueKind.Object:
                var dict = new Dictionary<string, object>();
                foreach (var prop in element.EnumerateObject())
                {
                    dict[prop.Name] = FixNumbers(prop.Value);
                }
                return dict;

            case JsonValueKind.Array:
                var list = new List<object>();
                foreach (var item in element.EnumerateArray())
                {
                    list.Add(FixNumbers(item));
                }
                return list;

            case JsonValueKind.String:
                string strValue = element.GetString();
                if (int.TryParse(strValue, out int intValue))
                    return intValue;
                if (long.TryParse(strValue, out long longValue))
                    return longValue;
                if (double.TryParse(strValue, out double doubleValue))
                    return doubleValue;
                return strValue;

            case JsonValueKind.Number:
                if (element.TryGetInt32(out int numInt))
                    return numInt;
                if (element.TryGetInt64(out long numLong))
                    return numLong;
                return element.GetDouble();

            case JsonValueKind.True:
                return true;

            case JsonValueKind.False:
                return false;

            case JsonValueKind.Null:
                return null;

            default:
                return element.GetRawText();
        }
    }

    private static bool TryParseNumeric(string? str, out object number)
    {
        number = str ?? string.Empty;

        if (string.IsNullOrEmpty(str))
        {
            return false;
        }

        if (int.TryParse(str, out var intVal))
        {
            number = intVal;
            return true;
        }

        if (long.TryParse(str, out var longVal))
        {
            number = longVal;
            return true;
        }

        if (double.TryParse(str, out var doubleVal) && !double.IsNaN(doubleVal) && !double.IsInfinity(doubleVal))
        {
            number = doubleVal;
            return true;
        }

        return false;
    }

    private static readonly Lazy<JsonElement> _emptyElement = new(() =>
    {
        using var doc = JsonDocument.Parse(EmptyJson, JsonOptions);
        return doc.RootElement.Clone();
    });

    private static string? TryFixJson(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return null;

        var trimmed = json.Trim();

        if (!trimmed.StartsWith("{") && !trimmed.StartsWith("["))
        {
            if (trimmed.StartsWith("\"") && trimmed.EndsWith("\""))
            {
                return $"{{\"value\":{trimmed}}}";
            }

            var escaped = trimmed.Replace("\\", "\\\\").Replace("\"", "\\\"");
            return $"{{\"value\":\"{escaped}\"}}";
        }

        return trimmed;
    }

    private static JsonElement CreateDefaultAttributes(string templateId)
    {
        var defaultAttrs = new Dictionary<string, object>
        {
            ["level"] = 1,
            ["item_seen"] = true,
            ["playlists"] = new object[0],
            ["variants"] = new object[0],
            ["favorite"] = false
        };

        var json = JsonSerializer.Serialize(defaultAttrs, SerializerOptions);
        using var doc = JsonDocument.Parse(json, JsonOptions);
        return doc.RootElement.Clone();
    }

    private static JsonElement? ParseJson(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
        {
            return null;
        }

        if (json.Length > 1024 * 1024)
        {
            return null;
        }

        return HeliosFastCache.GetOrAdd($"json:{json.GetHashCode()}", () =>
        {
            try
            {
                using var doc = JsonDocument.Parse(json, JsonOptions);
                return doc.RootElement.Clone();
            }
            catch (JsonException)
            {
                return (JsonElement?)null;
            }
        }, CacheDuration);
    }

    ~ProfileBuilder()
    {
        Interlocked.Decrement(ref _activeInstances);
    }

    public static (long Total, long Active) GetInstanceCounts() => (_totalInstances, _activeInstances);

    private class StatsContainer
    {
        public Dictionary<string, JsonElement> attributes { get; set; }
    }
}