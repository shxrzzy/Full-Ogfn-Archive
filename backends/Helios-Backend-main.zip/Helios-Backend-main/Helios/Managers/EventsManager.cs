﻿using Helios.Classes.Tournaments;
using Helios.Classes.Tournaments.DBInterfaces;
using Helios.Database.Repository;
using Helios.Database.Tables.Tournaments;
using Helios.Utilities;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;

namespace Helios.Managers;

public static class EventsManager
{
    private static readonly Regex SeasonPattern = new(@"S\d+", RegexOptions.Compiled);
    private static readonly ConcurrentDictionary<string, (DateTime lastModified, string content)> FileCache = new();

    public static async Task<string?> LoadFileWithCachingAsync(string fileName)
    {
        var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Events", fileName);

        if (!File.Exists(filePath))
            return null;

        var lastModified = File.GetLastWriteTime(filePath);

        if (FileCache.TryGetValue(fileName, out var cached) && cached.lastModified >= lastModified)
            return cached.content;

        var content = await File.ReadAllTextAsync(filePath);
        FileCache.AddOrUpdate(fileName, (lastModified, content), (_, _) => (lastModified, content));

        return content;
    }

    public static async Task<IEnumerable<TournamentHype>> RefreshPersistentScoresAsync(
        IEnumerable<TournamentHype> persistentScores,
        Repository<TournamentHype> repository)
    {
        var refreshedScores = new List<TournamentHype>();
        foreach (var score in persistentScores)
        {
            var refreshed = await repository.FindByColumnsAsync(new Dictionary<string, object>
            {
                { "accountid", score.AccountId },  
                { "season", score.Season },       
                { "type", score.Type }           
            });

            if (refreshed != null)
                refreshedScores.Add(refreshed);
        }
        return refreshedScores;
    }


    public static void ProcessArenaEventsInParallel(List<Classes.Tournaments.Event> arenaEvents, string seasonReplacement)
    {
        Parallel.ForEach(arenaEvents, evt =>
        {
            evt.eventId = SeasonPattern.Replace(evt.eventId ?? string.Empty, seasonReplacement);

            if (evt.eventWindows != null)
            {
                Parallel.ForEach(evt.eventWindows, window =>
                {
                    window.EventTemplateId = SeasonPattern.Replace(window.EventTemplateId ?? string.Empty, seasonReplacement);
                    window.EventWindowId = SeasonPattern.Replace(window.EventWindowId ?? string.Empty, seasonReplacement);

                    window.RequireAllTokens ??= Array.Empty<string>();
                    window.RequireNoneTokensCaller ??= Array.Empty<string>();

                    window.RequireAllTokens = window.RequireAllTokens
                        .Select(token => SeasonPattern.Replace(token ?? string.Empty, seasonReplacement))
                        .ToArray();

                    window.RequireNoneTokensCaller = window.RequireNoneTokensCaller
                        .Select(token => SeasonPattern.Replace(token ?? string.Empty, seasonReplacement))
                        .ToArray();
                });
            }
        });
    }

    public static void ProcessArenaTemplatesInParallel(List<ArenaEventTemplate> arenaEventTemplates, string seasonReplacement)
    {
        Parallel.ForEach(arenaEventTemplates, template =>
        {
            template.EventTemplateId = SeasonPattern.Replace(template.EventTemplateId, seasonReplacement);

            if (template.PayoutTable?.Ranks != null)
            {
                Parallel.ForEach(template.PayoutTable.Ranks, rank =>
                {
                    if (rank.Payouts != null)
                    {
                        Parallel.ForEach(rank.Payouts, payout =>
                        {
                            if (!string.IsNullOrEmpty(payout.Value))
                            {
                                payout.Value = SeasonPattern.Replace(payout.Value, seasonReplacement);
                            }
                        });
                    }
                });
            }
        });
    }

    public static DivisionInfo[] CreateDivisions(int season)
    {
        var divisions = new List<DivisionInfo>();

        divisions.AddRange(new[]
        {
            new DivisionInfo { Name = $"Arena_LateGame_S{season}_Division1", Min = 0, Max = 399 },
            new DivisionInfo { Name = $"Arena_LateGame_S{season}_Division2", Min = 400, Max = 799 },
            new DivisionInfo { Name = $"Arena_LateGame_S{season}_Division3", Min = 800, Max = 1199 },
            new DivisionInfo { Name = $"Arena_LateGame_S{season}_Division4", Min = 1200, Max = 1999 },
            new DivisionInfo { Name = $"Arena_LateGame_S{season}_Division5", Min = 2000, Max = 2999 },
            new DivisionInfo { Name = $"Arena_LateGame_S{season}_Division6", Min = 3000, Max = 4999 },
            new DivisionInfo { Name = $"Arena_LateGame_S{season}_Division7", Min = 5000, Max = 7499 },
            new DivisionInfo { Name = $"Arena_LateGame_S{season}_Division8", Min = 7500, Max = 9999 },
            new DivisionInfo { Name = $"Arena_LateGame_S{season}_Division9", Min = 10000, Max = 14999 },
            new DivisionInfo { Name = $"Arena_LateGame_S{season}_Division10", Min = 15000, Max = 9999999 },
        });

        divisions.AddRange(new[]
        {
            new DivisionInfo { Name = $"Arena_S{season}_Division1_Solo", Min = 0, Max = 399 },
            new DivisionInfo { Name = $"Arena_S{season}_Division2_Solo", Min = 400, Max = 799 },
            new DivisionInfo { Name = $"Arena_S{season}_Division3_Solo", Min = 800, Max = 1199 },
            new DivisionInfo { Name = $"Arena_S{season}_Division4_Solo", Min = 1200, Max = 1999 },
            new DivisionInfo { Name = $"Arena_S{season}_Division5_Solo", Min = 2000, Max = 2999 },
            new DivisionInfo { Name = $"Arena_S{season}_Division6_Solo", Min = 3000, Max = 4999 },
            new DivisionInfo { Name = $"Arena_S{season}_Division7_Solo", Min = 5000, Max = 7499 },
            new DivisionInfo { Name = $"Arena_S{season}_Division8_Solo", Min = 7500, Max = 9999 },
            new DivisionInfo { Name = $"Arena_S{season}_Division9_Solo", Min = 10000, Max = 14999 },
            new DivisionInfo { Name = $"Arena_S{season}_Division10_Solo", Min = 15000, Max = 9999999 },
        });

        return divisions.ToArray();
    }

    public static DivisionRequirement[] CreateDivisionRequirements(int season)
    {
        return CreateDivisions(season).Select(d => new DivisionRequirement
        {
            RequiredPoints = d.Min,
            Token = d.Name
        }).ToArray();
    }

    public static List<TournamentHypeTokens> CreateHypeEntities(DivisionInfo[] divisions, string accountId, int season)
    {
        return divisions.Select((division, idx) => new TournamentHypeTokens
        {
            AccountId = accountId,
            Token = division.Name,
            MinimumRequiredHype = division.Min,
            Division = idx + 1,
            MaximumRequiredHype = division.Max,
            Season = season,
        }).ToList();
    }

    public static async Task ProcessHypeTokensAsync(List<TournamentHypeTokens> hypeEntities,
        IEnumerable<TournamentHypeTokens> existingHypeTokens, Repository<TournamentHypeTokens> repository)
    {
        var existingKeys = new HashSet<string>(existingHypeTokens.Select(t => $"{t.AccountId}_{t.Token}_{t.Season}"));

        var newEntities = hypeEntities
            .Where(entity => !existingKeys.Contains($"{entity.AccountId}_{entity.Token}_{entity.Season}"))
            .ToList();

        if (newEntities.Any())
            await repository.BulkInsertAsync(newEntities);
    }

    public static async Task ProcessNewTokensAsync(IEnumerable<TournamentHype> persistentScores,
        DivisionInfo[] divisions, IEnumerable<TournamentTokens> allTokens, string accountId,
        int season, Repository<TournamentTokens> repository)
    {
        var tokens = new List<string>();

        foreach (var eventHype in persistentScores ?? Enumerable.Empty<TournamentHype>())
        {
            var matchingDivisions = divisions
                .Where(d => d.Max <= eventHype.Hype || (eventHype.Hype >= d.Min && eventHype.Hype <= d.Max))
                .Select(d => d.Name);

            tokens.AddRange(matchingDivisions);
        }

        var existingTokenSet = new HashSet<string>(allTokens.Select(et => et.Token));
        var newTokens = tokens
            .Where(token => !existingTokenSet.Contains(token))
            .Select(token => new TournamentTokens
            {
                AccountId = accountId,
                Token = token,
                Season = season
            }).ToList();

        if (newTokens.Any())
            await repository.BulkInsertAsync(newTokens);
    }

    public static List<EventMapping> CreateEventMappings(IEnumerable<TournamentEvents> allEvents, string appId)
    {
        return allEvents.Select(eventItem => new EventMapping
        {
            gameId = "Fortnite",
            eventId = eventItem.EventId,
            displayDataId = eventItem.DisplayDataId,
            beginTime = eventItem.BeginTime,
            endTime = eventItem.EndTime,
            announcementTime = eventItem.AnnouncementTime,
            regions = eventItem.Regions?.ToList() ?? new List<string>(),
            regionMappings = eventItem.RegionMappings ?? new Dictionary<string, string>(),
            platforms = eventItem.Platforms?.ToList() ?? new List<string>(),
            platformMappings = eventItem.PlatformMappings,
            appId = "Fortnite",
            environment = eventItem.Environment,
            metadata = new DB_Metadata
            {
                MinimumAccountLevel = 1,
                TrackedStats = Array.Empty<string>(),
                TeamLockType = "Window",
                DisqualifyType = "Event",
                AccountLockType = "Window"
            },
            eventWindows = eventItem.EventWindows != null ? eventItem.EventWindows
                    .Select(window => DeserializeEventWindow(window))
                    .ToList()
                    : new List<DB_EventWindow>()
        }).ToList();
    }

    private static DB_Metadata DeserializeMetadata(object? eventMetadata)
    {
        if (eventMetadata == null)
            return new DB_Metadata();

        var metadataString = eventMetadata.ToString();
        if (string.IsNullOrEmpty(metadataString))
            return new DB_Metadata();

        try
        {
            var trimmed = metadataString.Trim();
            if (trimmed.StartsWith("{") || trimmed.StartsWith("["))
            {
                return JsonConvert.DeserializeObject<DB_Metadata>(metadataString) ?? new DB_Metadata();
            }
            else
            {
                return new DB_Metadata();
            }
        }
        catch (JsonException ex)
        {
            Logger.Error($"Failed to deserialize EventMetadata: {metadataString}. Error: {ex.Message}");
            return new DB_Metadata();
        }
    }

    public static DB_EventWindow DeserializeEventWindow(object window)
    {
        try
        {
            var windowString = window.ToString();
            if (string.IsNullOrEmpty(windowString))
                return new DB_EventWindow();

            var trimmed = windowString.Trim();
            if (trimmed.StartsWith("{") || trimmed.StartsWith("["))
            {
                return JsonConvert.DeserializeObject<DB_EventWindow>(windowString) ?? new DB_EventWindow();
            }
            else
            {
                return new DB_EventWindow();
            }
        }
        catch (JsonException ex)
        {
            Logger.Error($"Failed to deserialize EventWindow: {window}. Error: {ex.Message}");
            return new DB_EventWindow();
        }
    }
    private static DB_TiebreakerFormula DeserializeTiebreakerFormula(object? tiebreakerFormula)
    {
        if (tiebreakerFormula == null)
            return new DB_TiebreakerFormula();

        try
        {
            var formulaString = tiebreakerFormula.ToString();
            if (string.IsNullOrEmpty(formulaString))
                return new DB_TiebreakerFormula();

            var trimmed = formulaString.Trim();
            if (trimmed.StartsWith("{") || trimmed.StartsWith("["))
            {
                return JsonConvert.DeserializeObject<DB_TiebreakerFormula>(formulaString) ?? new DB_TiebreakerFormula();
            }
            else
            {
                return new DB_TiebreakerFormula();
            }
        }
        catch (JsonException ex)
        {
            Logger.Error($"Failed to deserialize TiebreakerFormula: {tiebreakerFormula}. Error: {ex.Message}");
            return new DB_TiebreakerFormula();
        }
    }

    private static DB_ScoringRules DeserializeScoringRule(object rule)
    {
        try
        {
            var ruleString = rule.ToString();
            if (string.IsNullOrEmpty(ruleString))
                return new DB_ScoringRules();

            var trimmed = ruleString.Trim();
            if (trimmed.StartsWith("{") || trimmed.StartsWith("["))
            {
                return JsonConvert.DeserializeObject<DB_ScoringRules>(ruleString) ?? new DB_ScoringRules();
            }
            else
            {
                Logger.Warn($"ScoringRule is not valid JSON: {ruleString}");
                return new DB_ScoringRules();
            }
        }
        catch (JsonException ex)
        {
            Logger.Error($"Failed to deserialize ScoringRule: {rule}. Error: {ex.Message}");
            return new DB_ScoringRules();
        }
    }

    public static List<TemplateMapping> CreateTemplateMappings(IEnumerable<TournamentTemplates> allEventTemplates, string appId)
    {
        return allEventTemplates.Select(template => new TemplateMapping
        {
            eventTemplateId = template.TournamentId,
            playlistId = template.PlaylistId,
            tiebreakerFormula = template.TiebreakerFormula != null ? JsonConvert.DeserializeObject<DB_TiebreakerFormula>(template.TiebreakerFormula) : new DB_TiebreakerFormula(),
            matchCap = template.MatchCap,
            gameId = appId,
            scoringRules = !string.IsNullOrEmpty(template.ScoringRules)
                    ? JsonConvert.DeserializeObject<List<DB_ScoringRules>>(template.ScoringRules)
                    : new List<DB_ScoringRules>(),
            payoutTable = JsonConvert.DeserializeObject<List<object>>(template.PayoutTable?.ToString() ?? "[]"),
            liveSessionAttributes = JsonConvert.DeserializeObject<List<object>>(template.LiveSessionAttributes?.ToString() ?? "[]"),
            clampsToZero = template.ClampsToZero,
            onlyScoreTopN = template.OnlyScoreTopN
        }).ToList();
    }

    public static List<EventMapping> CreateArenaEventMappings(List<Classes.Tournaments.Event> arenaEvents)
    {
        return arenaEvents.Select(eventItem => new EventMapping
        {
            gameId = eventItem.gameId ?? string.Empty,
            eventId = eventItem.eventId ?? string.Empty,
            displayDataId = eventItem.displayDataId ?? string.Empty,
            beginTime = eventItem.beginTime ?? string.Empty,
            endTime = eventItem.endTime ?? string.Empty,
            announcementTime = eventItem.announcementTime ?? string.Empty,
            regions = eventItem.regions?.ToList() ?? new List<string>(),
            regionMappings = eventItem.regionMappings ?? new Dictionary<string, string>(),
            platforms = eventItem.platforms?.ToList() ?? new List<string>(),
            platformMappings = eventItem.platformMappings ?? new Dictionary<string, object>(),
            appId = eventItem.appId,
            environment = eventItem.environment,
            metadata = eventItem.metadata ?? new DB_Metadata(),
            eventWindows = eventItem.eventWindows?.Select(window => new DB_EventWindow
            {
                EventTemplateId = window.EventTemplateId,
                EventWindowId = window.EventWindowId,
                BeginTime = window.BeginTime,
                EndTime = window.EndTime,
                CountdownBeginTime = window.CountdownBeginTime,
                Round = window.Round,
                PayoutDelay = window.PayoutDelay,
                IsTBD = window.IsTBD,
                CanLiveSpectate = window.CanLiveSpectate,
                Visibility = window.Visibility,
                TeammateEligibility = window.TeammateEligibility,
                RequireAllTokens = window.RequireAllTokens ?? Array.Empty<string>(),
                RequireAllTokensCaller = window.RequireAllTokensCaller ?? Array.Empty<string>(),
                RequireAnyTokens = window.RequireAnyTokens ?? Array.Empty<string>(),
                RequireAnyTokensCaller = window.RequireAnyTokensCaller ?? Array.Empty<string>(),
                RequireNoneTokensCaller = window.RequireNoneTokensCaller ?? Array.Empty<string>(),
                AdditionalRequirements = window.AdditionalRequirements ?? new List<string>(),
                BlackoutPeriods = window.BlackoutPeriods ?? new List<string>(),
                ScoreLocations = window.ScoreLocations ?? new List<DB_ScoreLocation>(),
                Metadata = window.Metadata ?? new DB_EventMetadata()
            }).ToList() ?? new List<DB_EventWindow>(),
            eventGroup = eventItem.eventGroup ?? string.Empty,
            link = eventItem.link
        }).ToList();
    }

    public static List<TemplateMapping> CreateArenaTemplateMappings(List<ArenaEventTemplate> arenaEventTemplates, string appId)
    {
        return arenaEventTemplates.Select(template => new TemplateMapping
        {
            eventTemplateId = template.EventTemplateId,
            persistentScoreId = template.PersistentScoreId,
            playlistId = template.PlaylistId,
            matchCap = template.MatchCap,
            gameId = appId,
            scoringRules = template.ScoringRules,
            payoutTable = template.PayoutTable
        }).ToList();
    }

    public static Dictionary<string, int> CreateScoresDictionary(IEnumerable<TournamentHype>? persistentScores,
        IEnumerable<TournamentScores>? allEventScores)
    {
        var scores = new Dictionary<string, int>();

        foreach (var score in persistentScores ?? Enumerable.Empty<TournamentHype>())
        {
            scores.TryAdd(score.Type, score.Hype);
        }

        foreach (var eventScore in allEventScores ?? Enumerable.Empty<TournamentScores>())
        {
            scores[eventScore.ScoringType] = eventScore.Score;
        }

        return scores;
    }

    public static async Task<TournamentPlayer> EnsurePlayerExistsAsync(TournamentPlayer? player, string accountId,
        int season, Repository<TournamentPlayer> repository)
    {
        if (player != null) return player;

        var newPlayer = new TournamentPlayer
        {
            AccountId = accountId,
            PendingPayouts = new List<object>(),
            PendingPenalties = new List<object>(),
            PersistentScores = new List<object>(),
            Season = season,
        };

        await repository.SaveAsync(newPlayer);
        return newPlayer;
    }

    public static async Task<IEnumerable<TournamentHype>> GetFreshPersistentScoresAsync(
        string accountId,
        int season,
        Repository<TournamentHype> repository)
    {
        return await repository.FindAllByColumnsAsync(new Dictionary<string, object>
        {
            { "accountid", accountId },
            { "season", season }
        });
    }

    public static async Task<IEnumerable<TournamentHype>> EnsurePersistentScoresExistAsync(
        IEnumerable<TournamentHype> persistentScores,
        string accountId,
        int season,
        Repository<TournamentHype> repository)
    {
        var freshScores = await GetFreshPersistentScoresAsync(accountId, season, repository);

        if (freshScores.Any())
            return freshScores;

        var newEventHype = new TournamentHype
        {
            AccountId = accountId,
            Season = season,
            Type = "NormalHype",
            Hype = 0
        };

        await repository.SaveAsync(newEventHype);
        return new[] { newEventHype };
    }

    public static bool ShouldIncludeArenaEvents(int season, string currentVersion)
    {
        return season > 7 && season == int.Parse(currentVersion.Split(".")[0]);
    }
}
