using Helios.Classes.MatchmakingServers;
using Helios.Classes.Storefront;
using Helios.Database.Repository;
using Helios.Utilities.Requests.GetMatchmakingServers;
using Microsoft.AspNetCore.Hosting.Server;
using Newtonsoft.Json;

namespace Helios.Managers.Storefront
{
    public class StorefrontItemManager
    {

        public static readonly List<MetaInfo> DefaultMetaInfo = new()
        {
            new() { Key = "TileSize", Value = "Normal" },
            new() { Key = "SectionId", Value = "Featured" },
            new() { Key = "BannerOverride", Value = "" }
        };

        public static readonly Meta DefaultMeta = new()
        {
            NewDisplayAssetPath = "",
            DisplayAssetPath = "",
            SectionId = "Daily",
            TileSize = "Small",
            LayoutId = "Daily.99",
            AnalyticOfferGroupId = "Daily"
        };

        public static Requirement DefaultRequirements(string type, string id) => new()
        {
            RequirementType = "DenyOnItemOwnership",
            RequiredId = $"{type}:{id}",
            MinQuantity = 1
        };

        public static string GetBaseItemId(string fullItemId)
        {
            List<string> prefixesToRemove = new List<string>
            {
                "AthenaCharacter",
                "AthenaGlider",
                "AthenaPickaxe",
                "AthenaItemWrap",
                "AthenaDance"
            };

            foreach (var prefix in prefixesToRemove)
            {
                if (fullItemId.Contains(prefix))
                {
                    return fullItemId.Replace(prefix + ":", "");
                }
            }

            return fullItemId;
        }

        public static string SetDisplayAsset(string item)
        {
            return $"/Game/Catalog/DisplayAssets/{item}.{item}";
        }

        public static string SetNewDisplayAssetPath(string item)
        {
            return $"/Game/Catalog/NewDisplayAssets/DAv2_Featured_{item}.DAv2_Featured_{item}";
        }

        public static string GetDisplayAsset(string item)
        {
            string baseItemId = GetBaseItemId(item);
            return $"/Game/Catalog/DisplayAssets/{baseItemId}.{baseItemId}";
        }

        public static void AddItemGrant(StorefrontEntry entry, string type, string id)
        {
            entry.ItemGrants.Add(new ItemGrant { TemplateId = $"{type}:{id}", Quantity = 1 });
        }

        public static void AddRequirement(StorefrontEntry entry, string type, string id)
        {
            entry.Requirements.Add(DefaultRequirements(type, id));
        }
    }
}