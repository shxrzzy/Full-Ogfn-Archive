using System.Text.Json.Serialization;

namespace Helios.Classes.Tournaments.DBInterfaces;

public class DB_EventLink
{
    [JsonPropertyName("type")]
    public string Type { get; set; }
    [JsonPropertyName("code")]
    public string Code { get; set; }
    [JsonPropertyName("version")]
    public int Version { get; set; }
}