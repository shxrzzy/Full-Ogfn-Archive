﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Helios.Classes.Tournaments.DBInterfaces
{
    public class DB_EventWindow
    {
        [JsonProperty("beginTime")]
        public string BeginTime { get; set; }

        [JsonProperty("additionalRequirements")]
        public List<string> AdditionalRequirements { get; set; } = new List<string>();

        [JsonProperty("blackoutPeriods")]
        public List<string> BlackoutPeriods { get; set; } = new List<string>();

        [JsonProperty("canLiveSpectate")]
        public bool CanLiveSpectate { get; set; }

        [JsonProperty("countdownBeginTime")]
        public string CountdownBeginTime { get; set; }

        [JsonProperty("endTime")]
        public string EndTime { get; set; }

        [JsonProperty("eventTemplateId")]
        public string EventTemplateId { get; set; }

        [JsonProperty("eventWindowId")]
        public string EventWindowId { get; set; }

        [JsonProperty("isTBD")]
        public bool IsTBD { get; set; }

        [JsonProperty("leaderboardId")]
        public string LeaderboardId { get; set; }

        [JsonProperty("metadata")]
        public DB_EventMetadata Metadata { get; set; }

        [JsonProperty("payoutDelay")]
        public int PayoutDelay { get; set; }

        [JsonProperty("requireAllTokens")]
        public string[] RequireAllTokens { get; set; } = new string[0];

        [JsonProperty("requireAllTokensCaller")]
        public string[] RequireAllTokensCaller { get; set; } = new string[0];

        [JsonProperty("requireAnyTokens")]
        public string[] RequireAnyTokens { get; set; } = new string[0];

        [JsonProperty("requireAnyTokensCaller")]
        public string[] RequireAnyTokensCaller { get; set; } = new string[0];

        [JsonProperty("requireNoneTokensCaller")]
        public string[] RequireNoneTokensCaller { get; set; } = new string[0];

        [JsonProperty("round")]
        public int Round { get; set; }

        [JsonProperty("scoreLocations")]
        public List<DB_ScoreLocation> ScoreLocations { get; set; } = new List<DB_ScoreLocation>();

        [JsonProperty("teammateEligibility")]
        public string TeammateEligibility { get; set; } = "all";

        [JsonProperty("visibility")]
        public string Visibility { get; set; } = "public";
    }
}
