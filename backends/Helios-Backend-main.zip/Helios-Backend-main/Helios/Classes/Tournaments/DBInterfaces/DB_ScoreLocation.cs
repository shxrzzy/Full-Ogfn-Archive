using System.Text.Json.Serialization;

namespace Helios.Classes.Tournaments.DBInterfaces;

public class DB_ScoreLocation
{
    [JsonPropertyName("leaderboardId")]
    public string LeaderboardId { get; set; } = string.Empty;

    [JsonPropertyName("leaderboardDefId")]
    public string LeaderboardDefId { get; set; } = string.Empty;

    [JsonPropertyName("scoreId")]
    public string? ScoreId { get; set; }  

    [JsonPropertyName("scoreMode")]
    public string ScoreMode { get; set; } = string.Empty;

    [JsonPropertyName("isMainWindowLeaderboard")]
    public bool IsMainWindowLeaderboard { get; set; }

    [JsonPropertyName("windowEndCondition")]
    public object? WindowEndCondition { get; set; }  
}
