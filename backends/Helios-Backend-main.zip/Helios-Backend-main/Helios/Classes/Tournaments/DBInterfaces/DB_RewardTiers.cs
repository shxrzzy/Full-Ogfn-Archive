﻿using Newtonsoft.Json;

namespace Helios.Classes.Tournaments.DBInterfaces;

public class DB_RewardTiers
{
    [JsonProperty("keyValue")]
    public int KeyValue { get; set; }
    [JsonProperty("multiplicative")]
    public bool Multiplicative { get; set; }
    [JsonProperty("pointsEarned")]
    public int PointsEarned { get; set; }
}