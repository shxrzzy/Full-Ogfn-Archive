﻿using Newtonsoft.Json;
using Org.BouncyCastle.Bcpg.OpenPgp;

namespace Helios.Classes.Tournaments.DBInterfaces;

public class DB_Metadata
{
    [JsonProperty("minimumAccountLevel")]
    public int MinimumAccountLevel { get; set; }
    [JsonProperty("TrackedStats")]
    public string[] TrackedStats { get; set; }
    public string TeamLockType { get; set; }
    public string DisqualifyType { get; set; }
    public string RegionLockType { get; set; }
    public string AccountLockType { get; set; }
}