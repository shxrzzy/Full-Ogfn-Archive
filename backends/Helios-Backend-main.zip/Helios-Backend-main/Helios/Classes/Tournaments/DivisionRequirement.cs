namespace Helios.Classes.Tournaments;

public class DivisionRequirement
{
    public long RequiredPoints { get; set; }
    public string Token { get; set; }
}