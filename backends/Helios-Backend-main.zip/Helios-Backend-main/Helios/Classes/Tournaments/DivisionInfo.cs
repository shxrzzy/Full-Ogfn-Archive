﻿namespace Helios.Classes.Tournaments;

public class DivisionInfo
{
    public string Name { get; set; } = string.Empty;
    public int Min { get; set; }
    public long Max { get; set; }
}