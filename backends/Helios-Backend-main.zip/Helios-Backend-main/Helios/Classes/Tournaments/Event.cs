﻿using Helios.Classes.Tournaments.DBInterfaces;

namespace Helios.Classes.Tournaments;

public class Event
{
    public string gameId { get; set; }
    public string eventId { get; set; }
    public string displayDataId { get; set; }
    public string beginTime { get; set; }
    public string endTime { get; set; }
    public string announcementTime { get; set; }
    public string[] regions { get; set; }
    public Dictionary<string, string> regionMappings { get; set; }
    public string[] platforms { get; set; }
    public Dictionary<string, object> platformMappings { get; set; }
    public string appId { get; set; }
    public string environment { get; set; }
    public DB_Metadata metadata { get; set; }
    public List<DB_EventWindow> eventWindows { get; set; }
    public string eventGroup { get; set; }
    public DB_EventLink link { get; set; }
}