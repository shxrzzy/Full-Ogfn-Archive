﻿using Helios.Classes.Tournaments.DBInterfaces;
using System.Text.Json.Serialization;

namespace Helios.Classes.Tournaments;

public class ArenaEventTemplate
{
    [JsonPropertyName("playlistId")]
    public string PlaylistId { get; set; }

    [JsonPropertyName("matchCap")]
    public int MatchCap { get; set; }

    [JsonPropertyName("eventTemplateId")]
    public string EventTemplateId { get; set; }

    [JsonPropertyName("scoringRules")]
    public List<DB_ScoringRules> ScoringRules { get; set; }

    [JsonPropertyName("persistentScoreId")]
    public string PersistentScoreId { get; set; }

    [JsonPropertyName("gameId")]
    public string GameId { get; set; }

    [JsonPropertyName("payoutTable")]
    public PayoutTable PayoutTable { get; set; }
}

public class PayoutTable
{
    [JsonPropertyName("ranks")]
    public List<Rank> Ranks { get; set; }

    [JsonPropertyName("scoreId")]
    public string ScoreId { get; set; }

    [JsonPropertyName("scoringType")]
    public string ScoringType { get; set; }
}

public class Rank
{
    [JsonPropertyName("payouts")]
    public List<Payout> Payouts { get; set; }

    [JsonPropertyName("threshold")]
    public int Threshold { get; set; }
}

public class Payout
{
    [JsonPropertyName("quantity")]
    public int Quantity { get; set; }

    [JsonPropertyName("rewardMode")]
    public string RewardMode { get; set; }

    [JsonPropertyName("rewardType")]
    public string RewardType { get; set; }

    [JsonPropertyName("value")]
    public string Value { get; set; }
}