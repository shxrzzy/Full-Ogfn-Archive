﻿namespace Helios.Classes.CloudStorage.Files;

public class RuntimeOptions
{
    public static string GetDefaultRuntimeOptions()
    {
        return @"
[/Script/FortniteGame.FortRuntimeOptions]
!DisabledFrontendNavigationTabs=ClearArray
+DisabledFrontendNavigationTabs=(TabName=""Showdown"", TabState=EFortRuntimeOptionTabState::Hidden)
bEnableGlobalChat=true
bDisableGifting=false
bDisableGiftingPC=false
bDisableGiftingPS4=false
bDisableGiftingXB=false
bEnableInGameMatchmaking=true
bSkipTrailerMovie=true
bEnableEULA=false
bAlwaysPlayTrailerMovie=false
MaxPartySizeAthena=16
MaxPartySizeCampaign=16
MaxSquadSize=16
bAllowMimicingEmotes=true

bShowStoreBanner=true
bEnableCatabaDynamicBackground=true
NewMtxStoreCohortSampleSet=100

ShowdownTournamentCacheExpirationHours=1
TournamentRefreshPlayerMaxRateSeconds=60
TournamentRefreshEventsMaxRateSeconds=60
TournamentRefreshPayoutMaxRateSeconds=60

bSkipInternetCheck=true
bLoginErebusDisabled=true
bLoginXBLDisabled=true
bLoginPSNDisabled=true
bLoginEpicWeb=true

!ExperimentalCohortPercent=ClearArray
+ExperimentalCohortPercent=(CohortPercent=100,ExperimentNum=20)
+ExperimentalCohortPercent=(CohortPercent=100, ExperimentNum=14)
+ExperimentalCohortPercent=(CohortPercent=100, ExperimentNum=15)
bEnableClientSettingsSaveToCloud=false
";
    }
}