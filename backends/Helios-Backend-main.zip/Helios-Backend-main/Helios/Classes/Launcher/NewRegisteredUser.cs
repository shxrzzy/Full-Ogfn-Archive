﻿namespace Helios.Classes.Launcher;

public class NewRegisteredUser
{
    public string Email { get; set; }
    public string Password { get; set; }
    public string Username { get; set; }
    public string DiscordId { get; set; }
    public bool IsServer { get; set; }
    public string Avatar { get; set; }
    public string[] Roles { get; set; }
}