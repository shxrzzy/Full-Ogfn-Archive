﻿using Newtonsoft.Json;

namespace Helios.Classes.Launcher.Socket
{
    public class RequestedUserData
    {
        [JsonProperty("id")]
        public string Id { get; set; } = string.Empty;

        [JsonProperty("discord")]
        public DiscordInfo Discord { get; set; } = new DiscordInfo();

        [JsonProperty("profile")]
        public UserProfile Profile { get; set; } = new UserProfile();

        [JsonProperty("roles")]
        public UserRoles Roles { get; set; } = new UserRoles();
        [JsonProperty("hellowelcometocrystalfortnite")]
        public string Secret { get; set; }
    }

    public class DiscordInfo
    {
        [JsonProperty("id")]
        public string Id { get; set; } = string.Empty;

        [JsonProperty("username")]
        public string Username { get; set; } = string.Empty;

        [JsonProperty("displayName")]
        public string DisplayName { get; set; } = string.Empty;

        [JsonProperty("avatarUrl")]
        public string AvatarUrl { get; set; } = string.Empty;

        [JsonProperty("isDonator")]
        public bool IsDonator { get; set; } = false;
    }

    public class UserRoles
    {
        [JsonProperty("list")]
        public string[] List { get; set; } = System.Array.Empty<string>();
    }

    public class UserProfile
    {
        [JsonProperty("athena")]
        public AthenaProfile Athena { get; set; } = new AthenaProfile();

        [JsonProperty("common_core")]
        public CommonCoreProfile CommonCore { get; set; } = new CommonCoreProfile();
        [JsonProperty("stats")]
        public UserStatistics Statistics { get; set; } = new UserStatistics();
    }

    public class UserStatistics
    {
        [JsonProperty("kd")]
        public double Kd { get; set; }
        [JsonProperty("wins")]
        public int Wins { get; set; }
        [JsonProperty("eliminations")]
        public int Eliminations { get; set; }
        [JsonProperty("matchesPlayed")]
        public int MatchesPlayed { get; set; }
    }

    public class AthenaProfile
    {
        [JsonProperty("favoriteCharacterId")]
        public string FavoriteCharacterId { get; set; } = string.Empty;

        [JsonProperty("season")]
        public AthenaSeason Season { get; set; } = new AthenaSeason();
        [JsonProperty("hype")]
        public int Hype { get; set; } = 0;
    }

    public class AthenaSeason
    {
        [JsonProperty("level")]
        public int Level { get; set; } = 0;

        [JsonProperty("xp")]
        public int Xp { get; set; } = 0;

        [JsonProperty("battlePass")]
        public BattlePass BattlePass { get; set; } = new BattlePass();
    }

    public class BattlePass
    {
        [JsonProperty("purchased")]
        public bool Purchased { get; set; } = false;

        [JsonProperty("level")]
        public int Level { get; set; } = 0;

        [JsonProperty("xp")]
        public int Xp { get; set; } = 0;
    }

    public class CommonCoreProfile
    {
        [JsonProperty("vbucks")]
        public int Vbucks { get; set; } = 0;
    }
}
