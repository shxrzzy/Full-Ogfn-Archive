using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace Helios.Classes.GlobalDBInterfaces;

public class DB_Stats
{
    [JsonPropertyName("kills")]
    public int Kills { get; set; }
    [JsonPropertyName("wins")]
    public int Wins { get; set; }

    [JsonPropertyName("top5")]
    public int Top5 { get; set; }

    [JsonPropertyName("top10")]
    public int Top10 { get; set; }

    [JsonPropertyName("top25")]
    public int Top25 { get; set; }
}