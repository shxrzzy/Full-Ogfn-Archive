using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace Helios.Classes.MCP.Response
{
    public class MultiUpdate
    {
        [JsonProperty("profileRevision")]
        public int ProfileRevision { get; set; }
        [JsonProperty("profileId")]
        public string ProfileId { get; set; }
        [JsonProperty("profileChangesBaseRevision")]
        public int ProfileChangesBaseRevision { get; set; }
        [JsonProperty("profileChanges")]
        public List<object> ProfileChanges { get; set; } = new List<object>();
        [JsonProperty("profileCommandRevision")]
        public int ProfileCommandRevision { get; set; }
    }
}