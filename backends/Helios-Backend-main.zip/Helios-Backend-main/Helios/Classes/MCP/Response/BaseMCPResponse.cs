﻿using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace Helios.Classes.MCP.Response;

public class BaseMCPResponse
{
    [JsonProperty("profileRevision")]
    public int ProfileRevision { get; set; }
    [JsonProperty("profileId")]
    public string ProfileId { get; set; }
    [JsonProperty("profileChangesBaseRevision")]
    public int ProfileChangesBaseRevision { get; set; }
    [JsonProperty("profileChanges")]
    public List<object> ProfileChanges { get; set; } = new List<object>();
    [JsonProperty("profileCommandRevision")]
    public int ProfileCommandRevision { get; set; }
    [JsonProperty("serverTime")]
    public string ServerTime { get; set; }
    [JsonProperty("responseVersion")]
    public int ResponseVersion { get; set; }
}