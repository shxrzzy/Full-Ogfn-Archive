using System.Text.Json.Serialization;

namespace Helios.Classes.MatchmakingServers;

public class SelectedPlaylist
{
    [JsonPropertyName("playlist")]
    public string Playlist { get; set; }
    [JsonPropertyName("count")]
    public int Count { get; set; }
}