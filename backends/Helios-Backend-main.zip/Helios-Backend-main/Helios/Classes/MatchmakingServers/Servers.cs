using System.Text.Json.Serialization;

namespace Helios.Classes.MatchmakingServers;

public class Servers
{
    [JsonPropertyName("sessionId")]
    public string SessionId { get; set; }

    [JsonPropertyName("identifier")]
    public string Identifier { get; set; }

    [JsonPropertyName("bucketId")]
    public string BucketId { get; set; }

    [JsonPropertyName("region")]
    public string Region { get; set; }

    [JsonPropertyName("playlist")]
    public string Playlist { get; set; }

    [JsonPropertyName("matchId")]
    public string MatchId { get; set; }

    [JsonPropertyName("dedicatedSessionId")]
    public string DedicatedSessionId { get; set; }

    [JsonPropertyName("clients")]
    public int Clients { get; set; }

    [JsonPropertyName("serverAddress")]
    public string Address { get; set; }

    [JsonPropertyName("serverPort")]
    public int Port { get; set; }
}
