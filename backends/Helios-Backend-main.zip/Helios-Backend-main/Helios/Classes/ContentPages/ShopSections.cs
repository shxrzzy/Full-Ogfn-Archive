using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class ShopSections
    {
        [JsonPropertyName("_title")]
        public string Title { get; set; }

        [JsonPropertyName("sectionList")]
        public ShopSectionList SectionList { get; set; }

        [JsonPropertyName("_noIndex")]
        public bool NoIndex { get; set; }

        [JsonPropertyName("_activeDate")]
        public DateTime ActiveDate { get; set; }

        [JsonPropertyName("lastModified")]
        public DateTime LastModified { get; set; }

        [JsonPropertyName("_locale")]
        public string Locale { get; set; }

        [JsonPropertyName("_templateName")]
        public string TemplateName { get; set; }
    }

    public class ShopSectionList
    {
        [JsonPropertyName("_type")]
        public string Type { get; set; }

        [JsonPropertyName("sections")]
        public List<ShopSection> Sections { get; set; }
    }

    public class ShopSection
    {
        [JsonPropertyName("bSortOffersByOwnership")]
        public bool SortOffersByOwnership { get; set; }

        [JsonPropertyName("bShowIneligibleOffersIfGiftable")]
        public bool ShowIneligibleOffersIfGiftable { get; set; }

        [JsonPropertyName("bEnableToastNotification")]
        public bool EnableToastNotification { get; set; }

        [JsonPropertyName("background")]
        public DynamicBackground Background { get; set; }

        [JsonPropertyName("_type")]
        public string Type { get; set; }

        [JsonPropertyName("landingPriority")]
        public int LandingPriority { get; set; }

        [JsonPropertyName("bHidden")]
        public bool Hidden { get; set; }

        [JsonPropertyName("sectionId")]
        public string SectionId { get; set; }

        [JsonPropertyName("bShowTimer")]
        public bool ShowTimer { get; set; }

        [JsonPropertyName("sectionDisplayName")]
        public string SectionDisplayName { get; set; }

        [JsonPropertyName("bShowIneligibleOffers")]
        public bool ShowIneligibleOffers { get; set; }
    }

    public class DynamicBackground
    {
        [JsonPropertyName("stage")]
        public string Stage { get; set; }

        [JsonPropertyName("_type")]
        public string Type { get; set; }

        [JsonPropertyName("key")]
        public string Key { get; set; }
    }
}