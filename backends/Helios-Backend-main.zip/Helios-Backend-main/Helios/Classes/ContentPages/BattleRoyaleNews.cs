﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class BattleRoyaleNews
    {
        [JsonPropertyName("news")]
        public News News { get; set; }

        [JsonPropertyName("_title")]
        public string Title { get; set; }

        [JsonPropertyName("header")]
        public string Header { get; set; }

        [JsonPropertyName("style")]
        public string Style { get; set; }

        [JsonPropertyName("_noIndex")]
        public bool NoIndex { get; set; }

        [JsonPropertyName("alwaysShow")]
        public bool AlwaysShow { get; set; }

        [JsonPropertyName("_activeDate")]
        public DateTime ActiveDate { get; set; }

        [JsonPropertyName("lastModified")]
        public DateTime LastModified { get; set; }

        [JsonPropertyName("_locale")]
        public string Locale { get; set; }

        [JsonPropertyName("_templateName")]
        public string TemplateName { get; set; }
    }
}
