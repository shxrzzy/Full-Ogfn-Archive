using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class ScoringRulesDisplayInfo
    {
        [JsonPropertyName("poster_description")]
        public string PosterDescription { get; set; }

        [JsonPropertyName("rule_name")]
        public string RuleName { get; set; }

        [JsonPropertyName("_type")]
        public string Type { get; set; } = "Scoring Rules Display Info";

        [JsonPropertyName("icon")]
        public string Icon { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; }

        [JsonPropertyName("hide_score_toast_notifications")]
        public bool HideScoreToastNotifications { get; set; }

        [JsonPropertyName("poster_interval_description")]
        public string PosterIntervalDescription { get; set; }
    }
}
