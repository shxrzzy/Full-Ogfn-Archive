﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages;

public class EmergencyNoticeV2
{
    [JsonPropertyName("jcr:isCheckedOut")]
    public bool JcrIsCheckedOut { get; set; }
    [JsonPropertyName("jcr:baseVersion")]
    public string JcrBaseVersion { get; set; }

    [JsonPropertyName("_title")]
    public string Title { get; set; }
    [JsonPropertyName("alwaysShow")]
    public bool AlwaysShow { get; set; }

    [JsonPropertyName("_noIndex")]
    public bool NoIndex { get; set; }

    [JsonPropertyName("emergencynotices")]
    public EmergencyNoticesContainer EmergencyNotices { get; set; }

    [JsonPropertyName("_activeDate")]
    public DateTime ActiveDate { get; set; }

    [JsonPropertyName("lastModified")]
    public DateTime LastModified { get; set; }

    [JsonPropertyName("_locale")]
    public string Locale { get; set; }
}


public class EmergencyNoticesContainer
{
    [JsonPropertyName("_type")]
    public string Type { get; set; }

    [JsonPropertyName("emergencynotices")]
    public List<NoticeV2> Notices { get; set; }
}

public class NoticeV2
{
    [JsonPropertyName("gamemodes")]
    public List<string> GameModes { get; set; }
    [JsonPropertyName("hidden")]
    public bool Hidden { get; set; }

    [JsonPropertyName("_type")]
    public string Type { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("body")]
    public string Body { get; set; }
    [JsonPropertyName("spotlight")]
    public bool Spotlight { get; set; }
}