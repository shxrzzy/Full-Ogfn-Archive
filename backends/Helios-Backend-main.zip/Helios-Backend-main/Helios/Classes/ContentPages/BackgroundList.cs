﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class BackgroundList
    {
        [JsonPropertyName("backgrounds")]
        public List<Backgrounds> Backgrounds { get; set; }

        [JsonPropertyName("_type")]
        public string Type { get; set; }
    }
}
