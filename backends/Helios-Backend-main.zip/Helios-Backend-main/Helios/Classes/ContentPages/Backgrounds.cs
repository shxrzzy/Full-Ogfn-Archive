﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class Backgrounds
    {
        [JsonPropertyName("stage")]
        public string Stage { get; set; }

        [JsonPropertyName("_type")]
        public string Type { get; set; }

        [JsonPropertyName("key")]
        public string Key { get; set; }
        [JsonPropertyName("backgroundImage")]
        public string BackgroundImage { get; set; } = "";
    }
}
