﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages;

public class EmergencyNoticeMessages
{
    [JsonPropertyName("hidden")]
    public bool bHidden { get; set; }
    [JsonPropertyName("_type")]
    public string Type { get; set; }
    [JsonPropertyName("subgame")]
    public string SubGame { get; set; }
    [JsonPropertyName("title")]
    public string Title { get; set; }
    [JsonPropertyName("body")]
    public string Body { get; set; }
    [JsonPropertyName("spotlight")]
    public bool bSpotlight { get; set; }
}