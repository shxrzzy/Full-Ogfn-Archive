﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class Message
    {
        [JsonPropertyName("image")]
        public string Image { get; set; }

        [JsonPropertyName("hidden")]
        public bool Hidden { get; set; }

        [JsonPropertyName("messagetype")]
        public string MessageType { get; set; }

        [JsonPropertyName("_type")]
        public string Type { get; set; }

        [JsonPropertyName("title")]
        public string Title { get; set; }

        [JsonPropertyName("body")]
        public string Body { get; set; }

        [JsonPropertyName("spotlight")]
        public bool Spotlight { get; set; }
    }
}
