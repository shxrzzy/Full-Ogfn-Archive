﻿using System.Text.Json.Serialization;

namespace Helios.Classes.ContentPages
{
    public class NewsV2
    {
        [JsonPropertyName("_type")]
        public string Type { get; set; }

        [JsonPropertyName("motds")]
        public List<object> Motds { get; set; }
    }
}
