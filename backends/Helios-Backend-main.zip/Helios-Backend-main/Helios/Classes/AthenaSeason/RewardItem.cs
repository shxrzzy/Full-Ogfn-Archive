namespace Helios.Classes.AthenaSeason;

public class RewardItem
{
    public string TemplateId { get; set; }
    public int Quantity { get; set; }
    public int Tier { get; set; }
}