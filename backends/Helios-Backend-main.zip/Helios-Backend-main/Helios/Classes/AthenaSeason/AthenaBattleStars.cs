namespace Helios.Classes.AthenaSeason;

public class AthenaBattleStars
{
    public int Level { get; set; }
    public int Amount { get; set; }
}