namespace Helios.Classes.AthenaSeason;

public class SeasonXpCurve
{
    public int Level { get; set; }
    public int XpToNextLevel { get; set; }
    public int XpTotal { get; set; }
    public string RowId { get; set; }
}