using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Helios.Classes.Storefront
{
    public class Price
    {
        [JsonPropertyName("currencyType")]
        public string CurrencyType { get; set; }

        [JsonPropertyName("currencySubType")]
        public string CurrencySubType { get; set; }

        [JsonPropertyName("regularPrice")]
        public int RegularPrice { get; set; }

        [JsonPropertyName("dynamicRegularPrice")]
        public int? DynamicRegularPrice { get; set; }

        [JsonPropertyName("finalPrice")]
        public int FinalPrice { get; set; }
        [JsonPropertyName("saleExpiration")]
        public string SaleExpiration { get; set; } = "9999-12-31T23:59:59.999Z";
        [JsonPropertyName("basePrice")]
        public int BasePrice { get; set; }
    }
}