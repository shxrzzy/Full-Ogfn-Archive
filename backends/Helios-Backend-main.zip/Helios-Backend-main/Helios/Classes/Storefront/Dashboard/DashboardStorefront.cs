using System.Text.Json.Serialization;

namespace Helios.Classes.Storefront.Dashboard
{
    public class StorefrontItem
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        public string Rarity { get; set; }
        public string Type { get; set; }
        public string Image { get; set; }
    }

    public class SaveStorefrontRequest
    {
        public List<StorefrontItemRequest> FeaturedItems { get; set; } = new();
        public List<StorefrontItemRequest> DailyItems { get; set; } = new();
    }

    public class StorefrontItemRequest
    {
        public string CosmeticId { get; set; }
        public int Price { get; set; }
    }

    public class StorefrontResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public List<StorefrontItem> FeaturedItems { get; set; } = new();
        public List<StorefrontItem> DailyItems { get; set; } = new();
    }

    public class AddStorefrontItemRequest
    {
        public string CosmeticId { get; set; } = string.Empty;
        public int Price { get; set; }
        public string Section { get; set; } = string.Empty; 
    }

    public class AddStorefrontItemResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public StorefrontItem Item { get; set; } = new StorefrontItem();
    }
}