using System.Text.Json.Serialization;

namespace Helios.Classes.Storefront.Dashboard.FortniteAPI
{
    public class VariantsDefOptions
    {
        [JsonPropertyName("tag")]
        public string Tag { get; set; }
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("image")]
        public string Image { get; set; }
    }
}