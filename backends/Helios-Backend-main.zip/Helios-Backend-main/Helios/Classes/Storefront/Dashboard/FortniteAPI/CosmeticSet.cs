using System.Text.Json.Serialization;

namespace Helios.Classes.Storefront.Dashboard.FortniteAPI
{
    public class CosmeticSet
    {
        [JsonPropertyName("value")]
        public string Value { get; set; }
        [JsonPropertyName("text")]
        public string Text { get; set; }
        [JsonPropertyName("backendValue")]
        public string BackendValue { get; set; }
    }
}