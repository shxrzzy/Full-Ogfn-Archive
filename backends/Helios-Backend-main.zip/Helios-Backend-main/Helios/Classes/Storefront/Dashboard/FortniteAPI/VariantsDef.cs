using System.Text.Json.Serialization;

namespace Helios.Classes.Storefront.Dashboard.FortniteAPI
{
    public class VariantsDef
    {
        [JsonPropertyName("channel")]
        public string Channel { get; set; }
        [JsonPropertyName("type")]
        public string Type { get; set; }
        [JsonPropertyName("options")]
        public List<VariantsDefOptions> Options { get; set; }
    }
}