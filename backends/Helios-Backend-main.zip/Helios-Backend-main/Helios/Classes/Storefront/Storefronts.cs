using System.Text.Json.Serialization;

namespace Helios.Classes.Storefront
{
    public class Storefronts
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("catalogEntries")]
        public List<StorefrontEntry> CatalogEntries { get; set; } = new();
    }
}