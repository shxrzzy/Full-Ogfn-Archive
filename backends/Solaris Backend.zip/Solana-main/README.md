# Solana

> Backend for **Solaris** developed using GoLang

## File Structure

- `/controllers/*group` - Handlers for requests
- `/classes` - Contains class definitions
- `/static` - Holds static files (e.g., .json)
- `/managers` - Manager modules (currently minimal)
- `/database` - Database-related files
- `/modules` - Contains modules for Solana
