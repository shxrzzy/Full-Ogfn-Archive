package battlepass

type BattlePass struct {
	Rewards []map[string]int `json:"rewards"`
}
