package quests

type AthenaChallengeBundleRewards struct {
	TemplateId string
	Quantity   int
}
