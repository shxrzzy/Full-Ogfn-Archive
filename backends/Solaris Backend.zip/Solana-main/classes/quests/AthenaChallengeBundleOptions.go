package quests

type AthenaChallengeBundleOptions struct {
	IsBattlePass                  bool
	IsOvertime                    bool
	GrantWithPass                 bool
	ProgressOnBattlePassPurchased bool
	AthenaSeasonProgress          bool
	BattlePassProgress            bool
}
