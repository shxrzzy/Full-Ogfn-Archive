package quests

type AthenaChallengeBundleObjectives struct {
	BackendName string
	Count       int
	Stage       int
}
