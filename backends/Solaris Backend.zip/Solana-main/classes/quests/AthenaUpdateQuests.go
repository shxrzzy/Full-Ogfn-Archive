package quests

type AthenaUpdateQuests struct {
	BackendName string
	Count       int32
	Objective   string
}
