package quests

type AthenaCompletionRewards struct {
	TemplateId string `json:"TemplateId"`
	Quantity   int    `json:"Quantity"`
}
