package quests

type AthenaChallengeBundleObjects struct {
	QuestDefinition string
	Rewards         []AthenaChallengeBundleRewards
	Objectives      []AthenaChallengeBundleObjectives
	Options         AthenaChallengeBundleOptions
}
