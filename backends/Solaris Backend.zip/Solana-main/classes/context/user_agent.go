package context

type UserAgent struct {
	VersionId  string `json:"versionId"`
	VersionStr string `json:"versionStr"`
}
