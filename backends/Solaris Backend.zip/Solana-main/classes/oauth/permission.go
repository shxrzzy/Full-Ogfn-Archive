package oauth

type Permission struct {
	PermissionName string `json:"permissionName"`
	Type           string `json:"type"`
}
