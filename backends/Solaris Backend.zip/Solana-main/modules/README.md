# Modules

> This folder contains the external modules for solana.

## Current Modules

### Storefront

> The solana shop generator. It scrapes a storefront from a certain point in time using `fnbr.co`

### Database

> Database module (what else is there to explain monk)
