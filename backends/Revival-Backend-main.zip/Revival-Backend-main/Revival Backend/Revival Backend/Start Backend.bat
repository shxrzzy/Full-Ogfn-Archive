@echo off

bun start