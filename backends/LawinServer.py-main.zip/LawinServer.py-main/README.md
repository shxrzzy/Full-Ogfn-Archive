# LawinServer.py
LawinServer v1 backend recreated in python (not really good tho)

## Note
- This backend is pretty ass imo  i ahev amde better things than this also mcp and locker is vibe coded as hell.
- timeline is missing kinda and matchmaker only works on like  s3-s5

