@echo off
setlocal

cd /d "%~dp0"

set PORT=3551
if not "%~1"=="" set PORT=%~1

where py >nul 2>nul
if %errorlevel%==0 (
	py -3 -m uvicorn src-private.main:app --host 0.0.0.0 --port %PORT%
) else (
	python -m uvicorn src-private.main:app --host 0.0.0.0 --port %PORT%
)
