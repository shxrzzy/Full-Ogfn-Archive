import configparser
import asyncio
import base64
import hashlib
import json
import os
import random
import re
import threading
import uuid
from copy import deepcopy
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

from fastapi import Body, FastAPI, Request, Response, WebSocket
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from starlette.websockets import WebSocketDisconnect


ROOT_DIR = Path(__file__).resolve().parent.parent
PUBLIC_DIR = ROOT_DIR / "src-public"
RESPONSES_DIR = PUBLIC_DIR / "responses"
PROFILES_DIR = PUBLIC_DIR / "profiles"
CLOUDSTORAGE_DIR = PUBLIC_DIR / "CloudStorage"
CONFIG_DIR = PUBLIC_DIR / "Config"

CLIENT_SETTINGS_DIR = Path(os.getenv("LOCALAPPDATA", str(ROOT_DIR))) / "LawinServer.py" / "ClientSettings"
CLIENT_SETTINGS_DIR.mkdir(parents=True, exist_ok=True)


def utc_now_iso() -> str:
	return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def utc_iso_from_dt(dt: datetime) -> str:
	return dt.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def load_json(path: Path, default: Any = None) -> Any:
	if not path.exists():
		return default
	with path.open("r", encoding="utf-8") as fp:
		return json.load(fp)


def clone_json(path: Path, default: Any = None) -> Any:
	return deepcopy(load_json(path, default))


def save_json(path: Path, data: Any) -> None:
	path.parent.mkdir(parents=True, exist_ok=True)
	with path.open("w", encoding="utf-8") as fp:
		json.dump(data, fp, indent=2)


def parse_config() -> configparser.ConfigParser:
	parser = configparser.ConfigParser()
	parser.read(CONFIG_DIR / "config.ini", encoding="utf-8")
	return parser


def config_bool(section: str, key: str, fallback: bool) -> bool:
	try:
		return CONFIG.getboolean(section, key)
	except Exception:
		return fallback


def config_str(section: str, key: str, fallback: str) -> str:
	try:
		return CONFIG.get(section, key)
	except Exception:
		return fallback


def parse_version_info(request: Request) -> dict[str, Any]:
	user_agent = request.headers.get("user-agent", "")
	bucket_id = request.query_params.get("bucketId", "")

	build = 2.0
	season = 2
	cl = 0
	lobby = "LobbyWinterDecor"

	# Match release versions across legacy and modern user-agent formats.
	release_match = re.search(r"Release-(\d+(?:\.\d+){0,2})", user_agent, re.IGNORECASE)
	if release_match:
		try:
			release_raw = release_match.group(1)
			parts = release_raw.split(".")
			if len(parts) == 3:
				# Lawin behavior: x.y.z becomes x.yz (e.g. 23.50.0 -> 23.500)
				release_raw = f"{parts[0]}.{parts[1]}{parts[2]}"
			build = float(release_raw)
			season = int(parts[0])
			# Original Lawin behavior: use LobbySeason{season} for parsed versions.
			lobby = f"LobbySeason{season}"
		except Exception:
			pass

	cl_match = re.search(r"CL-(\d+)", user_agent, re.IGNORECASE)
	if cl_match:
		cl = int(cl_match.group(1))

	if not cl and bucket_id:
		bucket_cl = re.search(r"\d{5,}", bucket_id)
		if bucket_cl:
			cl = int(bucket_cl.group(0))

	if not cl:
		cl = 0

	return {
		"build": build,
		"season": season,
		"cl": cl,
		"lobby": lobby,
	}


def choose_translations_in_json(obj: Any, request: Request, target_language: str = "") -> Any:
	"""Collapse translation maps to a single language value, matching Lawin behavior."""
	language = (target_language or "").strip()
	if not language:
		accept = (request.headers.get("accept-language", "") or "").strip()
		if accept:
			if "-" in accept and accept not in ("es-419", "pt-BR"):
				language = accept.split("-")[0]
			else:
				language = accept
		else:
			language = "en"

	def _visit(value: Any) -> Any:
		if isinstance(value, list):
			return [_visit(v) for v in value]
		if isinstance(value, dict):
			mapped = {k: _visit(v) for k, v in value.items()}
			if language in mapped and isinstance(mapped[language], (str, int, float, bool)):
				return mapped[language]
			if "en" in mapped and isinstance(mapped["en"], (str, int, float, bool)):
				return mapped["en"]
			return mapped
		return value

	return _visit(obj)


def chapter_and_season_from_release(release_season: int) -> tuple[int, int]:
	"""Convert global release season (e.g. 23) to chapter/season-in-chapter."""
	if release_season <= 10:
		return 1, max(release_season, 1)
	if release_season <= 18:
		return 2, release_season - 10
	if release_season <= 22:
		return 3, release_season - 18
	if release_season <= 26:
		return 4, release_season - 22
	# Chapter 5+ cadence is currently 4 seasons per chapter.
	chapter = 5 + max(release_season - 27, 0) // 4
	chapter_season = ((release_season - 27) % 4) + 1
	return chapter, chapter_season


def timeline_events_for_version(memory: dict[str, Any]) -> list[str]:
	season = int(memory.get("season", 2))
	build = float(memory.get("build", 2.0))

	season_map: dict[int, list[str]] = {
		# Chapter 1
		1: [],
		2: [],
		3: ["EventFlag.Spring_Lobby"],
		4: [
			"EventFlag.Blockbuster2018",
			"EventFlag.Blockbuster2018Phase1",
			"EventFlag.Blockbuster2018Phase2",
			"EventFlag.Blockbuster2018Phase3",
			"EventFlag.Blockbuster2018Phase4",
			"EventFlag.RocketLaunch",
		],
		5: [
			"EventFlag.RoadTrip2018",
			"EventFlag.Horde",
			"EventFlag.Anniversary2018_BR",
			"EventFlag.LTM_Heist",
			"EventFlag.AutumnDecoration",
		],
		6: [
			"EventFlag.LTM_Fortnitemares",
			"EventFlag.LTM_LilKevin",
			"EventFlag.Fortnitemares",
			"EventFlag.FortnitemaresPhase1",
			"EventFlag.FortnitemaresPhase2",
			"EventFlag.HalloweenDecoration",
		],
		7: [
			"EventFlag.Frostnite",
			"EventFlag.LTM_14DaysOfFortnite",
			"EventFlag.LTE_Festivus",
			"EventFlag.LTM_WinterDeimos",
			"EventFlag.LTE_S7_OverTime",
			"EventFlag.HolidayDeco",
			"EventFlag.WinterDecoration",
			"EventFlag.WinterFest",
			"EventFlag.HalloweenDecoration",
		],
		8: [
			"EventFlag.PirateDecoration",
			"EventFlag.Spring2019",
			"EventFlag.Spring2019.Phase1",
		],
		9: [
			"EventFlag.Season9.Phase1",
			"EventFlag.Season9.Phase2",
			"EventFlag.Anniversary2019_BR",
			"EventFlag.TechRocks",
		],
		10: [
			"EventFlag.Mayday",
			"EventFlag.S10_Oak",
			"EventFlag.S10_Mystery",
			"EventFlag.LTE_BlackMonday",
			"EventFlag.Season10.Phase2",
			"EventFlag.Season10.Phase3",
			"EventFlag.Chapter2Preroll",
		],
		# Chapter 2
		11: [
			"EventFlag.LTE_WinterFest",
			"EventFlag.LTE_WinterFestTab",
			"EventFlag.Season11.WinterFest.Quests.Phase1",
			"EventFlag.Season11.WinterFest.Quests.Phase2",
			"EventFlag.Season11.WinterFest.Quests.Phase3",
		],
		12: [
			"EventFlag.Agency",
			"EventFlag.LTE_SpyGames",
			"EventFlag.LTE_JerkyChallenges",
			"EventFlag.LTE_Oro",
			"EventFlag.LTE_StormTheAgency",
		],
		13: ["EventFlag.Wetlands"],
		14: ["EventFlag.Authority", "EventFlag.TheFoundation"],
		15: ["EventFlag.SpireQuests"],
		16: ["EventFlag.Wildlife"],
		17: ["EventFlag.Alien"],
		18: ["EventFlag.Foundation"],
		# Chapter 3
		19: ["EventFlag.ZeroPointHunt"],
		20: [
			"Event_S20_AliQuest",
			"Event_S20_EmicidaQuest",
			"EventFlag.Event_S20_LevelUpPack",
			"EventFlag.NoBuildQuests",
			"EventFlag.Event_S20_NoBuildQuests_TokenGrant",
		],
		21: [
			"Event_S21_FallFest",
			"Event_S21_IslandHopper",
			"Event_S21_CRRocketQuest",
			"EventFlag.Event_S21_LevelUpPack",
			"EventFlag.Event_NoSweatSummer",
		],
		22: [
			"EventFlag.Event_S22_BirthdayQuests",
			"EventFlag.Event_S22_DistantEcho",
			"Event_S22_AyaQuest",
			"EventFlag.Event_S22_LevelUpPack",
			"EventFlag.Event_S22NarrativePart1",
			"EventFlag.Event_S22_RebootRally",
		],
		23: [
			"EventFlag.Event_S23_Weekly_01",
			"EventFlag.Event_S23_Weekly_02",
			"EventFlag.Event_S23_Weekly_03",
			"EventFlag.Event_S23_Weekly_04",
			"EventFlag.Event_S23_Weekly_05",
			"EventFlag.Event_S23Cipher",
			"EventFlag.Event_S23_Emerald",
			"EventFlag.Event_S23_FindIt",
			"EventFlag.Event_S23_CreedQuests",
			"EventFlag.Event_S23_Lettuce",
			"EventFlag.Event_S23_LevelUpPack",
			"EventFlag.Event_S23NarrativePart1",
			"EventFlag.Event_S23NarrativePart2",
			"EventFlag.Event_S23NarrativePart3",
			"EventFlag.Event_S23NarrativePart4",
			"EventFlag.Event_S23NarrativePart4BonusGoal",
			"EventFlag.Event_S23NarrativePart5",
			"EventFlag.Event_S23_RebootRally",
			"EventFlag.Event_S23_SunBurst",
			"EventFlag.Event_S23_ZeroWeek",
		],
		24: ["EventFlag.Event_S24_SunBurst", "EventFlag.Event_S24_LevelUpPack", "EventFlag.Event_S24_NarrativeQuests", "EventFlag.Event_S24_RebootRally"],
		25: ["EventFlag.Event_S25_14DOS", "EventFlag.Event_S25_AloeCrouton", "EventFlag.Event_S25_LevelUpPack", "EventFlag.Event_S25_Maze", "EventFlag.Event_S25_RebootRally"],
		26: ["EventFlag.Event_S26_BirthdayQuests", "EventFlag.Event_S26_FNM", "EventFlag.Event_S26_Mash", "EventFlag.Event_S26_Intertwine", "EventFlag.Event_S26_LevelUpPack"],
		27: ["EventFlag.Event_S27_Mash", "EventFlag.Event_S27_LevelUpPack", "EventFlag.Event_S27_RebootRally"],
		28: ["EventFlag.Event_S28_Winterfest"],
		29: ["Event_S29_ColdDayPrelude", "EventFlag.Event_S29_LevelUpPass", "EventFlag.Event_S29_RebootRally", "EventFlag.Event_S29_SeasonalActivation", "EventFlag.Event_S29_WhiplashWW"],
		30: ["EventFlag.Event_S30_FlatWare", "Event_GreenhousePrelude", "EventFlag.Event_S30_LevelUpPass", "EventFlag.Event_S30_RebootRally"],
		31: ["EventFlag.Event_S31_Birthday", "EventFlag.Event_S31_QuestDeckBed", "Event_S31_FoundQuests_GreenTown", "Event_S31_FoundQuests_PB_P01", "Event_S31_FoundQuests_PB_P02", "EventFlag.Event_S31_FoundQuests_TroutWrist", "EventFlag.Event_S31_LevelUpPass", "EventFlag.Event_S31_MobileQuests", "EventFlag.Event_S31_RebootRally", "EventFlag.Event_S31_Sweatember"],
		32: ["EventFlag.Event_S32_RebootRally", "EventFlag.Event_S32_ScytheGold"],
		33: ["EventFlag.Event_S33_BlondeJaw", "EventFlag.Event_S33_Scenario_BatterBoi", "EventFlag.Event_Scenario_Shell", "EventFlag.Event_S33_NarrativeBattleQuest", "EventFlag.Event_S33_ChatQuest"],
		34: [
			"EventFlag.Event_S34_StoryQuests_EOS_02",
			"EventFlag.Event_S34_StoryQuests_P1",
			"EventFlag.Event_S34_WeaponExpertise",
			"EventFlag.Event_S34_WeaponExpertiseSniper",
		],
		35: [
			"EventFlag.Event_S35_FoundQuests",
			"EventFlag.Event_S35_MidSeasonCharacter_Quests",
			"EventFlag.Event_S35_SummerRoadtrip_Quests",
		],
		36: [
			"EventFlag.Event_S36_IslandStories",
			"EventFlag.Event_S36_MidSeasonCharacter_Quests",
			"EventFlag.Event_S36_SummerRoadtrip_Quests",
			"EventFlag.Event_PistolCanary_Quests",
		],
		37: [
			"EventFlag.Event_S37_StoryQuests",
			"EventFlag.Event_S37_LevelUpPass",
			"EventFlag.Event_S37_RebootRally",
		],
		38: [
			"EventFlag.Event_S38_Stories",
			"EventFlag.Event_S38_Stories_P04",
			"EventFlag.Event_S38_RebootRally",
		],
		39: [
			"EventFlag.Event_S39_HoneyFiber",
			"EventFlag.Event_S39_Story_P01",
			"EventFlag.Event_S39_Story_P02",
			"EventFlag.Event_S39_Story_P03",
			"EventFlag.Event_S39_Story_P04",
		],
	}

	events = list(season_map.get(season, []))

	# Build-gated legacy events (closest behavior to Lawin v1 timeline).
	if season == 8 and build >= 8.20:
		events.append("EventFlag.Spring2019.Phase2")

	if season == 9 and build >= 9.20:
		events.append("EventFlag.Season9.Phase2")

	if season == 10 and build >= 10.40:
		events.extend([
			"EventFlag.Fortnitemares",
			"EventFlag.FortnitemaresPhase1",
			"EventFlag.FortnitemaresPhase2",
		])

	if season == 6 and (abs(build - 6.20) < 0.001 or abs(build - 6.21) < 0.001):
		events.extend([
			"EventFlag.LobbySeason6Halloween",
			"EventFlag.HalloweenBattleBus",
		])

	if season == 5 and abs(build - 5.10) < 0.001:
		events.append("EventFlag.BirthdayBattleBus")

	if season == 23 and abs(build - 23.10) < 0.001:
		events.extend(["EventFlag.LTE_WinterFest", "EventFlag.LTE_WinterFestTab", "WF_GUFF_AVAIL"])

	seen: set[str] = set()
	uniq: list[str] = []
	for event_name in events:
		if event_name not in seen:
			seen.add(event_name)
			uniq.append(event_name)
	return uniq


def get_client_settings_file(cl: int) -> Path:
	return CLIENT_SETTINGS_DIR / f"ClientSettings-{cl}.Sav"


def current_display_name() -> str:
	return STATE["current_account_id"]


def make_fake_jwt(account_id: str) -> str:
	"""Return a syntactically valid unsigned JWT-shaped token for permissive clients."""
	header = {"alg": "none", "typ": "JWT"}
	payload = {
		"sub": account_id,
		"account_id": account_id,
		"app": "fortnite",
		"in_app_id": account_id,
		"displayName": account_id,
		"exp": 4102444800,
		"iat": 1704067200,
	}
	enc = lambda obj: base64.urlsafe_b64encode(json.dumps(obj, separators=(",", ":")).encode("utf-8")).decode("utf-8").rstrip("=")
	return f"{enc(header)}.{enc(payload)}."


CONFIG = parse_config()
DEFAULT_NAME = config_str("Config", "displayName", "LawinServer.py")
STRICT_LAWINV1_PARITY = config_bool("Compatibility", "bStrictLawinV1Parity", True)
ENABLE_TINY_COMPAT_BOOSTS = config_bool("Compatibility", "bEnableTinyCompatibilityBoosts", True)

STATE: dict[str, Any] = {
	"current_account_id": DEFAULT_NAME,
	"parties": {},
	"account_party": {},
}

# Shared matchmaking state — keyed by session_id so the HTTP session endpoint
# can return stable data for the session the WS just handed the client.
MM_SESSIONS: dict[str, dict[str, Any]] = {}

# ── XMPP push state ────────────────────────────────────────────────────────────
# Maps account_id -> active WebSocket so HTTP handlers can push XMPP stanzas.
_XMPP_CONNS: dict[str, "WebSocket"] = {}  # type: ignore[type-arg]
_XMPP_JIDS: dict[str, str] = {}           # account_id -> bound JID
_XMPP_CONNS_LOCK = threading.Lock()
_XMPP_EVENT_LOOP: "asyncio.AbstractEventLoop | None" = None  # type: ignore[name-defined]


def _xmpp_push(account_id: str, xml: str) -> None:
	"""Send an XMPP stanza to a connected client from a sync HTTP handler."""
	import asyncio as _asyncio
	loop = _XMPP_EVENT_LOOP
	ws = _XMPP_CONNS.get(account_id)
	if ws is None or loop is None or not loop.is_running():
		return
	try:
		_asyncio.run_coroutine_threadsafe(ws.send_text(xml), loop)
	except Exception:
		pass


def _xmpp_party_notify(party: dict[str, Any], notif_type: str, extra: dict[str, Any] | None = None) -> None:
	"""Push a party notification to every member that has an active XMPP connection."""
	payload: dict[str, Any] = {
		"type": f"com.epicgames.social.party.notification.v0.{notif_type}",
		"ns": "Fortnite",
		"pns": "Fortnite",
		"sent": utc_now_iso(),
		"revision": party.get("revision", 0),
		"party_id": party.get("id", ""),
		"party_privacy_type": "PUBLIC",
		"party_state_updated": {},
		"party_state_removed": [],
	}
	if extra:
		payload.update(extra)
	body_json = json.dumps([payload])
	for member in party.get("members", []):
		mid = str(member.get("account_id", ""))
		if not mid:
			continue
		jid = _XMPP_JIDS.get(mid, f"{mid}@prod.ol.epicgames.com")
		xml = (
			f'<message to="{jid}" from="xmpp-admin@prod.ol.epicgames.com"'
			f' id="{uuid.uuid4().hex}" xmlns="jabber:client">'
			f'<body>{body_json}</body>'
			f'</message>'
		)
		_xmpp_push(mid, xml)


def _new_session_key() -> str:
	# Epic responses commonly use base64-like keys for session handshakes.
	return base64.b64encode(os.urandom(32)).decode("ascii")


def _normalize_playlist(raw: str) -> str:
	val = (raw or "").strip()
	if not val:
		return "Playlist_DefaultSolo"
	if val.isdigit() or val in ("0", "1", "2", "3"):
		playlist_map = {
			"0": "Playlist_DefaultSolo",
			"1": "Playlist_DefaultDuo",
			"2": "Playlist_DefaultSolo",
			"3": "Playlist_DefaultSquad",
		}
		return playlist_map.get(val, "Playlist_DefaultSolo")
	if not val.startswith("Playlist_"):
		return "Playlist_DefaultSolo"
	return val


def _build_mm_record(session_id: str, request: Request | None = None, seed: dict[str, Any] | None = None) -> dict[str, Any]:
	seed_data = seed or {}
	bucket_id = str(seed_data.get("bucketId", ""))
	bucket_parts = bucket_id.split(":") if bucket_id else []

	if request is not None:
		memory = parse_version_info(request)
	else:
		memory = {"season": 2, "cl": 0}

	bucket_prefix = seed_data.get("buildUniqueId") or (bucket_parts[0] if bucket_parts else "0")
	region = seed_data.get("region") or (bucket_parts[2] if len(bucket_parts) > 2 else "NAE")
	playlist = seed_data.get("playlist") or _normalize_playlist(bucket_parts[3] if len(bucket_parts) > 3 else "Playlist_DefaultSolo")

	server_port = int(config_str("GameServer", "port", "7777"))
	config_beacon_port = int(config_str("GameServer", "beaconPort", "15009"))
	season = int(memory.get("season", 2))
	beacon_port = int(seed_data.get("beaconPort", config_beacon_port))

	return {
		"id": session_id,
		"matchId": seed_data.get("matchId", uuid.uuid4().hex.upper()),
		"sessionKey": seed_data.get("sessionKey", _new_session_key()),
		"ownerId": seed_data.get("ownerId", uuid.uuid4().hex.upper()),
		"region": region,
		"playlist": playlist,
		"buildUniqueId": str(bucket_prefix or memory.get("cl", 0) or "0"),
		"serverAddress": seed_data.get("serverAddress", config_str("GameServer", "ip", "127.0.0.1")),
		"serverPort": int(seed_data.get("serverPort", server_port)),
		"beaconPort": int(seed_data.get("beaconPort", beacon_port)),
		"started": bool(seed_data.get("started", season <= 5)),
	}


def ensure_mm_session(session_id: str, request: Request | None = None, seed: dict[str, Any] | None = None) -> dict[str, Any]:
	rec = MM_SESSIONS.get(session_id)
	if rec is not None:
		return rec
	rec = _build_mm_record(session_id, request=request, seed=seed)
	MM_SESSIONS[session_id] = rec
	return rec


app = FastAPI(title="LawinServer.py V1 Python", version="1.0.0")


@app.get("/health")
def health() -> dict[str, str]:
	return {"status": "ok"}


@app.get("/lightswitch/api/service/Fortnite/status")
def lightswitch_status() -> dict[str, Any]:
	return {
		"serviceInstanceId": "fortnite",
		"status": "UP",
		"message": "Fortnite is online",
		"maintenanceUri": None,
		"overrideCatalogIds": ["a7f138b2e51945ffbfdacc1af0541053"],
		"allowedActions": [],
		"banned": False,
		"launcherInfoDTO": {
			"appName": "Fortnite",
			"catalogItemId": "4fe75bbc5a674f4f9b356b5c90567da5",
			"namespace": "fn",
		},
	}


@app.get("/lightswitch/api/service/bulk/status")
def lightswitch_bulk() -> list[dict[str, Any]]:
	return [
		{
			"serviceInstanceId": "fortnite",
			"status": "UP",
			"message": "fortnite is up.",
			"maintenanceUri": None,
			"overrideCatalogIds": ["a7f138b2e51945ffbfdacc1af0541053"],
			"allowedActions": ["PLAY", "DOWNLOAD"],
			"banned": False,
		}
	]


@app.get("/account/api/public/account")
def public_account(accountId: str | list[str] | None = None) -> list[dict[str, Any]]:
	if accountId is None:
		return []

	ids = accountId if isinstance(accountId, list) else [accountId]
	response = []

	for item in ids:
		simple = item.split("@")[0]
		response.append({"id": simple, "displayName": simple, "externalAuths": {}})

	return response


@app.get("/account/api/public/account/{account_id}")
def public_account_by_id(account_id: str) -> dict[str, Any]:
	if not config_bool("Config", "bUseConfigDisplayName", False):
		STATE["current_account_id"] = account_id.split("@")[0]

	display_name = current_display_name()
	return {
		"id": account_id,
		"displayName": display_name,
		"name": "Ducki67",
		"email": f"{display_name}@ducki67.com",
		"failedLoginAttempts": 0,
		"lastLogin": utc_now_iso(),
		"numberOfDisplayNameChanges": 0,
		"ageGroup": "UNKNOWN",
		"headless": False,
		"country": "US",
		"lastName": "Server",
		"preferredLanguage": "en",
		"canUpdateDisplayName": False,
		"tfaEnabled": False,
		"emailVerified": True,
		"minorVerified": False,
		"minorExpected": False,
		"minorStatus": "NOT_MINOR",
		"cabinedMode": False,
		"hasHashedEmail": False,
		"externalAuths": {},
	}


@app.get("/account/api/public/account/{account_id}/externalAuths")
def external_auths(account_id: str) -> list[Any]:
	return []


@app.get("/account/api/public/account/displayName/{display_name}")
def account_by_display_name(display_name: str) -> dict[str, Any]:
	return {"id": display_name, "displayName": display_name, "externalAuths": {}}


@app.get("/account/api/public/account/email/{email}")
def account_by_email(email: str) -> dict[str, Any]:
	name = email.split("@")[0]
	return {"id": name, "displayName": name, "externalAuths": {}}


def make_oauth_payload() -> dict[str, Any]:
	account = current_display_name()
	access_token = make_fake_jwt(account)
	return {
		"access_token": access_token,
		"expires_in": 28800,
		"expires_at": "9999-12-31T23:59:59.999Z",
		"token_type": "bearer",
		"refresh_token": make_fake_jwt(account),
		"refresh_expires": 86400,
		"refresh_expires_at": "9999-12-31T23:59:59.999Z",
		"account_id": account,
		"client_id": "lawinsclientidlol",
		"internal_client": True,
		"client_service": "fortnite",
		"displayName": account,
		"app": "fortnite",
		"in_app_id": account,
		"device_id": "lawinsdeviceidlol",
	}


@app.post("/account/api/oauth/token")
async def account_oauth_token(request: Request) -> dict[str, Any]:
	form = await request.form()
	username = str(form.get("username", "")).strip()

	if not config_bool("Config", "bUseConfigDisplayName", False) and username:
		STATE["current_account_id"] = username.split("@")[0]

	return make_oauth_payload()


@app.post("/auth/v1/oauth/token")
def auth_v1_token() -> dict[str, Any]:
	account = current_display_name()
	return {
		"access_token": make_fake_jwt(account),
		"token_type": "bearer",
		"expires_in": 28800,
		"expires_at": "9999-12-31T23:59:59.999Z",
		"refresh_token": make_fake_jwt(account),
		"refresh_expires_in": 86400,
		"refresh_expires_at": "9999-12-31T23:59:59.999Z",
		"nonce": "lawinserverpy",
		"deployment_id": "62a9473a2dca46b29ccf17577fcf42d7",
		"organization_id": "lawinsorganizationidlol",
		"product_id": "prod-fn",
		"sandbox_id": "fn",
		"account_id": account,
		"scope": "basic_profile friends_list openid presence",
	}


@app.post("/epic/oauth/v2/token")
def epic_oauth_v2_token() -> dict[str, Any]:
	account = current_display_name()
	access_token = make_fake_jwt(account)
	return {
		"scope": "basic_profile friends_list openid presence",
		"token_type": "bearer",
		"access_token": access_token,
		"expires_in": 28800,
		"expires_at": "9999-12-31T23:59:59.999Z",
		"refresh_token": make_fake_jwt(account),
		"refresh_expires_in": 86400,
		"refresh_expires_at": "9999-12-31T23:59:59.999Z",
		"id_token": access_token,
		"account_id": account,
		"deployment_id": "62a9473a2dca46b29ccf17577fcf42d7",
		"organization_id": "lawinsorganizationidlol",
		"product_id": "prod-fn",
		"sandbox_id": "fn",
		"app": "fortnite",
		"in_app_id": account,
		"displayName": account,
	}


@app.post("/publickey/v1/publickey/")
def publickey_v1() -> dict[str, Any]:
	# Newer builds call this during early bootstrap; empty key list is accepted.
	return {"publicKeys": []}


@app.get("/content-controls/{account_id}")
def content_controls(account_id: str) -> dict[str, Any]:
	# Keep shape permissive for modern clients that probe parental/content controls.
	return {"accountId": account_id, "controls": {}, "enabled": False}


@app.put("/profile/play_region")
def set_play_region(payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	region = str(payload.get("region", payload.get("playRegion", "AUTO")) or "AUTO")
	return {"region": region, "success": True}


@app.get("/epic/id/v2/sdk/accounts")
def sdk_accounts() -> list[dict[str, Any]]:
	account = current_display_name()
	return [{"accountId": account, "displayName": account, "preferredLanguage": "en", "cabinedMode": False, "empty": False}]


@app.get("/account/api/oauth/verify")
def oauth_verify() -> dict[str, Any]:
	account = current_display_name()
	return {
		"token": "lawinstokenlol",
		"session_id": "3c3662bcb661d6de679c636744c66b62",
		"token_type": "bearer",
		"client_id": "lawinsclientidlol",
		"internal_client": True,
		"client_service": "fortnite",
		"account_id": account,
		"expires_in": 28800,
		"expires_at": "9999-12-02T01:12:01.100Z",
		"auth_method": "exchange_code",
		"display_name": account,
		"app": "fortnite",
		"in_app_id": account,
		"device_id": "lawinsdeviceidlol",
	}


@app.delete("/account/api/oauth/sessions/kill")
def oauth_kill() -> Response:
	return Response(status_code=204)


@app.delete("/account/api/oauth/sessions/kill/{rest:path}")
def oauth_kill_any(rest: str) -> Response:
	return Response(status_code=204)


@app.post("/account/api/oauth/exchange")
def oauth_exchange() -> dict[str, Any]:
	account = current_display_name()
	return {
		"expiresInSeconds": 300,
		"code": make_fake_jwt(account),
		"creatingClientId": "lawinsclientidlol",
		"creatingClientService": "fortnite",
		"creatingUserId": account,
		"expires": "9999-12-31T23:59:59.999Z",
	}


@app.get("/account/api/epicdomains/ssodomains")
def epic_domains() -> list[str]:
	return ["unrealengine.com", "unrealtournament.com", "fortnite.com", "epicgames.com"]


@app.post("/fortnite/api/game/v2/tryPlayOnPlatform/account/{rest:path}")
def try_play_platform(rest: str) -> PlainTextResponse:
	return PlainTextResponse("true")


@app.get("/sdk/v1/{rest:path}")
def sdk_v1(rest: str, request: Request) -> Any:
	data = clone_json(RESPONSES_DIR / "sdkv1.json", {})
	client = data.setdefault("client", {}) if isinstance(data, dict) else {}
	lobby_client = client.setdefault("LobbyClient", {}) if isinstance(client, dict) else {}
	host = request.headers.get("host", "127.0.0.1:3551")
	deployment_id = request.query_params.get("deploymentId", "62a9473a2dca46b29ccf17577fcf42d7")

	# Redirect all EOS SDK service URLs to our local server.
	if isinstance(lobby_client, dict):
		lobby_client["LobbySocketURL"] = f"ws://{host}/lobby/v1/{deployment_id}/lobbies/connect"
		lobby_client["MaxConnectionRetries"] = 0

	if isinstance(client, dict):
		# XMPP messaging (in case DefaultEngine.ini override doesn't reach SDK)
		xmpp_msg = client.setdefault("Messaging.XMPP", {})
		if isinstance(xmpp_msg, dict):
			xmpp_msg["ServerAddr"] = f"ws://{host}//"
			xmpp_msg["Domain"] = host.split(":")[0]

	if isinstance(data, dict) and rest.startswith("product/"):
		product_id = rest.split("/", 1)[1]
		data.setdefault("productId", product_id)
		data.setdefault("deploymentId", deployment_id)
		data.setdefault("sandboxId", "fn")
		data.setdefault("product", {
			"id": product_id,
			"productId": product_id,
			"sandboxId": "fn",
			"deploymentId": deployment_id,
			"status": "ACTIVE",
		})
		client.setdefault("DeploymentId", deployment_id)
		client.setdefault("SandboxId", "fn")

	return data


@app.websocket("/connect")
@app.websocket("/connect/v2")
async def eos_connect_ws(websocket: WebSocket) -> None:
	"""EOS Connect real-time messaging stub."""
	try:
		await websocket.accept()
	except Exception:
		return
	while True:
		try:
			incoming = await websocket.receive()
		except (WebSocketDisconnect, RuntimeError):
			break
		if incoming.get("type") == "websocket.disconnect":
			break
		text = incoming.get("text") or ""
		if not text:
			continue
		try:
			msg = json.loads(text)
		except Exception:
			continue
		msg_type = str(msg.get("type", "")).upper()
		if msg_type in ("CONNECT", "CONNECTION_REQUEST"):
			try:
				await websocket.send_text(json.dumps({"type": "CONNECTED", "payload": {}}))
			except Exception:
				break
		elif msg_type in ("HEARTBEAT", "PING"):
			try:
				await websocket.send_text(json.dumps({"type": "HEARTBEAT", "payload": {}}))
			except Exception:
				break


@app.websocket("/lobby/v1/{deployment_id}/lobbies/connect")
async def lobby_ws(deployment_id: str, websocket: WebSocket) -> None:
	"""EOS lobby WebSocket stub — speaks the minimal EOS lobby framing protocol."""
	try:
		await websocket.accept()
	except Exception:
		return

	while True:
		try:
			incoming = await websocket.receive()
		except (WebSocketDisconnect, RuntimeError):
			break
		if incoming.get("type") == "websocket.disconnect":
			break

		text = incoming.get("text") or ""
		if not text:
			continue
		try:
			msg = json.loads(text)
		except Exception:
			continue
		msg_type = str(msg.get("type", "")).upper()
		if msg_type in ("CONNECT", "CONNECT_REQUEST"):
			try:
				await websocket.send_text(json.dumps({"type": "CONNECTED", "payload": {}}))
			except Exception:
				break
		elif msg_type in ("HEARTBEAT", "PING"):
			try:
				await websocket.send_text(json.dumps({"type": "HEARTBEAT", "payload": {}}))
			except Exception:
				break
		# All other messages (party operations etc.) are silently accepted.


@app.get("/content/api/pages/fortnite-game/seasonpasses")
def season_passes(request: Request) -> Any:
	season_passes_data = clone_json(RESPONSES_DIR / "Athena" / "seasonPasses.json", {})
	return choose_translations_in_json(season_passes_data, request)


@app.get("/content/api/pages/fortnite-game/spark-tracks")
def spark_tracks() -> Any:
	return load_json(RESPONSES_DIR / "Athena" / "sparkTracks.json", {})


@app.get("/content/api/pages/fortnite-game/radio-stations")
def radio_stations() -> dict[str, Any]:
	return {
		"_title": "Radio Stations",
		"radioStationList": {
			"_type": "RadioStationList",
			"stations": [
				{
					"resourceID": "QWGQAynCdixzoLIdJl",
					"stationImage": "https://fortnite-public-service-prod11.ol.epicgames.com/images/lawinpfp.png",
					"_type": "RadioStationItem",
					"title": {
						"en": "Party Royale",
					},
				},
			],
		},
	}


@app.get("/content/api/pages/{rest:path}")
def content_pages(rest: str, request: Request) -> Any:
	contentpages = clone_json(RESPONSES_DIR / "contentpages.json", {})
	memory = parse_version_info(request)
	season = int(memory["season"])
	build = float(memory["build"])
	contentpages = choose_translations_in_json(contentpages, request)

	try:
		backgrounds = contentpages["dynamicbackgrounds"]["backgrounds"]["backgrounds"]

		# --- Per-build background stage + image table ---
		# (stage, image_url or None)  —  ported from Backend-BGs.js
		# Keyed by (season, build_rounded_to_2dp) then fallback by season.
		_CL = int(memory.get("cl", 0))

		def _set_bg(stage: str, image: str | None = None, idx: int = 0) -> None:
			if idx < len(backgrounds):
				backgrounds[idx]["stage"] = stage
				if image:
					backgrounds[idx]["backgroundimage"] = image

		def _set_bg_both(stage: str, image: str | None = None) -> None:
			_set_bg(stage, image, 0)
			_set_bg(stage, image, 1)

		# Default stage naming: seasonX for old builds, seasonX00 for modern (S21+).
		if season == 10:
			default_stage = "seasonx"
		elif season >= 21:
			default_stage = f"season{season}00"
		else:
			default_stage = f"season{season}"
		_set_bg_both(default_stage)

		# Season-level fallback images (used when no build-specific override matches)
		_SEASON_IMGS: dict[int, str] = {
			11: "https://cdn2.unrealengine.com/s11-lobby-background-2048x1024-2e7112b25dc3.jpg",
			12: "https://cdn2.unrealengine.com/s12-lobby-background-2048x1024-3ab63fbe5e12.jpg",
			13: "https://cdn2.unrealengine.com/s13-lobby-background-2048x1024-3ab63fbe5e12.jpg",
			14: "https://cdn2.unrealengine.com/s14-lobby-background-2048x1024-3ab63fbe5e12.jpg",
			15: "https://cdn2.unrealengine.com/s15-lobby-background-2048x1024-3ab63fbe5e12.jpg",
			16: "https://cdn2.unrealengine.com/s16-lobby-background-2048x1024-3ab63fbe5e12.jpg",
			17: "https://cdn2.unrealengine.com/s17-lobby-background-2048x1024-3ab63fbe5e12.jpg",
			18: "https://cdn2.unrealengine.com/s18-lobby-background-2048x1024-3ab63fbe5e12.jpg",
			19: "https://cdn2.unrealengine.com/t-bp19-lobby-2048x1024-main.jpg",
			20: "https://cdn2.unrealengine.com/t-bp20-lobby-2048x1024-d89eb522746c.png",
			21: "https://cdn2.unrealengine.com/s21-lobby-background-2048x1024-2e7112b25dc3.jpg",
			22: "https://cdn2.unrealengine.com/t-bp22-lobby-square-2048x2048-2048x2048-e4e90c6e8018.jpg",
			23: "https://cdn2.unrealengine.com/t-bp23-lobby-2048x1024-2048x1024-26f2c1b27f63.png",
			24: "https://cdn2.unrealengine.com/t-ch4s2-bp-lobby-4096x2048-edde08d15f7e.jpg",
			25: "https://cdn2.unrealengine.com/s25-lobby-4k-4096x2048-4a832928e11f.jpg",
			26: "https://cdn2.unrealengine.com/0814-ch4s4-lobby-2048x1024-2048x1024-e3c2cf8d342d.png",
			27: "https://cdn2.unrealengine.com/og-lobby-rufus-4096x2048-4096x2048.jpg",
			28: "https://cdn2.unrealengine.com/ch5s1-lobbybg-3640x2048-0974e0c3333c.jpg",
			29: "https://cdn2.unrealengine.com/br-lobby-ch5s2-4096x2304-a0879ccdaafc.jpg",
		}
		if season in _SEASON_IMGS:
			_set_bg("defaultnotris", _SEASON_IMGS[season], 0)

		# Ch1 explicit local fallbacks so old clients don't end up on an empty-looking grid.
		if season <= 10:
			base_url = str(request.base_url).rstrip("/")
			if season == 10:
				_set_bg("seasonx", f"{base_url}/images/seasonx.png", 0)
			else:
				_set_bg(f"season{season}", f"{base_url}/images/lightlobbybg.png", 0)

		# ---------- Build-specific overrides ----------
		# Ch1
		if season < 10:
			_set_bg_both(f"season{season}")
		elif season == 10:
			_set_bg_both("seasonx")

		# Ch2 S1 (11)
		if season == 11:
			if abs(build - 11.10) < 0.01:
				_set_bg_both("fortnitemares")
			elif abs(build - 11.30) < 0.01:
				_set_bg_both("Galileo")
			elif abs(build - 11.31) < 0.01 or abs(build - 11.40) < 0.01:
				_set_bg_both("Winter19")
			elif abs(build - 11.50) < 0.01:
				_set_bg_both("LoveAndWar")

		# Ch2 S2-S8 (12-18) — use stage only, season fallback image already set
		# Ch2 S3 (13) fortnitemares
		if season == 13 and abs(build - 13.40) < 0.01:
			_set_bg_both("fortnitemares2020")

		# Ch2 S4 (14)
		if season == 14:
			if abs(build - 14.40) < 0.01 or abs(build - 14.60) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/halloween2020-lobby-2048x1024-2048x1024.jpg", 0)
				_set_bg_both("halloween2020")

		# Ch3 S1 (19)
		if season == 19:
			if abs(build - 19.01) < 0.01:
				_set_bg("defaultnotris", "https://cdn.discordapp.com/attachments/927739901540188200/930880158167085116/t-bp19-lobby-xmas-2048x1024-f85d2684b4af.png", 0)
				_set_bg_both("winter2021")

		# Ch3 S2 (20)
		if season == 20:
			if abs(build - 20.40) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/t-bp20-40-armadillo-glowup-lobby-2048x2048-2048x2048-3b83b887cc7f.jpg", 0)
			else:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/t-bp20-lobby-2048x1024-d89eb522746c.png", 0)

		# Ch3 S3 (21)
		if season == 21:
			_set_bg("defaultnotris", None, 0)
			if abs(build - 21.00) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/s21-lobby-background-2048x1024-2e7112b25dc3.jpg", 0)
			elif abs(build - 21.10) < 0.01:
				_set_bg_both("season2110")
			elif abs(build - 21.30) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/nss-lobbybackground-2048x1024-f74a14565061.jpg", 0)
				_set_bg_both("season2130")

		# Ch3 S4 (22)
		if season == 22:
			_set_bg("defaultnotris", "https://cdn2.unrealengine.com/t-bp22-lobby-square-2048x2048-2048x2048-e4e90c6e8018.jpg", 0)

		# Ch4 S1 (23)
		if season == 23:
			if abs(build - 23.10) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/t-bp23-winterfest-lobby-square-2048x2048-2048x2048-277a476e5ca6.png", 0)
				if isinstance(contentpages.get("specialoffervideo"), dict):
					contentpages["specialoffervideo"]["bSpecialOfferEnabled"] = "true"
			else:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/t-bp23-lobby-2048x1024-2048x1024-26f2c1b27f63.png", 0)

		# Ch4 S2 (24)
		if season == 24:
			if abs(build - 24.30) < 0.01 or abs(build - 24.40) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/ch4s2-lobbyupdate-4-20-2022-lifted-copy-3840x2160-d3a138f5f9e7.jpg", 0)
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/ch4s2-lobbyupdate-4-20-2022-lifted-copy-3840x2160-d3a138f5f9e7.jpg", 1)
			else:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/t-ch4s2-bp-lobby-4096x2048-edde08d15f7e.jpg", 0)
				if abs(build - 24.00) < 0.01 or abs(build - 24.20) < 0.01:
					if isinstance(contentpages.get("specialoffervideo"), dict):
						contentpages["specialoffervideo"]["bSpecialOfferEnabled"] = "true"

		# Ch4 S3 (25)
		if season == 25:
			if abs(build - 25.00) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/s25-lobby-4k-4096x2048-4a832928e11f.jpg", 0)
			elif abs(build - 25.10) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/fn-shop-ch4s3-04-1920x1080-785ce1d90213.png", 0)
			elif abs(build - 25.11) < 0.01 or abs(build - 25.20) < 0.01 or abs(build - 25.30) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/t-s25-14dos-lobby-4096x2048-2be24969eee3.jpg", 0)

		# Ch4 S4 (26)
		if season == 26:
			if abs(build - 26.00) < 0.01:
				_set_bg_both("season26")
			elif abs(build - 26.10) < 0.01 or abs(build - 26.20) < 0.01:
				_set_bg_both("season26")
			elif abs(build - 26.30) < 0.01 and _CL == 28509302:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/s26-lobby-timemachine-final-2560x1440-a3ce0018e3fa.jpg", 0)
				_set_bg_both("season2630")
			elif abs(build - 26.30) < 0.01 and _CL == 28688692:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/s26-lobby-timemachine-final-2560x1440-a3ce0018e3fa.jpg", 0)
				_set_bg_both("season2630")
			else:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/0814-ch4s4-lobby-2048x1024-2048x1024-e3c2cf8d342d.png", 0)

		# Ch4 S5 / OG (27)
		if season == 27:
			_set_bg_both("rufus")

		# Ch5 S1 (28)
		if season == 28:
			if abs(build - 28.00) < 0.01 and _CL == 29915848:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/ch5s1-lobbybg-3640x2048-0974e0c3333c.jpg", 0)
				_set_bg_both("season2800")
			elif abs(build - 28.01) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/winterfest2023-lobby-2048x1024-a8853c3a6f59.jpg", 0)
			elif abs(build - 28.20) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/s28-tmnt-lobby-4096x2048-e6c06a310c05.jpg", 0)
			elif abs(build - 28.30) < 0.01 and _CL == 31511038:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/ch5s1-lobbybg-3640x2048-0974e0c3333c.jpg", 0)
				_set_bg_both("season2800")
			else:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/ch5s1-lobbybg-3640x2048-0974e0c3333c.jpg", 0)

		# Ch5 S2 (29)
		if season == 29:
			if abs(build - 29.00) < 0.01 and _CL == 32116959:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/br-lobby-ch5s2-4096x2304-a0879ccdaafc.jpg", 0)
			elif abs(build - 29.40) < 0.01:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/mkart-2940-sw-fnbr-lobby-3840x2160-4f1f1486a54a.jpg", 0)
			else:
				_set_bg("defaultnotris", "https://cdn2.unrealengine.com/br-lobby-ch5s2-4096x2304-a0879ccdaafc.jpg", 0)

	except Exception:
		pass

	return contentpages


@app.post("/api/v1/fortnite-br/{rest:path}/target")
def br_target(rest: str, request: Request, payload: dict[str, Any] = Body(default={})) -> Any:
	motd = load_json(RESPONSES_DIR / "Athena" / "motd.json", {})
	language = str(payload.get("language") or payload.get("parameters", {}).get("language") or "").strip()
	tags = payload.get("tags", [])
	if language:
		motd = choose_translations_in_json(motd, request, language)

	if isinstance(motd, dict) and isinstance(tags, list):
		items = motd.get("contentItems", [])
		for item in items:
			item["placements"] = []
			for tag in tags:
				item["placements"].append({"trackingId": "lawinstrackingidlol", "tag": tag, "position": 0})

	return motd


@app.get("/fortnite/api/storefront/v2/catalog")
def storefront_catalog(request: Request) -> Response:
	user_agent = request.headers.get("user-agent", "")
	if "2870186" in user_agent:
		return Response(status_code=404)

	memory = parse_version_info(request)
	catalog = clone_json(RESPONSES_DIR / "catalog.json", {})

	try:
		if memory["build"] >= 30.10:
			catalog = json.loads(json.dumps(catalog).replace('"Normal"', '"Size_1_x_2"'))
		if memory["build"] >= 30.20:
			catalog = json.loads(json.dumps(catalog).replace("Game/Items/CardPacks/", "SaveTheWorld/Items/CardPacks/"))
	except Exception:
		pass

	return JSONResponse(catalog)


@app.get("/fortnite/api/storefront/v2/keychain")
def storefront_keychain() -> Any:
	return load_json(RESPONSES_DIR / "keychain.json", [])


@app.get("/catalog/api/shared/bulk/offers")
def shared_bulk_offers() -> dict[str, Any]:
	return {}


@app.get("/affiliate/api/public/affiliates/slug/{slug}")
def affiliate_slug(slug: str) -> Response:
	supported_codes = load_json(RESPONSES_DIR / "SAC.json", [])
	for code in supported_codes:
		if str(code).lower() == slug.lower():
			return JSONResponse({"id": code, "slug": code, "displayName": code, "status": "ACTIVE", "verified": False})
	return JSONResponse({}, status_code=404)


@app.get("/fortnite/api/game/v2/privacy/account/{account_id}")
def privacy_get(account_id: str) -> Any:
	data = load_json(RESPONSES_DIR / "privacy.json", {"accountId": "", "optOutOfPublicLeaderboards": False})
	data["accountId"] = account_id
	return data


@app.post("/fortnite/api/game/v2/privacy/account/{account_id}")
def privacy_post(account_id: str, payload: dict[str, Any] = Body(default={})) -> Any:
	data = load_json(RESPONSES_DIR / "privacy.json", {"accountId": "", "optOutOfPublicLeaderboards": False})
	data["accountId"] = account_id
	data["optOutOfPublicLeaderboards"] = bool(payload.get("optOutOfPublicLeaderboards", False))
	save_json(RESPONSES_DIR / "privacy.json", data)
	return data


@app.get("/friends/api/v1/{account_id}/settings")
def friends_settings(account_id: str) -> dict[str, Any]:
	return {}


@app.get("/friends/api/v1/{account_id}/blocklist")
def friends_blocklist(account_id: str) -> list[Any]:
	return []


def ensure_friend(account_id: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
	friendslist_path = RESPONSES_DIR / "friendslist.json"
	friendslist2_path = RESPONSES_DIR / "friendslist2.json"

	friendslist = load_json(friendslist_path, [])
	friendslist2 = load_json(friendslist2_path, {"friends": [], "incoming": [], "outgoing": [], "suggested": [], "blocklist": [], "settings": {"acceptInvites": "public"}})

	exists = any(i.get("accountId") == account_id for i in friendslist)
	if not exists:
		created = utc_now_iso()
		friend_obj = {
			"accountId": account_id,
			"status": "ACCEPTED",
			"direction": "OUTBOUND",
			"created": created,
			"favorite": False,
		}
		friendslist.append(friend_obj)
		friendslist2.setdefault("friends", []).append(
			{
				"accountId": account_id,
				"groups": [],
				"mutual": 0,
				"alias": "",
				"note": "",
				"favorite": False,
				"created": created,
			}
		)
		save_json(friendslist_path, friendslist)
		save_json(friendslist2_path, friendslist2)

	return friendslist, friendslist2


def profile_path(profile_id: str) -> Path:
	return PROFILES_DIR / f"{profile_id}.json"


# Per-profile locks prevent concurrent SetCosmeticLockerSlot / other command
# races where multiple requests load the same profile before any save completes.
_PROFILE_LOCKS: dict[str, threading.Lock] = {}
_PROFILE_LOCKS_GUARD = threading.Lock()


def _profile_lock(profile_id: str) -> threading.Lock:
	with _PROFILE_LOCKS_GUARD:
		if profile_id not in _PROFILE_LOCKS:
			_PROFILE_LOCKS[profile_id] = threading.Lock()
		return _PROFILE_LOCKS[profile_id]


def load_profile(profile_id: str, account_id: str) -> dict[str, Any]:
	profile = load_json(profile_path(profile_id), {})
	if not isinstance(profile, dict):
		profile = {}

	profile.setdefault("_id", account_id)
	profile.setdefault("accountId", account_id)
	profile.setdefault("profileId", profile_id)
	profile.setdefault("created", "0001-01-01T00:00:00.000Z")
	profile.setdefault("updated", "0001-01-01T00:00:00.000Z")
	profile.setdefault("rvn", 0)
	profile.setdefault("commandRevision", 0)
	profile.setdefault("wipeNumber", 1)
	profile.setdefault("version", "no_version")
	profile.setdefault("items", {})
	profile.setdefault("stats", {"attributes": {}})
	return profile


def save_profile(profile_id: str, profile: dict[str, Any]) -> None:
	save_json(profile_path(profile_id), profile)


def profile_response(profile: dict[str, Any], changes: list[dict[str, Any]] | None = None) -> dict[str, Any]:
	if changes is None:
		changes = [{"changeType": "fullProfileUpdate", "profile": profile}]

	rvn = int(profile.get("rvn", 1))
	command_revision = int(profile.get("commandRevision", rvn))

	return {
		"profileRevision": rvn,
		"profileId": profile.get("profileId", "unknown"),
		"profileChangesBaseRevision": rvn,
		"profileChanges": changes,
		"profileCommandRevision": command_revision,
		"serverTime": utc_now_iso(),
		"responseVersion": 1,
		"multiUpdate": [],
		"notifications": [],
	}


def parse_query_rvn(request: Request) -> int:
	try:
		return int(str(request.query_params.get("rvn", "-1")))
	except Exception:
		return -1


def mcp_response(profile: dict[str, Any], base_revision: int, query_revision: int, changes: list[dict[str, Any]] | None = None) -> dict[str, Any]:
	apply_changes = changes or []
	if query_revision != base_revision:
		apply_changes = [{"changeType": "fullProfileUpdate", "profile": profile}]

	return {
		"profileRevision": int(profile.get("rvn", 1)),
		"profileId": profile.get("profileId", "unknown"),
		"profileChangesBaseRevision": base_revision,
		"profileChanges": apply_changes,
		"profileCommandRevision": int(profile.get("commandRevision", profile.get("rvn", 1))),
		"serverTime": utc_now_iso(),
		"multiUpdate": [],
		"notifications": [],
		"responseVersion": 1,
	}


@app.post("/fortnite/api/game/v2/profile/{account_id}/client/QueryProfile")
def profile_query(account_id: str, request: Request, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	profile_id = request.query_params.get("profileId")
	if not profile_id:
		return JSONResponse(status_code=404, content={"error": "Profile not defined."})
	# common_public is a read-only mirror of common_core stats — serve it from there.
	if profile_id == "common_public":
		profile = load_profile("common_core", account_id)
		profile["profileId"] = "common_public"
	else:
		profile = load_profile(profile_id, account_id)
	base_revision = int(profile.get("rvn", 1))
	query_revision = parse_query_rvn(request)
	return mcp_response(profile, base_revision, query_revision)


@app.post("/fortnite/api/game/v2/profile/{account_id}/client/{command}")
def profile_client_command(account_id: str, command: str, request: Request, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	profile_id = request.query_params.get("profileId")
	if not profile_id:
		return JSONResponse(status_code=404, content={"error": "Profile not defined."})
	with _profile_lock(profile_id):
		return _profile_client_command_inner(account_id, command, profile_id, request, payload)


def _profile_client_command_inner(account_id: str, command: str, profile_id: str, request: Request, payload: dict[str, Any]) -> dict[str, Any]:
	profile = load_profile(profile_id, account_id)
	base_revision = int(profile.get("rvn", 1))
	query_revision = parse_query_rvn(request)
	items = profile.setdefault("items", {})
	changes: list[dict[str, Any]] = []
	multi_update: list[dict[str, Any]] = []
	notifications: list[dict[str, Any]] = []

	cmd = command.lower()

	SLOT_STAT_MAP: dict[str, str] = {
		"Character": "favorite_character",
		"Backpack": "favorite_backpack",
		"Pickaxe": "favorite_pickaxe",
		"Glider": "favorite_glider",
		"MusicPack": "favorite_musicpack",
		"LoadingScreen": "favorite_loadingscreen",
		"SkyDiveContrail": "favorite_skydivecontrail",
		"Dance": "favorite_dance",
		"ItemWrap": "favorite_itemwraps",
	}

	def canonical_slot_name(raw_slot: Any) -> str:
		raw = str(raw_slot or "").strip()
		if not raw:
			return ""
		aliases = {
			"character": "Character",
			"outfit": "Character",
			"backpack": "Backpack",
			"backbling": "Backpack",
			"pickaxe": "Pickaxe",
			"harvestingtool": "Pickaxe",
			"glider": "Glider",
			"skydivecontrail": "SkyDiveContrail",
			"contrail": "SkyDiveContrail",
			"musicpack": "MusicPack",
			"music": "MusicPack",
			"loadingscreen": "LoadingScreen",
			"dance": "Dance",
			"emote": "Dance",
			"itemwrap": "ItemWrap",
			"wrap": "ItemWrap",
		}
		return aliases.get(raw.lower(), raw)

	def resolve_locker_item_id(raw_locker_item: Any) -> str | None:
		needle = str(raw_locker_item or payload.get("lockerItemId") or payload.get("loadoutId") or "").strip()
		if needle and needle in items:
			return needle
		for iid, ientry in items.items():
			tmpl = str(ientry.get("templateId", ""))
			if not tmpl.lower().startswith("cosmeticlocker:"):
				continue
			if not needle:
				return iid
			locker_name = str(ientry.get("attributes", {}).get("locker_name", "")).strip().lower()
			if iid.lower() == needle.lower() or locker_name == needle.lower():
				return iid
		return None

	def ensure_locker_item() -> str:
		locker_id = resolve_locker_item_id(payload.get("lockerItem"))
		if locker_id:
			return locker_id
		locker_id = "lawin-loadout"
		if locker_id not in items:
			default_slots: dict[str, Any] = {
				"Character": {"items": [""], "activeVariants": [{"variants": []}]},
				"Backpack": {"items": [""], "activeVariants": [{"variants": []}]},
				"Pickaxe": {"items": ["AthenaPickaxe:DefaultPickaxe"], "activeVariants": [{"variants": []}]},
				"Glider": {"items": ["AthenaGlider:DefaultGlider"], "activeVariants": [{"variants": []}]},
				"SkyDiveContrail": {"items": [""], "activeVariants": [{"variants": []}]},
				"MusicPack": {"items": [""], "activeVariants": [{"variants": []}]},
				"LoadingScreen": {"items": [""], "activeVariants": [{"variants": []}]},
				"Dance": {"items": ["", "", "", "", "", ""], "activeVariants": []},
				"ItemWrap": {"items": ["", "", "", "", "", "", ""], "activeVariants": [{"variants": []}]},
			}
			new_item: dict[str, Any] = {
				"templateId": "CosmeticLocker:cosmeticlocker_athena",
				"attributes": {
					"locker_slots_data": {"slots": default_slots},
					"banner_icon_template": "StandardBanner1",
					"banner_color_template": "DefaultColor1",
					"locker_name": "LawinServer.py",
					"item_seen": False,
					"favorite": False,
				},
				"quantity": 1,
			}
			items[locker_id] = new_item
			changes.append({"changeType": "itemAdded", "itemId": locker_id, "item": new_item})
		return locker_id

	def ensure_slot_array(slot_data: dict[str, Any], slot_name: str) -> list[str]:
		expected_size = {
			"Dance": 6,
			"ItemWrap": 7,
		}.get(slot_name, 1)
		existing = slot_data.get("items")
		if not isinstance(existing, list):
			existing = []
		while len(existing) < expected_size:
			existing.append("")
		slot_data["items"] = existing
		return existing

	if cmd == "setitemfavoritestatus":
		target = str(payload.get("targetItemId", ""))
		entry = items.get(target)
		if entry:
			fav = bool(payload.get("bFavorite", False))
			entry.setdefault("attributes", {})["favorite"] = fav
			changes.append({"changeType": "itemAttrChanged", "itemId": target, "attributeName": "favorite", "attributeValue": fav})

	if cmd == "setitemfavoritestatusbatch":
		# Lawin supports both itemIds/itemFavStatus and targetItemIds/bFavorite payload shapes.
		item_ids = payload.get("itemIds", []) or payload.get("targetItemIds", []) or []
		item_status = payload.get("itemFavStatus", []) or []
		default_status = bool(payload.get("bFavorite", False))

		for idx, target in enumerate(item_ids):
			entry = items.get(target)
			if entry:
				fav = bool(item_status[idx]) if idx < len(item_status) else default_status
				entry.setdefault("attributes", {})["favorite"] = fav
				changes.append({"changeType": "itemAttrChanged", "itemId": target, "attributeName": "favorite", "attributeValue": fav})

	elif cmd == "markitemseen":
		item_ids = payload.get("itemIds", []) or []
		single_item_id = str(payload.get("itemId", ""))
		if single_item_id:
			item_ids.append(single_item_id)
		for target in item_ids:
			entry = items.get(target)
			if entry:
				entry.setdefault("attributes", {})["item_seen"] = True
				changes.append({"changeType": "itemAttrChanged", "itemId": target, "attributeName": "item_seen", "attributeValue": True})

	elif cmd == "setitemarchivedstatusbatch":
		item_ids = payload.get("itemIds", []) or []
		archived = bool(payload.get("archived", False))
		for target in item_ids:
			entry = items.get(target)
			if entry:
				entry.setdefault("attributes", {})["archived"] = archived
				changes.append({"changeType": "itemAttrChanged", "itemId": target, "attributeName": "archived", "attributeValue": archived})

	elif cmd == "setbattlepassinfo":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		attrs["book_purchased"] = bool(payload.get("bPurchased", False))
		attrs["book_level"] = int(payload.get("bookLevel", attrs.get("book_level", 1)))
		attrs["season_num"] = int(payload.get("seasonNum", attrs.get("season_num", 1)))
		changes.append({"changeType": "statModified", "name": "book_purchased", "value": attrs["book_purchased"]})

	elif cmd == "sethomebasebanner":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		icon_id = payload.get("homebaseBannerIconId")
		color_id = payload.get("homebaseBannerColorId")
		if icon_id and color_id:
			if profile_id == "profile0":
				homebase = attrs.setdefault("homebase", {})
				homebase["bannerIconId"] = icon_id
				homebase["bannerColorId"] = color_id
				changes.append({"changeType": "statModified", "name": "homebase", "value": homebase})
			else:
				attrs["banner_icon"] = icon_id
				attrs["banner_color"] = color_id
				changes.append({"changeType": "statModified", "name": "banner_icon", "value": attrs["banner_icon"]})
				changes.append({"changeType": "statModified", "name": "banner_color", "value": attrs["banner_color"]})

	elif cmd == "sethomebasename":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		homebase_name = payload.get("homebaseName")
		if homebase_name:
			if profile_id == "profile0":
				homebase = attrs.setdefault("homebase", {})
				homebase["townName"] = homebase_name
				changes.append({"changeType": "statModified", "name": "homebase", "value": homebase})
			else:
				attrs["homebase_name"] = homebase_name
				changes.append({"changeType": "statModified", "name": "homebase_name", "value": attrs["homebase_name"]})

	elif cmd == "setbattleroyalebanner":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		icon_id = payload.get("homebaseBannerIconId")
		color_id = payload.get("homebaseBannerColorId")
		if icon_id and color_id:
			attrs["banner_icon"] = icon_id
			attrs["banner_color"] = color_id
			changes.append({"changeType": "statModified", "name": "banner_icon", "value": attrs["banner_icon"]})
			changes.append({"changeType": "statModified", "name": "banner_color", "value": attrs["banner_color"]})

	elif cmd == "setpartyassistquest":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		if "party_assist_quest" in attrs:
			attrs["party_assist_quest"] = payload.get("questToPinAsPartyAssist", "")
			changes.append({"changeType": "statModified", "name": "party_assist_quest", "value": attrs["party_assist_quest"]})

	elif cmd == "athenapinquest":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		if "pinned_quest" in attrs:
			attrs["pinned_quest"] = payload.get("pinnedQuest", "")
			changes.append({"changeType": "statModified", "name": "pinned_quest", "value": attrs["pinned_quest"]})

	elif cmd == "setpinnedquests":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		client_settings = attrs.setdefault("client_settings", {})
		if payload.get("pinnedQuestIds") is not None:
			client_settings["pinnedQuestInstances"] = payload.get("pinnedQuestIds", [])
			changes.append({"changeType": "statModified", "name": "client_settings", "value": client_settings})

	elif cmd == "incrementnamedcounterstat":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		named_counters = attrs.get("named_counters", {})
		counter_name = payload.get("counterName")
		if counter_name and isinstance(named_counters, dict) and counter_name in named_counters:
			entry = named_counters[counter_name]
			entry["current_count"] = int(entry.get("current_count", 0)) + 1
			entry["last_incremented_time"] = utc_now_iso()
			changes.append({"changeType": "statModified", "name": "named_counters", "value": named_counters})

	elif cmd == "setseasonpassautoclaim":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		season_ids = payload.get("seasonIds", []) or []
		enabled = payload.get("bEnabled", None)
		if enabled is not None:
			auto_claim_ids = attrs.setdefault("auto_spend_season_currency_ids", [])
			for season_id in season_ids:
				if enabled and season_id not in auto_claim_ids:
					auto_claim_ids.append(season_id)
				elif (not enabled) and season_id in auto_claim_ids:
					auto_claim_ids.remove(season_id)
			changes.append({"changeType": "statModified", "name": "auto_spend_season_currency_ids", "value": auto_claim_ids})

	elif cmd == "equipbattleroyalecustomization":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		slot = canonical_slot_name(payload.get("slotName", ""))
		item_to_slot = str(payload.get("itemToSlot", ""))
		if slot in {"Character", "Backpack", "Pickaxe", "Glider", "SkyDiveContrail", "MusicPack", "LoadingScreen"}:
			key = f"favorite_{slot.lower()}"
			attrs[key] = item_to_slot
			changes.append({"changeType": "statModified", "name": key, "value": attrs[key]})
		elif slot == "Dance":
			idx = int(payload.get("indexWithinSlot", 0))
			dances = attrs.setdefault("favorite_dance", ["", "", "", "", "", ""])
			if 0 <= idx < len(dances):
				dances[idx] = item_to_slot
				changes.append({"changeType": "statModified", "name": "favorite_dance", "value": dances})
		elif slot == "ItemWrap":
			idx = int(payload.get("indexWithinSlot", 0))
			wraps = attrs.setdefault("favorite_itemwraps", ["", "", "", "", "", "", ""])
			if idx == -1:
				for i in range(len(wraps)):
					wraps[i] = item_to_slot
				changes.append({"changeType": "statModified", "name": "favorite_itemwraps", "value": wraps})
			elif 0 <= idx < len(wraps):
				wraps[idx] = item_to_slot
				changes.append({"changeType": "statModified", "name": "favorite_itemwraps", "value": wraps})

		# Keep modern locker slots synchronized so Chapter 2+ locker UI stays in sync.
		locker_item_id = ensure_locker_item()
		locker_entry = items.get(locker_item_id)
		if locker_entry is not None:
			locker_attrs = locker_entry.setdefault("attributes", {})
			locker_slots_data = locker_attrs.setdefault("locker_slots_data", {"slots": {}})
			slot_data = locker_slots_data["slots"].setdefault(slot, {})
			slot_items = ensure_slot_array(slot_data, slot)
			if slot in ("Dance", "ItemWrap"):
				idx = int(payload.get("indexWithinSlot", 0))
				if slot == "ItemWrap" and idx == -1:
					for i in range(len(slot_items)):
						slot_items[i] = item_to_slot
				elif 0 <= idx < len(slot_items):
					slot_items[idx] = item_to_slot
			else:
				slot_items[0] = item_to_slot
			changes.append({"changeType": "itemAttrChanged", "itemId": locker_item_id, "attributeName": "locker_slots_data", "attributeValue": locker_slots_data})

	elif cmd == "setaffiliatename":
		supported_codes = load_json(RESPONSES_DIR / "SAC.json", [])
		affiliate_name = str(payload.get("affiliateName", ""))
		if affiliate_name == "" or any(str(code).lower() == affiliate_name.lower() for code in supported_codes):
			attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
			attrs["mtx_affiliate_set_time"] = utc_now_iso()
			attrs["mtx_affiliate"] = affiliate_name
			changes.append({"changeType": "statModified", "name": "mtx_affiliate_set_time", "value": attrs["mtx_affiliate_set_time"]})
			changes.append({"changeType": "statModified", "name": "mtx_affiliate", "value": attrs["mtx_affiliate"]})

	# ── NEW COMMANDS (1:1 LawinV1 parity) ──────────────────────────────────

	elif cmd == "setactivearchetype":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		archetype_group = payload.get("archetypeGroup")
		if archetype_group:
			if "loadout_archetype_values" not in attrs:
				attrs["loadout_archetype_values"] = {}
			attrs["loadout_archetype_values"][archetype_group] = payload.get("archetype", "")
			changes.append({"changeType": "statModified", "name": "loadout_archetype_values", "value": attrs["loadout_archetype_values"]})

	elif cmd == "setactiveheroloadout":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		selected = payload.get("selectedLoadout")
		if selected:
			attrs["selected_hero_loadout"] = selected
			changes.append({"changeType": "statModified", "name": "selected_hero_loadout", "value": attrs["selected_hero_loadout"]})

	elif cmd == "setcosmeticlockerbanner":
		banner_icon = payload.get("bannerIconTemplateName")
		banner_color = payload.get("bannerColorTemplateName")
		locker_item_id = resolve_locker_item_id(payload.get("lockerItem")) or ensure_locker_item()
		if banner_icon and banner_color:
			entry = items.get(locker_item_id)
			if entry:
				entry.setdefault("attributes", {})["banner_icon_template"] = banner_icon
				entry["attributes"]["banner_color_template"] = banner_color
				changes.append({"changeType": "itemAttrChanged", "itemId": locker_item_id, "attributeName": "banner_icon_template", "attributeValue": banner_icon})
				changes.append({"changeType": "itemAttrChanged", "itemId": locker_item_id, "attributeName": "banner_color_template", "attributeValue": banner_color})

	elif cmd == "setcosmeticlockerslot":
		locker_item_id = ensure_locker_item()
		slot_name = canonical_slot_name(payload.get("slotName", ""))
		item_to_slot = str(payload.get("itemToSlot") or payload.get("slotItemToEquip") or payload.get("equippedItem") or "")
		variant_updates = payload.get("variantUpdates") or payload.get("itemVariantUpdates") or []
		slot_index_raw = payload.get("indexWithinSlot", payload.get("slotIndex", 0))
		try:
			slot_index = int(slot_index_raw)
		except Exception:
			slot_index = 0
		entry = items.get(locker_item_id)
		if entry is not None and slot_name:
			attrs_e = entry.setdefault("attributes", {})
			locker_slots_data = attrs_e.setdefault("locker_slots_data", {"slots": {}})
			slot_data = locker_slots_data["slots"].setdefault(slot_name, {})
			slot_items = ensure_slot_array(slot_data, slot_name)

			if slot_name in ("Dance", "ItemWrap"):
				if slot_name == "ItemWrap" and slot_index == -1:
					for i in range(len(slot_items)):
						slot_items[i] = item_to_slot
				elif 0 <= slot_index < len(slot_items):
					slot_items[slot_index] = item_to_slot
			else:
				slot_items[0] = item_to_slot

			# activeVariants shape: the game stores [{"variants": [...]}] — one bucket per item in the slot.
			# The client sends variantUpdates as a flat [{"channel":...,"active":...,"owned":[]}] array.
			if isinstance(variant_updates, list) and variant_updates:
				# If already in the nested shape (list of dicts with "variants" key), keep as-is.
				if isinstance(variant_updates[0], dict) and "variants" in variant_updates[0]:
					slot_data["activeVariants"] = variant_updates
				else:
					# Wrap flat channel array into the nested bucket structure.
					slot_data["activeVariants"] = [{"variants": variant_updates}]
			elif not variant_updates and "activeVariants" not in slot_data:
				# Ensure key exists so locker slot reads correctly on older clients too.
				slot_data["activeVariants"] = [{"variants": []}]

			# Also mirror into legacy stat keys for older lobby/locker readers.
			attr_stat = profile.setdefault("stats", {}).setdefault("attributes", {})
			stat_key = SLOT_STAT_MAP.get(slot_name)
			if stat_key:
				if slot_name in ("Dance", "ItemWrap"):
					attr_stat[stat_key] = list(slot_items)
				else:
					attr_stat[stat_key] = slot_items[0] if slot_items else ""
				changes.append({"changeType": "statModified", "name": stat_key, "value": attr_stat[stat_key]})

			changes.append({"changeType": "itemAttrChanged", "itemId": locker_item_id, "attributeName": "locker_slots_data", "attributeValue": locker_slots_data})

	elif cmd == "setcosmeticlockerslotclearvariants":
		# Clears variants on a specific locker slot — used by CH3+ variant reset button.
		locker_item_id = resolve_locker_item_id(payload.get("lockerItem")) or ensure_locker_item()
		slot_name = canonical_slot_name(payload.get("slotName", ""))
		entry = items.get(locker_item_id)
		if entry and slot_name:
			slot_data = entry.setdefault("attributes", {}).setdefault("locker_slots_data", {"slots": {}}).setdefault("slots", {}).setdefault(slot_name, {})
			slot_data["activeVariants"] = [{"variants": []}]
			changes.append({"changeType": "itemAttrChanged", "itemId": locker_item_id, "attributeName": "locker_slots_data", "attributeValue": entry["attributes"]["locker_slots_data"]})

	elif cmd == "setcosmeticlockername":
		# Rename a locker preset — CH2+ locker UI.
		locker_item_id = resolve_locker_item_id(payload.get("lockerItem")) or ensure_locker_item()
		new_name = str(payload.get("name") or payload.get("lockerName") or "").strip()[:64]
		entry = items.get(locker_item_id)
		if entry and new_name:
			entry.setdefault("attributes", {})["locker_name"] = new_name
			changes.append({"changeType": "itemAttrChanged", "itemId": locker_item_id, "attributeName": "locker_name", "attributeValue": new_name})

	elif cmd in ("copycosmticloadout", "copycosmeticloadout"):
		# Duplicate a locker preset into a new slot — CH2+ preset tabs.
		src_id = resolve_locker_item_id(payload.get("lockerItem") or payload.get("sourceLoadoutId"))
		if src_id:
			new_id = str(uuid.uuid4())
			new_entry = deepcopy(items[src_id])
			new_entry.setdefault("attributes", {})["locker_name"] = str(new_entry.get("attributes", {}).get("locker_name", "Loadout")) + " Copy"
			items[new_id] = new_entry
			changes.append({"changeType": "itemAdded", "itemId": new_id, "item": new_entry})

	elif cmd == "createcosmeticloadout":
		# Create a fresh empty locker preset.
		new_name = str(payload.get("name") or payload.get("lockerName") or "Loadout").strip()[:64]
		new_id = str(uuid.uuid4())
		default_slots: dict[str, Any] = {
			"Character": {"items": [""], "activeVariants": [{"variants": []}]},
			"Backpack": {"items": [""], "activeVariants": [{"variants": []}]},
			"Pickaxe": {"items": ["AthenaPickaxe:DefaultPickaxe"], "activeVariants": [{"variants": []}]},
			"Glider": {"items": ["AthenaGlider:DefaultGlider"], "activeVariants": [{"variants": []}]},
			"SkyDiveContrail": {"items": [""], "activeVariants": [{"variants": []}]},
			"MusicPack": {"items": [""], "activeVariants": [{"variants": []}]},
			"LoadingScreen": {"items": [""], "activeVariants": [{"variants": []}]},
			"Dance": {"items": ["", "", "", "", "", ""], "activeVariants": []},
			"ItemWrap": {"items": ["", "", "", "", "", "", ""], "activeVariants": [{"variants": []}]},
		}
		new_entry: dict[str, Any] = {
			"templateId": "CosmeticLocker:cosmeticlocker_athena",
			"attributes": {
				"locker_slots_data": {"slots": default_slots},
				"banner_icon_template": "StandardBanner1",
				"banner_color_template": "DefaultColor1",
				"locker_name": new_name,
				"item_seen": False,
				"favorite": False,
			},
			"quantity": 1,
		}
		items[new_id] = new_entry
		changes.append({"changeType": "itemAdded", "itemId": new_id, "item": new_entry})

	elif cmd == "deletecosmeticloadout":
		# Delete a locker preset — never delete the last one.
		locker_ids = [iid for iid, ie in items.items() if str(ie.get("templateId", "")).lower().startswith("cosmeticlocker:")]
		target_id = resolve_locker_item_id(payload.get("lockerItem") or payload.get("loadoutId"))
		if target_id and target_id in locker_ids and len(locker_ids) > 1:
			del items[target_id]
			changes.append({"changeType": "itemRemoved", "itemId": target_id})

	elif cmd == "setherocosmeticvariants":
		hero_item = payload.get("heroItem")
		outfit_variants = payload.get("outfitVariants")
		backbling_variants = payload.get("backblingVariants")
		if hero_item and outfit_variants is not None and backbling_variants is not None:
			entry = items.get(hero_item)
			if entry:
				entry.setdefault("attributes", {})["outfitvariants"] = outfit_variants
				entry["attributes"]["backblingvariants"] = backbling_variants
				changes.append({"changeType": "itemAttrChanged", "itemId": hero_item, "attributeName": "outfitvariants", "attributeValue": outfit_variants})
				changes.append({"changeType": "itemAttrChanged", "itemId": hero_item, "attributeName": "backblingvariants", "attributeValue": backbling_variants})

	elif cmd == "putmodularcosmeticloadout":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		loadout_type = str(payload.get("loadoutType", ""))
		try:
			loadout_data = json.loads(payload.get("loadoutData", "{}"))
		except Exception:
			loadout_data = {}
		if "loadout_presets" not in attrs:
			attrs["loadout_presets"] = {}
			changes.append({"changeType": "statModified", "name": "loadout_presets", "value": {}})
		if loadout_type and loadout_type not in attrs.get("loadout_presets", {}):
			new_loadout_id = str(uuid.uuid4())
			items[new_loadout_id] = {"templateId": loadout_type, "attributes": {}, "quantity": 1}
			changes.append({"changeType": "itemAdded", "itemId": new_loadout_id, "item": items[new_loadout_id]})
		if loadout_type and loadout_data:
			for slot in loadout_data.get("slots", []):
				slot_template = slot.get("slot_template", "")
				equipped = slot.get("equipped_item", "")
				for key, item_entry in items.items():
					if item_entry.get("templateId", "").lower() == loadout_type.lower():
						item_entry.setdefault("attributes", {})[slot_template] = equipped
						break
		changes.append({"changeType": "statModified", "name": "loadout_presets", "value": attrs.get("loadout_presets", {})})

	elif cmd == "removegiftbox":
		gift_id = payload.get("giftBoxItemId")
		gift_ids = payload.get("giftBoxItemIds") or []
		if gift_id and gift_id in items:
			del items[gift_id]
			changes.append({"changeType": "itemRemoved", "itemId": gift_id})
		for gid in gift_ids:
			if gid in items:
				del items[gid]
				changes.append({"changeType": "itemRemoved", "itemId": gid})

	elif cmd == "marknewquestnotificationsent":
		quest_id = payload.get("questId")
		if quest_id and quest_id in items:
			items[quest_id].setdefault("attributes", {})["sent_new_notification"] = True
			changes.append({"changeType": "itemAttrChanged", "itemId": quest_id, "attributeName": "sent_new_notification", "attributeValue": True})

	elif cmd == "modifyquickbar":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		player_loadout = attrs.get("player_loadout")
		if player_loadout:
			primary = payload.get("primaryQuickbarChoices")
			secondary = payload.get("secondaryQuickbarChoice")
			if primary is not None:
				pri_rec = player_loadout.setdefault("primaryQuickBarRecord", {})
				slots = pri_rec.setdefault("slots", [])
				for i, choice in enumerate(primary):
					a = i + 1
					val = [choice.replace("-", "").upper()] if choice else []
					if isinstance(slots, list):
						while len(slots) <= a:
							slots.append({"items": []})
						slots[a]["items"] = val
					else:
						slots.setdefault(str(a), {"items": []})["items"] = val
			if isinstance(secondary, str):
				sec_rec = player_loadout.setdefault("secondaryQuickBarRecord", {})
				sec_slots = sec_rec.setdefault("slots", [])
				val = [secondary.replace("-", "").upper()] if secondary else []
				if isinstance(sec_slots, list):
					while len(sec_slots) <= 5:
						sec_slots.append({"items": []})
					sec_slots[5]["items"] = val
				else:
					sec_slots.setdefault("5", {"items": []})["items"] = val
			changes.append({"changeType": "statModified", "name": "player_loadout", "value": player_loadout})

	elif cmd == "populateprerolledoffers":
		now = utc_now_iso()
		today_end = now.split("T")[0] + "T23:59:59.999Z"
		card_pack_data = load_json(RESPONSES_DIR / "Campaign" / "cardPackData.json", {})
		default_items_list = card_pack_data.get("default", [])
		for key, item_entry in items.items():
			if item_entry.get("templateId", "").lower() == "prerolldata:preroll_basic":
				attrs_e = item_entry.setdefault("attributes", {})
				expiration = attrs_e.get("expiration", "")
				if now > expiration:
					new_items = []
					for _ in range(10):
						if default_items_list:
							chosen = random.choice(default_items_list)
							tmpl = chosen if isinstance(chosen, str) else chosen.get("templateId", "")
							new_items.append({"itemType": tmpl, "attributes": {"legacy_alterations": [], "max_level_bonus": 0, "level": 1, "refund_legacy_item": False, "item_seen": False, "alterations": ["", "", "", "", "", ""], "xp": 0, "refundable": False, "alteration_base_rarities": [], "favorite": False}, "quantity": 1})
					attrs_e["items"] = new_items
					attrs_e["expiration"] = today_end
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "items", "attributeValue": new_items})
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "expiration", "attributeValue": today_end})

	elif cmd == "claimcollectionbookrewards":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		if payload.get("requiredXp") is not None:
			cb = attrs.setdefault("collection_book", {"maxBookXpLevelAchieved": 0})
			cb["maxBookXpLevelAchieved"] = int(cb.get("maxBookXpLevelAchieved", 0)) + 1
			changes.append({"changeType": "statModified", "name": "collection_book", "value": cb})

	elif cmd == "respecalteration":
		target_id = payload.get("targetItemId")
		alteration_id = payload.get("alterationId")
		alteration_slot = int(payload.get("alterationSlot", 0))
		if target_id and alteration_id and target_id in items:
			attrs_e = items[target_id].setdefault("attributes", {})
			if "alterations" not in attrs_e:
				attrs_e["alterations"] = ["", "", "", "", "", ""]
			alts = attrs_e["alterations"]
			if isinstance(alts, list) and alteration_slot < len(alts):
				alts[alteration_slot] = alteration_id
			changes.append({"changeType": "itemAttrChanged", "itemId": target_id, "attributeName": "alterations", "attributeValue": attrs_e["alterations"]})

	elif cmd == "upgradealteration":
		target_id = payload.get("targetItemId")
		alteration_slot = int(payload.get("alterationSlot", 0))
		if target_id and target_id in items:
			attrs_e = items[target_id].setdefault("attributes", {})
			alts = attrs_e.get("alterations", ["", "", "", "", "", ""])
			if isinstance(alts, list) and alteration_slot < len(alts):
				alt = alts[alteration_slot]
				for old, new in [("t04", "T05"), ("t03", "T04"), ("t02", "T03"), ("t01", "T02")]:
					if old in alt.lower():
						alts[alteration_slot] = re.sub(old, new, alt, flags=re.IGNORECASE)
						break
			attrs_e["alterations"] = alts
			changes.append({"changeType": "itemAttrChanged", "itemId": target_id, "attributeName": "alterations", "attributeValue": alts})

	elif cmd == "respecresearch":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		if "research_levels" in attrs:
			for stat in ("technology", "fortitude", "offense", "resistance"):
				attrs["research_levels"][stat] = 0
			changes.append({"changeType": "statModified", "name": "research_levels", "value": attrs["research_levels"]})

	elif cmd == "respecupgrades":
		for key, item_entry in items.items():
			if item_entry.get("templateId", "").lower().startswith("homebasenode:skilltree_"):
				item_entry["quantity"] = 0
				changes.append({"changeType": "itemQuantityChanged", "itemId": key, "quantity": 0})

	elif cmd == "purchaseresearchstatupgrade":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		stat_id = payload.get("statId")
		if "research_levels" in attrs and stat_id:
			attrs["research_levels"][stat_id] = int(attrs["research_levels"].get(stat_id, 0)) + 1
			changes.append({"changeType": "statModified", "name": "research_levels", "value": attrs["research_levels"]})

	elif cmd == "purchasehomebasenode":
		node_id = payload.get("nodeId")
		if node_id:
			created_new = True
			for key, item_entry in items.items():
				if item_entry.get("templateId", "").lower() == node_id.lower():
					item_entry["quantity"] = int(item_entry.get("quantity", 0)) + 1
					changes.append({"changeType": "itemQuantityChanged", "itemId": key, "quantity": item_entry["quantity"]})
					created_new = False
					break
			if created_new:
				new_id = str(uuid.uuid4())
				items[new_id] = {"templateId": node_id, "attributes": {"item_seen": False}, "quantity": 1}
				changes.append({"changeType": "itemAdded", "itemId": new_id, "item": items[new_id]})

	elif cmd == "purchaseorupgradehomebasenode":
		node_id = payload.get("nodeId")
		if node_id:
			created_new = True
			for key, item_entry in items.items():
				if item_entry.get("templateId", "").lower() == node_id.lower():
					item_entry["quantity"] = int(item_entry.get("quantity", 0)) + 1
					changes.append({"changeType": "itemQuantityChanged", "itemId": key, "quantity": item_entry["quantity"]})
					created_new = False
					break
			if created_new:
				new_id = str(uuid.uuid4())
				items[new_id] = {"templateId": node_id, "attributes": {"item_seen": False}, "quantity": 1}
				changes.append({"changeType": "itemAdded", "itemId": new_id, "item": items[new_id]})

	elif cmd == "assignteamperktoloadout":
		loadout_id = payload.get("loadoutId")
		perk_item_id = str(payload.get("teamPerkItemId", ""))
		if loadout_id and loadout_id in items:
			items[loadout_id].setdefault("attributes", {})["team_perk"] = perk_item_id
			changes.append({"changeType": "itemAttrChanged", "itemId": loadout_id, "attributeName": "team_perk", "attributeValue": perk_item_id})

	elif cmd == "assigngadgettoloadout":
		loadout_id = payload.get("loadoutId")
		gadget_id = str(payload.get("gadgetId", ""))
		slot_index = int(payload.get("slotIndex", 0))
		if loadout_id and loadout_id in items:
			gadgets = items[loadout_id].setdefault("attributes", {}).setdefault("gadgets", [{"gadget": "", "slot_index": 0}, {"gadget": "", "slot_index": 1}])
			other = 1 - slot_index
			if isinstance(gadgets, list) and len(gadgets) > other and gadgets[other].get("gadget", "").lower() == gadget_id.lower():
				gadgets[other]["gadget"] = gadgets[slot_index].get("gadget", "") if len(gadgets) > slot_index else ""
			if isinstance(gadgets, list) and len(gadgets) > slot_index:
				gadgets[slot_index]["gadget"] = gadget_id
			changes.append({"changeType": "itemAttrChanged", "itemId": loadout_id, "attributeName": "gadgets", "attributeValue": gadgets})

	elif cmd == "assignherotoloadout":
		loadout_id = payload.get("loadoutId")
		slot_name = str(payload.get("slotName", ""))
		hero_id = str(payload.get("heroId", ""))
		slot_map = {"CommanderSlot": "commanderslot", "FollowerSlot1": "followerslot1", "FollowerSlot2": "followerslot2", "FollowerSlot3": "followerslot3", "FollowerSlot4": "followerslot4", "FollowerSlot5": "followerslot5"}
		if loadout_id and loadout_id in items:
			crew = items[loadout_id].setdefault("attributes", {}).setdefault("crew_members", {"commanderslot": "", "followerslot1": "", "followerslot2": "", "followerslot3": "", "followerslot4": "", "followerslot5": ""})
			slot_key = slot_map.get(slot_name)
			if slot_key:
				for k in crew:
					if k != slot_key and crew[k].lower() == hero_id.lower():
						crew[k] = ""
				crew[slot_key] = hero_id
				changes.append({"changeType": "itemAttrChanged", "itemId": loadout_id, "attributeName": "crew_members", "attributeValue": crew})

	elif cmd == "clearheroloadout":
		loadout_id = payload.get("loadoutId")
		if loadout_id and loadout_id in items:
			attrs_e = items[loadout_id].setdefault("attributes", {})
			commander = attrs_e.get("crew_members", {}).get("commanderslot", "")
			attrs_e["team_perk"] = ""
			attrs_e["crew_members"] = {"followerslot5": "", "followerslot4": "", "followerslot3": "", "followerslot2": "", "followerslot1": "", "commanderslot": commander}
			attrs_e["gadgets"] = [{"gadget": "", "slot_index": 0}, {"gadget": "", "slot_index": 1}]
			changes.append({"changeType": "itemAttrChanged", "itemId": loadout_id, "attributeName": "team_perk", "attributeValue": ""})
			changes.append({"changeType": "itemAttrChanged", "itemId": loadout_id, "attributeName": "crew_members", "attributeValue": attrs_e["crew_members"]})
			changes.append({"changeType": "itemAttrChanged", "itemId": loadout_id, "attributeName": "gadgets", "attributeValue": attrs_e["gadgets"]})

	elif cmd == "assignworkertosquad":
		character_id = payload.get("characterId")
		squad_id_val = str(payload.get("squadId", ""))
		slot_index = int(payload.get("slotIndex", -1))
		if character_id:
			for key, item_entry in items.items():
				attrs_e = item_entry.get("attributes", {})
				if attrs_e.get("squad_id", "").lower() == squad_id_val.lower() and attrs_e.get("squad_slot_idx") == slot_index and key != character_id:
					attrs_e["squad_id"] = ""
					attrs_e["squad_slot_idx"] = -1
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "squad_id", "attributeValue": ""})
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "squad_slot_idx", "attributeValue": -1})
			if character_id in items:
				items[character_id].setdefault("attributes", {})["squad_id"] = squad_id_val
				items[character_id]["attributes"]["squad_slot_idx"] = slot_index
				changes.append({"changeType": "itemAttrChanged", "itemId": character_id, "attributeName": "squad_id", "attributeValue": squad_id_val})
				changes.append({"changeType": "itemAttrChanged", "itemId": character_id, "attributeName": "squad_slot_idx", "attributeValue": slot_index})

	elif cmd == "assignworkertosquadbatch":
		char_ids = payload.get("characterIds") or []
		sq_ids = payload.get("squadIds") or []
		sl_idxs = payload.get("slotIndices") or []
		for i, char_id in enumerate(char_ids):
			sq_id = sq_ids[i] if i < len(sq_ids) else ""
			sl_idx = sl_idxs[i] if i < len(sl_idxs) else -1
			for key, item_entry in items.items():
				attrs_e = item_entry.get("attributes", {})
				if attrs_e.get("squad_id", "").lower() == sq_id.lower() and attrs_e.get("squad_slot_idx") == sl_idx and key != char_id:
					attrs_e["squad_id"] = ""
					attrs_e["squad_slot_idx"] = -1
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "squad_id", "attributeValue": ""})
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "squad_slot_idx", "attributeValue": -1})
			if char_id in items:
				items[char_id].setdefault("attributes", {})["squad_id"] = sq_id
				items[char_id]["attributes"]["squad_slot_idx"] = sl_idx
				changes.append({"changeType": "itemAttrChanged", "itemId": char_id, "attributeName": "squad_id", "attributeValue": sq_id})
				changes.append({"changeType": "itemAttrChanged", "itemId": char_id, "attributeName": "squad_slot_idx", "attributeValue": sl_idx})

	elif cmd == "unassignallsquads":
		for sq_id in (payload.get("squadIds") or []):
			for key, item_entry in items.items():
				attrs_e = item_entry.get("attributes", {})
				if attrs_e.get("squad_id", "").lower() == sq_id.lower():
					attrs_e["squad_id"] = ""
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "squad_id", "attributeValue": ""})

	elif cmd == "destroyworlditems":
		for item_id in (payload.get("itemIds") or []):
			if item_id in items:
				del items[item_id]
				changes.append({"changeType": "itemRemoved", "itemId": item_id})

	elif cmd == "disassembleworlditems":
		for pair in (payload.get("targetItemIdAndQuantityPairs") or []):
			item_id = pair.get("itemId", "")
			qty = int(pair.get("quantity", 0))
			if item_id in items:
				orig_q = int(items[item_id].get("quantity", 0))
				if qty >= orig_q:
					del items[item_id]
					changes.append({"changeType": "itemRemoved", "itemId": item_id})
				else:
					items[item_id]["quantity"] = orig_q - qty
					changes.append({"changeType": "itemQuantityChanged", "itemId": item_id, "quantity": items[item_id]["quantity"]})

	elif cmd == "upgradeitem":
		target_id = payload.get("targetItemId")
		if target_id and target_id in items:
			desired = payload.get("desiredLevel")
			new_level = int(desired) if desired is not None else int(items[target_id].get("attributes", {}).get("level", 1)) + 1
			items[target_id].setdefault("attributes", {})["level"] = new_level
			changes.append({"changeType": "itemAttrChanged", "itemId": target_id, "attributeName": "level", "attributeValue": new_level})

	elif cmd == "upgradeitembulk":
		target_id = payload.get("targetItemId")
		desired = payload.get("desiredLevel")
		if target_id and target_id in items and desired is not None:
			new_level = int(desired)
			items[target_id].setdefault("attributes", {})["level"] = new_level
			changes.append({"changeType": "itemAttrChanged", "itemId": target_id, "attributeName": "level", "attributeValue": new_level})

	elif cmd == "upgradeslotteditem":
		target_id = payload.get("targetItemId")
		if target_id and target_id in items:
			desired = payload.get("desiredLevel")
			new_level = int(desired) if desired is not None else int(items[target_id].get("attributes", {}).get("level", 1)) + 1
			items[target_id].setdefault("attributes", {})["level"] = new_level
			changes.append({"changeType": "itemAttrChanged", "itemId": target_id, "attributeName": "level", "attributeValue": new_level})

	elif cmd == "upgradeitemrarity":
		target_id = payload.get("targetItemId")
		if target_id and target_id in items:
			template = items[target_id].get("templateId", "")
			parts = template.split(":", 1)
			if len(parts) == 2:
				sub_parts = parts[1].split("_")
				rarity_map = {"c": "UC", "uc": "R", "r": "VR", "vr": "SR"}
				for j, sp in enumerate(sub_parts):
					if sp.lower() in rarity_map:
						sub_parts[j] = rarity_map[sp.lower()]
						break
				items[target_id]["templateId"] = parts[0] + ":" + "_".join(sub_parts)
			items[target_id].setdefault("attributes", {})["level"] = 1
			changes.append({"changeType": "itemAttrChanged", "itemId": target_id, "attributeName": "level", "attributeValue": 1})

	elif cmd == "promoteitem":
		target_id = payload.get("targetItemId")
		if target_id and target_id in items:
			level = int(items[target_id].get("attributes", {}).get("level", 0))
			items[target_id].setdefault("attributes", {})["level"] = level + 2
			changes.append({"changeType": "itemAttrChanged", "itemId": target_id, "attributeName": "level", "attributeValue": items[target_id]["attributes"]["level"]})

	elif cmd == "convertitem":
		target_id = payload.get("targetItemId")
		if target_id and target_id in items:
			tmpl = items[target_id].get("templateId", "")
			for old, new in [("t04", "T05"), ("t03", "T04"), ("t02", "T03"), ("t01", "T02")]:
				if old in tmpl.lower():
					tmpl = re.sub(old, new, tmpl, flags=re.IGNORECASE)
					break
			items[target_id]["templateId"] = tmpl
			notifications.append({"type": "convertItemResult", "primary": True, "newItemId": target_id, "newTemplateId": tmpl})
			changes.append({"changeType": "itemAttrChanged", "itemId": target_id, "attributeName": "templateId", "attributeValue": tmpl})

	elif cmd == "convertslotteditem":
		target_id = payload.get("targetItemId")
		if target_id and target_id in items:
			tmpl = items[target_id].get("templateId", "")
			for old, new in [("t04", "T05"), ("t03", "T04")]:
				if old in tmpl.lower():
					tmpl = re.sub(old, new, tmpl, flags=re.IGNORECASE)
					break
			items[target_id]["templateId"] = tmpl
			notifications.append({"type": "convertItemResult", "primary": True, "newItemId": target_id, "newTemplateId": tmpl})
			changes.append({"changeType": "itemAttrChanged", "itemId": target_id, "attributeName": "templateId", "attributeValue": tmpl})

	elif cmd == "redeemresearchtoken":
		if payload.get("index") is not None:
			token_id = next((k for k, v in items.items() if v.get("templateId", "").lower() == "token:campaignresearchtoken"), None)
			if token_id:
				items[token_id]["quantity"] = int(items[token_id].get("quantity", 0)) - 1
				if items[token_id]["quantity"] <= 0:
					del items[token_id]
					changes.append({"changeType": "itemRemoved", "itemId": token_id})
				else:
					changes.append({"changeType": "itemQuantityChanged", "itemId": token_id, "quantity": items[token_id]["quantity"]})

	elif cmd == "activateconsumable":
		target_id = payload.get("targetItemId")
		if target_id and target_id in items:
			items[target_id]["quantity"] = int(items[target_id].get("quantity", 1)) - 1
			changes.append({"changeType": "itemQuantityChanged", "itemId": target_id, "quantity": items[target_id]["quantity"]})
			xp_key = next((k for k, v in items.items() if v.get("templateId", "").lower() == "token:xpboost"), None)
			if xp_key:
				boost = random.randint(1000000, 2250000)
				items[xp_key]["quantity"] = int(items[xp_key].get("quantity", 0)) + boost
				changes.append({"changeType": "itemQuantityChanged", "itemId": xp_key, "quantity": items[xp_key]["quantity"]})

	elif cmd == "refunditem":
		target_id = payload.get("targetItemId")
		if target_id and target_id in items:
			del items[target_id]
			changes.append({"changeType": "itemRemoved", "itemId": target_id})

	elif cmd == "fortrerolldailyquest":
		quest_id = payload.get("questId")
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		quest_manager = attrs.get("quest_manager", {})
		daily_rerolls = int(quest_manager.get("dailyQuestRerolls", 0)) if quest_manager else 0
		if quest_id and daily_rerolls >= 1 and quest_id in items:
			quests_path = (RESPONSES_DIR / "Campaign" / "quests.json") if profile_id in ("profile0", "campaign") else (RESPONSES_DIR / "Athena" / "quests.json")
			daily_list = load_json(quests_path, {}).get("Daily", [])
			del items[quest_id]
			changes.append({"changeType": "itemRemoved", "itemId": quest_id})
			existing_tmpls = {v.get("templateId", "").lower() for v in items.values()}
			candidates = [q for q in daily_list if q.get("templateId", "").lower() not in existing_tmpls] or daily_list
			if candidates:
				chosen = random.choice(candidates)
				new_id = str(uuid.uuid4())
				new_q: dict[str, Any] = {"templateId": chosen["templateId"], "attributes": {"creation_time": utc_now_iso(), "level": -1, "item_seen": False, "sent_new_notification": False, "xp_reward_scalar": 1, "quest_state": "Active", "last_state_change_time": utc_now_iso(), "max_level_bonus": 0, "xp": 0, "favorite": False}, "quantity": 1}
				for obj in chosen.get("objectives", []):
					new_q["attributes"][f"completion_{obj.lower()}"] = 0
				items[new_id] = new_q
				quest_manager["dailyQuestRerolls"] = daily_rerolls - 1
				quest_manager["dailyLoginInterval"] = utc_now_iso()
				changes.append({"changeType": "itemAdded", "itemId": new_id, "item": new_q})
				changes.append({"changeType": "statModified", "name": "quest_manager", "value": quest_manager})
				notifications.append({"type": "dailyQuestReroll", "primary": True, "newQuestId": chosen["templateId"]})

	elif cmd == "updatequestclientobjectives":
		for adv in (payload.get("advance") or []):
			stat_name = adv.get("statName", "").lower()
			count = int(adv.get("count", 0))
			attr_key = f"completion_{stat_name}"
			for key, item_entry in items.items():
				item_attrs = item_entry.get("attributes", {})
				if attr_key in item_attrs:
					item_attrs[attr_key] = count
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": attr_key, "attributeValue": count})
					if item_attrs.get("quest_state", "").lower() != "claimed":
						all_done = all(item_attrs.get(k, 0) != 0 for k in item_attrs if k.startswith("completion_"))
						if all_done:
							item_attrs["quest_state"] = "Claimed"
							changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "quest_state", "attributeValue": "Claimed"})

	elif cmd == "researchitemfromcollectionbook":
		tmpl = payload.get("templateId")
		if tmpl:
			new_id = str(uuid.uuid4())
			items[new_id] = {"templateId": tmpl, "attributes": {"legacy_alterations": [], "max_level_bonus": 0, "level": 1, "refund_legacy_item": False, "item_seen": False, "alterations": ["", "", "", "", "", ""], "xp": 0, "refundable": False, "alteration_base_rarities": [], "favorite": False}, "quantity": 1}
			changes.append({"changeType": "itemAdded", "itemId": new_id, "item": items[new_id]})

	elif cmd == "slotitemincollectionbook":
		target_id = payload.get("slotItemId")
		section_id = str(payload.get("sectionId", ""))
		cb_profile_id = "collection_book_people0"
		cb_profile = load_profile(cb_profile_id, account_id)
		cb_items = cb_profile.setdefault("items", {})
		cb_base = int(cb_profile.get("rvn", 1))
		cb_changes: list[dict[str, Any]] = []
		if target_id and target_id in items:
			item_entry = items[target_id]
			cb_items[target_id] = deepcopy(item_entry)
			del items[target_id]
			changes.append({"changeType": "itemRemoved", "itemId": target_id})
			cb_changes.append({"changeType": "itemAdded", "itemId": target_id, "item": cb_items[target_id]})
		if cb_changes:
			cb_profile["rvn"] = cb_base + 1
			cb_profile["commandRevision"] = int(cb_profile.get("commandRevision", cb_base)) + 1
			cb_profile["updated"] = utc_now_iso()
			save_profile(cb_profile_id, cb_profile)
		multi_update.append({"profileRevision": int(cb_profile.get("rvn", 1)), "profileId": cb_profile_id, "profileChangesBaseRevision": cb_base, "profileChanges": cb_changes, "profileCommandRevision": int(cb_profile.get("commandRevision", 1))})

	elif cmd == "unslotitemfromcollectionbook":
		target_id = payload.get("itemId")
		cb_profile_id = "collection_book_people0"
		cb_profile = load_profile(cb_profile_id, account_id)
		cb_items = cb_profile.setdefault("items", {})
		cb_base = int(cb_profile.get("rvn", 1))
		cb_changes2: list[dict[str, Any]] = []
		if target_id and target_id in cb_items:
			items[target_id] = deepcopy(cb_items[target_id])
			del cb_items[target_id]
			changes.append({"changeType": "itemAdded", "itemId": target_id, "item": items[target_id]})
			cb_changes2.append({"changeType": "itemRemoved", "itemId": target_id})
		if cb_changes2:
			cb_profile["rvn"] = cb_base + 1
			cb_profile["commandRevision"] = int(cb_profile.get("commandRevision", cb_base)) + 1
			cb_profile["updated"] = utc_now_iso()
			save_profile(cb_profile_id, cb_profile)
		multi_update.append({"profileRevision": int(cb_profile.get("rvn", 1)), "profileId": cb_profile_id, "profileChangesBaseRevision": cb_base, "profileChanges": cb_changes2, "profileCommandRevision": int(cb_profile.get("commandRevision", 1))})

	elif cmd == "recycleitembatch":
		memory = parse_version_info(request)
		for tid in (payload.get("targetItemIds") or []):
			if tid not in items:
				continue
			if memory["season"] > 11 or memory["build"] in (11.30, 11.31, 11.40):
				cb_pid = "collection_book_people0"
				cb_p = load_profile(cb_pid, account_id)
				cb_i = cb_p.setdefault("items", {})
				if tid in cb_i:
					del cb_i[tid]
					cb_p["rvn"] = int(cb_p.get("rvn", 1)) + 1
					cb_p["commandRevision"] = int(cb_p.get("commandRevision", 1)) + 1
					cb_p["updated"] = utc_now_iso()
					save_profile(cb_pid, cb_p)
			else:
				del items[tid]
				changes.append({"changeType": "itemRemoved", "itemId": tid})

	elif cmd == "transmogitem":
		transform_ids_data = load_json(RESPONSES_DIR / "Campaign" / "transformItemIDS.json", {})
		card_pack_data = load_json(RESPONSES_DIR / "Campaign" / "cardPackData.json", {})
		sacrifice_ids = payload.get("sacrificeItemIds") or []
		transmog_key = str(payload.get("transmogKeyTemplateId", ""))
		if sacrifice_ids and transmog_key:
			for sid in sacrifice_ids:
				if sid in items:
					del items[sid]
					changes.append({"changeType": "itemRemoved", "itemId": sid})
			candidates = transform_ids_data.get(transmog_key, card_pack_data.get("default", []))
			if candidates:
				new_tid = str(uuid.uuid4())
				chosen_tmpl = random.choice(candidates) if isinstance(candidates, list) else list(candidates.values())[0]
				if isinstance(chosen_tmpl, dict):
					chosen_tmpl = chosen_tmpl.get("templateId", "")
				items[new_tid] = {"templateId": chosen_tmpl, "attributes": {"legacy_alterations": [], "max_level_bonus": 0, "level": 1, "refund_legacy_item": False, "item_seen": False, "alterations": ["", "", "", "", "", ""], "xp": 0, "refundable": False, "alteration_base_rarities": [], "favorite": False}, "quantity": 1}
				changes.append({"changeType": "itemAdded", "itemId": new_tid, "item": items[new_tid]})
				notifications.append({"type": "transmog", "primary": True, "lootResult": {"items": [{"itemType": chosen_tmpl, "itemGuid": new_tid, "itemProfile": profile_id, "attributes": items[new_tid]["attributes"], "quantity": 1}]}})

	elif cmd == "opencardpack":
		card_pack_item_id = payload.get("cardPackItemId")
		card_pack_data = load_json(RESPONSES_DIR / "Campaign" / "cardPackData.json", {})
		if card_pack_item_id and card_pack_item_id in items:
			pack_tmpl = items[card_pack_item_id].get("templateId", "")
			pack_key = pack_tmpl.split(":", 1)[-1].lower() if ":" in pack_tmpl else pack_tmpl.lower()
			items_pool = card_pack_data.get(pack_key, card_pack_data.get("default", []))
			notifications.append({"type": "cardPackResult", "primary": True, "lootGranted": {"tierGroupName": pack_key, "items": []}, "displayLevel": 0})
			for _ in range(6):
				if not items_pool:
					break
				new_id = str(uuid.uuid4())
				chosen = random.choice(items_pool)
				tmpl_val = chosen if isinstance(chosen, str) else chosen.get("templateId", "")
				item_obj: dict[str, Any] = {"templateId": tmpl_val, "attributes": {"legacy_alterations": [], "max_level_bonus": 0, "level": 1, "refund_legacy_item": False, "item_seen": False, "alterations": ["", "", "", "", "", ""], "xp": 0, "refundable": False, "alteration_base_rarities": [], "favorite": False}, "quantity": 1}
				items[new_id] = item_obj
				changes.append({"changeType": "itemAdded", "itemId": new_id, "item": item_obj})
				notifications[0]["lootGranted"]["items"].append({"itemType": tmpl_val, "itemGuid": new_id, "itemProfile": profile_id, "attributes": item_obj["attributes"], "quantity": 1})
			if int(items[card_pack_item_id].get("quantity", 1)) <= 1:
				del items[card_pack_item_id]
				changes.append({"changeType": "itemRemoved", "itemId": card_pack_item_id})
			else:
				items[card_pack_item_id]["quantity"] = int(items[card_pack_item_id].get("quantity", 1)) - 1
				changes.append({"changeType": "itemQuantityChanged", "itemId": card_pack_item_id, "quantity": items[card_pack_item_id]["quantity"]})

	elif cmd == "claimloginreward":
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		daily_rewards_data = load_json(RESPONSES_DIR / "Campaign" / "dailyRewards.json", [])
		memory = parse_version_info(request)
		date_format = utc_now_iso().split("T")[0] + "T00:00:00.000Z"
		dr = attrs.setdefault("daily_rewards", {"lastClaimDate": "", "nextDefaultReward": 0, "totalDaysLoggedIn": 0, "additionalSchedules": {"founderspackdailyrewardtoken": {"rewardsClaimed": 0, "bonusRewardsClaimed": 0}}})
		if dr.get("lastClaimDate") != date_format:
			dr["nextDefaultReward"] = int(dr.get("nextDefaultReward", 0)) + 1
			dr["totalDaysLoggedIn"] = int(dr.get("totalDaysLoggedIn", 0)) + 1
			dr["lastClaimDate"] = date_format
			dr.setdefault("additionalSchedules", {}).setdefault("founderspackdailyrewardtoken", {"rewardsClaimed": 0, "bonusRewardsClaimed": 0})["rewardsClaimed"] = int(dr.get("additionalSchedules", {}).get("founderspackdailyrewardtoken", {}).get("rewardsClaimed", 0)) + 1
			changes.append({"changeType": "statModified", "name": "daily_rewards", "value": dr})
			if memory["season"] < 7 and daily_rewards_data:
				day = int(dr.get("totalDaysLoggedIn", 0)) % max(len(daily_rewards_data), 1)
				reward = daily_rewards_data[day] if day < len(daily_rewards_data) else None
				if reward:
					notifications.append({"type": "daily_rewards", "primary": True, "daysLoggedIn": dr["totalDaysLoggedIn"], "items": [reward]})

	elif cmd == "clientquestlogin":
		memory = parse_version_info(request)
		season = memory["season"]
		season_prefix = f"0{season}" if season < 10 else str(season)
		attrs = profile.setdefault("stats", {}).setdefault("attributes", {})
		is_campaign = profile_id in ("profile0", "campaign")
		quests_path = (RESPONSES_DIR / "Campaign" / "quests.json") if is_campaign else (RESPONSES_DIR / "Athena" / "quests.json")
		quests_data_all = load_json(quests_path, {})
		daily_list = quests_data_all.get("Daily", [])
		season_quests = quests_data_all.get(f"Season{season_prefix}") or quests_data_all.get(f"Season{season}")
		quest_count = 0
		date_format = utc_now_iso().split("T")[0]
		should_give_quest = True
		# Count existing daily quests
		for item_entry in items.values():
			tmpl_lower = item_entry.get("templateId", "").lower()
			if is_campaign and tmpl_lower.startswith("quest:daily"):
				quest_count += 1
			elif not is_campaign and tmpl_lower.startswith("quest:athenadaily"):
				quest_count += 1
		# Grant founders pack quests if configured
		if is_campaign and config_bool("Profile", "bGrantFoundersPacks", False):
			founders_quests = ["Quest:foundersquest_getrewards_0_1", "Quest:foundersquest_getrewards_1_2", "Quest:foundersquest_getrewards_2_3", "Quest:foundersquest_getrewards_3_4", "Quest:foundersquest_chooseherobundle", "Quest:foundersquest_getrewards_4_5", "Quest:foundersquest_herobundle_nochoice"]
			existing = {v.get("templateId", "").lower() for v in items.values()}
			for fq in founders_quests:
				if fq.lower() not in existing:
					fq_id = str(uuid.uuid4())
					fq_item: dict[str, Any] = {"templateId": fq, "attributes": {"creation_time": "min", "quest_state": "Completed", "last_state_change_time": utc_now_iso(), "level": -1, "sent_new_notification": True, "xp_reward_scalar": 1}, "quantity": 1}
					items[fq_id] = fq_item
					changes.append({"changeType": "itemAdded", "itemId": fq_id, "item": fq_item})
		# Check daily login interval
		qm = attrs.get("quest_manager", {})
		if isinstance(qm, dict) and "dailyLoginInterval" in qm:
			daily_login_val = qm["dailyLoginInterval"]
			if isinstance(daily_login_val, str) and "T" in daily_login_val:
				login_date = daily_login_val.split("T")[0]
				if login_date == date_format:
					should_give_quest = False
				else:
					should_give_quest = True
					if int(qm.get("dailyQuestRerolls", 1)) <= 0:
						qm["dailyQuestRerolls"] = int(qm.get("dailyQuestRerolls", 0)) + 1
		# Grant daily quests
		if quest_count < 3 and should_give_quest and daily_list:
			existing_tmpls2 = {v.get("templateId", "").lower() for v in items.values()}
			candidates2 = [q for q in daily_list if q.get("templateId", "").lower() not in existing_tmpls2] or daily_list
			chosen2 = random.choice(candidates2)
			new_q_id = str(uuid.uuid4())
			new_q2: dict[str, Any] = {"templateId": chosen2["templateId"], "attributes": {"creation_time": utc_now_iso(), "level": -1, "item_seen": False, "sent_new_notification": False, "xp_reward_scalar": 1, "quest_state": "Active", "last_state_change_time": utc_now_iso(), "max_level_bonus": 0, "xp": 0, "favorite": False}, "quantity": 1}
			for obj in chosen2.get("objectives", []):
				new_q2["attributes"][f"completion_{obj.lower()}"] = 0
			if isinstance(qm, dict):
				qm["dailyLoginInterval"] = utc_now_iso()
			items[new_q_id] = new_q2
			changes.append({"changeType": "itemAdded", "itemId": new_q_id, "item": new_q2})
			changes.append({"changeType": "statModified", "name": "quest_manager", "value": qm})
		# Grant seasonal quests
		if season_quests and isinstance(season_quests, dict):
			complete_seasonal = config_bool("Profile", "bCompletedSeasonalQuests", False)
			quests_to_add: list[Any] = []
			bundles = season_quests.get("ChallengeBundles", {})
			for bundle_id, bundle_data in bundles.items():
				existing_in = bundle_id in items
				if existing_in:
					del items[bundle_id]
					changes.append({"changeType": "itemRemoved", "itemId": bundle_id})
				granted = list(bundle_data.get("grantedquestinstanceids", []))
				if complete_seasonal and "questStages" in bundle_data:
					granted = granted + list(bundle_data["questStages"])
				bundle_item: dict[str, Any] = {"templateId": bundle_data.get("templateId", bundle_id), "attributes": {"has_unlock_by_completion": False, "num_quests_completed": 0, "level": 0, "grantedquestinstanceids": granted, "item_seen": True, "max_allowed_bundle_level": 0, "num_granted_bundle_quests": len(granted), "max_level_bonus": 0, "challenge_bundle_schedule_id": bundle_data.get("challenge_bundle_schedule_id", ""), "num_progress_quests_completed": 0, "xp": 0, "favorite": False}, "quantity": 1}
				if complete_seasonal:
					bundle_item["attributes"]["num_quests_completed"] = len(granted)
					bundle_item["attributes"]["num_progress_quests_completed"] = len(granted)
				items[bundle_id] = bundle_item
				changes.append({"changeType": "itemAdded", "itemId": bundle_id, "item": bundle_item})
				quests_to_add.extend(granted)
			season_quests_map = season_quests.get("Quests", {})
			def grant_quest_recursive(quest_key: str) -> None:
				if quest_key in items:
					return
				q_data = season_quests_map.get(quest_key)
				if not q_data:
					return
				q_item: dict[str, Any] = {"templateId": q_data.get("templateId", quest_key), "attributes": {"creation_time": utc_now_iso(), "level": -1, "item_seen": False, "sent_new_notification": True, "challenge_bundle_id": q_data.get("challenge_bundle_id", ""), "xp_reward_scalar": 1, "quest_state": "Active", "last_state_change_time": utc_now_iso(), "max_level_bonus": 0, "xp": 0, "favorite": False}, "quantity": 1}
				if complete_seasonal:
					q_item["attributes"]["quest_state"] = "Claimed"
				for obj_key, obj_val in q_data.get("objectives", {}).items():
					q_item["attributes"][f"completion_{obj_key}"] = obj_val if complete_seasonal else 0
				items[quest_key] = q_item
				changes.append({"changeType": "itemAdded", "itemId": quest_key, "item": q_item})
				if complete_seasonal:
					for reward in q_data.get("rewards", {}).values():
						if isinstance(reward, dict) and str(reward.get("templateId", "")).startswith("Quest:"):
							nested = reward.get("templateId", "")
							for qkey2, qdata2 in season_quests_map.items():
								if qdata2.get("templateId", "") == nested:
									grant_quest_recursive(qkey2)
			for qk in quests_to_add:
				grant_quest_recursive(qk)

	elif cmd == "claimquestreward":
		quest_id = payload.get("questId")
		selected_reward_idx = payload.get("selectedRewardIndex", -1)
		rewards_data = load_json(RESPONSES_DIR / "Campaign" / "rewards.json", {}).get("quest", {})
		theater0_profile = load_profile("theater0", account_id)
		t0_base = int(theater0_profile.get("rvn", 1))
		t0_changes: list[dict[str, Any]] = []
		cc_profile: dict[str, Any] | None = None
		cc_base = 0
		cc_changes: list[dict[str, Any]] = []
		notifications.append({"type": "questClaim", "primary": True, "questId": "", "loot": {"items": []}})
		t0_items = theater0_profile.setdefault("items", {})
		if profile_id == "campaign":
			cc_profile = load_profile("common_core", account_id)
			cc_base = int(cc_profile.get("rvn", 1))
		if quest_id:
			tmpl_of_quest = ""
			for key, item_entry in items.items():
				if key.lower() == quest_id.lower():
					tmpl_of_quest = item_entry.get("templateId", "").lower()
					break
			notifications[0]["questId"] = tmpl_of_quest
			reward_entry = rewards_data.get(tmpl_of_quest, {})
			if reward_entry:
				if selected_reward_idx != -1 and reward_entry.get("selectableRewards"):
					rewards_list = reward_entry["selectableRewards"][int(selected_reward_idx)]["rewards"] if int(selected_reward_idx) < len(reward_entry["selectableRewards"]) else []
				else:
					rewards_list = reward_entry.get("rewards", [])
				for reward in rewards_list:
					r_tmpl = reward.get("templateId", "")
					r_qty = int(reward.get("quantity", 1))
					new_rid = str(uuid.uuid4())
					if r_tmpl.lower().startswith(("weapon:", "trap:", "ammo:")):
						r_item: dict[str, Any] = {"templateId": r_tmpl, "attributes": {"clipSizeScale": 0, "loadedAmmo": 999, "level": 1, "alterationDefinitions": [], "baseClipSize": 999, "durability": 375, "itemSource": "", "item_seen": False}, "quantity": r_qty}
						t0_items[new_rid] = r_item
						t0_changes.append({"changeType": "itemAdded", "itemId": new_rid, "item": r_item})
						notifications[0]["loot"]["items"].append({"itemType": r_tmpl, "itemGuid": new_rid, "itemProfile": "theater0", "quantity": r_qty})
					elif profile_id == "campaign" and cc_profile is not None and (r_tmpl.lower().startswith("homebasebannericon:") or r_tmpl.lower() == "token:founderchatunlock"):
						r_item2: dict[str, Any] = {"templateId": r_tmpl, "attributes": {"max_level_bonus": 0, "level": 1, "item_seen": False, "xp": 0, "favorite": False}, "quantity": r_qty}
						cc_profile.setdefault("items", {})[new_rid] = r_item2
						cc_changes.append({"changeType": "itemAdded", "itemId": new_rid, "item": r_item2})
						notifications[0]["loot"]["items"].append({"itemType": r_tmpl, "itemGuid": new_rid, "itemProfile": "common_core", "quantity": r_qty})
					else:
						r_item3: dict[str, Any] = {"templateId": r_tmpl, "attributes": {"legacy_alterations": [], "max_level_bonus": 0, "level": 1, "refund_legacy_item": False, "item_seen": False, "alterations": ["", "", "", "", "", ""], "xp": 0, "refundable": False, "alteration_base_rarities": [], "favorite": False}, "quantity": r_qty}
						if r_tmpl.lower().startswith("quest:"):
							r_item3["attributes"]["quest_state"] = "Active"
						items[new_rid] = r_item3
						changes.append({"changeType": "itemAdded", "itemId": new_rid, "item": r_item3})
						notifications[0]["loot"]["items"].append({"itemType": r_tmpl, "itemGuid": new_rid, "itemProfile": profile_id, "quantity": r_qty})
			if quest_id in items:
				items[quest_id].setdefault("attributes", {})["quest_state"] = "Claimed"
				items[quest_id]["attributes"]["last_state_change_time"] = utc_now_iso()
				changes.append({"changeType": "itemAttrChanged", "itemId": quest_id, "attributeName": "quest_state", "attributeValue": "Claimed"})
				changes.append({"changeType": "itemAttrChanged", "itemId": quest_id, "attributeName": "last_state_change_time", "attributeValue": items[quest_id]["attributes"]["last_state_change_time"]})
		if t0_changes:
			theater0_profile["rvn"] = t0_base + 1
			theater0_profile["commandRevision"] = int(theater0_profile.get("commandRevision", t0_base)) + 1
			theater0_profile["updated"] = utc_now_iso()
			save_profile("theater0", theater0_profile)
		multi_update.append({"profileRevision": int(theater0_profile.get("rvn", 1)), "profileId": "theater0", "profileChangesBaseRevision": t0_base, "profileChanges": t0_changes, "profileCommandRevision": int(theater0_profile.get("commandRevision", 1))})
		if cc_profile is not None and cc_changes:
			cc_profile["rvn"] = cc_base + 1
			cc_profile["commandRevision"] = int(cc_profile.get("commandRevision", cc_base)) + 1
			cc_profile["updated"] = utc_now_iso()
			save_profile("common_core", cc_profile)
			multi_update.append({"profileRevision": int(cc_profile.get("rvn", 1)), "profileId": "common_core", "profileChangesBaseRevision": cc_base, "profileChanges": cc_changes, "profileCommandRevision": int(cc_profile.get("commandRevision", 1))})

	elif cmd == "refreshexpeditions":
		exp_data = load_json(RESPONSES_DIR / "Campaign" / "expeditionData.json", {})
		quests_unlocking = exp_data.get("questsUnlockingSlots", [])
		slots_from_quests = exp_data.get("slotsFromQuests", {})
		expedition_slots: list[str] = []
		now_ts = utc_now_iso()
		# Determine available slots from completed quests
		for key, item_entry in items.items():
			tmpl_lower = item_entry.get("templateId", "").lower()
			if tmpl_lower in quests_unlocking and item_entry.get("attributes", {}).get("quest_state") == "Claimed":
				expedition_slots.extend(slots_from_quests.get(tmpl_lower, []))
		# Remove expired expeditions, keep active ones and remove their slot
		to_delete = []
		for key, item_entry in items.items():
			if not item_entry.get("templateId", "").lower().startswith("expedition:"):
				continue
			attrs_e = item_entry.get("attributes", {})
			exp_end = attrs_e.get("expedition_expiration_end_time", "")
			if now_ts > exp_end and "expedition_start_time" not in attrs_e:
				to_delete.append(key)
				changes.append({"changeType": "itemRemoved", "itemId": key})
			else:
				slot_id = attrs_e.get("expedition_slot_id", "")
				if slot_id in expedition_slots:
					expedition_slots.remove(slot_id)
		for key in to_delete:
			del items[key]
		# Create new expeditions for open slots
		exp_slots_data = exp_data.get("slots", {})
		exp_attrs_data = exp_data.get("attributes", {})
		exp_criteria = exp_data.get("criteria", [])
		for slot in expedition_slots:
			slot_opts = exp_slots_data.get(slot, {})
			pool = slot_opts.get("rare", []) if slot_opts.get("rare") and random.random() < 0.05 else slot_opts.get("normal", [])
			if not pool:
				continue
			tmpl_chosen = random.choice(pool)
			new_eid = str(uuid.uuid4())
			exp_meta = exp_attrs_data.get(tmpl_chosen, {})
			exp_min = exp_end_dt = utc_now_iso()
			exp_end_dt2 = datetime.now(timezone.utc) + timedelta(minutes=int(exp_meta.get("expiration_duration_minutes", 60)))
			exp_end_str = utc_iso_from_dt(exp_end_dt2)
			exp_criteria_list = [random.choice(exp_criteria) for _ in range(3) if exp_criteria and random.random() < 0.2]
			exp_item: dict[str, Any] = {"templateId": tmpl_chosen, "attributes": {"expedition_expiration_end_time": exp_end_str, "expedition_criteria": exp_criteria_list, "level": 1, "expedition_max_target_power": exp_meta.get("expedition_max_target_power", 0), "expedition_min_target_power": exp_meta.get("expedition_min_target_power", 0), "expedition_slot_id": slot, "expedition_expiration_start_time": now_ts}, "quantity": 1}
			items[new_eid] = exp_item
			changes.append({"changeType": "itemAdded", "itemId": new_eid, "item": exp_item})

	elif cmd == "startexpedition":
		exp_id = payload.get("expeditionId")
		squad_id_exp = payload.get("squadId", "")
		item_ids_exp = payload.get("itemIds") or []
		slot_indices_exp = payload.get("slotIndices") or []
		exp_data2 = load_json(RESPONSES_DIR / "Campaign" / "expeditionData.json", {})
		item_rating_data = load_json(RESPONSES_DIR / "Campaign" / "itemRatingData.json", {})
		if exp_id and exp_id in items:
			now_ts2 = utc_now_iso()
			exp_attrs2 = items[exp_id].setdefault("attributes", {})
			exp_tmpl = items[exp_id].get("templateId", "")
			exp_meta2 = exp_data2.get("attributes", {}).get(exp_tmpl, {})
			# Assign heroes to squad
			for i, hero in enumerate(item_ids_exp):
				if hero in items:
					sl = slot_indices_exp[i] if i < len(slot_indices_exp) else i
					items[hero].setdefault("attributes", {})["squad_id"] = squad_id_exp.lower()
					items[hero]["attributes"]["squad_slot_idx"] = sl
					changes.append({"changeType": "itemAttrChanged", "itemId": hero, "attributeName": "squad_id", "attributeValue": squad_id_exp.lower()})
					changes.append({"changeType": "itemAttrChanged", "itemId": hero, "attributeName": "squad_slot_idx", "attributeValue": sl})
			exp_end_dt3 = datetime.now(timezone.utc) + timedelta(minutes=int(exp_meta2.get("expedition_duration_minutes", 60)))
			exp_end_str2 = utc_iso_from_dt(exp_end_dt3)
			exp_attrs2["expedition_squad_id"] = squad_id_exp.lower()
			exp_attrs2["expedition_success_chance"] = 0.7
			exp_attrs2["expedition_start_time"] = now_ts2
			exp_attrs2["expedition_end_time"] = exp_end_str2
			for attr_name in ("expedition_squad_id", "expedition_success_chance", "expedition_start_time", "expedition_end_time"):
				changes.append({"changeType": "itemAttrChanged", "itemId": exp_id, "attributeName": attr_name, "attributeValue": exp_attrs2[attr_name]})

	elif cmd == "abandonexpedition":
		exp_id = payload.get("expeditionId")
		exp_data3 = load_json(RESPONSES_DIR / "Campaign" / "expeditionData.json", {})
		if exp_id and exp_id in items:
			squad_id_ab = items[exp_id].get("attributes", {}).get("expedition_squad_id", "")
			for key, item_entry in items.items():
				attrs_e = item_entry.get("attributes", {})
				if attrs_e.get("squad_id", "") == squad_id_ab and squad_id_ab:
					attrs_e["squad_id"] = ""
					attrs_e["squad_slot_idx"] = -1
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "squad_id", "attributeValue": ""})
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "squad_slot_idx", "attributeValue": -1})
			# Reset expedition attrs
			for attr_name in ("expedition_squad_id", "expedition_start_time", "expedition_end_time"):
				items[exp_id]["attributes"].pop(attr_name, None)
			changes.append({"changeType": "itemAttrChanged", "itemId": exp_id, "attributeName": "expedition_squad_id", "attributeValue": ""})
			changes.append({"changeType": "itemAttrChanged", "itemId": exp_id, "attributeName": "expedition_start_time", "attributeValue": None})
			changes.append({"changeType": "itemAttrChanged", "itemId": exp_id, "attributeName": "expedition_end_time", "attributeValue": None})

	elif cmd == "collectexpedition":
		exp_id = payload.get("expeditionId")
		exp_data4 = load_json(RESPONSES_DIR / "Campaign" / "expeditionData.json", {})
		if exp_id and exp_id in items:
			exp_attrs4 = items[exp_id].get("attributes", {})
			success_chance = float(exp_attrs4.get("expedition_success_chance", 0.7))
			succeeded = random.random() < success_chance
			notifications.append({"type": "expeditionResult", "primary": True, "client_request_id": "", "bExpeditionSucceeded": succeeded})
			if succeeded:
				notifications[0]["expeditionRewards"] = []
				for reward_pool in exp_data4.get("rewards", []):
					new_eid2 = str(uuid.uuid4())
					chosen_r = random.choice(reward_pool) if reward_pool else None
					if chosen_r:
						r_tmpl2 = chosen_r.get("templateId", "")
						r_qty2 = random.randint(int(chosen_r.get("minQuantity", 1)), int(chosen_r.get("maxQuantity", 1)))
						r_profile = chosen_r.get("itemProfile", profile_id)
						r_item4: dict[str, Any] = {"templateId": r_tmpl2, "attributes": {"loadedAmmo": 0, "inventory_overflow_date": False, "level": 0, "alterationDefinitions": [], "durability": 1, "itemSource": ""}, "quantity": r_qty2}
						items[new_eid2] = r_item4
						changes.append({"changeType": "itemAdded", "itemId": new_eid2, "item": r_item4})
						notifications[0]["expeditionRewards"].append({"itemType": r_tmpl2, "itemGuid": new_eid2, "itemProfile": r_profile, "quantity": r_qty2})
			# Release heroes from squad
			squad_id_coll = exp_attrs4.get("expedition_squad_id", "")
			for key, item_entry in items.items():
				attrs_e2 = item_entry.get("attributes", {})
				if attrs_e2.get("squad_id", "") == squad_id_coll and squad_id_coll:
					attrs_e2["squad_id"] = ""
					attrs_e2["squad_slot_idx"] = -1
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "squad_id", "attributeValue": ""})
					changes.append({"changeType": "itemAttrChanged", "itemId": key, "attributeName": "squad_slot_idx", "attributeValue": -1})
			# Replace the expedition with a new one
			slot_id2 = exp_attrs4.get("expedition_slot_id", "")
			del items[exp_id]
			changes.append({"changeType": "itemRemoved", "itemId": exp_id})
			exp_slots_data2 = exp_data4.get("slots", {})
			exp_attrs_data2 = exp_data4.get("attributes", {})
			if slot_id2 and slot_id2 in exp_slots_data2:
				slot_opts2 = exp_slots_data2[slot_id2]
				pool2 = slot_opts2.get("rare", []) if slot_opts2.get("rare") and random.random() < 0.05 else slot_opts2.get("normal", [])
				if pool2:
					new_exp_id = str(uuid.uuid4())
					new_tmpl2 = random.choice(pool2)
					new_meta2 = exp_attrs_data2.get(new_tmpl2, {})
					new_end2 = utc_iso_from_dt(datetime.now(timezone.utc) + timedelta(minutes=int(new_meta2.get("expiration_duration_minutes", 60))))
					new_exp_item2: dict[str, Any] = {"templateId": new_tmpl2, "attributes": {"expedition_expiration_end_time": new_end2, "expedition_criteria": [], "level": 1, "expedition_max_target_power": new_meta2.get("expedition_max_target_power", 0), "expedition_min_target_power": new_meta2.get("expedition_min_target_power", 0), "expedition_slot_id": slot_id2, "expedition_expiration_start_time": utc_now_iso()}, "quantity": 1}
					items[new_exp_id] = new_exp_item2
					changes.append({"changeType": "itemAdded", "itemId": new_exp_id, "item": new_exp_item2})

	elif cmd == "storagetransfer":
		outpost_profile = load_profile("outpost0", account_id)
		op_base = int(outpost_profile.get("rvn", 1))
		op_changes: list[dict[str, Any]] = []
		op_items = outpost_profile.setdefault("items", {})
		transfer_ops = payload.get("transferOperations") or []
		theater_to_outpost = payload.get("theaterToOutpostItems") or []
		outpost_to_theater = payload.get("outpostToTheaterItems") or []
		def _do_transfer(from_items: dict, to_items: dict, from_changes: list, to_changes: list, item_id: str, qty: int) -> None:
			if item_id not in from_items:
				return
			src_qty = int(from_items[item_id].get("quantity", 0))
			move_qty = min(qty, src_qty)
			if item_id in to_items:
				to_items[item_id]["quantity"] = int(to_items[item_id].get("quantity", 0)) + move_qty
				to_changes.append({"changeType": "itemQuantityChanged", "itemId": item_id, "quantity": to_items[item_id]["quantity"]})
			else:
				to_items[item_id] = deepcopy(from_items[item_id])
				to_items[item_id]["quantity"] = move_qty
				to_changes.append({"changeType": "itemAdded", "itemId": item_id, "item": to_items[item_id]})
			if move_qty >= src_qty:
				del from_items[item_id]
				from_changes.append({"changeType": "itemRemoved", "itemId": item_id})
			else:
				from_items[item_id]["quantity"] = src_qty - move_qty
				from_changes.append({"changeType": "itemQuantityChanged", "itemId": item_id, "quantity": from_items[item_id]["quantity"]})
		for op in transfer_ops:
			oid = op.get("itemId", "")
			oqty = int(op.get("quantity", 0))
			if op.get("toStorage"):
				_do_transfer(items, op_items, changes, op_changes, oid, oqty)
			else:
				_do_transfer(op_items, items, op_changes, changes, oid, oqty)
		for op in theater_to_outpost:
			_do_transfer(items, op_items, changes, op_changes, op.get("itemId", ""), int(op.get("quantity", 0)))
		for op in outpost_to_theater:
			_do_transfer(op_items, items, op_changes, changes, op.get("itemId", ""), int(op.get("quantity", 0)))
		if op_changes:
			outpost_profile["rvn"] = op_base + 1
			outpost_profile["commandRevision"] = int(outpost_profile.get("commandRevision", op_base)) + 1
			outpost_profile["updated"] = utc_now_iso()
			save_profile("outpost0", outpost_profile)
		multi_update.append({"profileRevision": int(outpost_profile.get("rvn", 1)), "profileId": "outpost0", "profileChangesBaseRevision": op_base, "profileChanges": op_changes, "profileCommandRevision": int(outpost_profile.get("commandRevision", 1))})

	elif cmd == "refundmtxpurchase":
		athena_profile2 = load_profile("athena", account_id)
		ath_base2 = int(athena_profile2.get("rvn", 1))
		ath_changes2: list[dict[str, Any]] = []
		ath_items2 = athena_profile2.setdefault("items", {})
		attrs2 = profile.setdefault("stats", {}).setdefault("attributes", {})
		pu_id = payload.get("purchaseId")
		if pu_id:
			ath_mu_entry: dict[str, Any] = {"profileRevision": ath_base2, "profileId": "athena", "profileChangesBaseRevision": ath_base2, "profileChanges": [], "profileCommandRevision": int(athena_profile2.get("commandRevision", ath_base2))}
			ph = attrs2.setdefault("mtx_purchase_history", {"refundsUsed": 0, "refundCredits": 3, "purchases": []})
			ph["refundsUsed"] = int(ph.get("refundsUsed", 0)) + 1
			ph["refundCredits"] = int(ph.get("refundCredits", 3)) - 1
			item_guids: list[str] = []
			for pu in ph.get("purchases", []):
				if pu.get("purchaseId") == pu_id:
					for lr in pu.get("lootResult", []):
						item_guids.append(lr.get("itemGuid", ""))
					pu["refundDate"] = utc_now_iso()
					# Refund mtx
					mtx_platform = attrs2.get("current_mtx_platform", "EpicPC")
					for key, item_entry in items.items():
						if item_entry.get("templateId", "").lower().startswith("currency:mtx"):
							item_plat = item_entry.get("attributes", {}).get("platform", "")
							if item_plat.lower() == mtx_platform.lower() or item_plat.lower() == "shared":
								item_entry["quantity"] = int(item_entry.get("quantity", 0)) + int(pu.get("totalMtxPaid", 0))
								changes.append({"changeType": "itemQuantityChanged", "itemId": key, "quantity": item_entry["quantity"]})
								break
			for guid in item_guids:
				if guid in ath_items2:
					del ath_items2[guid]
					ath_changes2.append({"changeType": "itemRemoved", "itemId": guid})
			if ath_changes2:
				athena_profile2["rvn"] = ath_base2 + 1
				athena_profile2["commandRevision"] = int(athena_profile2.get("commandRevision", ath_base2)) + 1
				athena_profile2["updated"] = utc_now_iso()
				save_profile("athena", athena_profile2)
			ath_mu_entry["profileRevision"] = int(athena_profile2.get("rvn", 1))
			ath_mu_entry["profileCommandRevision"] = int(athena_profile2.get("commandRevision", 1))
			ath_mu_entry["profileChanges"] = ath_changes2
			multi_update.append(ath_mu_entry)
			changes.append({"changeType": "statModified", "name": "mtx_purchase_history", "value": ph})

	elif cmd == "unlockrewardnode":
		winterfest_ids = load_json(RESPONSES_DIR / "Athena" / "winterfestRewards.json", {})
		node_id = payload.get("nodeId")
		reward_graph_id = payload.get("rewardGraphId")
		memory2 = parse_version_info(request)
		season_key = f"Season{memory2['season']}"
		if node_id and reward_graph_id and reward_graph_id in items:
			wf_rewards = winterfest_ids.get(season_key, {}).get(node_id, [])
			# Add gift box
			gift_id = str(uuid.uuid4())
			gift_item: dict[str, Any] = {"templateId": "GiftBox:gb_winterfestreward", "attributes": {"max_level_bonus": 0, "fromAccountId": "", "lootList": [], "level": 1, "item_seen": False, "xp": 0, "giftedOn": utc_now_iso(), "params": {"SubGame": "Athena", "winterfestGift": "true"}, "favorite": False}, "quantity": 1}
			items[gift_id] = gift_item
			cc2_profile: dict[str, Any] | None = None
			cc2_base = 0
			cc2_changes: list[dict[str, Any]] = []
			for reward_tmpl in wf_rewards:
				new_wr_id = str(uuid.uuid4())
				if reward_tmpl.lower().startswith("homebasebannericon:"):
					if cc2_profile is None:
						cc2_profile = load_profile("common_core", account_id)
						cc2_base = int(cc2_profile.get("rvn", 1))
					exists_wr = False
					for k, v in cc2_profile.get("items", {}).items():
						if v.get("templateId", "").lower() == reward_tmpl.lower():
							v.setdefault("attributes", {})["item_seen"] = False
							cc2_changes.append({"changeType": "itemAttrChanged", "itemId": k, "attributeName": "item_seen", "attributeValue": False})
							new_wr_id = k
							exists_wr = True
							break
					if not exists_wr:
						wr_item: dict[str, Any] = {"templateId": reward_tmpl, "attributes": {"max_level_bonus": 0, "level": 1, "item_seen": False, "xp": 0, "variants": [], "favorite": False}, "quantity": 1}
						cc2_profile.setdefault("items", {})[new_wr_id] = wr_item
						cc2_changes.append({"changeType": "itemAdded", "itemId": new_wr_id, "item": wr_item})
					gift_item["attributes"]["lootList"].append({"itemType": reward_tmpl, "itemGuid": new_wr_id, "itemProfile": "common_core", "attributes": {"creation_time": utc_now_iso()}, "quantity": 1})
				else:
					wr_item2: dict[str, Any] = {"templateId": reward_tmpl, "attributes": {"max_level_bonus": 0, "level": 1, "item_seen": False, "xp": 0, "variants": [], "favorite": False}, "quantity": 1}
					items[new_wr_id] = wr_item2
					changes.append({"changeType": "itemAdded", "itemId": new_wr_id, "item": wr_item2})
					gift_item["attributes"]["lootList"].append({"itemType": reward_tmpl, "itemGuid": new_wr_id, "itemProfile": profile_id, "attributes": {"creation_time": utc_now_iso()}, "quantity": 1})
			rg_attrs = items[reward_graph_id].setdefault("attributes", {})
			rk = rg_attrs.setdefault("reward_keys", [{"unlock_keys_used": 0}])
			if rk:
				rk[0]["unlock_keys_used"] = int(rk[0].get("unlock_keys_used", 0)) + 1
			claimed = rg_attrs.setdefault("reward_nodes_claimed", [])
			claimed.append(node_id)
			changes.append({"changeType": "itemAdded", "itemId": gift_id, "item": gift_item})
			changes.append({"changeType": "itemAttrChanged", "itemId": reward_graph_id, "attributeName": "reward_keys", "attributeValue": rk})
			changes.append({"changeType": "itemAttrChanged", "itemId": reward_graph_id, "attributeName": "reward_nodes_claimed", "attributeValue": claimed})
			if memory2["season"] == 11 and "S11_GIFT_KEY" in items:
				items["S11_GIFT_KEY"]["quantity"] = int(items["S11_GIFT_KEY"].get("quantity", 1)) - 1
				changes.append({"changeType": "itemQuantityChanged", "itemId": "S11_GIFT_KEY", "quantity": items["S11_GIFT_KEY"]["quantity"]})
			if cc2_profile is not None:
				if cc2_changes:
					cc2_profile["rvn"] = cc2_base + 1
					cc2_profile["commandRevision"] = int(cc2_profile.get("commandRevision", cc2_base)) + 1
					cc2_profile["updated"] = utc_now_iso()
					save_profile("common_core", cc2_profile)
				multi_update.append({"profileRevision": int(cc2_profile.get("rvn", 1)), "profileId": "common_core", "profileChangesBaseRevision": cc2_base, "profileChanges": cc2_changes, "profileCommandRevision": int(cc2_profile.get("commandRevision", 1))})

	elif cmd == "purchasecatalogentry":
		catalog_data = load_json(RESPONSES_DIR / "catalog.json", {})
		catalog_storefronts = catalog_data.get("storefronts", [])
		offer_id = payload.get("offerId")
		purchase_qty = int(payload.get("purchaseQuantity", 1))
		currency_sub_type = str(payload.get("currencySubType", ""))
		ath_profile = load_profile("athena", account_id)
		ath_p_base = int(ath_profile.get("rvn", 1))
		ath_p_changes: list[dict[str, Any]] = []
		ath_p_items = ath_profile.setdefault("items", {})
		camp_profile = load_profile("campaign", account_id)
		camp_p_base = int(camp_profile.get("rvn", 1))
		camp_p_changes: list[dict[str, Any]] = []
		camp_p_items = camp_profile.setdefault("items", {})
		camp_p_attrs = camp_profile.setdefault("stats", {}).setdefault("attributes", {})
		purchased_llama = False
		athena_modified = False
		camp_modified = False
		card_pack_data2 = load_json(RESPONSES_DIR / "Campaign" / "cardPackData.json", {})
		if offer_id:
			notifications.append({"type": "CatalogPurchase", "primary": True, "lootResult": {"items": []}})
			for sf in catalog_storefronts:
				sf_name = sf.get("name", "")
				for entry in sf.get("catalogEntries", []):
					if entry.get("offerId") != offer_id:
						continue
					price_info = entry.get("prices", [{}])[0] if entry.get("prices") else {}
					price_cur = price_info.get("currencyType", "")
					final_price = int(price_info.get("finalPrice", 0))
					# STW llama / cardpack
					if sf_name.lower().startswith("cardpack") and not purchased_llama:
						for grant in entry.get("itemGrants", []):
							for _ in range(purchase_qty):
								new_iid = str(uuid.uuid4())
								camp_p_items[new_iid] = {"templateId": grant.get("templateId", ""), "attributes": {"is_loot_tier_overridden": False, "max_level_bonus": 0, "level": 1391, "pack_source": "Schedule", "item_seen": False, "xp": 0, "favorite": False, "override_loot_tier": 0}, "quantity": 1}
								camp_p_changes.append({"changeType": "itemAdded", "itemId": new_iid, "item": camp_p_items[new_iid]})
								notifications[0]["lootResult"]["items"].append({"itemType": grant.get("templateId", ""), "itemGuid": new_iid, "itemProfile": "campaign", "quantity": 1})
						if price_cur.lower() == "mtxcurrency":
							for k, v in items.items():
								if v.get("templateId", "").lower().startswith("currency:mtx"):
									mtx_plat = v.get("attributes", {}).get("platform", "")
									curr_plat = profile.get("stats", {}).get("attributes", {}).get("current_mtx_platform", "EpicPC")
									if mtx_plat.lower() == curr_plat.lower() or mtx_plat.lower() == "shared":
										v["quantity"] = int(v.get("quantity", 0)) - final_price * purchase_qty
										changes.append({"changeType": "itemQuantityChanged", "itemId": k, "quantity": v["quantity"]})
										profile["rvn"] = int(profile.get("rvn", 1)) + 1
										profile["commandRevision"] = int(profile.get("commandRevision", 1)) + 1
										break
						purchased_llama = True
						camp_modified = True
					# BR cosmetics
					elif sf_name.startswith("BR") and not sf_name.startswith("BRSeason"):
						for grant in entry.get("itemGrants", []):
							item_exists2 = any(v.get("templateId", "").lower() == grant.get("templateId", "").lower() for v in ath_p_items.values())
							if not item_exists2:
								new_iid2 = str(uuid.uuid4())
								br_item: dict[str, Any] = {"templateId": grant.get("templateId", ""), "attributes": {"max_level_bonus": 0, "level": 1, "item_seen": False, "xp": 0, "variants": [], "favorite": False}, "quantity": 1}
								ath_p_items[new_iid2] = br_item
								ath_p_changes.append({"changeType": "itemAdded", "itemId": new_iid2, "item": br_item})
								notifications[0]["lootResult"]["items"].append({"itemType": grant.get("templateId", ""), "itemGuid": new_iid2, "itemProfile": "athena", "quantity": grant.get("quantity", 1)})
								athena_modified = True
						if price_cur.lower() == "mtxcurrency":
							for k, v in items.items():
								if v.get("templateId", "").lower().startswith("currency:mtx"):
									mtx_plat = v.get("attributes", {}).get("platform", "")
									curr_plat = profile.get("stats", {}).get("attributes", {}).get("current_mtx_platform", "EpicPC")
									if mtx_plat.lower() == curr_plat.lower() or mtx_plat.lower() == "shared":
										v["quantity"] = int(v.get("quantity", 0)) - final_price * purchase_qty
										changes.append({"changeType": "itemQuantityChanged", "itemId": k, "quantity": v["quantity"]})
										profile["rvn"] = int(profile.get("rvn", 1)) + 1
										profile["commandRevision"] = int(profile.get("commandRevision", 1)) + 1
										break
						# Add to purchase history
						if entry.get("itemGrants"):
							pu_id2 = str(uuid.uuid4())
							ph2 = profile.setdefault("stats", {}).setdefault("attributes", {}).setdefault("mtx_purchase_history", {"refundsUsed": 0, "refundCredits": 3, "purchases": []})
							ph2["purchases"].append({"purchaseId": pu_id2, "offerId": f"v2:/{pu_id2}", "purchaseDate": utc_now_iso(), "freeRefundEligible": False, "fulfillments": [], "lootResult": notifications[0]["lootResult"]["items"], "totalMtxPaid": final_price, "metadata": {}, "gameContext": ""})
							changes.append({"changeType": "statModified", "name": "mtx_purchase_history", "value": ph2})
					# STW store
					elif sf_name.startswith("STW"):
						for grant in entry.get("itemGrants", []):
							new_iid3 = str(uuid.uuid4())
							stw_item: dict[str, Any] = {"templateId": grant.get("templateId", ""), "attributes": {"legacy_alterations": [], "max_level_bonus": 0, "level": 1, "refund_legacy_item": False, "item_seen": False, "alterations": ["", "", "", "", "", ""], "xp": 0, "refundable": False, "alteration_base_rarities": [], "favorite": False}, "quantity": purchase_qty * int(grant.get("quantity", 1))}
							items[new_iid3] = stw_item
							changes.append({"changeType": "itemAdded", "itemId": new_iid3, "item": stw_item})
							notifications[0]["lootResult"]["items"].append({"itemType": grant.get("templateId", ""), "itemGuid": new_iid3, "itemProfile": profile_id, "quantity": stw_item["quantity"]})
						if price_cur.lower() == "gameitem":
							cur_sub = price_info.get("currencySubType", "")
							for k, v in items.items():
								if v.get("templateId", "").lower() == cur_sub.lower():
									v["quantity"] = int(v.get("quantity", 0)) - final_price * purchase_qty
									changes.append({"changeType": "itemQuantityChanged", "itemId": k, "quantity": v["quantity"]})
									break
						profile["rvn"] = int(profile.get("rvn", 1)) + 1
						profile["commandRevision"] = int(profile.get("commandRevision", 1)) + 1
					break
		if athena_modified:
			ath_profile["rvn"] = ath_p_base + 1
			ath_profile["commandRevision"] = int(ath_profile.get("commandRevision", ath_p_base)) + 1
			ath_profile["updated"] = utc_now_iso()
			save_profile("athena", ath_profile)
			multi_update.append({"profileRevision": int(ath_profile.get("rvn", 1)), "profileId": "athena", "profileChangesBaseRevision": ath_p_base, "profileChanges": ath_p_changes, "profileCommandRevision": int(ath_profile.get("commandRevision", 1))})
		if camp_modified:
			camp_profile["rvn"] = camp_p_base + 1
			camp_profile["commandRevision"] = int(camp_profile.get("commandRevision", camp_p_base)) + 1
			camp_profile["updated"] = utc_now_iso()
			save_profile("campaign", camp_profile)
			multi_update.append({"profileRevision": int(camp_profile.get("rvn", 1)), "profileId": "campaign", "profileChangesBaseRevision": camp_p_base, "profileChanges": camp_p_changes, "profileCommandRevision": int(camp_profile.get("commandRevision", 1))})

	elif cmd == "craftworlditem":
		memory3 = parse_version_info(request)
		schematic_items = profile.setdefault("items", {})
		if memory3["season"] >= 4 or memory3["build"] in (3.5, 3.6):
			schematic_items = load_profile("campaign", account_id).setdefault("items", {})
		output_qty = int(payload.get("outputQuantity", 1))
		schematic_id = payload.get("schematicId", "")
		from_items = {k: v for k, v in schematic_items.items() if v.get("templateId", "").lower() == schematic_id.lower()}
		if from_items:
			new_cid = str(uuid.uuid4())
			c_tmpl = list(from_items.values())[0].get("templateId", "")
			c_item: dict[str, Any] = {"templateId": c_tmpl, "attributes": {"loadedAmmo": 999, "level": 1, "alterationDefinitions": [], "baseClipSize": 999, "durability": 375, "itemSource": "", "item_seen": False}, "quantity": output_qty}
			items[new_cid] = c_item
			changes.append({"changeType": "itemAdded", "itemId": new_cid, "item": c_item})
			notifications.append({"type": "craftingResult", "primary": True, "lootResult": {"items": [{"itemType": c_tmpl, "itemGuid": new_cid, "itemProfile": profile_id, "attributes": c_item["attributes"], "quantity": output_qty}]}})

	# ── END NEW COMMANDS ────────────────────────────────────────────────────

	elif cmd == "bulkequipbattleroyalecustomization":
		# S16+ full locker-preset equip — slots payload mirrors SetCosmeticLockerSlot for each slot.
		locker_item_id = resolve_locker_item_id(payload.get("lockerItem")) or ensure_locker_item()
		slots_data = payload.get("slots") or {}
		entry = items.get(locker_item_id)
		attr_stat = profile.setdefault("stats", {}).setdefault("attributes", {})
		if entry is not None:
			attrs_e = entry.setdefault("attributes", {})
			locker_slots = attrs_e.setdefault("locker_slots_data", {"slots": {}})
			for slot_name, slot_content in slots_data.items():
				if not isinstance(slot_content, dict):
					continue
				slot_items = slot_content.get("items") or []
				raw_variants = slot_content.get("activeVariants") or []
				# Normalise activeVariants into [{"variants": [...]}] shape.
				if raw_variants and isinstance(raw_variants[0], dict) and "variants" not in raw_variants[0]:
					norm_variants: list[Any] = [{"variants": raw_variants}]
				else:
					norm_variants = raw_variants
				locker_slots["slots"][slot_name] = {"items": slot_items, "activeVariants": norm_variants}
				stat_key = SLOT_STAT_MAP.get(slot_name)
				if stat_key and slot_items:
					if slot_name in ("Dance", "ItemWrap"):
						attr_stat[stat_key] = slot_items
						changes.append({"changeType": "statModified", "name": stat_key, "value": slot_items})
					else:
						attr_stat[stat_key] = slot_items[0] if slot_items else ""
						changes.append({"changeType": "statModified", "name": stat_key, "value": attr_stat[stat_key]})
			changes.append({"changeType": "itemAttrChanged", "itemId": locker_item_id, "attributeName": "locker_slots_data", "attributeValue": locker_slots})

	elif cmd == "setreceivegiftsenabled":
		attr_stat2 = profile.setdefault("stats", {}).setdefault("attributes", {})
		attr_stat2["allowed_to_receive_gifts"] = bool(payload.get("bReceiveGifts", True))
		changes.append({"changeType": "statModified", "name": "allowed_to_receive_gifts", "value": attr_stat2["allowed_to_receive_gifts"]})

	elif cmd == "setgiftboxenabled":
		attr_stat3 = profile.setdefault("stats", {}).setdefault("attributes", {})
		attr_stat3["gift_history"] = attr_stat3.get("gift_history") or {}
		changes.append({"changeType": "statModified", "name": "gift_history", "value": attr_stat3["gift_history"]})

	elif cmd == "giftcatalogentry":
		# Grant catalog items to receiver accounts; in single-player sender==receiver.
		catalog_data_g = load_json(RESPONSES_DIR / "catalog.json", {})
		g_offer_id = payload.get("offerId")
		g_receivers = payload.get("receiverAccountIds") or []
		g_message = str(payload.get("personalMessage", ""))[:512]
		if g_offer_id:
			for sf_g in catalog_data_g.get("storefronts", []):
				for entry_g in sf_g.get("catalogEntries", []):
					if entry_g.get("offerId") != g_offer_id:
						continue
					price_info_g = (entry_g.get("prices") or [{}])[0]
					final_price_g = int(price_info_g.get("finalPrice", 0))
					# Deduct MTX from sender profile
					if price_info_g.get("currencyType", "").lower() == "mtxcurrency":
						for k_g, v_g in items.items():
							if v_g.get("templateId", "").lower().startswith("currency:mtx"):
								mtx_plat_g = v_g.get("attributes", {}).get("platform", "")
								curr_plat_g = profile.get("stats", {}).get("attributes", {}).get("current_mtx_platform", "EpicPC")
								if mtx_plat_g.lower() == curr_plat_g.lower() or mtx_plat_g.lower() == "shared":
									v_g["quantity"] = int(v_g.get("quantity", 0)) - final_price_g
									changes.append({"changeType": "itemQuantityChanged", "itemId": k_g, "quantity": v_g["quantity"]})
									break
					# Grant items — in a single-player server receiver is always same account
					g_granted: list[dict[str, Any]] = []
					for recv_id in (g_receivers or [account_id]):
						recv_ath = load_profile("athena", recv_id)
						recv_items = recv_ath.setdefault("items", {})
						for grant_g in entry_g.get("itemGrants", []):
							g_tmpl = grant_g.get("templateId", "")
							already_g = any(iv.get("templateId", "").lower() == g_tmpl.lower() for iv in recv_items.values())
							if not already_g:
								g_iid = str(uuid.uuid4())
								g_item: dict[str, Any] = {"templateId": g_tmpl, "attributes": {"max_level_bonus": 0, "level": 1, "item_seen": False, "xp": 0, "variants": [], "favorite": False}, "quantity": 1}
								recv_items[g_iid] = g_item
								g_granted.append({"itemType": g_tmpl, "itemGuid": g_iid, "itemProfile": "athena", "quantity": 1})
						recv_ath["rvn"] = int(recv_ath.get("rvn", 1)) + 1
						recv_ath["commandRevision"] = int(recv_ath.get("commandRevision", 1)) + 1
						recv_ath["updated"] = utc_now_iso()
						save_profile("athena", recv_ath)
					# Record in sender gift history
					g_hist = profile.setdefault("stats", {}).setdefault("attributes", {}).setdefault("gift_history", {"num_sent": 0, "sentTo": {}, "gifts": []})
					g_hist["num_sent"] = int(g_hist.get("num_sent", 0)) + 1
					for r_id in g_receivers:
						g_hist.setdefault("sentTo", {})[r_id] = {"sent": True}
					g_hist.setdefault("gifts", []).append({"offerId": g_offer_id, "toAccountId": g_receivers[0] if g_receivers else account_id, "lootList": g_granted, "params": {"personalMessage": g_message}, "date": utc_now_iso()})
					changes.append({"changeType": "statModified", "name": "gift_history", "value": g_hist})
					notifications.append({"type": "CatalogPurchase", "primary": True, "lootResult": {"items": g_granted}})
					break

	elif cmd in ("redeemrealmoneypurchases", "verifyrealmoneyreceipt", "verifyrealmoneypurchase"):
		# IAP redemption — no real items to grant in a private server; just ack.
		pass

	elif cmd == "issuefriendcode":
		notifications.append({"type": "IssueFriendCode", "primary": True, "codes": [{"codeId": "LAWIN-PRIV", "codeType": "CodeToken:FounderFriendInvite", "dateCreated": utc_now_iso()}]})

	elif cmd in ("claimitemswithrealmoneypurchase", "grantbattlepasspurchased"):
		pass  # No-op — single-player servers don't process real payments.

	if changes:
		profile["rvn"] = int(profile.get("rvn", 1)) + 1
		profile["commandRevision"] = int(profile.get("commandRevision", 1)) + 1
		profile["updated"] = utc_now_iso()
		save_profile(profile_id, profile)

	resp = mcp_response(profile, base_revision, query_revision, changes)
	if multi_update:
		resp["multiUpdate"] = multi_update
	if notifications:
		resp["notifications"] = notifications
	return resp


@app.post("/fortnite/api/game/v2/profile/{account_id}/dedicated_server/{command}")
def profile_dedicated_server(account_id: str, command: str, request: Request) -> dict[str, Any]:
	profile_id = request.query_params.get("profileId")
	if not profile_id:
		return JSONResponse(status_code=404, content={"error": "Profile not defined."})
	profile = load_profile(profile_id, account_id)
	base_revision = int(profile.get("rvn", 1))
	query_revision = parse_query_rvn(request)
	return mcp_response(profile, base_revision, query_revision)


@app.get("/friends/api/public/friends/{account_id}")
def friends_public(account_id: str, request: Request) -> Any:
	friendslist, _ = ensure_friend(account_id)
	memory = parse_version_info(request)

	if memory["season"] >= 7:
		filtered = [f for f in friendslist if f.get("accountId") != account_id]
		return filtered

	return friendslist


@app.get("/friends/api/v1/{account_id}/summary")
def friends_summary(account_id: str) -> Any:
	_, friendslist2 = ensure_friend(account_id)
	return friendslist2


@app.get("/friends/api/v1/{account_id}/friends")
def friends_v1_list(account_id: str) -> Any:
	_, fl2 = ensure_friend(account_id)
	return fl2.get("friends", [])


@app.get("/friends/api/v1/{account_id}/incoming")
def friends_incoming(account_id: str) -> list[Any]:
	return []


@app.get("/friends/api/v1/{account_id}/outgoing")
def friends_outgoing(account_id: str) -> list[Any]:
	return []


@app.post("/friends/api/v1/{account_id}/friends/{friend_id}")
def friends_add(account_id: str, friend_id: str) -> Response:
	friendslist_path = RESPONSES_DIR / "friendslist.json"
	friendslist2_path = RESPONSES_DIR / "friendslist2.json"
	fl = load_json(friendslist_path, [])
	fl2 = load_json(friendslist2_path, {"friends": [], "incoming": [], "outgoing": [], "suggested": [], "blocklist": [], "settings": {"acceptInvites": "public"}})
	if not any(i.get("accountId") == friend_id for i in fl):
		created = utc_now_iso()
		fl.append({"accountId": friend_id, "status": "ACCEPTED", "direction": "OUTBOUND", "created": created, "favorite": False})
		fl2.setdefault("friends", []).append({"accountId": friend_id, "groups": [], "mutual": 0, "alias": "", "note": "", "favorite": False, "created": created})
		save_json(friendslist_path, fl)
		save_json(friendslist2_path, fl2)
	return Response(status_code=204)


@app.delete("/friends/api/v1/{account_id}/friends/{friend_id}")
def friends_remove(account_id: str, friend_id: str) -> Response:
	friendslist_path = RESPONSES_DIR / "friendslist.json"
	friendslist2_path = RESPONSES_DIR / "friendslist2.json"
	fl = load_json(friendslist_path, [])
	fl2 = load_json(friendslist2_path, {"friends": [], "incoming": [], "outgoing": [], "suggested": [], "blocklist": [], "settings": {"acceptInvites": "public"}})
	fl = [i for i in fl if i.get("accountId") != friend_id]
	fl2["friends"] = [i for i in fl2.get("friends", []) if i.get("accountId") != friend_id]
	save_json(friendslist_path, fl)
	save_json(friendslist2_path, fl2)
	return Response(status_code=204)


@app.post("/friends/api/v1/{account_id}/blocklist/{block_id}")
def friends_block(account_id: str, block_id: str) -> Response:
	return Response(status_code=204)


@app.delete("/friends/api/v1/{account_id}/blocklist/{block_id}")
def friends_unblock(account_id: str, block_id: str) -> Response:
	return Response(status_code=204)


@app.get("/friends/api/public/list/fortnite/{rest:path}/recentPlayers")
def recent_players(rest: str) -> list[Any]:
	return []


@app.get("/friends/api/public/blocklist/{rest:path}")
def public_blocklist(rest: str) -> dict[str, Any]:
	return {"blockedUsers": []}


@app.get("/fortnite/api/cloudstorage/system")
def cloudstorage_system(request: Request) -> Response:
	memory = parse_version_info(request)
	if 9.40 <= memory["build"] <= 10.40:
		return Response(status_code=404)

	files = []
	for file in CLOUDSTORAGE_DIR.glob("*.ini"):
		raw = file.read_text(encoding="utf-8", errors="ignore")
		stats = file.stat()
		files.append(
			{
				"uniqueFilename": file.name,
				"filename": file.name,
				"hash": hashlib.sha1(raw.encode("utf-8", errors="ignore")).hexdigest(),
				"hash256": hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest(),
				"length": len(raw),
				"contentType": "application/octet-stream",
				"uploaded": utc_iso_from_dt(datetime.fromtimestamp(stats.st_mtime, tz=timezone.utc)),
				"storageType": "S3",
				"storageIds": {},
				"doNotCache": True,
			}
		)
	return JSONResponse(files)


@app.get("/fortnite/api/cloudstorage/system/{filename}")
def cloudstorage_system_file(filename: str, request: Request) -> Response:
	# S12+ clients request /system/config before the listing — return empty JSON array.
	if filename == "config":
		return JSONResponse([])

	memory = parse_version_info(request)
	file = CLOUDSTORAGE_DIR / filename

	if not file.exists():
		return Response(status_code=404)

	data = file.read_text(encoding="utf-8", errors="ignore")

	if filename == "DefaultEngine.ini" and memory["season"] >= 23:
		data += "\n[ConsoleVariables]\nnet.AllowEncryption=0\n"

	if filename == "DefaultRuntimeOptions.ini" and 17.50 <= memory["build"] <= 19.30:
		data += "\nbLoadDirectlyIntoLobby=false\n"

	return Response(content=data, media_type="application/octet-stream")


@app.get("/fortnite/api/cloudstorage/user/{account_id}")
def cloudstorage_user_files(account_id: str, request: Request) -> list[dict[str, Any]]:
	memory = parse_version_info(request)
	cl = memory["cl"]
	file = get_client_settings_file(cl)

	if not file.exists():
		return []

	raw = file.read_bytes()
	stats = file.stat()
	return [
		{
			"uniqueFilename": "ClientSettings.Sav",
			"filename": "ClientSettings.Sav",
			"hash": hashlib.sha1(raw).hexdigest(),
			"hash256": hashlib.sha256(raw).hexdigest(),
			"length": len(raw),
			"contentType": "application/octet-stream",
			"uploaded": utc_iso_from_dt(datetime.fromtimestamp(stats.st_mtime, tz=timezone.utc)),
			"storageType": "S3",
			"storageIds": {},
			"accountId": account_id,
			"doNotCache": True,
		}
	]


@app.get("/fortnite/api/cloudstorage/user/{account_id}/{filename}")
def cloudstorage_user_file(account_id: str, filename: str, request: Request) -> Response:
	if filename.lower() != "clientsettings.sav":
		return JSONResponse({"error": "file not found"}, status_code=404)

	memory = parse_version_info(request)
	file = get_client_settings_file(memory["cl"])
	if not file.exists():
		return Response(status_code=404)

	return Response(content=file.read_bytes(), media_type="application/octet-stream")


@app.put("/fortnite/api/cloudstorage/user/{account_id}/{filename}")
async def cloudstorage_user_upload(account_id: str, filename: str, request: Request) -> Response:
	if filename.lower() != "clientsettings.sav":
		return JSONResponse({"error": "file not found"}, status_code=404)

	memory = parse_version_info(request)
	file = get_client_settings_file(memory["cl"])
	body = await request.body()
	file.write_bytes(body)
	return Response(status_code=204)


@app.get("/fortnite/api/game/v2/matchmakingservice/ticket/player/{rest:path}")
def matchmaking_ticket(rest: str, request: Request) -> Response:
	bucket_id = request.query_params.get("bucketId", "")
	# bucketId format: "{CL}:{region}:{playlist}" or similar; extract CL prefix for the cookie.
	bucket_parts = bucket_id.split(":")
	bucket_prefix = bucket_parts[0] if bucket_parts else bucket_id
	host = request.headers.get("host", "127.0.0.1:3551")

	# Pre-create a stable session record that the WS and HTTP handler both reference.
	session_id = uuid.uuid4().hex.upper()
	match_id = uuid.uuid4().hex.upper()
	ensure_mm_session(
		session_id,
		request=request,
		seed={
			"matchId": match_id,
			"bucketId": bucket_id,
			"buildUniqueId": bucket_prefix or "0",
		},
	)
	print(f"[MM] ticket account={rest} session={session_id} match={match_id} bucket={bucket_id}")

	proto = request.headers.get("x-forwarded-proto", request.url.scheme).lower()
	ws_scheme = "wss" if proto == "https" else "ws"

	payload = {
		"serviceUrl": f"{ws_scheme}://{host}/matchmaker?sid={session_id}&mid={match_id}",
		"ticketType": "mms-player",
		"payload": "lawinpayload",
		"signature": "lawinsignature",
		# Embed session_id in customConfig so the WS handler can look it up.
		"customConfig": {"sessionId": session_id, "matchId": match_id},
	}
	resp = JSONResponse(payload)
	resp.set_cookie("currentbuildUniqueId", bucket_prefix or "0")
	resp.set_cookie("lawin_session_id", session_id)
	return resp


@app.websocket("/")
@app.websocket("//")
@app.websocket("///")
async def xmpp_ws(websocket: WebSocket) -> None:
	"""Minimal XMPP-over-WebSocket stub so S15+ clients don't crash on connect."""
	import asyncio as _asyncio
	global _XMPP_EVENT_LOOP
	if _XMPP_EVENT_LOOP is None:
		_XMPP_EVENT_LOOP = _asyncio.get_event_loop()

	requested = websocket.headers.get("sec-websocket-protocol", "")
	subprotocol = "xmpp" if "xmpp" in requested else None
	try:
		await websocket.accept(subprotocol=subprotocol)
	except Exception:
		return

	stream_id = uuid.uuid4().hex
	account = current_display_name()
	bound_jid = f"{account}@prod.ol.epicgames.com"
	# Track whether SASL auth has completed so we send the right features on stream restart.
	authenticated = False
	sm_h = 0

	try:
		while True:
			# Accept both text and binary WebSocket frames (some builds send bytes).
			try:
				raw = await websocket.receive()
			except (WebSocketDisconnect, RuntimeError):
				break
			if raw.get("type") == "websocket.disconnect":
				break
			data: str = raw.get("text") or (raw.get("bytes", b"").decode("utf-8", errors="ignore"))

			if not data.strip():
				continue

			# Opening stream handshake (initial and post-SASL restart)
			if "<open" in data or "<stream:stream" in data:
				stream_id = uuid.uuid4().hex
				await websocket.send_text(
					f'<open xmlns="urn:ietf:params:xml:ns:xmpp-framing" '
					f'from="prod.ol.epicgames.com" id="{stream_id}" '
					f'version="1.0" xml:lang="en" />'
				)
				if not authenticated:
					# Pre-auth: advertise SASL mechanisms.
					await websocket.send_text(
						'<stream:features xmlns:stream="http://etherx.jabber.org/streams">'
						'<mechanisms xmlns="urn:ietf:params:xml:ns:xmpp-sasl">'
						'<mechanism>PLAIN</mechanism>'
						'</mechanisms>'
						'</stream:features>'
					)
				else:
					# Post-auth stream restart: offer resource binding + session.
					await websocket.send_text(
						'<stream:features xmlns:stream="http://etherx.jabber.org/streams">'
						'<bind xmlns="urn:ietf:params:xml:ns:xmpp-bind"/>'
						'<session xmlns="urn:ietf:params:xml:ns:xmpp-session"/>'
						'<sm xmlns="urn:xmpp:sm:3"/>'
						'<ver xmlns="urn:xmpp:features:rosterver"/>'
						'</stream:features>'
					)
				continue

			# SASL auth - always succeed
			if "<auth" in data:
				await websocket.send_text('<success xmlns="urn:ietf:params:xml:ns:xmpp-sasl"/>')
				authenticated = True
				continue

			# Resource binding IQ
			if "<iq" in data and "bind" in data:
				id_match = re.search(r'id="([^"]*)"', data)
				iq_id = id_match.group(1) if id_match else uuid.uuid4().hex
				res_match = re.search(r"<resource>([^<]+)</resource>", data)
				resource = res_match.group(1) if res_match else f"V2:Fortnite:WIN:{uuid.uuid4().hex.upper()}"
				bound_jid = f"{account}@prod.ol.epicgames.com/{resource}"
				await websocket.send_text(
					f'<iq xmlns="jabber:client" type="result" id="{iq_id}">'
					f'<bind xmlns="urn:ietf:params:xml:ns:xmpp-bind">'
					f'<jid>{bound_jid}</jid>'
					f'</bind>'
					f'</iq>'
				)
				# Register this connection so HTTP handlers can push party notifications.
				with _XMPP_CONNS_LOCK:
					_XMPP_CONNS[account] = websocket
					_XMPP_JIDS[account] = bound_jid
				# Send self-presence so the client knows it's online immediately.
				await websocket.send_text(
					f'<presence xmlns="jabber:client" from="{bound_jid}" to="{bound_jid}"/>'
				)
				continue

			# XMPP stream management enable/request acknowledgements
			if "urn:xmpp:sm:3" in data and "<enable" in data:
				await websocket.send_text('<enabled xmlns="urn:xmpp:sm:3" id="lawin-sm" resume="false"/>')
				continue

			if "urn:xmpp:sm:3" in data and "<r" in data:
				sm_h += 1
				await websocket.send_text(f'<a xmlns="urn:xmpp:sm:3" h="{sm_h}"/>')
				continue

			if "urn:xmpp:sm:3" in data and "<a" in data:
				continue

			# Session establishment IQ ("<session" is more specific than "session" to avoid false matches)
			if "<iq" in data and "<session" in data:
				id_match = re.search(r'id="([^"]*)"', data)
				iq_id = id_match.group(1) if id_match else uuid.uuid4().hex
				await websocket.send_text(f'<iq xmlns="jabber:client" type="result" id="{iq_id}"/>')
				continue

			# Roster query
			if "<iq" in data and "jabber:iq:roster" in data:
				id_match = re.search(r'id="([^"]*)"', data)
				iq_id = id_match.group(1) if id_match else uuid.uuid4().hex
				await websocket.send_text(
					f'<iq xmlns="jabber:client" type="result" id="{iq_id}">'
					f'<query xmlns="jabber:iq:roster" ver="1" />'
					f'</iq>'
				)
				continue

			if "<presence" in data:
				await websocket.send_text(
					f'<presence from="{bound_jid}" to="{account}@prod.ol.epicgames.com" />'
				)
				continue

			# Generic IQ - return empty result
			if "<iq" in data:
				id_match = re.search(r'id="([^"]*)"', data)
				iq_id = id_match.group(1) if id_match else uuid.uuid4().hex
				await websocket.send_text(f'<iq xmlns="jabber:client" type="result" id="{iq_id}"/>')
				continue

			# Stream close frame
			if "<close" in data:
				try:
					await websocket.send_text('<close xmlns="urn:ietf:params:xml:ns:xmpp-framing"/>')
				except Exception:
					pass
				break

			# Presence and message stanzas - silently accept
	except (WebSocketDisconnect, RuntimeError):
		pass
	finally:
		# Deregister connection so we don't push to a dead socket.
		with _XMPP_CONNS_LOCK:
			if _XMPP_CONNS.get(account) is websocket:
				_XMPP_CONNS.pop(account, None)
				_XMPP_JIDS.pop(account, None)


@app.websocket("/matchmaker")
async def matchmaker_ws(websocket: WebSocket) -> None:
	# Accept without echoing a subprotocol — the ticket payload was sent as
	# Sec-WebSocket-Protocol but may contain characters invalid in HTTP tokens.
	try:
		await websocket.accept()
	except Exception:
		return

	# Prefer explicit session mapping from serviceUrl query, then cookie fallback.
	# Some legacy clients don't reliably carry cookies on websocket upgrades.
	session_id_qs = websocket.query_params.get("sid", "")
	match_id_qs = websocket.query_params.get("mid", "")
	session_record = MM_SESSIONS.get(session_id_qs) if session_id_qs else None

	# Try to reuse the pre-created session from the ticket cookie.
	# Fall back to generating a fresh one if the query/cookie isn't present.
	session_id_cookie = websocket.cookies.get("lawin_session_id", "")
	if not session_record and session_id_cookie:
		session_record = MM_SESSIONS.get(session_id_cookie)
	if session_record:
		session_id = session_record["id"]
		match_id = session_record["matchId"]
		ticket_id = uuid.uuid4().hex.upper()
	else:
		ticket_id = uuid.uuid4().hex.upper()
		match_id = match_id_qs or uuid.uuid4().hex.upper()
		session_id = session_id_qs or uuid.uuid4().hex.upper()
		ensure_mm_session(session_id, seed={"matchId": match_id})

	print(f"[MM] ws-open session={session_id} match={match_id}")

	async def send_mm(payload: dict[str, Any], name: str) -> bool:
		try:
			await websocket.send_json({"payload": payload, "name": name})
			return True
		except (WebSocketDisconnect, RuntimeError):
			return False

	if not await send_mm({"state": "Connecting"}, "StatusUpdate"):
		return
	await asyncio.sleep(0.05)

	if not await send_mm({"totalPlayers": 1, "connectedPlayers": 1, "state": "Waiting"}, "StatusUpdate"):
		return
	await asyncio.sleep(0.05)

	if not await send_mm({
			"ticketId": ticket_id,
			"queuedPlayers": 0,
			"estimatedWaitSec": 0,
			"status": {},
			"state": "Queued",
		}, "StatusUpdate"):
		return
	await asyncio.sleep(0.05)

	if not await send_mm({"matchId": match_id, "state": "SessionAssignment"}, "StatusUpdate"):
		return
	await asyncio.sleep(0.05)

	# Play payload — send sessionId so the game can GET /matchmaking/session/{sessionId}
	if not await send_mm({
			"matchId": match_id,
			"sessionId": session_id,
			"joinDelaySec": 1,
		}, "Play"):
		return
	print(f"[MM] ws-play session={session_id} match={match_id}")

	# Keep alive — game closes socket after processing Play, that's expected.
	while True:
		try:
			await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
		except (WebSocketDisconnect, RuntimeError, asyncio.TimeoutError):
			break


@app.get("/fortnite/api/matchmaking/session/findPlayer/{rest:path}")
def matchmaking_find_player(rest: str) -> Response:
	return Response(status_code=200)


@app.get("/fortnite/api/game/v2/matchmaking/account/{account_id}/session/{session_id}")
def matchmaking_account_session(account_id: str, session_id: str, request: Request) -> dict[str, Any]:
	rec = ensure_mm_session(session_id, request=request)
	print(f"[MM] account-session account={account_id} session={session_id}")
	return {
		"accountId": account_id,
		"sessionId": session_id,
		# Keep this aligned with SESSIONKEY_s returned by /matchmaking/session.
		"key": rec["sessionKey"],
	}


@app.post("/fortnite/api/matchmaking/session/{session_path:path}/join")
def matchmaking_join(session_path: str) -> Response:
	return Response(status_code=204)


@app.post("/fortnite/api/matchmaking/session/matchMakingRequest")
def matchmaking_request() -> list[Any]:
	return []


@app.get("/fortnite/api/matchmaking/session/{session_id}")
def matchmaking_session(session_id: str, request: Request) -> dict[str, Any]:
	# Return stable session data from the shared MM_SESSIONS table when available.
	rec = ensure_mm_session(session_id, request=request)
	print(f"[MM] session-fetch session={session_id} key={'set' if rec.get('sessionKey') else 'missing'}")
	memory = parse_version_info(request)
	server_port = int(rec.get("serverPort", int(config_str("GameServer", "port", "7777"))))
	config_beacon_port = int(rec.get("beaconPort", int(config_str("GameServer", "beaconPort", "15009"))))
	beacon_port = config_beacon_port

	attributes = {
		"REGION_s": rec.get("region", "NAE"),
		"GAMEMODE_s": "FORTATHENA",
		"ALLOWBROADCASTING_b": True,
		"SUBREGION_s": rec.get("region", "NAE"),
		"DCID_s": "FORTNITE-LIVEEUGCEC1C2E30UBRCORE0A-14840880",
		"tenant_s": "Fortnite",
		"MATCHMAKINGPOOL_s": "Any",
		"STORMSHIELDDEFENSETYPE_i": 0,
		"HOTFIXVERSION_i": 0,
		"SESSIONKEY_s": rec["sessionKey"],
		"PLAYLISTNAME_s": rec.get("playlist", "Playlist_DefaultSolo"),
		"TENANT_s": "Fortnite",
		"BEACONPORT_i": beacon_port,
	}

	if int(memory.get("season", 2)) >= 6:
		attributes.update({
			"ALLOWMIGRATION_s": "false",
			"REJOINAFTERKICK_s": "OPEN",
			"CHECKSANCTIONS_s": "false",
			"BUCKET_s": "",
			"DEPLOYMENT_s": "Fortnite",
			"LASTUPDATED_s": utc_now_iso(),
			"ALLOWREADBYID_s": "false",
			"SERVERADDRESS_s": rec.get("serverAddress", config_str("GameServer", "ip", "127.0.0.1")),
			"serverAddress_s": rec.get("serverAddress", config_str("GameServer", "ip", "127.0.0.1")),
		})

	return {
		"id": session_id,
		"ownerId": rec.get("ownerId", uuid.uuid4().hex.upper()),
		"ownerName": "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
		"serverName": "[DS]fortnite-liveeugcec1c2e30ubrcore0a-z8hj-1968",
		"serverAddress": rec.get("serverAddress", config_str("GameServer", "ip", "127.0.0.1")),
		"serverPort": server_port,
		"maxPublicPlayers": 220,
		"openPublicPlayers": 175,
		"maxPrivatePlayers": 0,
		"openPrivatePlayers": 0,
		"attributes": attributes,
		"publicPlayers": [],
		"privatePlayers": [],
		"totalPlayers": 45,
		"allowJoinInProgress": False,
		"shouldAdvertise": False,
		"isDedicated": False,
		"usesStats": False,
		"allowInvites": False,
		"usesPresence": False,
		"allowJoinViaPresence": True,
		"allowJoinViaPresenceFriendsOnly": False,
		"buildUniqueId": rec.get("buildUniqueId", request.cookies.get("currentbuildUniqueId", "0")),
		"lastUpdated": utc_now_iso(),
		"started": bool(rec.get("started", int(memory.get("season", 2)) <= 5)),
	}


@app.get("/fortnite/api/calendar/v1/timeline")
def timeline(request: Request) -> dict[str, Any]:
	memory = parse_version_info(request)
	season = memory["season"]
	chapter_num, chapter_season = chapter_and_season_from_release(int(season))
	timeline_season_number = int(season)
	timeline_template_id = f"AthenaSeason:athenaseason{season}"

	# Modern clients expect season numbering inside the current chapter.
	if ENABLE_TINY_COMPAT_BOOSTS and int(season) >= 11:
		timeline_season_number = chapter_season
		timeline_template_id = f"AthenaSeason:athenaseason{chapter_season}"

	active_events = [
		{
			"eventType": f"EventFlag.Season{season}",
			"activeUntil": "9999-01-01T00:00:00.000Z",
			"activeSince": "2020-01-01T00:00:00.000Z",
		},
		{
			"eventType": f"EventFlag.{memory['lobby']}",
			"activeUntil": "9999-01-01T00:00:00.000Z",
			"activeSince": "2020-01-01T00:00:00.000Z",
		},
	]
	for event_name in timeline_events_for_version(memory):
		active_events.append(
			{
				"eventType": event_name,
				"activeUntil": "9999-01-01T00:00:00.000Z",
				"activeSince": "2020-01-01T00:00:00.000Z",
			}
		)

	states = [
		{
			"validFrom": "2020-01-01T00:00:00.000Z",
			"activeEvents": active_events,
			"state": {
				"activeStorefronts": [],
				"eventNamedWeights": {},
				"seasonNumber": timeline_season_number,
				"seasonTemplateId": timeline_template_id,
				"globalSeasonNumber": int(season),
				"chapterNumber": chapter_num,
				"matchXpBonusPoints": 0,
				"seasonBegin": "2020-01-01T13:00:00Z",
				"seasonEnd": "9999-01-01T14:00:00Z",
				"seasonDisplayedEnd": "9999-01-01T07:30:00Z",
				"weeklyStoreEnd": "9999-01-01T00:00:00Z",
				"stwEventStoreEnd": "9999-01-01T00:00:00.000Z",
				"stwWeeklyStoreEnd": "9999-01-01T00:00:00.000Z",
				"sectionStoreEnds": {},
			},
		}
	]

	return {
		"channels": {
			"client-matchmaking": {"states": [], "cacheExpire": "9999-01-01T22:28:47.830Z"},
			"client-events": {"states": states, "cacheExpire": "9999-01-01T22:28:47.830Z"},
		},
		"eventsTimeOffsetHrs": 0,
		"cacheIntervalMins": 10,
		"currentTime": utc_now_iso(),
	}


def launcher_distribution_payload(request: Request | None = None) -> dict[str, Any]:
	distributions = [
		"https://epicgames-download1.akamaized.net/",
		"https://download.epicgames.com/",
		"https://download2.epicgames.com/",
		"https://download3.epicgames.com/",
		"https://download4.epicgames.com/",
		"https://lawinserverpy.ol.epicgames.com/",
	]

	if STRICT_LAWINV1_PARITY and not ENABLE_TINY_COMPAT_BOOSTS:
		return {"distributions": distributions}

	if ENABLE_TINY_COMPAT_BOOSTS and request is not None:
		current_base = str(request.base_url)
		if current_base and current_base not in distributions:
			distributions.append(current_base)

	return {"distributions": distributions}


@app.get("/launcher/api/public/distributionpoints/")
def launcher_distribution_with_slash(request: Request) -> dict[str, Any]:
	return launcher_distribution_payload(request)


@app.get("/launcher/api/public/distributionpoints")
def launcher_distribution_without_slash(request: Request) -> dict[str, Any]:
	return launcher_distribution_payload(request)


@app.get("/launcher/api/public/assets/{rest:path}")
def launcher_assets(rest: str) -> dict[str, Any]:
	return {
		"appName": "FortniteContentBuilds",
		"labelName": "LawinServer.py",
		"buildVersion": "++Fortnite+Release-20.00-CL-19458861-Windows",
		"catalogItemId": "5cb97847cee34581afdbc445400e2f77",
		"expires": "9999-12-31T23:59:59.999Z",
		"items": {
			"MANIFEST": {
				"signature": "LawinServer.py",
				"distribution": "https://lawinserverpy.ol.epicgames.com/",
				"path": "Builds/Fortnite/Content/CloudDir/LawinServer.py.manifest",
				"hash": "55bb954f5596cadbe03693e1c06ca73368d427f3",
				"additionalDistributions": [],
			},
			"CHUNKS": {
				"signature": "LawinServer.py",
				"distribution": "https://lawinserverpy.ol.epicgames.com/",
				"path": "Builds/Fortnite/Content/CloudDir/LawinServer.py.manifest",
				"additionalDistributions": [],
			},
		},
		"assetId": "FortniteContentBuilds",
	}


@app.get("/Builds/Fortnite/Content/CloudDir/{filename:path}")
def cloud_dir_files(filename: str) -> Response:
	lower = filename.lower()
	if lower.endswith(".manifest"):
		file = RESPONSES_DIR / "CloudDir" / "LawinServer.py.manifest"
		if file.exists():
			return FileResponse(file, media_type="application/octet-stream")
	if lower.endswith(".chunk"):
		file = RESPONSES_DIR / "CloudDir" / "LawinServer.py.chunk"
		if file.exists():
			return FileResponse(file, media_type="application/octet-stream")
	if lower.endswith(".ini"):
		file = RESPONSES_DIR / "CloudDir" / "Full.ini"
		if file.exists():
			return FileResponse(file, media_type="application/octet-stream")
	return Response(status_code=404)


@app.get("/fortnite/api/storefront/v2/gift/check_eligibility/recipient/{account_id}/offer/{offer_id}")
def gift_eligibility(account_id: str, offer_id: str) -> dict[str, Any]:
	return {"eligible": True, "accountId": account_id, "offerId": offer_id}


@app.get("/fortnite/api/statsv2/account/{account_id}")
def statsv2_account(account_id: str) -> dict[str, Any]:
	return {"startTime": 0, "endTime": 0, "stats": {}, "accountId": account_id}


@app.get("/statsproxy/api/statsv2/account/{account_id}")
def statsv2_proxy_account(account_id: str) -> dict[str, Any]:
	return {"startTime": 0, "endTime": 0, "stats": {}, "accountId": account_id}


@app.post("/fortnite/api/statsv2/query")
def statsv2_query() -> list[Any]:
	return []


@app.post("/statsproxy/api/statsv2/query")
def statsv2_proxy_query() -> list[Any]:
	return []


@app.get("/socialban/api/public/v1/{rest:path}")
def social_ban(rest: str) -> dict[str, Any]:
	return {"bans": [], "warnings": []}


@app.get("/waitingroom/api/waitingroom")
def waitingroom() -> Response:
	return Response(status_code=204)


@app.get("/fortnite/api/game/v2/enabled_features")
def enabled_features() -> list[Any]:
	# Keep Lawin-like minimal behavior, but expose a few modern-safe toggles when enabled.
	if not ENABLE_TINY_COMPAT_BOOSTS:
		return []
	return ["CreativeDiscoverySurface", "ClientSettingsSaveToCloud", "PartyJoinability"]


@app.get("/party/api/v1/Fortnite/user/{account_id}/notifications/undelivered/count")
def party_notifications_count(account_id: str) -> dict[str, Any]:
	return {"count": 0}


@app.get("/party/api/v1/Fortnite/user/{account_id}/settings/privacy")
def party_privacy_get(account_id: str) -> dict[str, Any]:
	return {"partyType": "Public", "partyInviteRestriction": "AnyMember", "acceptingMembers": True}


@app.put("/party/api/v1/Fortnite/user/{account_id}/settings/privacy")
def party_privacy_put(account_id: str, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	return {"partyType": payload.get("partyType", "Public"), "partyInviteRestriction": payload.get("partyInviteRestriction", "AnyMember"), "acceptingMembers": payload.get("acceptingMembers", True)}


@app.get("/party/api/v1/Fortnite/user/{rest:path}")
def party_user(rest: str) -> dict[str, Any]:
	account_id = (rest.split("/")[0] if rest else "").strip()
	current: list[dict[str, Any]] = []
	if account_id:
		party_id = str(STATE.get("account_party", {}).get(account_id, ""))
		party = STATE.get("parties", {}).get(party_id)
		if isinstance(party, dict):
			current.append(deepcopy(party))
	return {"current": current, "pending": [], "invites": [], "pings": [], "settings": {}}


@app.post("/party/api/v1/Fortnite/parties")
def party_create(payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	join_info = payload.get("join_info") or {}
	connection = join_info.get("connection") or {}
	account_id = str(connection.get("id", "")).split("@prod")[0]
	now = utc_now_iso()
	party_id = uuid.uuid4().hex
	party = {
		"id": party_id,
		"created_at": now,
		"updated_at": now,
		"config": {
			"type": "DEFAULT",
			**(payload.get("config") or {}),
			"discoverability": "ALL",
			"sub_type": "default",
			"invite_ttl": 14400,
			"intention_ttl": 60,
		},
		"members": [
			{
				"account_id": account_id,
				"meta": join_info.get("meta") or {},
				"connections": [
					{
						"id": connection.get("id", ""),
						"connected_at": now,
						"updated_at": now,
						"yield_leadership": False,
						"meta": connection.get("meta") or {},
					}
				],
				"revision": 0,
				"updated_at": now,
				"joined_at": now,
				"role": "CAPTAIN",
			}
		],
		"applicants": [],
		"meta": payload.get("meta") or {},
		"invites": [],
		"revision": 0,
		"intentions": [],
	}
	if account_id:
		STATE.setdefault("account_party", {})[account_id] = party_id
	STATE.setdefault("parties", {})[party_id] = deepcopy(party)
	# Push XMPP party-created + member-joined notifications (Ch4+ requires these
	# before the client's lobby state machine will advance past party setup).
	_xmpp_party_notify(party, "PARTY_CREATED", {
		"account_id": account_id,
		"account_dn": account_id,
		"member_state_updated": {},
	})
	_xmpp_party_notify(party, "MEMBER_JOINED", {
		"account_id": account_id,
		"account_dn": account_id,
		"member_state_updated": (join_info.get("meta") or {}),
	})
	return party


@app.api_route("/party/api/v1/Fortnite/parties/{rest:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
def party_all(rest: str, request: Request, payload: dict[str, Any] = Body(default={})) -> Any:
	parts = [p for p in rest.split("/") if p]
	if not parts:
		return Response(status_code=204)

	party_id = parts[0]
	parties = STATE.setdefault("parties", {})
	party = parties.get(party_id)

	if request.method == "GET":
		if isinstance(party, dict):
			return party
		return JSONResponse({}, status_code=404)

	if request.method == "DELETE":
		if isinstance(party, dict):
			for member in party.get("members", []):
				member_id = str(member.get("account_id", ""))
				if member_id:
					STATE.setdefault("account_party", {}).pop(member_id, None)
			parties.pop(party_id, None)
		return Response(status_code=204)

	if not isinstance(party, dict):
		return Response(status_code=204)

	now = utc_now_iso()
	party["updated_at"] = now
	party["revision"] = int(party.get("revision", 0)) + 1

	if request.method in ("PATCH", "PUT", "POST"):
		# /party/{party_id}/members/{account_id}/meta
		if len(parts) >= 4 and parts[1] == "members" and parts[3] == "meta":
			member_id = parts[2]
			delete_keys = payload.get("delete") or []
			update_map = payload.get("update") or {}
			for member in party.get("members", []):
				if str(member.get("account_id", "")) != member_id:
					continue
				meta = member.setdefault("meta", {})
				if isinstance(meta, dict):
					for k in delete_keys:
						if isinstance(k, str):
							meta.pop(k, None)
					if isinstance(update_map, dict):
						meta.update(update_map)
				member["revision"] = int(member.get("revision", 0)) + 1
				member["updated_at"] = now
				break
			result = deepcopy(party)
			# Push MEMBER_STATE_UPDATED so Ch4+ clients' lobby state machine advances.
			_xmpp_party_notify(result, "MEMBER_STATE_UPDATED", {
				"account_id": member_id,
				"account_dn": member_id,
				"member_state_updated": (update_map if isinstance(update_map, dict) else {}),
				"urn": "urn:epic:member:datastreaming#replaced",
			})
			return result

		# /party/{party_id}
		if len(parts) == 1:
			config_update = payload.get("config") or {}
			meta_update = payload.get("meta") or {}
			if isinstance(config_update, dict):
				party.setdefault("config", {}).update(config_update)
			if isinstance(meta_update, dict):
				party.setdefault("meta", {}).update(meta_update)
			result = deepcopy(party)
			_xmpp_party_notify(result, "PARTY_UPDATED", {
				"party_state_updated": (meta_update if isinstance(meta_update, dict) else {}),
			})
			return result

	return Response(status_code=204)


@app.post("/datarouter/api/v1/public/data")
def datarouter_public() -> Response:
	return Response(status_code=204)


@app.post("/datarouter/api/v1/public/data/clients")
def datarouter_public_clients() -> Response:
	return Response(status_code=204)


@app.post("/api/v2/dedicated/service_update")
def dedicated_service_update(payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	# Legacy BR clients ping this during session bootstrap; original Lawin accepts it.
	return {}


@app.api_route("/api/v2/dedicated/{rest:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
def dedicated_fallback(rest: str, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	# Keep dedicated-service probes permissive to avoid hard failures on unknown subpaths.
	return {}


@app.post("/fortnite/api/feedback/{rest:path}")
def feedback(rest: str) -> Response:
	return Response(status_code=200)


# ── Hotfix / MCP config endpoints used by S12-S21 clients ─────────────────────

@app.get("/fortnite/api/cloudstorage/system/config")
def cloudstorage_system_config() -> list[Any]:
	"""S12+ clients call /system/config before the system listing. Return empty array."""
	return []


@app.post("/fortnite/api/game/v2/profile/{account_id}/client/ClientQuestLogin")
def client_quest_login_alias(account_id: str, request: Request, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	"""Alias kept for builds that POST ClientQuestLogin outside the regular command handler."""
	return profile_client_command(account_id, "ClientQuestLogin", request, payload)


@app.get("/fortnite/api/game/v2/battle_royale_storm_forecast")
def storm_forecast() -> dict[str, Any]:
	return {}


# ── Missing stubs discovered from S12 / S21 / S24 client logs ─────────────────

@app.get("/content-controls/{account_id}/rules/namespaces/{namespace}")
def content_controls_namespace(account_id: str, namespace: str) -> dict[str, Any]:
	return {"accountId": account_id, "namespace": namespace, "rules": []}


@app.get("/friends/api/v1/{account_id}/recent/fortnite")
def friends_recent(account_id: str) -> list[Any]:
	return []


@app.get("/presence/api/v1/_/{rest:path}/settings/subscriptions")
def presence_settings_subscriptions(rest: str) -> dict[str, Any]:
	return {}


@app.get("/presence/api/v1/_/{account_id}/subscriptions")
def presence_subscriptions(account_id: str) -> dict[str, Any]:
	return {}


@app.get("/presence/api/v1/Fortnite/{account_id}/subscriptions/nudged")
def presence_nudged(account_id: str) -> dict[str, Any]:
	return {}


@app.post("/presence/api/v1/Fortnite/{account_id}/subscriptions/broadcast")
def presence_broadcast(account_id: str) -> Response:
	return Response(status_code=204)


@app.get("/api/v1/Fortnite/get")
def api_v1_fortnite_get() -> dict[str, Any]:
	return {}


@app.post("/fortnite/api/game/v2/profileToken/verify/{account_id}")
def profile_token_verify(account_id: str) -> dict[str, Any]:
	return {"accountId": account_id, "token": "lawintoken", "success": True}


@app.get("/hotconfigs/v2/livefn.json")
def hotconfigs_live() -> dict[str, Any]:
	return {}


@app.get("/v1/avatar/fortnite/ids")
def avatar_ids(request: Request) -> list[dict[str, Any]]:
	ids = request.query_params.get("accountIds", "").split(",")
	return [{"accountId": a.strip(), "avatarId": "", "productId": ""} for a in ids if a.strip()]


@app.put("/profile/languages")
def profile_languages(payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	return {}


@app.put("/profile/privacy_settings")
def profile_privacy_settings(payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	return {}


@app.get("/api/v2/interactions/latest/{rest:path}")
def interactions_latest(rest: str) -> dict[str, Any]:
	return {"interactions": []}


@app.get("/api/v2/interactions/aggregated/{rest:path}")
def interactions_aggregated(rest: str) -> dict[str, Any]:
	return {"interactions": []}


@app.get("/images/{image_path:path}")
def static_images(image_path: str) -> Response:
	# Return a 1x1 transparent PNG so clients don't show broken image errors.
	_TRANSPARENT_PNG = (
		b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
		b"\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01"
		b"\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82"
	)
	return Response(content=_TRANSPARENT_PNG, media_type="image/png")


@app.get("/account/api/accounts/{account_id}/metadata")
def account_metadata(account_id: str) -> dict[str, Any]:
	return {"accountId": account_id, "metadata": {}}


@app.get("/account/api/public/account/lookup")
def account_lookup(q: str = "", accountId: str | None = None) -> Any:
	"""Allows lookup by query string (display name search) or by accountId."""
	name = accountId or q.split("@")[0] or "unknown"
	return {"id": name, "displayName": name, "externalAuths": {}}


@app.get("/entitlement/api/account/{account_id}/entitlements")
def entitlements(account_id: str) -> list[Any]:
	return []


@app.get("/fortnite/api/game/v2/creative/links/{account_id}")
def creative_links(account_id: str) -> list[Any]:
	return []


@app.post("/fortnite/api/game/v2/creative/links/{account_id}")
def creative_links_post(account_id: str) -> list[Any]:
	return []


@app.get("/api/v1/user/{account_id}/setting/{setting_key}")
def user_setting_get(account_id: str, setting_key: str) -> dict[str, Any]:
	return {"accountId": account_id, "key": setting_key, "value": None}


@app.post("/api/v1/user/{account_id}/setting")
def user_setting_post(account_id: str) -> Response:
	return Response(status_code=204)


def _ensure_athena_locker_profile(account_id: str) -> tuple[dict[str, Any], str]:
	profile = load_profile("athena", account_id)
	items = profile.setdefault("items", {})
	attrs = profile.setdefault("stats", {}).setdefault("attributes", {})

	locker_item_id = ""
	for item_id, item in items.items():
		if str(item.get("templateId", "")).lower().startswith("cosmeticlocker:"):
			locker_item_id = item_id
			break

	if not locker_item_id:
		locker_item_id = "lawin-loadout"
		items[locker_item_id] = {
			"templateId": "CosmeticLocker:cosmeticlocker_athena",
			"attributes": {
				"banner_icon_template": "StandardBanner1",
				"banner_color_template": "DefaultColor1",
				"locker_name": "LawinServer.py",
				"item_seen": False,
				"favorite": False,
			},
			"quantity": 1,
		}

	locker_attrs = items[locker_item_id].setdefault("attributes", {})
	locker_slots_data = locker_attrs.setdefault("locker_slots_data", {"slots": {}})
	slots = locker_slots_data.setdefault("slots", {})

	defaults: dict[str, list[str]] = {
		"Character": [""],
		"Backpack": [""],
		"Pickaxe": ["AthenaPickaxe:DefaultPickaxe"],
		"Glider": ["AthenaGlider:DefaultGlider"],
		"SkyDiveContrail": [""],
		"MusicPack": ["AthenaMusicPack:MusicPack_119_CH1_DefaultMusic"],
		"LoadingScreen": [""],
		"Dance": ["AthenaDance:eid_dancemoves", "", "", "", "", ""],
		"ItemWrap": ["", "", "", "", "", "", ""],
	}
	# Single-item slots that support activeVariants (excluding Dance which has no variants per-bucket).
	_variant_slots = {"Character", "Backpack", "Pickaxe", "Glider", "SkyDiveContrail", "MusicPack", "LoadingScreen", "ItemWrap"}

	for slot_name, default_items in defaults.items():
		slot_obj = slots.setdefault(slot_name, {})
		slot_obj.setdefault("items", list(default_items))
		if slot_name in _variant_slots:
			slot_obj.setdefault("activeVariants", [{"variants": []}])

	loadout_presets = attrs.setdefault("loadout_presets", {})
	loadout_presets.setdefault("CosmeticLoadout:cosmetic_loadout_athena", {"0": locker_item_id})

	return profile, locker_item_id


def _slot_customizations_from_active_variants(active_variants: Any) -> list[dict[str, Any]]:
	customizations: list[dict[str, Any]] = []
	if not isinstance(active_variants, list):
		return customizations
	for bucket in active_variants:
		if not isinstance(bucket, dict):
			continue
		for variant in bucket.get("variants", []) or []:
			if not isinstance(variant, dict):
				continue
			channel = str(variant.get("channel", ""))
			active = str(variant.get("active", ""))
			if not channel and not active:
				continue
			parts = active.split(".", 1)
			variant_tag = parts[0] if parts and parts[0] else active
			additional = parts[1] if len(parts) > 1 else ""
			customizations.append(
				{
					"channelTag": channel,
					"variantTag": variant_tag,
					"additionalData": additional,
				}
			)
	return customizations


def _locker_v3_loadout_from_item(deployment_id: str, account_id: str, loadout_type: str, athena_item_id: str, locker_item: dict[str, Any]) -> dict[str, Any]:
	now = utc_now_iso()
	slots = locker_item.get("attributes", {}).get("locker_slots_data", {}).get("slots", {})
	loadout_slots: list[dict[str, Any]] = []

	for slot_name, slot_obj in slots.items():
		if not isinstance(slot_obj, dict):
			continue
		items = slot_obj.get("items", [])
		equipped = ""
		if isinstance(items, list) and items:
			equipped = str(items[0] or "")
		loadout_slots.append(
			{
				"slotTemplate": slot_name,
				"equippedItemId": equipped,
				"itemCustomizations": _slot_customizations_from_active_variants(slot_obj.get("activeVariants", [])),
			}
		)

	return {
		"deploymentId": deployment_id,
		"accountId": account_id,
		"loadoutType": loadout_type,
		"loadoutShuffleType": "DISABLED",
		"athenaItemId": athena_item_id,
		"creationTime": now,
		"updatedTime": now,
		"loadoutSlots": loadout_slots,
	}


def _apply_locker_slots_to_item(locker_item: dict[str, Any], loadout_slots: list[dict[str, Any]]) -> None:
	slots = locker_item.setdefault("attributes", {}).setdefault("locker_slots_data", {}).setdefault("slots", {})
	for slot in loadout_slots:
		if not isinstance(slot, dict):
			continue
		slot_template = str(slot.get("slotTemplate", "")).strip()
		if not slot_template:
			continue
		equipped_item = str(slot.get("equippedItemId", "") or "")
		slot_obj = slots.setdefault(slot_template, {"items": []})
		slot_obj["items"] = [equipped_item]
		customizations = slot.get("itemCustomizations", [])
		if isinstance(customizations, list) and customizations:
			variants: list[dict[str, Any]] = []
			for c in customizations:
				if not isinstance(c, dict):
					continue
				channel = str(c.get("channelTag", ""))
				variant_tag = str(c.get("variantTag", ""))
				additional = str(c.get("additionalData", ""))
				if not channel:
					continue
				active = f"{variant_tag}.{additional}" if additional else variant_tag
				variants.append({"channel": channel, "active": active, "owned": []})
			slot_obj["activeVariants"] = [{"variants": variants}]


@app.get("/api/locker/v3/{deployment_id}/account/{account_id}/items")
def locker_v3_get(deployment_id: str, account_id: str) -> dict[str, Any]:
	profile, locker_item_id = _ensure_athena_locker_profile(account_id)
	locker_item = profile.setdefault("items", {}).get(locker_item_id, {})
	loadout = _locker_v3_loadout_from_item(deployment_id, account_id, "CosmeticLoadout:cosmetic_loadout_athena", locker_item_id, locker_item)
	save_profile("athena", profile)
	return {"activeLoadouts": [loadout], "loadoutPresets": [loadout]}


@app.put("/api/locker/v3/{deployment_id}/loadout/{loadout_type}/account/{account_id}/active-loadout")
def locker_v3_set(deployment_id: str, loadout_type: str, account_id: str, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	profile, locker_item_id = _ensure_athena_locker_profile(account_id)
	items = profile.setdefault("items", {})
	locker_item = items.get(locker_item_id, {})
	loadout_slots = payload.get("loadoutSlots", [])
	if isinstance(loadout_slots, list):
		_apply_locker_slots_to_item(locker_item, loadout_slots)
	items[locker_item_id] = locker_item
	save_profile("athena", profile)
	return _locker_v3_loadout_from_item(deployment_id, account_id, loadout_type, locker_item_id, locker_item)


@app.get("/api/locker/v4/{deployment_id}/account/{account_id}/items")
def locker_v4_get(deployment_id: str, account_id: str) -> dict[str, Any]:
	profile, locker_item_id = _ensure_athena_locker_profile(account_id)
	locker_item = profile.setdefault("items", {}).get(locker_item_id, {})
	loadout = _locker_v3_loadout_from_item(deployment_id, account_id, "CosmeticLoadout:cosmetic_loadout_athena", locker_item_id, locker_item)
	save_profile("athena", profile)
	return {
		"activeLoadoutGroup": {
			"accountId": account_id,
			"athenaItemId": "lawinsathenaitemidlol",
			"creationTime": utc_now_iso(),
			"deploymentId": deployment_id,
			"loadouts": {
				loadout["loadoutType"]: {
					"loadoutSlots": loadout["loadoutSlots"],
					"shuffleType": "DISABLED",
				}
			},
		},
		"loadoutGroupPresets": [],
		"loadoutPresets": [loadout],
	}


@app.put("/api/locker/v4/{deployment_id}/account/{account_id}/active-loadout-group")
def locker_v4_set(deployment_id: str, account_id: str, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	profile, locker_item_id = _ensure_athena_locker_profile(account_id)
	items = profile.setdefault("items", {})
	locker_item = items.get(locker_item_id, {})
	loadouts = payload.get("loadouts", {})
	if isinstance(loadouts, dict):
		for _, loadout_payload in loadouts.items():
			if not isinstance(loadout_payload, dict):
				continue
			loadout_slots = loadout_payload.get("loadoutSlots", [])
			if isinstance(loadout_slots, list):
				_apply_locker_slots_to_item(locker_item, loadout_slots)
	items[locker_item_id] = locker_item
	save_profile("athena", profile)
	return {
		"deploymentId": deployment_id,
		"accountId": account_id,
		"athenaItemId": "lawinsathenaitemidlol",
		"creationTime": utc_now_iso(),
		"updatedTime": utc_now_iso(),
		"loadouts": payload.get("loadouts", {}),
		"shuffleType": "DISABLED",
	}


@app.post("/api/locker/v4/{deployment_id}/account/{account_id}/lock-in-immutable-item/{cosmetic_item_id}")
def locker_v4_lock_immutable(deployment_id: str, account_id: str, cosmetic_item_id: str, payload: dict[str, Any] = Body(default={})) -> Response:
	profile, _ = _ensure_athena_locker_profile(account_id)
	item_guid = cosmetic_item_id.split(":")[-1] if ":" in cosmetic_item_id else cosmetic_item_id
	item = profile.setdefault("items", {}).get(item_guid)
	if item:
		variants = item.setdefault("attributes", {}).setdefault("variants", [])
		for channel, data in (payload.get("variants", {}) or {}).items():
			variant_tag = ""
			if isinstance(data, dict):
				variant_tag = str(data.get("variantTag", ""))
			if channel and variant_tag:
				variants.append({"channel": str(channel), "active": variant_tag, "owned": []})
		item.setdefault("attributes", {})["locked_in"] = True
		save_profile("athena", profile)
	return Response(status_code=204)


@app.patch("/api/locker/v4/{deployment_id}/account/{account_id}/companion-name")
def locker_v4_companion_name(deployment_id: str, account_id: str, payload: dict[str, Any] = Body(default={})) -> Response:
	profile, _ = _ensure_athena_locker_profile(account_id)
	cosmetic_item_id = str(payload.get("cosmeticItemId", ""))
	companion_name = str(payload.get("companionName", ""))
	if cosmetic_item_id and companion_name:
		item_guid = cosmetic_item_id.split(":")[-1]
		item = profile.setdefault("items", {}).get(item_guid)
		if item:
			variants = item.setdefault("attributes", {}).setdefault("variants", [])
			variants.append({"channel": "CustomName", "active": companion_name, "owned": []})
			save_profile("athena", profile)
	return Response(status_code=204)


@app.get("/fortnite/api/version")
def fortnite_version() -> dict[str, Any]:
	return {
		"app": "fortnite",
		"serverDate": utc_now_iso(),
		"overridePropertiesVersion": "unknown",
		"cln": "17951730",
		"build": "444",
		"moduleName": "Fortnite-Core",
		"buildDate": "2021-10-27T21:00:51.697Z",
		"version": "18.30",
		"branch": "Release-18.30",
		"modules": {
			"Epic-LightSwitch-AccessControlCore": {
				"cln": "17237679",
				"build": "b2130",
				"buildDate": "2021-08-19T18:56:08.144Z",
				"version": "1.0.0",
				"branch": "trunk",
			},
			"epic-common-core": {
				"cln": "17909521",
				"build": "3217",
				"buildDate": "2021-10-25T18:41:12.486Z",
				"version": "3.0",
				"branch": "TRUNK",
			},
		},
	}


@app.get("/fortnite/api/v2/versioncheck")
@app.get("/fortnite/api/v2/versioncheck/{rest:path}")
@app.get("/fortnite/api/versioncheck")
@app.get("/fortnite/api/versioncheck/{rest:path}")
def fortnite_versioncheck(rest: str = "") -> dict[str, str]:
	return {"type": "NO_UPDATE"}


def get_discovery_data() -> dict[str, Any]:
	return load_json(RESPONSES_DIR / "Athena" / "Discovery" / "discovery_frontend.json", {"v1": {}, "v2": {}})


def _discovery_results(channel: dict[str, Any]) -> list[dict[str, Any]]:
	results: list[dict[str, Any]] = []
	for panel in channel.get("Panels", []) or []:
		if not isinstance(panel, dict):
			continue
		first_page = panel.get("FirstPage")
		if isinstance(first_page, dict):
			for row in first_page.get("results", []) or []:
				if isinstance(row, dict):
					results.append(row)
		for page in panel.get("Pages", []) or []:
			if not isinstance(page, dict):
				continue
			for row in page.get("results", []) or []:
				if isinstance(row, dict):
					results.append(row)
	return results


def _discovery_link_index(discovery: dict[str, Any]) -> dict[str, dict[str, Any]]:
	links_by_mnemonic: dict[str, dict[str, Any]] = {}
	for source_name in ("v2", "v1"):
		channel = discovery.get(source_name, {})
		if not isinstance(channel, dict):
			continue
		for row in _discovery_results(channel):
			link_data = row.get("linkData")
			if not isinstance(link_data, dict):
				continue
			mnemonic = str(link_data.get("mnemonic", "")).strip()
			if mnemonic and mnemonic not in links_by_mnemonic:
				links_by_mnemonic[mnemonic] = link_data
	return links_by_mnemonic


def _fallback_link_data(mnemonic: str) -> dict[str, Any]:
	return {
		"namespace": "fn",
		"mnemonic": mnemonic,
		"linkType": "BR:Playlist",
		"active": True,
		"disabled": False,
		"version": 1,
		"moderationStatus": "Unmoderated",
		"accountId": "epic",
		"creatorName": "Epic",
		"descriptionTags": [],
		"metadata": {
			"matchmaking": {
				"override_playlist": mnemonic,
			}
		},
	}


@app.post("/api/v2/discovery/surface/{rest:path}")
@app.post("/{prefix:path}/api/v2/discovery/surface/{rest:path}")
def discovery_surface_v2(rest: str, prefix: str = "") -> Any:
	discovery = get_discovery_data()
	return discovery.get("v2", {})


@app.post("/discovery/surface/{rest:path}")
@app.post("/{prefix:path}/discovery/surface/{rest:path}")
def discovery_surface_v1(rest: str, prefix: str = "") -> Any:
	discovery = get_discovery_data()
	return discovery.get("v1", {})


@app.get("/fortnite/api/discovery/accessToken/{branch}")
def discovery_access_token(branch: str) -> dict[str, str]:
	return {
		"branchName": branch,
		"appId": "Fortnite",
		"token": "lawinstokenlol",
	}


@app.post("/links/api/fn/mnemonic")
def links_mnemonic() -> list[dict[str, Any]]:
	discovery = get_discovery_data()
	index = _discovery_link_index(discovery)
	return list(index.values())


@app.get("/links/api/fn/mnemonic/{playlist}/related")
def links_related(playlist: str) -> dict[str, Any]:
	discovery = get_discovery_data()
	index = _discovery_link_index(discovery)
	response = {"parentLinks": [], "links": {}}
	if playlist in index:
		response["links"][playlist] = index[playlist]
	return response


@app.get("/links/api/fn/mnemonic/{mnemonic:path}")
def links_mnemonic_single(mnemonic: str) -> Any:
	discovery = get_discovery_data()
	index = _discovery_link_index(discovery)
	needle = mnemonic.split("/")[-1]
	if needle in index:
		return index[needle]
	if ENABLE_TINY_COMPAT_BOOSTS:
		return _fallback_link_data(needle)
	return {}


@app.post("/api/v1/links/lock-status/{account_id}/check")
def links_lock_status(account_id: str, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
	response = {"results": [], "hasMore": False}
	for code in payload.get("linkCodes", []) or []:
		response["results"].append(
			{
				"playerId": account_id,
				"linkCode": code,
				"lockStatus": "UNLOCKED",
				"lockStatusReason": "NONE",
				"isVisible": True,
			}
		)
	return response


@app.get("/eulatracking/api/shared/agreements/{rest:path}")
def eula_agreements(rest: str) -> dict[str, Any]:
	return {}


@app.get("/fortnite/api/game/v2/friendcodes/{rest:path}/epic")
def friend_codes(rest: str) -> list[dict[str, str]]:
	return [
		{"codeId": "L4WINS3RV3R", "codeType": "CodeToken:FounderFriendInvite", "dateCreated": "2024-04-02T21:37:00.420Z"},
		{"codeId": "playeereq", "codeType": "CodeToken:FounderFriendInvite_XBOX", "dateCreated": "2024-04-02T21:37:00.420Z"},
		{"codeId": "lawinscodelol", "codeType": "CodeToken:MobileInvite", "dateCreated": "2024-04-02T21:37:00.420Z"},
	]


@app.get("/clearitemsforshop")
def clear_items_for_shop() -> PlainTextResponse:
	athena_path = PROFILES_DIR / "athena.json"
	catalog_config_path = CONFIG_DIR / "catalog_config.json"

	athena = load_json(athena_path, {})
	catalog_config = load_json(catalog_config_path, {})
	items = athena.get("items", {})
	changed = False

	for value in catalog_config.values():
		if not isinstance(value, dict):
			continue
		for grant in value.get("itemGrants", []):
			if not isinstance(grant, str) or not grant:
				continue
			for item_key in list(items.keys()):
				if str(items[item_key].get("templateId", "")).lower() == grant.lower():
					del items[item_key]
					changed = True

	if changed:
		athena["rvn"] = int(athena.get("rvn", 0)) + 1
		athena["commandRevision"] = int(athena.get("commandRevision", 0)) + 1
		save_json(athena_path, athena)
		return PlainTextResponse("Success")

	return PlainTextResponse("Failed, there are no items to remove")


@app.post("/fortnite/api/game/v2/grant_access/{rest:path}")
def grant_access(rest: str) -> dict[str, Any]:
	return {}


@app.post("/api/v1/user/setting")
def user_setting() -> list[Any]:
	return []


@app.get("/fortnite/api/stats/accountId/{account_id}/bulk/window/alltime")
def old_stats_alltime(account_id: str) -> dict[str, Any]:
	return {"startTime": 0, "endTime": 0, "stats": {}, "accountId": account_id}


@app.get("/d98eeaac-2bfa-4bf4-8a59-bdc95469c693")
def dash_playlist() -> dict[str, Any]:
	return {
		"uri": "https://fortnite-public-service-prod11.ol.epicgames.com/ummqUqCSFUWeQfzTvs/f2528fa1-5f30-42ff-8ae5-a03e3b023a0a/playlist.mpd",
		"method": "GET",
		"headers": {},
		"parameters": {},
		"playlist": "",
		"playlistType": "application/dash+xml",
		"metadata": {
			"assetId": "",
			"baseUrls": ["https://fortnite-public-service-prod11.ol.epicgames.com/ummqUqCSFUWeQfzTvs/f2528fa1-5f30-42ff-8ae5-a03e3b023a0a/"],
			"supportsCaching": True,
			"ucp": "a",
			"version": "f2528fa1-5f30-42ff-8ae5-a03e3b023a0a",
		},
	}


@app.post("/fortnite/api/game/v2/events/v2/setSubgroup/{rest:path}")
def set_subgroup(rest: str) -> Response:
	return Response(status_code=204)


@app.get("/fortnite/api/game/v2/events/v2/account/{account_id}")
def events_v2_account(account_id: str) -> dict[str, Any]:
	return {"accountId": account_id, "tokens": [], "drops": []}


@app.get("/fortnite/api/game/v2/events/v2/awards/{account_id}")
def events_v2_awards(account_id: str) -> dict[str, Any]:
	return {"accountId": account_id, "awards": []}


@app.get("/v1/item/{rest:path}")
def sidekick_item(rest: str) -> Response:
	image = PUBLIC_DIR / "public" / "images" / "lawinpfp.png"
	if image.exists():
		return FileResponse(image, media_type="image/png")
	return Response(status_code=404)


@app.get("/fortnite/api/game/v2/events/tournamentandhistory/{rest:path}")
def tournament_and_history(rest: str) -> Any:
	return load_json(RESPONSES_DIR / "Athena" / "Tournament" / "tournamentandhistory.json", {})


@app.get("/api/v1/events/Fortnite/download/{account_id}")
def tournament_download(account_id: str, request: Request) -> Any:
	memory = parse_version_info(request)
	tournament = clone_json(RESPONSES_DIR / "Athena" / "Tournament" / "tournament.json", {})
	player = tournament.get("player", {})
	player["accountId"] = account_id

	if memory["season"] >= 33:
		for event in tournament.get("events", []):
			event["beginTime"] = "2024-01-01T17:00:00Z"
			event["endTime"] = "9999-01-01T20:00:00Z"
			for window in event.get("eventWindows", []):
				window["countdownBeginTime"] = "2024-01-01T15:00:00Z"
				window["beginTime"] = "2024-01-01T17:00:00Z"
				window["endTime"] = "9999-01-01T20:00:00Z"

	return tournament


@app.get("/api/v1/players/Fortnite/tokens")
def player_tokens(teamAccountIds: str = "") -> dict[str, Any]:
	tournament = load_json(RESPONSES_DIR / "Athena" / "Tournament" / "tournament.json", {})
	tokens = tournament.get("player", {}).get("tokens", [])
	accounts = []
	for account_id in [x for x in teamAccountIds.split(",") if x]:
		accounts.append({"accountId": account_id, "tokens": tokens})
	return {"accounts": accounts}


@app.get("/api/v1/leaderboards/Fortnite/{event_id}/{event_window_id}/{account_id}")
def leaderboard_by_account(event_id: str, event_window_id: str, account_id: str) -> Any:
	leaderboard = clone_json(RESPONSES_DIR / "Athena" / "Tournament" / "leaderboard.json", {})
	hero_names = clone_json(RESPONSES_DIR / "Campaign" / "heroNames.json", [])
	random.shuffle(hero_names)
	hero_names = [account_id] + hero_names

	leaderboard["eventId"] = event_id
	leaderboard["eventWindowId"] = event_window_id

	entry = leaderboard.get("entryTemplate", {})
	entries = []
	for idx, name in enumerate(hero_names[:100]):
		new_entry = deepcopy(entry)
		new_entry["teamAccountIds"] = [name]
		new_entry["rank"] = idx + 1
		new_entry["pointsEarned"] = random.randint(1, 250)
		new_entry["score"] = float(new_entry["pointsEarned"])
		entries.append(new_entry)

	leaderboard["entries"] = entries
	return leaderboard


@app.get("/fortnite/api/game/v2/twitch/{rest:path}")
def twitch_presence(rest: str) -> Response:
	return Response(status_code=200)


@app.get("/fortnite/api/game/v2/world/info")
def world_info(request: Request) -> Any:
	memory = parse_version_info(request)
	theater_str = json.dumps(clone_json(RESPONSES_DIR / "Campaign" / "worldstw.json", {}))

	# Lawin compatibility transforms for mid/newer STW builds.
	if memory["build"] >= 30.20:
		theater_str = theater_str.replace("/Game/World/ZoneThemes", "/STW_Zones/World/ZoneThemes")
		theater_str = theater_str.replace('"DataTable\'/Game/', '"/Script/Engine.DataTable\'/Game/')

	if memory["build"] >= 15.30:
		theater_str = theater_str.replace("/Game/", "/SaveTheWorld/")
		theater_str = theater_str.replace('"DataTable\'/SaveTheWorld/', '"DataTable\'/Game/')

	try:
		return json.loads(theater_str)
	except Exception:
		return load_json(RESPONSES_DIR / "Campaign" / "worldstw.json", {})


@app.post("/fortnite/api/game/v2/chat/{a}/{b}/{c}/pc")
def chat_channels(a: str, b: str, c: str) -> dict[str, Any]:
	return {"GlobalChatRooms": [{"roomName": "lawinserverpyglobal"}]}


@app.post("/fortnite/api/game/v2/chat/{rest:path}/recommendGeneralChatRooms/pc")
def chat_recommend(rest: str) -> dict[str, Any]:
	account_id = rest.split("/")[0] if rest else "unknown"
	return {
		"presencePermissions": {},
		"joinPermissions": {},
		"chatRoomId": f"Fortnite:recommended-{account_id}",
		"chatRoomSubType": "Default",
		"chatRooms": [
			{
				"roomId": "Fortnite:recommended",
				"roomSubType": "Default",
				"presencePermissions": {},
				"joinPermissions": {},
			}
		],
	}


@app.post("/fortnite/api/game/v2/chat/{rest:path}/reserveGeneralChatRooms/pc")
def chat_reserve(rest: str) -> dict[str, Any]:
	account_id = rest.split("/")[0] if rest else "unknown"
	return {
		"presencePermissions": {},
		"joinPermissions": {},
		"chatRoomId": f"Fortnite:recommended-{account_id}",
		"chatRoomSubType": "Default",
		"chatRooms": [
			{
				"roomId": "Fortnite:recommended",
				"roomSubType": "Default",
				"presencePermissions": {},
				"joinPermissions": {},
			}
		],
	}


@app.get("/presence/api/v1/_/{rest:path}/last-online")
def presence_last_online(rest: str) -> list[Any]:
	return []


@app.get("/fortnite/api/receipts/v1/account/{rest:path}/receipts")
def receipts(rest: str) -> list[Any]:
	return []


@app.get("/fortnite/api/game/v2/leaderboards/cohort/{account_id}")
def leaderboard_cohort(account_id: str, playlist: str = "") -> dict[str, Any]:
	return {
		"accountId": account_id,
		"cohortAccounts": [account_id, "Ducki67", "TI93", "PRO100KatYT", "Playeereq", "Matteoki"],
		"expiresAt": "9999-12-31T00:00:00.000Z",
		"playlist": playlist,
	}


@app.post("/fortnite/api/leaderboards/type/group/stat/{stat_name}/window/{stat_window}")
def leaderboard_group(stat_name: str, stat_window: str, payload: list[str] = Body(default=[])) -> dict[str, Any]:
	entries = [{"accountId": account, "value": random.randint(1, 68)} for account in payload]
	return {"entries": entries, "statName": stat_name, "statWindow": stat_window}


@app.post("/fortnite/api/leaderboards/type/global/stat/{stat_name}/window/{stat_window}")
def leaderboard_global(stat_name: str, stat_window: str) -> dict[str, Any]:
	hero_names = load_json(RESPONSES_DIR / "Campaign" / "heroNames.json", [])
	entries = [{"accountId": name, "value": random.randint(1, 68)} for name in hero_names[:300]]
	return {"entries": entries, "statName": stat_name, "statWindow": stat_window}


@app.get("/fortnite/api/game/v2/homebase/allowed-name-chars")
def allowed_name_chars() -> dict[str, Any]:
	return {
		"ranges": [48, 57, 65, 90, 97, 122, 192, 255, 1024, 1279, 44032, 55215],
		"singlePoints": [32, 39, 45, 46, 95, 126],
		"excludedPoints": [208, 215, 222, 247],
	}


@app.post("/api/v1/assets/Fortnite/{rest:path}")
def discovery_assets(rest: str, payload: dict[str, Any] = Body(default={})) -> Any:
	if payload.get("FortCreativeDiscoverySurface") == 0:
		return load_json(RESPONSES_DIR / "Athena" / "Discovery" / "discovery_api_assets.json", {})

	return {
		"FortCreativeDiscoverySurface": {
			"meta": {
				"promotion": payload.get("FortCreativeDiscoverySurface", 0),
			},
			"assets": {},
		}
	}


@app.get("/region")
def region_info() -> dict[str, Any]:
	return {
		"continent": {
			"code": "EU",
			"geoname_id": 6255148,
			"names": {
				"en": "Europe",
			},
		},
		"country": {
			"geoname_id": 2635167,
			"iso_code": "GB",
			"names": {
				"en": "United Kingdom",
			},
		},
	}


@app.api_route("/v1/epic-settings/public/users/{rest:path}/values", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
def epic_settings_values(rest: str) -> Any:
	return load_json(RESPONSES_DIR / "epic-settings.json", {})


@app.get("/fortnite/api/game/v2/br-inventory/account/{rest:path}")
def br_inventory(rest: str) -> dict[str, Any]:
	return {"stash": {"globalcash": 5000}}


@app.get("/fortnite/api/game/v2/creative/island/config/{rest:path}")
def creative_island_config(rest: str) -> dict[str, Any]:
	return {}


@app.post("/fortnite/api/game/v2/creative/island/config/{rest:path}")
def creative_island_config_post(rest: str) -> Response:
	return Response(status_code=204)


@app.get("/fortnite/api/game/v2/islands/config/{rest:path}")
def islands_config(rest: str) -> dict[str, Any]:
	return {}


@app.post("/fortnite/api/game/v2/islands/config/{rest:path}")
def islands_config_post(rest: str) -> Response:
	return Response(status_code=204)


@app.exception_handler(404)
async def not_found_handler(request: Request, exc: Exception) -> JSONResponse:
	return JSONResponse(
		{
			"errorCode": "errors.com.lawinserverpy.common.not_found",
			"errorMessage": "The requested endpoint was not found.",
			"messageVars": [],
			"numericErrorCode": 1004,
			"originatingService": "LawinServer.py",
			"intent": "prod",
			"error_description": "The requested endpoint was not found.",
			"error": "not_found",
		},
		status_code=404,
		headers={
			"X-Epic-Error-Name": "errors.com.lawinserverpy.common.not_found",
			"X-Epic-Error-Code": "1004",
		},
	)

