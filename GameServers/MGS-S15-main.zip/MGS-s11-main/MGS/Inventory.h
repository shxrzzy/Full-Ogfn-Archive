#pragma once
#include "Utils.h"
#include <numeric>

bool IsPrimaryQuickbar(UFortItemDefinition* ItemDefinition)
{
	if (ItemDefinition->IsA(UFortConsumableItemDefinition::StaticClass()) ||
		ItemDefinition->IsA(UFortWeaponRangedItemDefinition::StaticClass()) ||
		ItemDefinition->IsA(UFortGadgetItemDefinition::StaticClass()))
	{
		return true;
	}

	if (ItemDefinition->GetFullName().contains("UncleBrolly") ||
		ItemDefinition->GetFullName().contains("D_Athena_Keycard"))
	{
		return true;
	}

	static auto FortWeaponMeleeItemDefinitionClass = StaticFindObject<UClass>(L"/Script/FortniteGame.FortWeaponMeleeItemDefinition");
	static auto FortEditToolItemDefinitionClass = StaticFindObject<UClass>(L"/Script/FortniteGame.FortEditToolItemDefinition");
	static auto FortBuildingItemDefinitionClass = StaticFindObject<UClass>(L"/Script/FortniteGame.FortBuildingItemDefinition");
	static auto FortAmmoItemDefinitionClass = StaticFindObject<UClass>(L"/Script/FortniteGame.FortAmmoItemDefinition");
	static auto FortResourceItemDefinitionClass = StaticFindObject<UClass>(L"/Script/FortniteGame.FortResourceItemDefinition");
	static auto FortTrapItemDefinitionClass = StaticFindObject<UClass>(L"/Script/FortniteGame.FortTrapItemDefinition");

	if (!ItemDefinition->IsA(FortWeaponMeleeItemDefinitionClass) &&
		!ItemDefinition->IsA(FortEditToolItemDefinitionClass) &&
		!ItemDefinition->IsA(FortBuildingItemDefinitionClass) &&
		!ItemDefinition->IsA(FortAmmoItemDefinitionClass) &&
		!ItemDefinition->IsA(FortResourceItemDefinitionClass) &&
		!ItemDefinition->IsA(FortTrapItemDefinitionClass))
	{
		return true;
	}

	return false;
}

float GetMaxStack(UFortItemDefinition* Def) 
{
	return Def->MaxStackSize;
}

FFortItemEntry* GiveItem(AFortPlayerController* PC, UFortItemDefinition* Def, int Count, int LoadedAmmo, bool Stack)
{
	if (!PC || !Def || Count <= 0)
		return nullptr;

	if (Stack)
	{
		int MaxStackSize = Def->MaxStackSize;

		for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			auto& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];
			if (Entry.ItemDefinition == Def && Entry.Count < MaxStackSize)
			{
				int NewCount = Entry.Count + Count;
				Entry.Count = (NewCount > MaxStackSize) ? MaxStackSize : NewCount;

			    Entry.LoadedAmmo = LoadedAmmo;

				PC->WorldInventory->Inventory.MarkItemDirty(Entry);

				PC->WorldInventory->bRequiresLocalUpdate = true;
				PC->WorldInventory->HandleInventoryLocalUpdate();
				PC->HandleWorldInventoryLocalUpdate();
				PC->ClientForceUpdateQuickbar(EFortQuickBars::Primary);
				PC->ClientForceUpdateQuickbar(EFortQuickBars::Secondary);

				return &Entry;
			}
		}
	}

	UFortWorldItem* Item = Cast<UFortWorldItem>(Def->CreateTemporaryItemInstanceBP(Count, 0));
	if (!Item)
		return nullptr;

	Item->SetOwningControllerForTemporaryItem(PC);
	Item->OwnerInventory = PC->WorldInventory;
	Item->ItemEntry.ItemDefinition = Def;
	Item->ItemEntry.Count = Count;
	Item->ItemEntry.LoadedAmmo = LoadedAmmo;

	FFortItemEntryStateValue Value{};
	Value.IntValue = true;
	Value.StateType = EFortItemEntryState::ShouldShowItemToast;
	Item->ItemEntry.StateValues.Add(Value);

	Item->ItemEntry.ReplicationKey++;

	PC->WorldInventory->Inventory.ReplicatedEntries.Add(Item->ItemEntry);
	PC->WorldInventory->Inventory.ItemInstances.Add(Item);

	//if (auto Gadget = Cast<UFortGadgetItemDefinition>(Def))
	//{
		//((bool(*)(UFortGadgetItemDefinition*, IInterface*, UFortWorldItem*, uint8)) (InSDKUtils::GetImageBase() + 0x693C810))(Gadget,GetInterface<IFortInventoryOwnerInterface>(PC),Item,1);
	//}

	PC->WorldInventory->Inventory.MarkItemDirty(Item->ItemEntry);

	PC->WorldInventory->bRequiresLocalUpdate = true;
	PC->WorldInventory->HandleInventoryLocalUpdate();
	PC->HandleWorldInventoryLocalUpdate();
	PC->ClientForceUpdateQuickbar(EFortQuickBars::Primary);
	PC->ClientForceUpdateQuickbar(EFortQuickBars::Secondary);

	return &Item->ItemEntry;
}

void RemoveItem(AFortPlayerController* PC, UFortItemDefinition* Def, int Count, FGuid Guid)
{
	bool Remove = false;

	for (int i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		auto& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

		if (Entry.ItemGuid == Guid)
		{
			Entry.Count -= Count;

			if (Entry.Count <= 0)
			{
				Entry.StateValues.Free();
				PC->WorldInventory->Inventory.ReplicatedEntries.RemoveSingle(i);
				Remove = true;
			}
			else
			{
				PC->WorldInventory->Inventory.MarkItemDirty(Entry);

				for (int j = 0; j < PC->WorldInventory->Inventory.ItemInstances.Num(); j++)
				{
					if (PC->WorldInventory->Inventory.ItemInstances[j]->ItemEntry.ItemGuid == Guid)
					{
						PC->WorldInventory->Inventory.ItemInstances[j]->ItemEntry = Entry;
						PC->WorldInventory->Inventory.MarkItemDirty(Entry);
						break;
					}
				}

				PC->WorldInventory->HandleInventoryLocalUpdate();
				return;
			}

			break;
		}
	}

	if (Remove)
	{
		for (int i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
		{
			if (PC->WorldInventory->Inventory.ItemInstances[i]->GetItemGuid() == Guid)
			{
				PC->WorldInventory->Inventory.ItemInstances.RemoveSingle(i);
				break;
			}
		}
	}

	PC->WorldInventory->Inventory.MarkArrayDirty();
	PC->WorldInventory->HandleInventoryLocalUpdate();
}

__int64 (*OnReloadOG)(AFortWeapon* Weapon, int RemoveCount);
__int64 OnReload(AFortWeapon* Weapon, int RemoveCount)
{
	Log("Called onreload");
	AFortGameModeAthena* GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;

	auto GameState = (AFortGameStateAthena*)GameMode->GameState;

	auto Ret = OnReloadOG(Weapon, RemoveCount);
	auto WeaponDef = Weapon->WeaponData;
	if (!WeaponDef)
		return Ret;

	auto AmmoDef = WeaponDef->GetAmmoWorldItemDefinition_BP();
	if (!AmmoDef)
		return Ret;

	AFortPlayerPawnAthena* Pawn = (AFortPlayerPawnAthena*)Weapon->GetOwner();
	AFortPlayerControllerAthena* PC = (AFortPlayerControllerAthena*)Pawn->Controller;
	AFortPlayerStateAthena* PlayerState = (AFortPlayerStateAthena*)PC->PlayerState;
	if (!PC || !PC->Pawn || !PC->IsA(AFortPlayerControllerAthena::StaticClass()) || &PC->WorldInventory->Inventory == nullptr || GameState->GamePhase >= EAthenaGamePhase::EndGame)
		return Ret;

	if (PC->bInfiniteAmmo) {
		for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Weapon->ItemEntryGuid)
			{
				PC->WorldInventory->Inventory.ReplicatedEntries[i].LoadedAmmo += RemoveCount;
				for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
				{
					if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid)
					{
						PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry = PC->WorldInventory->Inventory.ReplicatedEntries[i];
						PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
						break;
					}
				}
				PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
				break;
			}
		}
		return Ret;
	}

	int AmmoCount = 0;
	FFortItemEntry* FoundEntry = nullptr;
	for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		FFortItemEntry& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

		if (Entry.ItemDefinition == AmmoDef) {
			AmmoCount = Entry.Count;
			FoundEntry = &Entry;
			break;
		}
	}

	int AmmoToRemove = (RemoveCount < AmmoCount) ? RemoveCount : AmmoCount;

	if (AmmoToRemove > 0) {
		RemoveItem(PC, AmmoDef, AmmoToRemove, FoundEntry->ItemGuid);
		for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Weapon->ItemEntryGuid)
			{
				PC->WorldInventory->Inventory.ReplicatedEntries[i].LoadedAmmo += AmmoToRemove;
				for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
				{
					if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid)
					{
						PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry = PC->WorldInventory->Inventory.ReplicatedEntries[i];
						PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
						break;
					}
				}
				PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
				break;
			}
		}

	}

	if (WeaponDef == StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Shields/Athena_Shields.Athena_Shields"))
	{
		FGameplayEffectContextHandle Handle = PlayerState->AbilitySystemComponent->MakeEffectContext();
		FGameplayTag tag{};
		static auto name = UKismetStringLibrary::GetDefaultObj()->Conv_StringToName(TEXT("GameplayCue.Shield.PotionConsumed"));
		tag.TagName = name;

		//PlayerState->AbilitySystemComponent->NetMulticast_InvokeGameplayCueAdded(tag, FPredictionKey(), Handle);
		PlayerState->AbilitySystemComponent->NetMulticast_InvokeGameplayCueExecuted(tag, FPredictionKey(), Handle);
	}

	if (WeaponDef == StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Medkit/Athena_Medkit.Athena_Medkit"))
	{
		FGameplayEffectContextHandle Handle = PlayerState->AbilitySystemComponent->MakeEffectContext();
		FGameplayTag tag;
		static auto name = UKismetStringLibrary::GetDefaultObj()->Conv_StringToName(TEXT("GameplayCue.Athena.Health.HealUsed"));
		tag.TagName = name;

		//PlayerState->AbilitySystemComponent->NetMulticast_InvokeGameplayCueAdded(tag, FPredictionKey(), Handle);
		PlayerState->AbilitySystemComponent->NetMulticast_InvokeGameplayCueExecuted(tag, FPredictionKey(), Handle);
	}

	PC->WorldInventory->bRequiresLocalUpdate = true;
	//PC->WorldInventory->Inventory.MarkItemDirty();
	PC->WorldInventory->HandleInventoryLocalUpdate();

	return Ret;
}

inline void (*NetMulticast_BatchedDamageCuesOG)(AFortPawn* Pawn, void* SharedData, void* NonSharedData);
inline void NetMulticast_BatchedDamageCues(AFortPawn* Pawn, void* SharedData, void* NonSharedData)
{
	if (!Pawn || Pawn->Controller->IsA(ABP_PhoebePlayerController_C::StaticClass()) || !NetMulticast_BatchedDamageCuesOG)
		return;

	auto PC = (AFortPlayerController*)Pawn->Controller;
	auto Weapon = ((AFortPlayerPawn*)Pawn)->CurrentWeapon;

	if (Weapon)
	{
		for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Weapon->ItemEntryGuid)
			{
				PC->WorldInventory->Inventory.ReplicatedEntries[i].LoadedAmmo = Weapon->AmmoCount;
				for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
				{
					if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid)
					{
						PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry = PC->WorldInventory->Inventory.ReplicatedEntries[i];
						PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
						break;
					}
				}
				PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
				break;
			}
		}
	}

	return NetMulticast_BatchedDamageCuesOG(Pawn, SharedData, NonSharedData);
}
