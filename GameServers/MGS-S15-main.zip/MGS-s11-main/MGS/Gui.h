#pragma once
#include <tchar.h>
#include "Hooking.h"
#include "minhook/MinHook.h"
#include <windows.h>
#include <commctrl.h>
#include <dwmapi.h>
#include <map>
#include <string>
#include <uxtheme.h>
#include <windowsx.h>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "uxtheme.lib")
#pragma comment(lib, "minhook/minhook.lib")

#define DARK_BG_COLOR RGB(30, 30, 30)
#define DARK_TEXT_COLOR RGB(220, 220, 220)

//there must be a better way bro this is skunked af i hate vs
namespace Gamemode {
    void InitHooks();
}

namespace Misc {
    void InitHooks();
}

namespace PC {
    void InitHooks();
}

namespace Tick {
    void InitHooks();
}

namespace Abilities {
    void InitHooks();
}

namespace Inventory {
    void InitHooks();
}

namespace Building {
    void InitHooks();
}

bool bStarted = false;
bool Botlobbies = false;
bool LateGame = false;
static int SelectedIndex = 0;
HWND hSlider, hCombo;
HWND hSliderValueLabel = nullptr;
HWND hStatusLabel = nullptr;
HWND hwndMain = nullptr;
HBRUSH hBrushBackground = CreateSolidBrush(RGB(30, 30, 30)); 
HBRUSH hDarkBrush = CreateSolidBrush(RGB(45, 45, 48));
HWND hStartButton = nullptr;
HFONT hFont = nullptr;
bool g_isHovering = false;
bool g_mouseTracking = false;
WNDPROC Button;
WNDPROC Slider = nullptr;
WNDPROC ComboBox;
HWND hLateCheck = nullptr;
HWND hBotCheck = nullptr;
HWND hBotLabel = nullptr;
HWND hLateLabel = nullptr;
int currentValue = 1; 
const int minValue = 1;
const int maxValue = 100;
const int thumbWidth = 10;

std::map<int, std::pair<const wchar_t*, std::wstring>> ModeForPlaylist = {
    {0, { L"Solos", L"Playlist_DefaultSolo" }},
    {1, { L"Duos", L"Playlist_DefaultDuo" }},
    {2, { L"Squads", L"Playlist_DefaultSquad" }},
    {3, { L"Arsenal", L"Playlist_Gg_Reverse" }},
    {4, { L"Solid Gold (Solo)", L"Playlist_SolidGold_Solo" }},
    {5, { L"Solid Gold (Duo)", L"Playlist_SolidGold_Duos" }},
    {6, { L"Battle Lab", L"Playlist_BattleLab" }},
    {7, { L"Respawn Solos", L"Playlist_Respawn_Solo" }},
    {8, { L"Creative", L"Playlist_PlaygroundV2" }}
};

void AnimateStartingDots()
{
    const wchar_t* baseText = L"Server is starting";
    int dotCount = 0;

    while (!bStartedListening)
    {
        dotCount = (dotCount + 1) % 4;
        std::wstring text(baseText);
        for (int i = 0; i < dotCount; i++)
            text += L".";
        SetWindowText(hStatusLabel, text.c_str());
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    SetWindowText(hStatusLabel, L"Server is ready!");
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_COMMAND:
        switch (LOWORD(wParam))
        {
        case 1:
            bStarted = true;

            for (HWND child = GetWindow(hwnd, GW_CHILD); child != nullptr; child = GetWindow(child, GW_HWNDNEXT))
            {
                if (child != hStatusLabel)
                    ShowWindow(child, SW_HIDE);
            }

            SetWindowText(hStatusLabel, L"Server is starting");

            Gamemode::InitHooks();
            Tick::InitHooks();
            PC::InitHooks();
            Misc::InitHooks();
            Abilities::InitHooks();
            Inventory::InitHooks();
            Building::InitHooks();
            MH_EnableHook(0);

            if (ModeForPlaylist[SelectedIndex].second.find(L"Playlist_PlaygroundV2") != std::wstring::npos)
            {
                UKismetSystemLibrary::ExecuteConsoleCommand(UWorld::GetWorld(), L"open Creative_NoApollo_Terrain", nullptr);
            }
            else
            {
                UKismetSystemLibrary::ExecuteConsoleCommand(UWorld::GetWorld(), L"open Apollo_Terrain", nullptr);
            }

            UWorld::GetWorld()->OwningGameInstance->LocalPlayers.Remove(0);

            std::thread(AnimateStartingDots).detach();

            break;
        case 2:
            if ((HWND)lParam == hBotCheck && HIWORD(wParam) == BN_CLICKED)
            {
                Botlobbies = !Botlobbies;
                currentValue = Botlobbies ? 100 : 1;

                SendMessage(hSlider, TBM_SETPOS, TRUE, currentValue);
                InvalidateRect(hSlider, nullptr, TRUE); 
            }
            break;

        case 3: 
            LateGame = !LateGame;
            break;
        case 4: 
            if (HIWORD(wParam) == CBN_SELCHANGE)
            {
                SelectedIndex = SendMessage(hCombo, CB_GETCURSEL, 0, 0);
            }
            break;
        }
        break;

    case WM_CTLCOLORDLG:
    case WM_CTLCOLORSTATIC: {
        HDC hdcStatic = (HDC)wParam;
        SetTextColor(hdcStatic, RGB(200, 200, 200));  
        SetBkColor(hdcStatic, RGB(30, 30, 30));   
        return (INT_PTR)hBrushBackground;
    }

    case WM_DRAWITEM:
    {
        LPDRAWITEMSTRUCT pDIS = (LPDRAWITEMSTRUCT)lParam;

        if (pDIS->CtlID == 1) 
        {
            HDC hdc = pDIS->hDC;

            HBRUSH hbrBackground = CreateSolidBrush(RGB(30, 30, 30));
            FillRect(hdc, &pDIS->rcItem, hbrBackground);
            DeleteObject(hbrBackground);

            COLORREF bgColor = g_isHovering ? RGB(70, 70, 75) : RGB(45, 45, 48);
            HBRUSH hBrush = CreateSolidBrush(bgColor);
            HPEN hPen = CreatePen(PS_SOLID, 1, bgColor);
            HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
            HPEN hOldPen = (HPEN)SelectObject(hdc, hPen);

            RoundRect(hdc, pDIS->rcItem.left, pDIS->rcItem.top, pDIS->rcItem.right, pDIS->rcItem.bottom, 12, 12);

            SelectObject(hdc, hOldBrush);
            SelectObject(hdc, hOldPen);
            DeleteObject(hBrush);
            DeleteObject(hPen);
            SetBkMode(hdc, TRANSPARENT);
            SetTextColor(hdc, RGB(230, 230, 230));

            HFONT hOldFont = (HFONT)SelectObject(hdc, hFont);
            DrawText(hdc, L"Start Server", -1, (LPRECT)&pDIS->rcItem, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            SelectObject(hdc, hOldFont);

            return TRUE;
        }
    }
    break;

    case WM_ERASEBKGND:
    {
        HDC hdc = (HDC)wParam;
        RECT rc;
        GetClientRect(hwndMain, &rc);
        HBRUSH hbr = CreateSolidBrush(RGB(30, 30, 30));
        FillRect(hdc, &rc, hbr);
        DeleteObject(hbr);
        return 1;
    }

    case WM_MOUSEMOVE:
        if (!g_mouseTracking)
        {
            TRACKMOUSEEVENT tme = { sizeof(tme) };
            tme.dwFlags = TME_LEAVE;
            tme.hwndTrack = hwnd;
            TrackMouseEvent(&tme);

            g_mouseTracking = true;
            g_isHovering = true;
            InvalidateRect(hwnd, NULL, TRUE);
        }
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

LRESULT CALLBACK MouseHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData)
{
    bool isHoverable = (dwRefData == 1);
    switch (msg)
    {
    case WM_MOUSEMOVE:
        if (!g_mouseTracking)
        {
            TRACKMOUSEEVENT tme = { sizeof(tme) };
            tme.dwFlags = TME_LEAVE;
            tme.hwndTrack = hwnd;
            TrackMouseEvent(&tme);

            g_mouseTracking = true;
            g_isHovering = true;
            InvalidateRect(hwnd, NULL, TRUE);
        }
        break;

    case WM_MOUSELEAVE:
        g_mouseTracking = false;
        g_isHovering = false;
        InvalidateRect(hwnd, NULL, TRUE);
        SetCursor(LoadCursor(NULL, IDC_ARROW));
        break;

    case WM_SETCURSOR:
        if (isHoverable && LOWORD(lParam) == HTCLIENT && g_isHovering)
        {
            SetCursor(LoadCursor(NULL, IDC_HAND));
            return TRUE;
        }
        break;

    case WM_NCDESTROY:
        RemoveWindowSubclass(hwnd, MouseHandler, uIdSubclass);
        break;
    }

    return DefSubclassProc(hwnd, msg, wParam, lParam);
}

LRESULT CALLBACK SliderHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    static bool dragging = false;

    switch (msg)
    {
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        RECT rc;
        GetClientRect(hwnd, &rc);

        HBRUSH bgBrush = CreateSolidBrush(RGB(30, 30, 30));
        FillRect(hdc, &rc, bgBrush);
        DeleteObject(bgBrush);

        int trackHeight = 6;
        int trackY = (rc.bottom / 2) - (trackHeight / 2);

        int valueAreaWidth = 40;
        int trackStartX = 11;

        RECT trackRect = { trackStartX, trackY, rc.right - 8 - valueAreaWidth, trackY + trackHeight };

        HBRUSH trackBrush = CreateSolidBrush(RGB(70, 70, 75));
        FillRect(hdc, &trackRect, trackBrush);
        DeleteObject(trackBrush);

        int sliderRange = (rc.right - 8 - valueAreaWidth) - trackStartX - thumbWidth;
        int thumbX = trackStartX + ((currentValue - minValue) * sliderRange) / (maxValue - minValue);
        RECT thumbRect = { thumbX, rc.bottom / 2 - 10, thumbX + thumbWidth, rc.bottom / 2 + 10 };

        HBRUSH thumbBrush = CreateSolidBrush(RGB(120, 120, 130));
        FillRect(hdc, &thumbRect, thumbBrush);
        DeleteObject(thumbBrush);

        wchar_t valueStr[16];
        wsprintf(valueStr, L"%d", currentValue);

        SetTextColor(hdc, RGB(200, 200, 200));
        SetBkMode(hdc, TRANSPARENT);

        int valueX = rc.right - valueAreaWidth + 8;
        TextOutW(hdc, valueX, rc.bottom / 2 - 8, valueStr, lstrlenW(valueStr));

        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_LBUTTONDOWN:
    {
        SetCapture(hwnd);
        dragging = true;
        SendMessage(hwnd, WM_MOUSEMOVE, wParam, lParam);
        return 0;
    }

    case WM_LBUTTONUP:
    {
        ReleaseCapture();
        dragging = false;
        return 0;
    }

    case WM_MOUSEMOVE:
    {
        if (!g_mouseTracking)
        {
            TRACKMOUSEEVENT tme = { sizeof(tme) };
            tme.dwFlags = TME_LEAVE;
            tme.hwndTrack = hwnd;
            TrackMouseEvent(&tme);

            g_mouseTracking = true;
            g_isHovering = true;
            InvalidateRect(hwnd, NULL, TRUE);
        }
        if (dragging)
        {
            RECT rc;
            GetClientRect(hwnd, &rc);
            int mouseX = GET_X_LPARAM(lParam);
            int usableWidth = rc.right - 8 * 2 - thumbWidth;

            int newValue = ((mouseX - 8) * (maxValue - minValue)) / (usableWidth);
            if (newValue < minValue) newValue = minValue;
            if (newValue > maxValue) newValue = maxValue;

            if (newValue != currentValue)
            {
                currentValue = newValue;
                InvalidateRect(hwnd, NULL, TRUE);
            }
        }
        return 0;
    }

    case WM_MOUSELEAVE:
        g_mouseTracking = false;
        g_isHovering = false;
        InvalidateRect(hwnd, NULL, TRUE);
        SetCursor(LoadCursor(NULL, IDC_ARROW));
        break;

    case WM_SETCURSOR:
    {
        if (LOWORD(lParam) == HTCLIENT)
        {
            if (g_isHovering)
            {
                SetCursor(LoadCursor(NULL, IDC_HAND));
                return TRUE;
            }
        }
        break;
    }

    case WM_HSCROLL:
    {
        if ((HWND)lParam == hSlider)
        {
            currentValue = SendMessage(hSlider, TBM_GETPOS, 0, 0);

            if (hSliderValueLabel)
            {
                std::wstring labelText = L"" + std::to_wstring(currentValue);
                SetWindowText(hSliderValueLabel, labelText.c_str());
            }
        }
        break;
    }

    case WM_ERASEBKGND:
        return 1;

    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }

    return CallWindowProc(Slider, hwnd, msg, wParam, lParam);
}

DWORD WINAPI GuiThread(LPVOID lpParam)
{
    HINSTANCE hInstance = (HINSTANCE)lpParam;

    InitCommonControls();

    const wchar_t CLASS_NAME[] = L"MGS GUI";
    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    RegisterClass(&wc);

    hwndMain = CreateWindowEx(0, CLASS_NAME, L"MGS 11.31", WS_OVERLAPPEDWINDOW & ~(WS_THICKFRAME | WS_MAXIMIZEBOX), CW_USEDEFAULT, CW_USEDEFAULT, 450, 350, nullptr, nullptr, hInstance, nullptr);

    if (!hwndMain) return 0;

    BOOL useDarkMode = TRUE;
    DwmSetWindowAttribute(hwndMain, 20, &useDarkMode, sizeof(useDarkMode));

    hFont = CreateFontW(-MulDiv(9, GetDeviceCaps(GetDC(hwndMain), LOGPIXELSY), 72), 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Segoe UI");

    hBotCheck = CreateWindow(L"BUTTON", L"", WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 20, 60, 16, 16, hwndMain, (HMENU)2, hInstance, nullptr);
    SendMessage(hBotCheck, WM_SETFONT, (WPARAM)hFont, TRUE);
    SetWindowSubclass(hBotCheck, MouseHandler, 1, 1);

    hBotLabel = CreateWindow(L"STATIC", L"Bot Lobbies", WS_VISIBLE | WS_CHILD, 37, 60, 150, 20, hwndMain, (HMENU)2, hInstance, nullptr);
    SendMessage(hBotLabel, WM_SETFONT, (WPARAM)hFont, TRUE);

    SetWindowTheme(hBotLabel, L"", L"");

    hLateCheck = CreateWindow(L"BUTTON", L"", WS_VISIBLE | WS_CHILD | BS_AUTOCHECKBOX, 20, 90, 16, 16, hwndMain, (HMENU)3, hInstance, nullptr);
    SendMessage(hLateCheck, WM_SETFONT, (WPARAM)hFont, TRUE);
    SetWindowSubclass(hLateCheck, MouseHandler, 1, 1);

    hLateLabel = CreateWindow(L"STATIC", L"Late Game", WS_VISIBLE | WS_CHILD, 37, 90, 150, 20, hwndMain, (HMENU)2, hInstance, nullptr);
    SendMessage(hLateLabel, WM_SETFONT, (WPARAM)hFont, TRUE);
    SetWindowTheme(hBotLabel, L"", L"");


    HWND hSliderLabel = CreateWindow(L"STATIC", L"Minimum players required to autostart:", WS_VISIBLE | WS_CHILD, 20, 120, 300, 20, hwndMain, nullptr, hInstance, nullptr);
    SendMessage(hSliderLabel, WM_SETFONT, (WPARAM)hFont, TRUE);

    hSlider = CreateWindowEx(0, TRACKBAR_CLASS, L"",WS_VISIBLE | WS_CHILD | TBS_AUTOTICKS | TBS_TOOLTIPS | TBS_BOTH,10, 140, 200, 30, hwndMain, nullptr, hInstance, nullptr);

    SendMessage(hSlider, TBM_SETRANGE, TRUE, MAKELPARAM(0, 100));
    SendMessage(hSlider, TBM_SETTICFREQ, 10, 0);
    SendMessage(hSlider, TBM_SETLINESIZE, 0, 1);
    SetWindowTheme(hSlider, L"Explorer", nullptr);

    Slider = (WNDPROC)SetWindowLongPtr(hSlider, GWLP_WNDPROC, (LONG_PTR)SliderHandler);

    HWND hComboLabel = CreateWindow(L"STATIC", L"Select Gamemode:", WS_VISIBLE | WS_CHILD, 20, 180, 200, 20, hwndMain, nullptr, hInstance, nullptr);
    SendMessage(hComboLabel, WM_SETFONT, (WPARAM)hFont, TRUE);

    hCombo = CreateWindow(L"COMBOBOX", nullptr, CBS_DROPDOWNLIST | WS_CHILD | WS_VISIBLE, 20, 200, 250, 300, hwndMain, (HMENU)4, hInstance, nullptr);
    SendMessage(hCombo, WM_SETFONT, (WPARAM)hFont, TRUE);

    for (auto& it : ModeForPlaylist) {
        SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)it.second.first);
    }

    SendMessage(hCombo, CB_SETCURSEL, SelectedIndex, 0);

    hStartButton = CreateWindow(L"BUTTON", L"Start Server", WS_VISIBLE | WS_CHILD | BS_OWNERDRAW, 20, 240, 120, 30, hwndMain, (HMENU)1, hInstance, nullptr);
    SetWindowSubclass(hStartButton, MouseHandler, 1, 0);

   // Button = (WNDPROC)SetWindowLongPtr(hStartButton, GWLP_WNDPROC, (LONG_PTR)MouseHandler);

    hStatusLabel = CreateWindow(L"STATIC", nullptr, WS_CHILD | WS_VISIBLE | SS_CENTER, 0, 0, 450, 50, hwndMain, nullptr, hInstance, nullptr);
    SendMessage(hStatusLabel, WM_SETFONT, (WPARAM)hFont, TRUE);

    SetWindowText(hStatusLabel, L"");

    ShowWindow(hwndMain, SW_SHOW);
    UpdateWindow(hwndMain);

    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}