#pragma once
#include "Utils.h"
#include "Abilities.h"
#include "Looting.h"
#include "Inventory.h"
#include "Vehicles.h"
#include <thread>

void (*ServerReadyToStartMatchOG)(AFortPlayerControllerAthena* PC);
void ServerReadyToStartMatch(AFortPlayerControllerAthena* PC)
{

	if (!PC) {
		return;
	}

	AFortGameModeAthena* GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;
	AFortGameStateAthena* GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;
	SDK::FName CurrentPlaylistFName = GameState->GetCurrentPlaylistName();
	std::string Playlist = CurrentPlaylistFName.ToString();

	float CurrentTime = UGameplayStatics::GetTimeSeconds(UWorld::GetWorld());
	float MaxEndTime = GameState->WarmupCountdownStartTime + 120.f; // Max: 2 minutes
	float Extension = 10.f;

	GameState->MapInfo->SupplyDropInfoList[0]->SupplyDropClass = StaticLoadObject<UClass>("/Game/Athena/SupplyDrops/AthenaSupplyDrop_Holiday.AthenaSupplyDrop_Holiday_C");

	GameState->DefaultBattleBus = StaticLoadObject<UAthenaBattleBusItemDefinition>("/Game/Athena/Items/Cosmetics/BattleBuses/BBID_WinterBus.BBID_WinterBus");

	for (size_t i = 0; i < GameMode->BattleBusCosmetics.Num(); i++)
	{
		GameMode->BattleBusCosmetics[i] = GameState->DefaultBattleBus;
	}

	static bool areyoureal = false;
	if (!areyoureal)
	{
		areyoureal = true;
		SpawnFloorLoot();
		SpawnLlamas();
		SpawnVehicles();

		if (Playlist.contains("BattleLab"))
		{
			GameMode->StartMatch();
			GameMode->StartPlay();

			GameState->GamePhase = EAthenaGamePhase::SafeZones;
			GameState->GamePhaseStep = EAthenaGamePhaseStep::StormHolding;
			GameState->OnRep_GamePhase(EAthenaGamePhase::SafeZones);
		}
	}

	if (GameState->GamePhase == EAthenaGamePhase::Warmup && GameMode->AlivePlayers.Num() == currentValue)
	{
		if (GameState->WarmupCountdownEndTime < MaxEndTime)
		{
			float NewEndTime = GameState->WarmupCountdownEndTime + Extension;

			if (NewEndTime > MaxEndTime)
				NewEndTime = MaxEndTime;

			GameState->WarmupCountdownEndTime = NewEndTime;
			GameMode->WarmupCountdownDuration = NewEndTime - GameState->WarmupCountdownStartTime;
		}
	}

	return ServerReadyToStartMatchOG(PC);
}

inline void (*ServerLoadingScreenDroppedOG)(AFortPlayerControllerAthena* PC);
inline void ServerLoadingScreenDropped(AFortPlayerControllerAthena* PC)
{
	if (PC->bLoadingScreenDropped)
		return;

	AFortPlayerStateAthena* PlayerState = (AFortPlayerStateAthena*)PC->PlayerState;
	AFortGameStateAthena* GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;
	AFortGameModeAthena* GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;
	SDK::FName CurrentPlaylistFName = GameState->GetCurrentPlaylistName();
	std::string Playlist = CurrentPlaylistFName.ToString();
    auto Pawn = (AFortPlayerPawn*)PC->Pawn;

	UFortKismetLibrary::UpdatePlayerCustomCharacterPartsVisualization(PlayerState);
	PlayerState->OnRep_CharacterData();

	InitAbilitiesForPlayer(PC);

	UAthenaPickaxeItemDefinition* PickaxeItemDef;
	FFortAthenaLoadout& CosmecticLoadoutPC = PC->CosmeticLoadoutPC;

	PickaxeItemDef = CosmecticLoadoutPC.Pickaxe != nullptr ? CosmecticLoadoutPC.Pickaxe : UObject::FindObject<UAthenaPickaxeItemDefinition>("DefaultPickaxe");// just incase the backend yk

	GiveItem(PC, PC->CosmeticLoadoutPC.Pickaxe->WeaponDefinition, 1, 0, false);

	Pawn->CosmeticLoadout = PC->CosmeticLoadoutPC;
	Pawn->OnRep_CosmeticLoadout();

	for (size_t i = 0; i < GameMode->StartingItems.Num(); i++)
	{
		if (GameMode->StartingItems[i].Count > 0)
		{
			GiveItem(PC, GameMode->StartingItems[i].Item, GameMode->StartingItems[i].Count, 0, false);
		}
	}

	FGameMemberInfo Info{ -1,-1,-1 };
	Info.MemberUniqueId = PlayerState->UniqueId;
	Info.SquadId = PlayerState->SquadId;
	Info.TeamIndex = PlayerState->TeamIndex;

	GameState->GameMemberInfoArray.Members.Add(Info);
	GameState->GameMemberInfoArray.MarkItemDirty(Info);

	PC->XPComponent->bRegisteredWithQuestManager = true;
	PC->XPComponent->OnRep_bRegisteredWithQuestManager();

	return ServerLoadingScreenDroppedOG(PC);
}

inline void ServerAttemptAircraftJump(UFortControllerComponent_Aircraft* Comp, FRotator Rotation)
{
	auto PC = (AFortPlayerControllerAthena*)Comp->GetOwner();
	auto GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;
	auto GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;
	auto Pawn = (AFortPlayerPawn*)PC->Pawn;


	if (!LateGame)
	{
		GameMode->RestartPlayer(PC);
	}

	PC->MyFortPawn->BeginSkydiving(true);
	PC->MyFortPawn->SetHealth(100);

}

void (*ServerAcknowledgePossessionOG)(AFortPlayerControllerAthena* PC, APawn* Pawn);
inline void ServerAcknowledgePossession(AFortPlayerControllerAthena* PC, APawn* Pawn)
{
	PC->AcknowledgedPawn = Pawn;
	return ServerAcknowledgePossessionOG(PC, Pawn);
}

inline void ServerExecuteInventoryItem(AFortPlayerControllerAthena* PC, FGuid Guid)
{
	if (!PC->MyFortPawn || !PC->Pawn)
		return;

	for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Guid)
		{
			UFortWeaponItemDefinition* DefToEquip = (UFortWeaponItemDefinition*)PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition;
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition->IsA(UFortGadgetItemDefinition::StaticClass()))
			{
				DefToEquip = ((UFortGadgetItemDefinition*)PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition)->GetWeaponItemDefinition();
			}
			else if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition->IsA(UFortDecoItemDefinition::StaticClass())) {
				auto DecoItemDefinition = (UFortDecoItemDefinition*)PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition;
				PC->MyFortPawn->PickUpActor(nullptr, DecoItemDefinition);
				PC->MyFortPawn->CurrentWeapon->ItemEntryGuid = Guid;
				static auto FortDecoTool_ContextTrapStaticClass = StaticLoadObject<UClass>("/Script/FortniteGame.FortDecoTool_ContextTrap");
				if (PC->MyFortPawn->CurrentWeapon->IsA(FortDecoTool_ContextTrapStaticClass))
				{
					reinterpret_cast<AFortDecoTool_ContextTrap*>(PC->MyFortPawn->CurrentWeapon)->ContextTrapItemDefinition = (UFortContextTrapItemDefinition*)PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition;
				}
				return;
			}
			PC->MyFortPawn->EquipWeaponDefinition(DefToEquip, Guid);
			break;
		}
	}
}

inline void (*ServerAttemptInteractOG)(UFortControllerComponent_Interaction* Comp, AActor* ReceivingActor, UPrimitiveComponent* InteractComponent, ETInteractionType InteractType, UObject* OptionalData, EInteractionBeingAttempted InteractionBeingAttempted);
inline void ServerAttemptInteract(UFortControllerComponent_Interaction* Comp, AActor* ReceivingActor, UPrimitiveComponent* InteractComponent, ETInteractionType InteractType, UObject* OptionalData, EInteractionBeingAttempted InteractionBeingAttempted)
{
	ServerAttemptInteractOG(Comp, ReceivingActor, InteractComponent, InteractType, OptionalData, InteractionBeingAttempted);

	std::cout << "ReceivingActor: " << ReceivingActor->GetFullName() << '\n';
	AFortPlayerControllerAthena* PC = Cast<AFortPlayerControllerAthena>(Comp->GetOwner());

	if (ReceivingActor->IsA(AFortAthenaSupplyDrop::StaticClass()))
	{
		if (ReceivingActor->GetName().starts_with("AthenaSupplyDrop_Llama_C_"))
		{
			static auto Drop = UKismetStringLibrary::Conv_StringToName(L"Loot_AthenaLlama");

			auto LootDrops = PickLootDrops(Drop);

			auto CorrectLocation = ReceivingActor->K2_GetActorLocation();

			for (auto& LootDrop : LootDrops)
			{
				SpawnPickup(LootDrop.ItemDefinition, LootDrop.Count, LootDrop.LoadedAmmo, CorrectLocation, EFortPickupSourceTypeFlag::Container, EFortPickupSpawnSource::SupplyDrop);
			}
		}
		else
		{
			static auto Drop = UKismetStringLibrary::Conv_StringToName(L"Loot_AthenaSupplyDrop");

			auto LootDrops = PickLootDrops(Drop);

			auto CorrectLocation = ReceivingActor->K2_GetActorLocation();

			for (auto& LootDrop : LootDrops)
			{
				SpawnPickup(LootDrop.ItemDefinition, LootDrop.Count, LootDrop.LoadedAmmo, CorrectLocation, EFortPickupSourceTypeFlag::Container, EFortPickupSpawnSource::SupplyDrop);
			}
		}
	}
	else if (PC->MyFortPawn && PC->MyFortPawn->IsInVehicle())
	{
		auto Vehicle = PC->MyFortPawn->GetVehicle();

		if (Vehicle)
		{
			auto SeatIdx = PC->MyFortPawn->GetVehicleSeatIndex();
			auto WeaponComp = Vehicle->GetSeatWeaponComponent(SeatIdx);
			if (WeaponComp)
			{
				GiveItem(PC, WeaponComp->WeaponSeatDefinitions[SeatIdx].VehicleWeapon, 1, 9999, false);
				for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
				{
					if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition == WeaponComp->WeaponSeatDefinitions[SeatIdx].VehicleWeapon)
					{
						PC->SwappingItemDefinition = PC->MyFortPawn->CurrentWeapon->WeaponData;
						PC->ServerExecuteInventoryItem(PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid);
						break;
					}
				}
			}
		}
	}
}

inline void (*ServerHandlePickupOG)(AFortPlayerPawn* Pawn, AFortPickup* Pickup, float InFlyTime, FVector InStartDirection, bool bPlayPickupSound);
inline void ServerHandlePickup(AFortPlayerPawnAthena* Pawn, AFortPickup* Pickup, float InFlyTime, const FVector& InStartDirection, bool bPlayPickupSound)
{

	if (!Pickup || !Pawn || !Pawn->Controller || Pickup->bPickedUp)
		return;

	AFortPlayerControllerAthena* PC = (AFortPlayerControllerAthena*)Pawn->Controller;
	FFortItemEntry& PickupEntry = Pickup->PrimaryPickupItemEntry;
	UFortItemDefinition* PickupItemDef = Pickup->PrimaryPickupItemEntry.ItemDefinition;
	float MaxStackSize = GetMaxStack(PickupItemDef);
	int Items = 0;
	FFortItemEntry* FoundEntry = nullptr;
	bool Found = false;

	for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		FFortItemEntry& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

		if (IsPrimaryQuickbar(PickupItemDef) && IsPrimaryQuickbar(Entry.ItemDefinition))
		{
			if (Entry.ItemDefinition->GetName() == "AGID_Lotus_Mustache") {
				Items += 2;
			}
			else {
				Items++;
			}
			if (Items > 5)
			{
				for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
				{
					if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Entry.ItemGuid)
					{
						PC->WorldInventory->Inventory.ReplicatedEntries.RemoveSingle(i);
						break;
					}
				}

				for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
				{
					if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == Entry.ItemGuid)
					{
						PC->WorldInventory->Inventory.ItemInstances.RemoveSingle(i);
						break;
					}
				}
			}
		}

		if (Entry.ItemDefinition == PickupItemDef && (Entry.Count < MaxStackSize))
		{
			FoundEntry = &PC->WorldInventory->Inventory.ReplicatedEntries[i];
		}
	}

	if (Items == 5 && IsPrimaryQuickbar(Pawn->CurrentWeapon->WeaponData))
	{
		FFortItemEntry* SwapEntry = nullptr;
		for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition == Pawn->CurrentWeapon->WeaponData)
			{
				SwapEntry = &PC->WorldInventory->Inventory.ReplicatedEntries[i];
				break;
			}
		}

		if (!SwapEntry || !SwapEntry->ItemDefinition)
			return;

		float SwapMaxStackSize = GetMaxStack(SwapEntry->ItemDefinition);

		if (!FoundEntry && !Pawn->CurrentWeapon->WeaponData->IsStackable() || SwapEntry->ItemDefinition != PickupItemDef || SwapEntry->Count >= SwapMaxStackSize)
		{
			FFortItemEntry* ItemEntry = nullptr;
			for (auto& Entry : PC->WorldInventory->Inventory.ReplicatedEntries)
			{
				if (Entry.ItemGuid == PC->MyFortPawn->CurrentWeapon->ItemEntryGuid)
				{
					ItemEntry = &Entry;
					break;
				}
			}

			PC->ServerAttemptInventoryDrop(ItemEntry->ItemGuid, ItemEntry->Count, false);
		}
	}

	if (PickupEntry.ItemDefinition->IsStackable())
	{
		for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			auto& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

			if (Entry.ItemDefinition == PickupItemDef)
			{
				Found = true;
				if ((MaxStackSize - Entry.Count) > 0)
				{
					Entry.Count += PickupEntry.Count;

					if (Entry.Count > MaxStackSize)
					{
						SpawnStack((APlayerPawn_Athena_C*)PC->Pawn, PickupItemDef, Entry.Count - MaxStackSize);
						Entry.Count = MaxStackSize;
					}

					PC->WorldInventory->Inventory.MarkItemDirty(Entry);
				}
				else
				{
					if (IsPrimaryQuickbar(PickupItemDef))
					{
						GiveItem(PC, PickupEntry.ItemDefinition, PickupEntry.Count, PickupEntry.LoadedAmmo, false);
					}
				}
				break;
			}
		}
		if (!Found)
		{
			GiveItem(PC, PickupEntry.ItemDefinition, PickupEntry.Count, PickupEntry.LoadedAmmo, false);
		}
	}
	else
	{
		GiveItem(PC, PickupEntry.ItemDefinition, PickupEntry.Count, PickupEntry.LoadedAmmo, false);
		PC->WorldInventory->HandleInventoryLocalUpdate();
		PC->WorldInventory->Inventory.MarkArrayDirty();

	}

	Pickup->PickupLocationData.bPlayPickupSound = true;
	Pickup->PickupLocationData.FlyTime = 0.3f;
	Pickup->PickupLocationData.ItemOwner = Pawn;
	Pickup->PickupLocationData.PickupGuid = Pickup->PrimaryPickupItemEntry.ItemGuid;
	Pickup->PickupLocationData.PickupTarget = Pawn;
	Pickup->OnRep_PickupLocationData();

	Pickup->bPickedUp = true;
	Pickup->OnRep_bPickedUp();
}

inline void ServerAttemptInventoryDrop(AFortPlayerControllerAthena* PC, FGuid ItemGuid, int Count, bool bTrash)
{
	FFortItemEntry* Entry = nullptr;
	for (auto& E : PC->WorldInventory->Inventory.ReplicatedEntries)
	{
		if (E.ItemGuid == ItemGuid)
		{
			Entry = &E;
			break;
		}
	}

	if (!Entry || !PC || !PC->Pawn)
		return;

	AFortPlayerPawn* Pawn = (AFortPlayerPawn*)PC->Pawn;

	SpawnPickup(Entry->ItemDefinition, Count, Entry->LoadedAmmo, Pawn->K2_GetActorLocation(), EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::Unset, Pawn);

	if (Entry->Count <= Count)
	{
		RemoveItem(PC, Entry->ItemDefinition, Entry->Count, Entry->ItemGuid);
	}
	else
	{
		Entry->Count -= Count;
		PC->WorldInventory->Inventory.MarkItemDirty(*Entry);
		PC->WorldInventory->bRequiresLocalUpdate = true;
		PC->WorldInventory->HandleInventoryLocalUpdate();
	}
}

inline void (*ClientOnPawnDiedOG)(AFortPlayerControllerAthena*, FFortPlayerDeathReport);
inline void ClientOnPawnDied(AFortPlayerControllerAthena* DeadPC, FFortPlayerDeathReport DeathReport)
{

	Log("Pawn died");
	DeadPC->bMarkedAlive = false;

	auto GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;
	auto GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;
	AFortPlayerStateAthena* DeadState = (AFortPlayerStateAthena*)DeadPC->PlayerState;
	AFortPlayerPawnAthena* KillerPawn = (AFortPlayerPawnAthena*)DeathReport.KillerPawn;
	AFortPlayerStateAthena* KillerState = (AFortPlayerStateAthena*)DeathReport.KillerPlayerState;
	static bool Won = false;

	if (!GameState->IsRespawningAllowed(DeadState))
	{
		if (DeadPC && DeadPC->WorldInventory)
		{
			for (size_t i = 0; i < DeadPC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
			{
				if (((UFortWorldItemDefinition*)DeadPC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition)->bCanBeDropped)
				{
					SpawnPickup(DeadPC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemDefinition, DeadPC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.Count, DeadPC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.LoadedAmmo, DeadPC->Pawn->K2_GetActorLocation(), EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::PlayerElimination, DeadPC->MyFortPawn);
				}
			}
		}
	}

	if (!Won && DeadPC && DeadState)
	{
		if (KillerState && KillerState != DeadState)
		{
			KillerState->KillScore++;

			for (size_t i = 0; i < KillerState->PlayerTeam->TeamMembers.Num(); i++)
			{
				((AFortPlayerStateAthena*)KillerState->PlayerTeam->TeamMembers[i]->PlayerState)->TeamKillScore++;
				((AFortPlayerStateAthena*)KillerState->PlayerTeam->TeamMembers[i]->PlayerState)->OnRep_TeamKillScore();
			}


			KillerState->ClientReportKill(DeadState);
			KillerState->OnRep_Kills();

			//if (SpawnedBots.empty())
			//{
				//GiveAccolade((AFortPlayerControllerAthena*)KillerState->Owner, GetDefFromEvent(EAccoladeEvent::Kill, KillerState->KillScore));
			//}

			DeadState->PawnDeathLocation = DeadPC->Pawn->K2_GetActorLocation();
			FDeathInfo& DeathInfo = DeadState->DeathInfo;

			DeathInfo.bDBNO = DeadPC->MyFortPawn->bWasDBNOOnDeath;
			DeathInfo.bInitialized = true;
			DeathInfo.DeathLocation = DeadPC->Pawn->K2_GetActorLocation();
			DeathInfo.DeathTags = DeathReport.Tags;
			DeathInfo.Downer = KillerState;
			DeathInfo.Distance = (KillerPawn ? KillerPawn->GetDistanceTo(DeadPC->Pawn) : ((AFortPlayerPawnAthena*)DeadPC->Pawn)->LastFallDistance);
			DeathInfo.FinisherOrDowner = KillerState;
			DeathInfo.DeathCause = DeadState->ToDeathCause(DeathInfo.DeathTags, DeathInfo.bDBNO);
			DeadState->OnRep_DeathInfo();
		}

		if (Won || !GameState->IsRespawningAllowed(DeadState))
		{
			FAthenaRewardResult Result;
			UFortPlayerControllerAthenaXPComponent* XPComponent = DeadPC->XPComponent;
			Result.TotalBookXpGained = XPComponent->TotalXpEarned;
			Result.TotalSeasonXpGained = XPComponent->TotalXpEarned;

			DeadPC->ClientSendEndBattleRoyaleMatchForPlayer(true, Result);

			FAthenaMatchStats Stats;
			FAthenaMatchTeamStats TeamStats;

			if (DeadState)
			{
				DeadState->Place = GameMode->AliveBots.Num() + GameMode->AlivePlayers.Num();
				DeadState->OnRep_Place();
			}

			for (size_t i = 0; i < 20; i++)
			{
				Stats.Stats[i] = 0;
			}

			Stats.Stats[3] = DeadState->KillScore;

			TeamStats.Place = DeadState->Place;
			TeamStats.TotalPlayers = GameState->TotalPlayers;

			DeadPC->ClientSendMatchStatsForPlayer(Stats);
			DeadPC->ClientSendTeamStatsForPlayer(TeamStats);
			FDeathInfo& DeathInfo = DeadState->DeathInfo;

			RemoveFromAlivePlayers(GameMode, DeadPC, (KillerState == DeadState ? nullptr : KillerState), KillerPawn, DeathReport.KillerWeapon ? DeathReport.KillerWeapon : nullptr, DeadState ? DeathInfo.DeathCause : EDeathCause::Rifle, 0);

			/*if (SpawnedBots.empty())
			{
				AFortGameModeAthena* GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;
				if (GameMode->AlivePlayers.Num() + GameMode->AliveBots.Num() == 50)
				{
					for (size_t i = 0; i < GameMode->AlivePlayers.Num(); i++)
					{
						GiveAccolade(GameMode->AlivePlayers[i], StaticLoadObject<UFortAccoladeItemDefinition>("/Game/Athena/Items/Accolades/AccoladeId_026_Survival_Default_Bronze.AccoladeId_026_Survival_Default_Bronze"));
					}
				}
				if (GameMode->AlivePlayers.Num() + GameMode->AliveBots.Num() == 25)
				{
					for (size_t i = 0; i < GameMode->AlivePlayers.Num(); i++)
					{
						GiveAccolade(GameMode->AlivePlayers[i], StaticLoadObject<UFortAccoladeItemDefinition>("/Game/Athena/Items/Accolades/AccoladeId_027_Survival_Default_Silver.AccoladeId_027_Survival_Default_Silver"));
					}
				}
				if (GameMode->AlivePlayers.Num() + GameMode->AliveBots.Num() == 10)
				{
					for (size_t i = 0; i < GameMode->AlivePlayers.Num(); i++)
					{
						GiveAccolade(GameMode->AlivePlayers[i], StaticLoadObject<UFortAccoladeItemDefinition>("/Game/Athena/Items/Accolades/AccoladeId_028_Survival_Default_Gold.AccoladeId_028_Survival_Default_Gold"));
					}
				}
			}*/

			if (KillerState)
			{
				if (KillerState->Place == 1)
				{
					if (DeathReport.KillerWeapon)
					{
						((AFortPlayerControllerAthena*)KillerState->Owner)->PlayWinEffects(KillerPawn, DeathReport.KillerWeapon, EDeathCause::Rifle, false);
						((AFortPlayerControllerAthena*)KillerState->Owner)->ClientNotifyWon(KillerPawn, DeathReport.KillerWeapon, EDeathCause::Rifle);
					}

					FAthenaRewardResult Result;
					AFortPlayerControllerAthena* KillerPC = (AFortPlayerControllerAthena*)KillerState->GetOwner();
					KillerPC->ClientSendEndBattleRoyaleMatchForPlayer(true, Result);

					FAthenaMatchStats Stats;
					FAthenaMatchTeamStats TeamStats;

					for (size_t i = 0; i < 20; i++)
					{
						Stats.Stats[i] = 0;
					}

					Stats.Stats[3] = KillerState->KillScore;

					TeamStats.Place = 1;
					TeamStats.TotalPlayers = GameState->TotalPlayers;

					KillerPC->ClientSendMatchStatsForPlayer(Stats);
					KillerPC->ClientSendTeamStatsForPlayer(TeamStats);

					GameState->WinningPlayerState = KillerState;
					GameState->WinningTeam = KillerState->TeamIndex;
					GameState->OnRep_WinningPlayerState();
					GameState->OnRep_WinningTeam();
				}
			}
		}
	}

	return ClientOnPawnDiedOG(DeadPC, DeathReport);
}

void ServerReturnToMainMenu(AFortPlayerControllerAthena* PC) 
{
	PC->ClientReturnToMainMenu(L"");
}

static inline void(*ServerSetInAircraftOG)(AFortPlayerStateAthena* PlayerState, bool bNewInAircraft);
void ServerSetInAircraft(AFortPlayerStateAthena* PlayerState, bool bNewInAircraft)
{

	AFortPlayerControllerAthena* PC = (AFortPlayerControllerAthena*)PlayerState->Owner;

	if (PC && PC->WorldInventory)
	{
		for (int i = PC->WorldInventory->Inventory.ReplicatedEntries.Num() - 1; i >= 0; i--)
		{
			if (((UFortWorldItemDefinition*)PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition)->bCanBeDropped && !GivenLootPlayers.Contains(PC) && LateGame)
			{
				int Count = PC->WorldInventory->Inventory.ReplicatedEntries[i].Count;
				for (auto& Entry : PC->WorldInventory->Inventory.ReplicatedEntries)
				{
					if (Entry.ItemGuid == PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid)
					{
						RemoveItem(PC, Entry.ItemDefinition, Count, Entry.ItemGuid);
						break;
					}
				}
			}
			else if (((UFortWorldItemDefinition*)PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition)->bCanBeDropped && !LateGame)
			{
				int Count = PC->WorldInventory->Inventory.ReplicatedEntries[i].Count;
				for (auto& Entry : PC->WorldInventory->Inventory.ReplicatedEntries)
				{
					if (Entry.ItemGuid == PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid)
					{
						RemoveItem(PC, Entry.ItemDefinition, Count, Entry.ItemGuid);
						break;
					}
				}
			}
		}
	}

	if (LateGame)
	{
		auto GameState = (AFortGameStateAthena*)UEngine::GetEngine()->GameViewport->World->GameState;
		auto GameMode = (AFortGameModeAthena*)UEngine::GetEngine()->GameViewport->World->AuthorityGameMode;
		FVector BattleBusLocation = GameMode->SafeZoneLocations[3];
		BattleBusLocation.Z += 15000;
		auto Aircraft = GameState->GetAircraft(0);


		if (Aircraft)
		{
			//Aircraft->FlightInfo.FlightSpeed = ;
			Aircraft->FlightInfo.FlightStartLocation = FVector_NetQuantize100(BattleBusLocation);
			Aircraft->ExitLocation = BattleBusLocation;
			GameState->bAircraftIsLocked = true;
		}

		if (!GivenLootPlayers.Contains(PC))
		{
			GiveLoadout(PC);
			GivenLootPlayers.Add(PC);
		}

		std::thread(LateGameAircraftThread, BattleBusLocation).detach();

	}

	return ServerSetInAircraftOG(PlayerState, bNewInAircraft);
}

void ServerPlayEmoteItem(AFortPlayerControllerAthena* PC, UFortMontageItemDefinitionBase* EmoteAsset, float EmoteRandomNumber)
{
	if (!PC)
		return;

	if (!EmoteAsset)
		return;

	auto Pawn = PC->MyFortPawn;

	UObject* AbilityToUse = nullptr;

	if (EmoteAsset->IsA(UAthenaSprayItemDefinition::StaticClass()))
	{
		AbilityToUse = UGAB_Spray_Generic_C::StaticClass()->DefaultObject;
	}
	else if (EmoteAsset->IsA(UAthenaToyItemDefinition::StaticClass()))
	{
	}
	else
	{
		AbilityToUse = UGAB_Emote_Generic_C::StaticClass()->DefaultObject;
	}

	if (!AbilityToUse)
	{
		return;
	}

	FGameplayAbilitySpec Spec{};
	AbilitySpecCtor(&Spec, (UGameplayAbility*)AbilityToUse, 1, -1, EmoteAsset);
	GiveAbilityAndActivateOnce(PC->MyFortPawn->AbilitySystemComponent, &Spec.Handle, Spec);
}

void ServerPlaySquadQuickChatMessage(AFortPlayerControllerAthena* PC, FAthenaQuickChatActiveEntry ChatEntry, __int64) {

	static ETeamMemberState MemberStates[10] = {
		ETeamMemberState::ChatBubble,
		ETeamMemberState::EnemySpotted,
		ETeamMemberState::NeedMaterials,
		ETeamMemberState::NeedBandages,
		ETeamMemberState::NeedShields,
		ETeamMemberState::NeedAmmoHeavy,
		ETeamMemberState::NeedAmmoLight,
		ETeamMemberState::FIRST_CHAT_MESSAGE,
		ETeamMemberState::NeedAmmoMedium,
		ETeamMemberState::NeedAmmoShells
	};

	auto PlayerState = reinterpret_cast<AFortPlayerStateAthena*>(PC->PlayerState);

	PlayerState->ReplicatedTeamMemberState = MemberStates[ChatEntry.Index];

	PlayerState->OnRep_ReplicatedTeamMemberState();

	static auto EmojiComm = StaticFindObject<UAthenaEmojiItemDefinition>(L"/Game/Athena/Items/Cosmetics/Dances/Emoji/Emoji_Comm.Emoji_Comm");

	if (EmojiComm)
	{
		PC->ServerPlayEmoteItem(EmojiComm, 0);
	}
}

void (*MovingEmoteStoppedOG)(AFortPawn* Pawn);
void MovingEmoteStopped(AFortPawn* Pawn)
{
	if (!Pawn)
		return;

	Pawn->bMovingEmote = false;
	Pawn->bMovingEmoteFollowingOnly = false;

	return MovingEmoteStoppedOG(Pawn);
}

void (*OnCapsuleBeginOverlapOG)(AFortPlayerPawn* Pawn, UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, FHitResult SweepResult);
void OnCapsuleBeginOverlap(AFortPlayerPawnAthena* Pawn, UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{

	if (OtherActor)
	{
		std::string ActorName = OtherActor->GetName();
		std::string ClassName = OtherActor->Class->GetName();
		Log(("Overlapped with: " + ActorName + " (" + ClassName + ")").c_str());
	}

	if (!Pawn)
		return;

	if (Pawn->Controller->IsA(AFortAthenaAIBotController::StaticClass()))
		return;

	if (OtherActor->Class->GetName() == "BGA_IslandPortal_C")
	{
		AFortAthenaCreativePortal* Portal = static_cast<AFortAthenaCreativePortal*>(OtherActor);
		AFortGameStateAthena* GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;
		AFortGameModeAthena* GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;
		SDK::FName CurrentPlaylistFName = GameState->GetCurrentPlaylistName();
		std::string Playlist = CurrentPlaylistFName.ToString();
		auto PC = (AFortPlayerControllerAthena*)Pawn->GetOwner();

		if (Portal && Playlist.contains("BattleLab"))
		{
			FVector TeleportLocation = Portal->TeleportLocation;
			FRotator TeleportRotation = {};

			Pawn->K2_TeleportTo(TeleportLocation, TeleportRotation);

			UClass* RiftAbilityClass = StaticLoadObject<UClass>("/Game/Athena/Items/ForagedItems/Rift/GA_Rift_Athena_Skydive.GA_Rift_Athena_Skydive_C");

			if (!RiftAbilityClass)
				return;

			UGameplayAbility* RiftDefault = (UGameplayAbility*)RiftAbilityClass->DefaultObject;

			FGameplayAbilitySpec Spec{};
			AbilitySpecCtor(&Spec, RiftDefault, 1, -1, nullptr);

			GiveAbilityAndActivateOnce(Pawn->AbilitySystemComponent, &Spec.Handle, Spec);

			auto Ability = RiftDefault;



			std::thread([Pawn, Ability, GameMode, TeleportLocation]()
				{

					auto* PC = Cast<AFortPlayerControllerAthena>(Pawn->GetController());

					while (Pawn)
					{
						FVector CurrentLocation = Pawn->K2_GetActorLocation();

						if (CurrentLocation.Z < 10000.0f)
						{

							Pawn->ForceOpenParachuteAndOverrideGlider(nullptr, true, true);
							Pawn->bCanBeDamaged = true;
							Pawn->bWeaponHolstered = false;
							break;
						}

						std::this_thread::sleep_for(std::chrono::milliseconds(50));
					}
					

			}).detach();


			return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
		}
	}


	if (OtherActor->IsA(AFortPickup::StaticClass()))
	{
		AFortPickup* Pickup = (AFortPickup*)OtherActor;

		if (Pickup->bPickedUp)
			return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);

		if (Pickup->PawnWhoDroppedPickup == Pawn) 
			return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);

		if (!Pickup->PrimaryPickupItemEntry.ItemDefinition) 
			return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);

		UFortItemDefinition* ItemDef = (UFortItemDefinition*)Pickup->PrimaryPickupItemEntry.ItemDefinition;

		if (!ItemDef) 
			return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);

		auto PC = (AFortPlayerControllerAthena*)Pawn->GetOwner();

		bool Stackable = ItemDef->IsStackable();

		UFortWorldItemDefinition* WorldItemDefinition = Cast<UFortWorldItemDefinition>(Pickup->PrimaryPickupItemEntry.ItemDefinition);
		int32 ItemQuantity = UFortKismetLibrary::K2_GetItemQuantityOnPlayer(PC, WorldItemDefinition);

		if (ItemDef->IsA(UFortAmmoItemDefinition::StaticClass()) || ItemDef->IsA(UFortResourceItemDefinition::StaticClass()) || ItemDef->IsA(UFortTrapItemDefinition::StaticClass()))
		{
			if (WorldItemDefinition && ItemQuantity < ItemDef->MaxStackSize)
			{
				Pawn->ServerHandlePickup(Pickup, 0.40f, FVector(), true);
			}
			return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
		}
		else if (Stackable)
		{
			if (WorldItemDefinition && ItemQuantity != 0 && ItemQuantity < ItemDef->MaxStackSize)
			{
				Pawn->ServerHandlePickup(Pickup, 0.40f, FVector(), true);
			}
			return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
		}
	}

	return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
}
