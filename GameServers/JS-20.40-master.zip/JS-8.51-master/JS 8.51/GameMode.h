#pragma once
#include "pch.h"
#include "framework.h"
#include "Offsets.h"
#include "Inventory.h"
#include "Abilities.h"

static void* (*ApplyCharacterCustomization)(AFortPlayerStateAthena* a1, APawn* a2) = decltype(ApplyCharacterCustomization)(Jeremy::ImageBase + 0x175FE30);

namespace GameMode
{
	uint8 NextIdx = 3;
	int CurrentPlayersOnTeam = 0;
	int MaxPlayersOnTeam = 1;

	inline bool (*ReadyToStartMatchOG)(AFortGameModeAthena* GameMode);
	inline bool ReadyToStartMatch(AFortGameModeAthena* GameMode)
	{
		AFortGameStateAthena* GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;

		static bool SetupPlaylist = false;
		if (!SetupPlaylist)
		{
			SetupPlaylist = true;
			UFortPlaylistAthena* Playlist;

			Playlist = Utils::FindObject<UFortPlaylistAthena>(Options::sPlaylist);

			GameState->CurrentPlaylistInfo.BasePlaylist = Playlist;
			GameState->CurrentPlaylistInfo.OverridePlaylist = Playlist;
			GameState->CurrentPlaylistInfo.PlaylistReplicationKey++;
			GameState->CurrentPlaylistInfo.MarkArrayDirty();
			GameState->OnRep_CurrentPlaylistInfo();

			GameMode->CurrentPlaylistName = Playlist->PlaylistName;
			GameMode->WarmupRequiredPlayerCount = Options::iMinPlayersForEarlyStart;

			GameMode->bDBNOEnabled = Playlist->MaxTeamSize > 1;
			GameMode->bAlwaysDBNO = Playlist->MaxTeamSize > 1;
			GameState->bDBNODeathEnabled = Playlist->MaxTeamSize > 1;
			GameState->SetIsDBNODeathEnabled(Playlist->MaxTeamSize > 1);

			NextIdx = Playlist->DefaultFirstTeam;
			MaxPlayersOnTeam = Playlist->MaxSquadSize;

			GameMode->GameSession->MaxPlayers = Playlist->MaxPlayers;
			GameMode->GameSession->MaxSpectators = 0;
			GameMode->GameSession->MaxPartySize = Playlist->MaxSquadSize;
			GameMode->GameSession->MaxSplitscreensPerConnection = 2;
			GameMode->GameSession->bRequiresPushToTalk = false;
			GameMode->GameSession->SessionName = UKismetStringLibrary::Conv_StringToName(FString(L"GameSession"));

			GameState->CurrentPlaylistId = Playlist->PlaylistId;
			GameState->OnRep_CurrentPlaylistId();

			GameState->bGameModeWillSkipAircraft = Playlist->bSkipAircraft;
			GameState->CachedSafeZoneStartUp = Playlist->SafeZoneStartUp;
			GameState->AirCraftBehavior = Playlist->AirCraftBehavior;
			GameState->OnRep_Aircraft();

			GameState->DefaultParachuteDeployTraceForGroundDistance = 10000;

			auto AbilitySet = Utils::FindObject<UFortAbilitySet>(L"/Game/Abilities/Player/Generic/Traits/DefaultPlayer/GAS_AthenaPlayer.GAS_AthenaPlayer");
			AbilitySets.Add(AbilitySet);

			if (Playlist && Playlist->ModifierList)
				for (int i = 0; i < Playlist->ModifierList.Num(); i++)
				{
					auto Modifier = Playlist->ModifierList.Get(i, sizeof(FSoftObjectPtr));

					if (!Modifier.Get())
						continue;

					for (int j = 0; j < Modifier->PersistentAbilitySets.Num(); j++)
					{
						auto& DeliveryInfo = Modifier->PersistentAbilitySets.Get(j, sizeof(FFortAbilitySetDeliveryInfo));

						if (!DeliveryInfo.DeliveryRequirements.bApplyToPlayerPawns)
							continue;

						for (int k = 0; k < DeliveryInfo.AbilitySets.Num(); k++)
						{
							auto AbilitySet = DeliveryInfo.AbilitySets.Get(k, sizeof(FSoftObjectPtr));

							AbilitySets.Add(AbilitySet.Get());
						}
					}
				}
		}

		if (!GameState->MapInfo)
		{
			return false;
		}

		static bool Listening = false;
		if (!Listening) {
			Listening = true;

			using CreateNetDriverType = UNetDriver * (*)(UEngine*, UWorld*, FName);
			using InitListenType = bool (*)(UNetDriver*, UWorld*, FURL&, bool, FString&);
			using SetWorldType = void (*)(UNetDriver*, UWorld*);

			auto NetDriver = ((CreateNetDriverType)Jeremy::Funcs::CreateNetDriver)(UEngine::GetEngine(), UWorld::GetWorld(), UKismetStringLibrary::Conv_StringToName(L"GameNetDriver"));
			NetDriver->World = UWorld::GetWorld();
			NetDriver->NetDriverName = UKismetStringLibrary::Conv_StringToName(L"GameNetDriver");

			UWorld::GetWorld()->NetDriver = NetDriver;
			for (auto& Collection : UWorld::GetWorld()->LevelCollections)
				Collection.NetDriver = NetDriver;

			FString Err;
			FURL URL;
			URL.Port = 7777;

			((InitListenType)Jeremy::Funcs::InitListen)(NetDriver, UWorld::GetWorld(), URL, false, Err);
			((SetWorldType)Jeremy::Funcs::SetWorld)(NetDriver, UWorld::GetWorld());

			AbilitySets.Add(Utils::FindObject<UFortAbilitySet>(L"/Game/Abilities/Player/Generic/Traits/DefaultPlayer/GAS_AthenaPlayer.GAS_AthenaPlayer"));

			for (int i = 0; i < UObject::GObjects->Num(); i++)
			{
				auto Object = UObject::GObjects->GetByIndex(i);

				if (!Object || !Object->Class || Object->IsDefaultObject())
					continue;

				if (auto GameFeatureData = Object->Cast<UFortGameData>())
				{
					auto AbilitySet = UObject::FindObject<UFortAbilitySet>(GameFeatureData->AthenaPlayerAbilitySet.ObjectID.AssetPathName.GetRawString().c_str());

					if (AbilitySet)
					{
						AbilitySet->AddToRoot();
						AbilitySets.Add(AbilitySet);
					}

				}
			}

			GameState->OnRep_AdditionalPlaylistLevelsStreamed();
			GameState->OnFinishedStreamingAdditionalPlaylistLevel();

			GameMode->bWorldIsReady = true;

			SetConsoleTitleA("JS 8.51 | Listening: 7777");
		}

	/*	if (GameState->PlayersLeft > 0)
		{
			return true;
		}
		else
		{
			auto TS = UGameplayStatics::GetTimeSeconds(UWorld::GetWorld());
			auto DR = Options::iWarmupTime;

			GameState->WarmupCountdownEndTime = TS + DR;
			GameMode->WarmupCountdownDuration = DR;
			GameState->WarmupCountdownStartTime = TS;
			GameMode->WarmupEarlyCountdownDuration = DR;
		}*/

		return true;
	}

	APawn* (*SpawnDefaultPawnForOG)(AFortGameModeAthena* GameMode, AFortPlayerControllerAthena* NewPlayer, AActor* StartSpot);
	APawn* SpawnDefaultPawnFor(AFortGameModeAthena* GameMode, AFortPlayerControllerAthena* NewPlayer, AActor* StartSpot) {
		
		AFortPlayerPawnAthena* Pawn = (AFortPlayerPawnAthena*)GameMode->SpawnDefaultPawnAtTransform(NewPlayer, StartSpot->GetTransform());
		AFortPlayerStateAthena* PlayerState = (AFortPlayerStateAthena*)NewPlayer->PlayerState;

		UAthenaPickaxeItemDefinition* PickDef;
		FFortAthenaLoadout& CosmecticLoadoutPC = NewPlayer->CosmeticLoadoutPC;
		PickDef = CosmecticLoadoutPC.Pickaxe != nullptr ? CosmecticLoadoutPC.Pickaxe : Utils::FindObject<UAthenaPickaxeItemDefinition>(L"/Game/Athena/Items/Weapons/WID_Harvest_Pickaxe_Athena_C_T01.WID_Harvest_Pickaxe_Athena_C_T01");
		if (PickDef) {
			Inventory::GiveItem(NewPlayer, PickDef->WeaponDefinition, 1, 0);
		}
		else {
		}

		for (size_t i = 0; i < GameMode->StartingItems.Num(); i++)
		{
			if (GameMode->StartingItems[i].Count > 0)
			{
				Inventory::GiveItem(NewPlayer, GameMode->StartingItems[i].Item, GameMode->StartingItems[i].Count, 0);
			}
		}

		Abilities::GiveAbilitySet(Pawn, Utils::FindObject<UFortAbilitySet>(L"/Game/Abilities/Player/Generic/Traits/DefaultPlayer/GAS_AthenaPlayer.GAS_AthenaPlayer"));

		ApplyCharacterCustomization(PlayerState, Pawn);

		return Pawn;
	}

	inline __int64 PickTeam(__int64 a1, unsigned __int8 a2, __int64 a3)
	{
		uint8 Ret = NextIdx;
		CurrentPlayersOnTeam++;

		if (CurrentPlayersOnTeam == MaxPlayersOnTeam)
		{
			NextIdx++;
			CurrentPlayersOnTeam = 0;
		}
		return Ret;
	};

	void Hook()
	{
		MH_CreateHook((LPVOID)(Jeremy::ImageBase + 0xfad530), ReadyToStartMatch, (LPVOID*)&ReadyToStartMatchOG); // done

		MH_CreateHook((LPVOID)(Jeremy::ImageBase + 0xfb4a00), SpawnDefaultPawnFor, (LPVOID*)&SpawnDefaultPawnForOG); //done

		MH_CreateHook((LPVOID)(Jeremy::ImageBase + 0xfa9b20), PickTeam, nullptr); //done
	}
}