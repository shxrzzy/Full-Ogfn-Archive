#include "framework.h"

enum class EAmmoType : uint8
{
    Assault = 0,
    Shotgun = 1,
    Submachine = 2,
    Rocket = 3,
    Sniper = 4
};

struct FLateGameItem
{
    uint32 Count;
    const UFortItemDefinition* Item;
};

namespace Lategame
{
    FLateGameItem GetShotgun()
    {
        static UEAllocatedVector<FLateGameItem> Shotguns
        {
            FLateGameItem(1,  Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Weapons/WID_Shotgun_Standard_Athena_VR_Ore_T03.WID_Shotgun_Standard_Athena_VR_Ore_T03")), // pump 
            FLateGameItem(1,  Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Weapons/WID_Shotgun_Standard_Athena_SR_Ore_T03.WID_Shotgun_Standard_Athena_SR_Ore_T03")), // pump 
        };

        return Shotguns[rand() % Shotguns.size()];
    }

    FLateGameItem GetAssaultRifle()
    {
        static UEAllocatedVector<FLateGameItem> AssaultRifles
        {
            FLateGameItem(1,  Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Weapons/WID_Assault_AutoHigh_Athena_SR_Ore_T03.WID_Assault_AutoHigh_Athena_SR_Ore_T03")), // scar 
            FLateGameItem(1,  Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Weapons/WID_Assault_AutoHigh_Athena_VR_Ore_T03.WID_Assault_AutoHigh_Athena_VR_Ore_T03")), // scar
        };

        return AssaultRifles[rand() % AssaultRifles.size()];
    }


    FLateGameItem GetSniper()
    {
        static UEAllocatedVector<FLateGameItem> Snipers
        {
            FLateGameItem(1,  Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Weapons/WID_Sniper_BoltAction_Scope_Athena_SR_Ore_T03.WID_Sniper_BoltAction_Scope_Athena_SR_Ore_T03")), // bolt
            FLateGameItem(1,  Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Weapons/WID_Pistol_Scavenger_Athena_VR_Ore_T03.WID_Pistol_Scavenger_Athena_VR_Ore_T03")) // tac smg
        };

        return Snipers[rand() % Snipers.size()];
    }

    FLateGameItem GetHeal()
    {
        static UEAllocatedVector<FLateGameItem> Heals
        {
            FLateGameItem(3,  Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Consumables/Shields/Athena_Shields.Athena_Shields")), // big pots
            FLateGameItem(6,  Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Consumables/ShieldSmall/Athena_ShieldSmall.Athena_ShieldSmall")) // minis
        };

        static bool bAdded = false;
        if (!bAdded)
        {
            bAdded = true;

            auto ChugSplash = FLateGameItem(6,  Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Consumables/ChillBronco/Athena_ChillBronco.Athena_ChillBronco"));
            auto SlurpJuice = FLateGameItem(2,  Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Consumables/PurpleStuff/Athena_PurpleStuff.Athena_PurpleStuff"));

            if (ChugSplash.Item)
                Heals.push_back(ChugSplash);

            if (SlurpJuice.Item)
                Heals.push_back(SlurpJuice);
        }

        return Heals[rand() % Heals.size()];
    }

    const UFortItemDefinition* GetAmmo(EAmmoType AmmoType)
    {
        static UEAllocatedVector<const UFortItemDefinition*> Ammos
        {
             Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Ammo/AthenaAmmoDataBulletsLight.AthenaAmmoDataBulletsLight"),
             Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Ammo/AthenaAmmoDataShells.AthenaAmmoDataShells"),
             Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Ammo/AthenaAmmoDataBulletsMedium.AthenaAmmoDataBulletsMedium"),
             Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Ammo/AmmoDataRockets.AmmoDataRockets"),
             Utils::FindObject<UFortItemDefinition>(L"/Game/Athena/Items/Ammo/AthenaAmmoDataBulletsHeavy.AthenaAmmoDataBulletsHeavy")
        };

        return Ammos[(uint8)AmmoType];
    }

    const UFortItemDefinition* GetResource(EFortResourceType ResourceType)
    {
        static UEAllocatedVector<const UFortItemDefinition*> Resources
        {
             Utils::FindObject<UFortItemDefinition>(L"/Game/Items/ResourcePickups/WoodItemData.WoodItemData"),
             Utils::FindObject<UFortItemDefinition>(L"/Game/Items/ResourcePickups/StoneItemData.StoneItemData"),
             Utils::FindObject<UFortItemDefinition>(L"/Game/Items/ResourcePickups/MetalItemData.MetalItemData")
        };

        return Resources[(uint8)ResourceType];
    }
}