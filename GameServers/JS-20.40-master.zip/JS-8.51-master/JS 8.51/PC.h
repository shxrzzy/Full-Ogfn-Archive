#pragma once
#include "pch.h"
#include "framework.h"
#include "Abilities.h"

static __int64 (*CantBuild)(UWorld*, UObject*, FVector, FRotator, char, void*, char*) = decltype(CantBuild)(Jeremy::ImageBase + 0x1330d70);

namespace PC
{
	static void GiveModifier(AFortPlayerControllerAthena* PC, UFortGameplayModifierItemDefinition* Modifier)
	{
		if (!PC || !PC->MyFortPawn || !Modifier)
			return;
		for (auto& Ability : Modifier->PersistentAbilitySets)
			if (Ability.DeliveryRequirements.bApplyToPlayerPawns)
				for (auto& Abi : Ability.AbilitySets)
					Abilities::GiveAbilitySet(PC->MyFortPawn, Abi.Get());
		for (auto& Effect : Modifier->PersistentGameplayEffects)
			if (Effect.DeliveryRequirements.bApplyToPlayerPawns)
				for (auto& eff : Effect.GameplayEffects)
					PC->MyFortPawn->AbilitySystemComponent->BP_ApplyGameplayEffectToSelf(eff.GameplayEffect.Get(), eff.Level, PC->MyFortPawn->AbilitySystemComponent->MakeEffectContext());
	}

	void (*ServerAcknowledgePossessionOG)(AFortPlayerControllerAthena* PC, APawn* Pawn);
	inline void ServerAcknowledgePossession(AFortPlayerControllerAthena* PC, APawn* Pawn)
	{
		PC->AcknowledgedPawn = Pawn;

		static UFortAbilitySet* AbilitySet = Utils::FindObject<UFortAbilitySet>(L"/Game/Abilities/Player/Generic/Traits/DefaultPlayer/GAS_AthenaPlayer.GAS_AthenaPlayer");
		Abilities::GiveAbilitySet((AFortPlayerPawn*)Pawn, AbilitySet);

		auto& ModifierList = AFortGameStateAthena::Get()->CurrentPlaylistInfo.BasePlaylist->ModifierList;
		for (auto& Mod : ModifierList)
			GiveModifier(PC, Mod.Get());

		return ServerAcknowledgePossessionOG(PC, Pawn);
	}

	inline void (*ServerLoadingScreenDroppedOG)(AFortPlayerControllerAthena* PC);
	inline void ServerLoadingScreenDropped(AFortPlayerControllerAthena* PC)
	{
		AFortGameStateAthena* GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;
		AFortGameModeAthena* GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;
		auto Pawn = (AFortPlayerPawn*)PC->Pawn;

		return ServerLoadingScreenDroppedOG(PC);
	}

	void (*ServerReadyToStartMatchOG)(AFortPlayerControllerAthena* PC);
	void ServerReadyToStartMatch(AFortPlayerControllerAthena* PC)
	{
		if (!PC)
		{
			return;
		}

		return ServerReadyToStartMatchOG(PC);
	}

	void (*GetPlayerViewPointOG)(AFortPlayerControllerAthena*, FVector&, FRotator&);
	void GetPlayerViewPoint(AFortPlayerControllerAthena* PlayerController, FVector& Loc, FRotator& Rot)
	{
		static auto SFName = UKismetStringLibrary::Conv_StringToName(FString(L"Spectating"));
		if (PlayerController->StateName == SFName)
		{
			Loc = PlayerController->LastSpectatorSyncLocation;
			Rot = PlayerController->LastSpectatorSyncRotation;
		}
		else
		{
			auto ViewTarget = PlayerController->GetViewTarget();

			if (ViewTarget)
			{
				Loc = ViewTarget->K2_GetActorLocation();
				if (auto TargetPawn = ViewTarget->Cast<AFortPlayerPawnAthena>())
					Loc.Z += TargetPawn->BaseEyeHeight;
				Rot = PlayerController->GetControlRotation();
			}
			else
				PlayerController->GetActorEyesViewPoint(&Loc, &Rot);
		}
	}

	inline void (*ServerAttemptAircraftJumpOG)(UFortControllerComponent* Comp, FRotator Rotation);
	inline void ServerAttemptAircraftJump(UFortControllerComponent* Comp, FRotator Rotation)
	{
		AFortGameStateAthena* GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;

		auto PC = (AFortPlayerControllerAthena*)Comp->GetOwner();
		UWorld::GetWorld()->AuthorityGameMode->RestartPlayer(PC);

		return ServerAttemptAircraftJumpOG(Comp, Rotation);
	}

	static inline __int64 (*ClientOnPawnDiedOG)(AFortPlayerControllerAthena* PC, FFortPlayerDeathReport DeathReport);

	__int64 ClientOnPawnDied(AFortPlayerControllerAthena* PC, FFortPlayerDeathReport DeathReport) {
		auto GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;
		auto GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;

		AFortPlayerStateAthena* PlayerState = (AFortPlayerStateAthena*)PC->PlayerState;
		if (!PlayerState) {
			return ClientOnPawnDied(PC, DeathReport);
		}
		FVector DeathLocation = PC->Pawn->K2_GetActorLocation();

		if (!GameState->IsRespawningAllowed(PlayerState))
		{
			if (PC && PC->WorldInventory)
			{
				for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
				{
					if (((UFortWorldItemDefinition*)PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition)->bCanBeDropped)
					{
						Utils::SpawnPickup(PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemDefinition, PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.Count, PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.LoadedAmmo, DeathLocation, EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::PlayerElimination, PC->MyFortPawn);
					}
				}
			}

			FAthenaRewardResult Result;

			PC->ClientSendEndBattleRoyaleMatchForPlayer(true, Result);

			FAthenaMatchStats Stats;
			FAthenaMatchTeamStats TeamStats;

			if (PlayerState)
			{
				PlayerState->Place = GameMode->AlivePlayers.Num();
				PlayerState->OnRep_Place();
			}

			for (size_t i = 0; i < 20; i++)
			{
				Stats.Stats[i] = 0;
			}

			Stats.Stats[3] = PlayerState->KillScore;

			TeamStats.Place = PlayerState->Place;
			TeamStats.TotalPlayers = GameState->TotalPlayers;

			PC->ClientSendMatchStatsForPlayer(Stats);
			PC->ClientSendTeamStatsForPlayer(TeamStats);
		}

		return ClientOnPawnDiedOG(PC, DeathReport);
	}

	void ServerSendZiplineState(UObject* Context, FFrame& Stack)
	{
		FZiplinePawnState State;

		Stack.StepCompiledIn(&State);
		Stack.IncrementCode();

		auto Pawn = (AFortPlayerPawn*)Context;

		if (!Pawn)
			return;

		Pawn->ZiplineState = State;

		((void (*)(AFortPlayerPawn*))(Jeremy::ImageBase + 0x16a2800))(Pawn);

		if (State.bJumped)
		{
			auto Velocity = Pawn->CharacterMovement->Velocity;
			auto VelocityX = Velocity.X * -0.5f;
			auto VelocityY = Velocity.Y * -0.5f;
			Pawn->LaunchCharacterJump({ VelocityX >= -750 ? min(VelocityX, 750) : -750, VelocityY >= -750 ? min(VelocityY, 750) : -750, 1200 }, false, false, true, true);
		}
	}

	static void ServerBeginEditingBuildingActor(AFortPlayerControllerAthena* PC, ABuildingSMActor* Building)
	{
		if (!PC || !PC->MyFortPawn || !Building || Building->TeamIndex != static_cast<AFortPlayerStateAthena*>(PC->PlayerState)->TeamIndex)
			return;

		AFortPlayerStateAthena* PlayerState = (AFortPlayerStateAthena*)PC->PlayerState;
		if (!PlayerState)
			return;

		auto itemEntry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([](FFortItemEntry& entry)
			{ return entry.ItemDefinition->IsA<UFortEditToolItemDefinition>(); });
		if (!itemEntry)
			return;

		PC->ServerExecuteInventoryItem(itemEntry->ItemGuid);
	}

	static bool CanBePlacedByPlayer(UClass* BuildClass)
	{
		return AFortGameStateAthena::Get()->AllPlayerBuildableClasses.Search([BuildClass](UClass* Class) { return Class == BuildClass; });
	}

	static void ServerEditBuildingActor(AFortPlayerControllerAthena* PC, ABuildingSMActor* Building, TSubclassOf<ABuildingSMActor> NewClass, uint8 RotationIterations, bool bMirrored)
	{
		if (!PC || !Building || !NewClass || !Building->IsA<ABuildingSMActor>() || !CanBePlacedByPlayer(NewClass) || Building->TeamIndex != static_cast<AFortPlayerStateAthena*>(PC->PlayerState)->TeamIndex)
			return;

		Building->SetNetDormancy(ENetDormancy::DORM_DormantAll);
		Building->EditingPlayer = nullptr;

		static auto ReplaceBuildingActor = (ABuildingSMActor * (*)(ABuildingSMActor*, unsigned int, UObject*, unsigned int, int, bool, AFortPlayerControllerAthena*))(Jeremy::ImageBase + 0x11252b0);

		ABuildingSMActor* NewBuild = ReplaceBuildingActor(Building, 1, NewClass, Building->CurrentBuildingLevel, RotationIterations, bMirrored, PC);

		if (NewBuild)
			NewBuild->bPlayerPlaced = true;
	}

	inline void ServerCreateBuildingActor(AFortPlayerControllerAthena* PC, FCreateBuildingActorData CreateBuildingData)
	{
		if (!PC || PC->IsInAircraft())
			return;

		UClass* BuildingClass = PC->BroadcastRemoteClientInfo->RemoteBuildableClass.Get();
		char a7;
		TArray<AActor*> BuildingsToRemove;

		if (!CantBuild(UWorld::GetWorld(), BuildingClass, CreateBuildingData.BuildLoc, CreateBuildingData.BuildRot, CreateBuildingData.bMirrored, &BuildingsToRemove, &a7))
		{
			auto ResDef = UFortKismetLibrary::GetDefaultObj()->K2_GetResourceItemDefinition(((ABuildingSMActor*)BuildingClass->DefaultObject)->ResourceType);

			if (!Options::bInfiniteMats)
				Inventory::RemoveItem(PC, ResDef, 10);

			ABuildingSMActor* NewBuilding = Utils::SpawnActor<ABuildingSMActor>(CreateBuildingData.BuildLoc, CreateBuildingData.BuildRot, PC, BuildingClass);

			NewBuilding->bPlayerPlaced = true;
			NewBuilding->InitializeKismetSpawnedBuildingActor(NewBuilding, PC, true);
			NewBuilding->TeamIndex = ((AFortPlayerStateAthena*)PC->PlayerState)->TeamIndex;
			NewBuilding->Team = EFortTeam(NewBuilding->TeamIndex);

			for (size_t i = 0; i < BuildingsToRemove.Num(); i++)
			{
				BuildingsToRemove[i]->K2_DestroyActor();
			}
			UKismetArrayLibrary::Array_Clear((TArray<int32>&)BuildingsToRemove);
		}
	}


	inline __int64 (*SpecConstructor)(FGameplayAbilitySpec*, UObject*, int, int, UObject*) = decltype(SpecConstructor)(InSDKUtils::GetImageBase() + 0x868290);
	inline FGameplayAbilitySpecHandle(*GiveAbilityAndActivateOnce)(UAbilitySystemComponent* ASC, FGameplayAbilitySpecHandle*, FGameplayAbilitySpec, __int64) = decltype(GiveAbilityAndActivateOnce)(__int64(GetModuleHandleW(0)) + 0x843f10);

	void ServerPlayEmoteItem(AFortPlayerController* PC, UFortItemDefinition* EmoteAsset, float RandomEmoteNumber)
	{
		if (!PC || !EmoteAsset || !PC->MyFortPawn)
			return;

		static UClass* DanceAbility = Utils::FindObject<UClass>(L"/Game/Abilities/Emotes/GAB_Emote_Generic.GAB_Emote_Generic_C");
		static UClass* SprayAbility = Utils::FindObject<UClass>(L"/Game/Abilities/Sprays/GAB_Spray_Generic.GAB_Spray_Generic_C");

		if (!DanceAbility || !SprayAbility)
			return;

		auto EmoteDef = (UAthenaDanceItemDefinition*)EmoteAsset;
		if (!EmoteDef)
			return;

		PC->MyFortPawn->bMovingEmote = EmoteDef->bMovingEmote;
		PC->MyFortPawn->EmoteWalkSpeed = EmoteDef->WalkForwardSpeed;
		PC->MyFortPawn->bMovingEmoteForwardOnly = EmoteDef->bMoveForwardOnly;
		PC->MyFortPawn->EmoteWalkSpeed = EmoteDef->WalkForwardSpeed;

		FGameplayAbilitySpec Spec{};
		UGameplayAbility* Ability = nullptr;
		if (EmoteAsset->IsA(UAthenaSprayItemDefinition::StaticClass()))
		{
			Ability = (UGameplayAbility*)SprayAbility->DefaultObject;
		}

		if (Ability == nullptr)
		{
			Ability = (UGameplayAbility*)DanceAbility->DefaultObject;
		}
		if (Ability)
		{
			FGameplayAbilitySpec Spec{};
			SpecConstructor(&Spec, Ability, 1, -1, EmoteAsset);
			GiveAbilityAndActivateOnce(((AFortPlayerStateAthena*)PC->PlayerState)->AbilitySystemComponent, &Spec.Handle, Spec, 0);
		}
	}

	void ServerPlaySquadQuickChatMessage(AFortPlayerControllerAthena* PC, FAthenaQuickChatActiveEntry ChatEntry, __int64)
	{
		static ETeamMemberState MemberStates[10] =
		{
			ETeamMemberState::ChatBubble,
			ETeamMemberState::EnemySpotted,
			ETeamMemberState::NeedMaterials,
			ETeamMemberState::NeedBandages,
			ETeamMemberState::NeedShields,
			ETeamMemberState::NeedAmmoHeavy,
			ETeamMemberState::NeedAmmoLight,
			ETeamMemberState::FIRST_CHAT_MESSAGE,
			ETeamMemberState::NeedAmmoMedium,
			ETeamMemberState::NeedAmmoShells
		};

		auto PlayerState = reinterpret_cast<AFortPlayerStateAthena*>(PC->PlayerState);

		PlayerState->ReplicatedTeamMemberState = MemberStates[ChatEntry.Index];

		PlayerState->OnRep_ReplicatedTeamMemberState();

		static auto EmojiComm = Utils::FindObject<UAthenaEmojiItemDefinition>(L"/Game/Athena/Items/Cosmetics/Dances/Emoji/Emoji_Comm.Emoji_Comm");

		if (EmojiComm)
		{
			PC->ServerPlayEmoteItem(EmojiComm);
		}
	}

	FFortItemEntry* FindEntry(AFortPlayerController* PC, UFortItemDefinition* Def)
	{

		auto Inventory = PC->WorldInventory;
		if (!Inventory && PC->IsA(AFortAthenaAIBotController::StaticClass()))
		{
			Inventory = ((AFortAthenaAIBotController*)PC)->Inventory;
		}


		for (size_t i = 0; i < Inventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (!Inventory->Inventory.ReplicatedEntries.IsValidIndex(i))
				continue;
			if (Inventory->Inventory.ReplicatedEntries[i].ItemDefinition == Def)
				return &Inventory->Inventory.ReplicatedEntries[i];
		}
		return nullptr;
	}


	void ServerEndEditingBuildingActor(AFortPlayerControllerAthena* PlayerController, ABuildingSMActor* BuildingActorToStopEditing)
	{
		if (!PlayerController || !BuildingActorToStopEditing || BuildingActorToStopEditing->EditingPlayer != (AFortPlayerStateAthena*)PlayerController->PlayerState || !PlayerController->MyFortPawn)
			return;

		BuildingActorToStopEditing->SetNetDormancy(ENetDormancy::DORM_DormantAll);
		BuildingActorToStopEditing->EditingPlayer = nullptr;

		static auto EditToolDefinition = Utils::FindObject<UFortItemDefinition>(L"/Game/Items/Weapons/BuildingTools/EditTool.EditTool");

		if (!PlayerController->MyFortPawn->CurrentWeapon || PlayerController->MyFortPawn->CurrentWeapon->WeaponData != EditToolDefinition)
		{
			FFortItemEntry* ItemEntry = FindEntry(PlayerController, EditToolDefinition);

			if (!ItemEntry)
				return;

			PlayerController->ServerExecuteInventoryItem(ItemEntry->ItemGuid);
		}

		AFortWeap_EditingTool* EditTool = Utils::Cast<AFortWeap_EditingTool>(PlayerController->MyFortPawn->CurrentWeapon);

		if (EditTool)
		{
			EditTool->EditActor = nullptr;
			EditTool->OnRep_EditActor();
		}
	}

	static void ServerRepairBuildingActor(AFortPlayerControllerAthena* PC, ABuildingSMActor* Building)
	{
		if (!PC)
			return;

		auto Price = (int32)std::floor((10.f * (1.f - Building->GetHealthPercent())) * 0.75f);
		auto res = UFortKismetLibrary::K2_GetResourceItemDefinition(Building->ResourceType);
		auto itemEntry = PC->WorldInventory->Inventory.ReplicatedEntries.Search([res](FFortItemEntry& entry)
			{ return entry.ItemDefinition == res; });

		Inventory::RemoveItem(PC, res, Price);

		Building->RepairBuilding(PC, Price);
	}

	static inline void (*OnDamageServerOG)(ABuildingSMActor*, float, FGameplayTagContainer, FVector, FHitResult, AFortPlayerControllerAthena*, AActor*, FGameplayEffectContextHandle);
	void OnDamageServer(ABuildingSMActor* Actor, float Damage, FGameplayTagContainer DamageTags, FVector Momentum, FHitResult HitInfo, AFortPlayerControllerAthena* InstigatedBy, AActor* DamageCauser, FGameplayEffectContextHandle EffectContext) {
		auto GameState = ((AFortGameStateAthena*)UWorld::GetWorld()->GameState);
		if (!InstigatedBy || Actor->bPlayerPlaced || Actor->GetHealth() == 1 || Actor->IsA(UObject::FindClassFast("B_Athena_VendingMachine_C")) || Actor->IsA(GameState->MapInfo->LlamaClass)) return OnDamageServerOG(Actor, Damage, DamageTags, Momentum, HitInfo, InstigatedBy, DamageCauser, EffectContext);
		if (!DamageCauser || !DamageCauser->IsA<AFortWeapon>() || !((AFortWeapon*)DamageCauser)->WeaponData->IsA<UFortWeaponMeleeItemDefinition>()) return OnDamageServerOG(Actor, Damage, DamageTags, Momentum, HitInfo, InstigatedBy, DamageCauser, EffectContext);
		static auto PickaxeTag = UKismetStringLibrary::Conv_StringToName(L"Weapon.Melee.Impact.Pickaxe");
		auto entry = DamageTags.GameplayTags.Search([](FGameplayTag& entry) {
			return entry.TagName.ComparisonIndex == PickaxeTag.ComparisonIndex;
			});
		if (!entry)
			return OnDamageServerOG(Actor, Damage, DamageTags, Momentum, HitInfo, InstigatedBy, DamageCauser, EffectContext);
		auto Resource = UFortKismetLibrary::K2_GetResourceItemDefinition(Actor->ResourceType);
		if (!Resource)
			return OnDamageServerOG(Actor, Damage, DamageTags, Momentum, HitInfo, InstigatedBy, DamageCauser, EffectContext);
		SDK::FScalableFloat StackSizeFloat(Resource->MaxStackSize);
		auto MaxMat = (int32)Utils::EvaluateScalableFloat(StackSizeFloat);
		FCurveTableRowHandle& BuildingResourceAmountOverride = Actor->BuildingResourceAmountOverride;
		int ResCount = 0;
		if (Actor->BuildingResourceAmountOverride.RowName.ComparisonIndex > 0)
		{
			float Out;
			UDataTableFunctionLibrary::EvaluateCurveTableRow(Actor->BuildingResourceAmountOverride.CurveTable, Actor->BuildingResourceAmountOverride.RowName, 0.f, nullptr, &Out, FString());
			float RC = Out / (Actor->GetMaxHealth() / Damage);
			ResCount = (int)round(RC);
		}
		if (ResCount > 0)
		{
			auto itemEntry = InstigatedBy->WorldInventory->Inventory.ReplicatedEntries.Search([&](FFortItemEntry& entry) {
				return entry.ItemDefinition == Resource;
				});
			if (itemEntry)
			{
				itemEntry->Count += ResCount;
				if (itemEntry->Count > MaxMat)
				{
					Inventory::SpawnPickup(InstigatedBy->Pawn->K2_GetActorLocation(), itemEntry->ItemDefinition, itemEntry->Count - MaxMat, 0, EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource::Unset, InstigatedBy->MyFortPawn);
					itemEntry->Count = MaxMat;
				}
				Inventory::ReplaceEntry(InstigatedBy, *itemEntry);
			}
			else
			{
				if (ResCount > MaxMat)
				{
					Inventory::SpawnPickup(InstigatedBy->Pawn->K2_GetActorLocation(), Resource, ResCount - MaxMat, 0, EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource::Unset, InstigatedBy->MyFortPawn);
					ResCount = MaxMat;
				}
				Inventory::GiveItem(InstigatedBy, Resource, ResCount, 0);
			}
		}

		InstigatedBy->ClientReportDamagedResourceBuilding(Actor, ResCount == 0 ? EFortResourceType::None : Actor->ResourceType, ResCount, false, Damage == 100.f);
		return OnDamageServerOG(Actor, Damage, DamageTags, Momentum, HitInfo, InstigatedBy, DamageCauser, EffectContext);
	}

	void (*OnReloadOG)(AFortWeapon* Weapon, int RemoveCount);
	void OnReload(AFortWeapon* Weapon, int RemoveCount)
	{
		if (Options::bInfiniteAmmo)
			return;

		OnReloadOG(Weapon, RemoveCount);
		auto WeaponDef = Weapon->WeaponData;
		if (!WeaponDef)
			return;

		auto AmmoDef = WeaponDef->GetAmmoWorldItemDefinition_BP();
		if (!AmmoDef)
			return;
		AFortPlayerPawnAthena* Pawn = (AFortPlayerPawnAthena*)Weapon->GetOwner();
		AFortPlayerControllerAthena* PC = (AFortPlayerControllerAthena*)Pawn->Controller;
		if (!PC->IsA(AFortPlayerControllerAthena::StaticClass()))
			return;

		Inventory::RemoveItem(PC, AmmoDef, RemoveCount);
		Inventory::UpdateLoadedAmmo(PC, Weapon, RemoveCount);

		return;
	}

	void TeleportPlayerPawn(UObject* Context, FFrame& Stack, bool* Ret)
	{
		UObject* WorldContextObject;
		AFortPlayerPawn* PlayerPawn;
		FVector DestLocation;
		FRotator DestRotation;
		bool bIgnoreCollision;
		bool bIgnoreSupplementalKillVolumeSweep;

		Stack.StepCompiledIn(&WorldContextObject);
		Stack.StepCompiledIn(&PlayerPawn);
		Stack.StepCompiledIn(&DestLocation);
		Stack.StepCompiledIn(&DestRotation);
		Stack.StepCompiledIn(&bIgnoreCollision);
		Stack.StepCompiledIn(&bIgnoreSupplementalKillVolumeSweep);
		Stack.IncrementCode();

		PlayerPawn->K2_TeleportTo(DestLocation, DestRotation);
		*Ret = true;
	}

	void Hook()
	{
		Utils::HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x108, ServerAcknowledgePossession, (LPVOID*)&ServerAcknowledgePossessionOG);

		Utils::HookVTable(AFortPlayerController::GetDefaultObj(), 0x261, ServerLoadingScreenDropped, (LPVOID*)ServerLoadingScreenDroppedOG);

		//Utils::HookVTable(AFortPlayerController::GetDefaultObj(), 0x26B, ServerReadyToStartMatch, (LPVOID*)ServerReadyToStartMatchOG);

		MH_CreateHook((LPVOID)(Jeremy::ImageBase + 0x18A7A60), OnReload, (LPVOID*)&OnReloadOG); //proper

		MH_CreateHook((LPVOID)(Jeremy::ImageBase + 0x16E2230), GetPlayerViewPoint, (LPVOID*)&GetPlayerViewPointOG);

		//MH_CreateHook((LPVOID)(Jeremy::ImageBase + 0x1013770), ServerAttemptAircraftJump, (LPVOID*)&ServerAttemptAircraftJumpOG); //done

		Utils::HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x433, ServerAttemptAircraftJump, nullptr);
		// 
		//MH_CreateHook((LPVOID)(Jeremy::ImageBase + 0x2f77d80), ClientOnPawnDied, (LPVOID*)&ClientOnPawnDiedOG);

		Utils::ExecHook(L"/Script/FortniteGame.FortPlayerPawn.ServerSendZiplineState", ServerSendZiplineState);

		Utils::HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x223, ServerCreateBuildingActor, nullptr);

		Utils::HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x22A, ServerBeginEditingBuildingActor, nullptr);
		Utils::HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x225, ServerEditBuildingActor, nullptr);
		Utils::HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x228, ServerEndEditingBuildingActor, nullptr);
		Utils::HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x21F, ServerRepairBuildingActor, nullptr);

		Utils::HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x45E, ServerPlaySquadQuickChatMessage, nullptr); //very proper

		MH_CreateHook((LPVOID)(Jeremy::ImageBase + 0x18f0570), OnDamageServer, (LPVOID*)&OnDamageServerOG);

		Utils::HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x1BC, ServerPlayEmoteItem, nullptr);

		//Utils::ExecHook(L"/Script/FortniteGame.FortMissionLibrary.TeleportPlayerPawn", TeleportPlayerPawn);
	}
}