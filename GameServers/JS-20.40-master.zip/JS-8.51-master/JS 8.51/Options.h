#pragma once

struct Options
{
public:
    static inline auto bInfiniteMats = true;
    static inline auto bInfiniteAmmo = true;
    static inline auto iMinPlayersForEarlyStart = 1;
    static inline auto iWarmupTime = 30.f;
    static inline auto sPlaylist = L"/Game/Athena/Playlists/Playlist_DefaultSolo.Playlist_DefaultSolo";
};