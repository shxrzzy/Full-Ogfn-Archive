#pragma once
#include "framework.h"
#include "pch.h"

static bool (*InternalTryActivateAbility)(UAbilitySystemComponent* AbilitySystemComp, FGameplayAbilitySpecHandle AbilityToActivate, FPredictionKey InPredictionKey, UGameplayAbility** OutInstancedAbility, void* OnGameplayAbilityEndedDelegate, const FGameplayEventData* TriggerEventData) = decltype(InternalTryActivateAbility)(Jeremy::ImageBase + 0x8455d0);
static void(*GiveAbilityOG)(UAbilitySystemComponent* This, FGameplayAbilitySpecHandle* Handle, FGameplayAbilitySpec Spec) = decltype(GiveAbilityOG)(Jeremy::ImageBase + 0x843df0);
static void (*AbilitySpecConstructor)(FGameplayAbilitySpec*, UGameplayAbility*, int, int, UObject*) = decltype(AbilitySpecConstructor)(Jeremy::ImageBase + 0x868290);

namespace Abilities
{
	static void GiveAbility(AFortPlayerPawn* Pawn, UObject* Ability)
	{
		if (!Pawn || !Pawn->PlayerState || !Ability)
			return;
		auto ASC = Pawn->AbilitySystemComponent;

		if (!ASC)
			return;

		FGameplayAbilitySpec Spec{};
		((void (*)(FGameplayAbilitySpec*, UGameplayAbility*, int, int, UObject*))AbilitySpecConstructor)(&Spec, (UGameplayAbility*)Ability, 1, -1, nullptr);
		((FGameplayAbilitySpecHandle * (__fastcall*)(UAbilitySystemComponent*, FGameplayAbilitySpecHandle*, FGameplayAbilitySpec)) GiveAbilityOG)(ASC, &Spec.Handle, Spec);
	}

	static void GiveAbilitySet(AFortPlayerPawn* Pawn, UFortAbilitySet* Set)
	{
		if (Set)
		{
			for (auto& GA : Set->GameplayAbilities)
				GiveAbility(Pawn, GA->DefaultObject);
			for (auto& GE : Set->PassiveGameplayEffects)
				Pawn->AbilitySystemComponent->BP_ApplyGameplayEffectToSelf(GE.GameplayEffect.Get(), GE.Level, Pawn->AbilitySystemComponent->MakeEffectContext());
		}
	}

	FGameplayAbilitySpec* FindAbilitySpecFromHandle(UAbilitySystemComponent* AbilitySystemComponent, FGameplayAbilitySpecHandle Handle)
	{
		for (FGameplayAbilitySpec& Spec : AbilitySystemComponent->ActivatableAbilities.Items)
		{
			if (Spec.Handle.Handle == Handle.Handle)
				return &Spec;
		}

		return nullptr;
	}

	void InternalServerTryActiveAbility(UAbilitySystemComponent* AbilitySystemComponent, FGameplayAbilitySpecHandle Handle, bool InputPressed, const FPredictionKey& PredictionKey, const FGameplayEventData* TriggerEventData)
	{
		FGameplayAbilitySpec* Spec = FindAbilitySpecFromHandle(AbilitySystemComponent, Handle);
		if (!Spec)
		{
			AbilitySystemComponent->ClientActivateAbilityFailed(Handle, PredictionKey.Current);
			return;
		}

		const UGameplayAbility* AbilityToActivate = Spec->Ability;

		UGameplayAbility* InstancedAbility = nullptr;
		Spec->InputPressed = true;

		if (!InternalTryActivateAbility(AbilitySystemComponent, Handle, PredictionKey, &InstancedAbility, nullptr, TriggerEventData))
		{
			AbilitySystemComponent->ClientActivateAbilityFailed(Handle, PredictionKey.Current);
			Spec->InputPressed = false;

			AbilitySystemComponent->ActivatableAbilities.MarkItemDirty(*Spec);
		}
	}

	void Hook()
	{
		Utils::HookEvery<UAbilitySystemComponent>(0xf4, InternalServerTryActiveAbility);
	}
}