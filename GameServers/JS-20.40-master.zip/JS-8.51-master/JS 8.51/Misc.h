#pragma once
#include "framework.h"

namespace Misc
{
    void NullFunc() {}

    int True()
    {
        return 1;
    }

    int False()
    {
        return 0;
    }

    __int64 NoMcp()
    {
        return 0;
    }

    static inline void (*KickPlayerOG)(AGameSession*, AController*);
    static void KickPlayer(AGameSession*, AController*)
    {
        return;
    }

    void (*DispatchRequestOG)(__int64 a1, unsigned __int64* a2, int a3);
    void DispatchRequest(__int64 a1, unsigned __int64* a2, int a3)
    {
        return DispatchRequestOG(a1, a2, 3);
    }

    void Hook()
    {
        MH_CreateHook((LPVOID)(Jeremy::ImageBase + 0x2c03d20), KickPlayer, (LPVOID*)&KickPlayerOG); //done
        MH_CreateHook((LPVOID)(Jeremy::ImageBase + 0xcf2e80), DispatchRequest, (LPVOID*)&DispatchRequestOG); //done
        MH_CreateHook((LPVOID)(Jeremy::ImageBase + 0x843F10), True, nullptr); //done
    }
}