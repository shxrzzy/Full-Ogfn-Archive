#pragma once
#include <stdint.h>
#include <vector>
#include <windows.h>

namespace Runtime {
	namespace Offsets {
		inline uint64_t ImageBase = (uint64_t)(GetModuleHandle(nullptr));
		inline uint64_t ReadyToStartMatch = ImageBase + 0x1ec78b0;
		inline uint64_t SpawnDefaultPawnFor = ImageBase + 0x1ed2b10;
		inline uint64_t ServerAcknowledgePossession = ImageBase + 0x91b840;
		inline uint64_t HandleStartingNewPlayer = ImageBase + 0x246b7e0;
		inline uint64_t ServerExecuteInventoryItem = ImageBase + 0x91b840;
		inline uint64_t ServerAttemptAircraftJump = ImageBase + 0x91b840;
		inline uint64_t CreateNetDriver = ImageBase + 0x4db8e70;
		inline uint64_t InitHost = ImageBase + 0xbb2970;
		inline uint64_t PauseBeaconRequests = ImageBase + 0x271ab00;
		inline uint64_t InitListen = ImageBase + 0xbb2ec0;
		inline uint64_t SetWorld = ImageBase + 0x4b297f0;
		inline uint64_t WorldNetMode = ImageBase + 0x4e1a9a0;
		inline uint64_t GIsClient = ImageBase + 0x8d265e9;
		inline uint64_t TickFlush = ImageBase + 0x4b2ac40;
		inline uint64_t GetMaxTickRate = ImageBase + 0x4dbfa20;
		inline uint64_t DispatchRequest = ImageBase + 0x1312430;
		inline uint64_t StaticFindObject = ImageBase + 0x352f6e0;
		inline uint64_t StaticLoadObject = ImageBase + 0x3530bd0;
		inline uint64_t ApplyCharacterCustomization = ImageBase + 0x29e0c70;
		inline uint64_t InternalTryActivateAbility = ImageBase + 0x9acc70;
		inline uint64_t InternalServerTryActivateAbility = ImageBase + 0x91b840;
		inline uint64_t ServerReplicateActors = ImageBase + 0x15a78d0;
		inline uint64_t Realloc = ImageBase + 0x3230950;
		inline uint64_t ConstructAbilitySpec = ImageBase + 0x9820d0;
		inline uint64_t InternalGiveAbility = ImageBase + 0x9a5e50;
		inline uint64_t StartNewSafeZonePhase = ImageBase + 0x1ed8e20;
		inline uint64_t PickTeam = ImageBase + 0x1ec1690;
		inline uint32_t ReadyToStartMatchVft = 0x101;
		inline uint32_t SpawnDefaultPawnForVft = 0xc8;
		inline uint32_t ServerAcknowledgePossessionVft = 0x10d;
		inline uint32_t HandleStartingNewPlayerVft = 0xce;
		inline uint32_t ServerExecuteInventoryItemVft = 0x20d;
		inline uint32_t ServerAttemptAircraftJumpVft = 0x89;
		inline uint32_t InternalServerTryActivateAbilityVft = 0xfa;
		inline uint64_t GameSessionPatch = ImageBase + 0x1f196c3;
		inline uint64_t EncryptionPatch = ImageBase + 0x4e1cfbe;

		inline std::vector<uint64_t> NullFuncs = { ImageBase + 0x247e020, ImageBase + 0x349d760 };
		inline std::vector<uint64_t> RetTrueFuncs = { ImageBase + 0x49c50f0 };
	}
}