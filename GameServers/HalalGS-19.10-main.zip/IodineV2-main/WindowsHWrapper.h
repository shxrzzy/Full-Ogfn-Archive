// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.
#pragma once

#include "CoreTypes.h"
#include "PreWindowsApi.h"
#ifndef STRICT
#define STRICT
#endif
#include "MinWindows.h"
#include "PostWindowsApi.h"