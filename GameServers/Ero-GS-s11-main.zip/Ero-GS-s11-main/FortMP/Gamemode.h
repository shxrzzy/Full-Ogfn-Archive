#pragma once
#include "Utils.h"
#include "SDK.hpp"
#include <iostream>
#include <fstream>
#include "Misc.h"
#include "World.h"
#include "llama.h"

static SDK::UNetDriver* (*CreateNetDriver)(void*, void*, SDK::FName) = decltype(CreateNetDriver)(__int64(GetModuleHandleW(0)) + 0x3B21C20);


using namespace std;
using namespace SDK;
using namespace Params;

inline bool Ready = false;

inline bool (*ReadyToStartMatchOG)(SDK::AFortGameModeAthena* GM);
inline bool ReadyToStartMatch(SDK::AFortGameModeAthena* GM)
{
	if (IsSTW)
	{
		static bool Done2 = false;
		AFortGameModeOutpost* GameMode = (AFortGameModeOutpost*)GM;
		if (!Ready || !GM->GameState)
			return false;
		GameMode->bTheaterDataIsReady = true;
		AFortGameStateOutpost* GameState = (AFortGameStateOutpost*)GM->GameState;
		GameState->bOutpostDefenseActive = true;

		if (!Done2)
		{
			Done2 = true;
			auto Engine = GetEngine();
			auto World = GetWorld();
			FName Name = ((UKismetStringLibrary*)UKismetStringLibrary::StaticClass()->DefaultObject)->Conv_StringToName(TEXT("GameNetDriver"));
			UNetDriver* Driver = CreateNetDriver(Engine, World, Name);

			Driver->World = World;
			Driver->NetDriverName = Name;

			FString Error;
			FURL InURL = FURL();
			InURL.Port = 7777;

			InitListen(Driver, World, InURL, false, Error);
			SetWorld(Driver, World);

			World->NetDriver = Driver;
			World->LevelCollections[0].NetDriver = Driver;
			World->LevelCollections[1].NetDriver = Driver;
		}

		return ReadyToStartMatchOG(GM);
	}
	else
	{
		ReadyToStartMatchOG(GM);
		auto GameState = (AFortGameStateAthena*)GM->GameState;
		static bool Done = false;
		static bool Done2 = false;
		if (!Ready || !GameState)
			return false;
		if (!Done)
		{
			Done = true;
			UFortPlaylistAthena* Playlist = IsDadBro ? StaticFindObject<UFortPlaylistAthena>("/Game/Athena/Playlists/DADBRO/Playlist_DADBRO_Squads.Playlist_DADBRO_Squads") : StaticFindObject<UFortPlaylistAthena>("/Game/Athena/Playlists/Playlist_DefaultSolo.Playlist_DefaultSolo");
			GameState->CurrentPlaylistInfo.BasePlaylist = Playlist;
			GameState->CurrentPlaylistInfo.PlaylistReplicationKey++;
			GameState->CurrentPlaylistId = Playlist->PlaylistId;

			GameState->CurrentPlaylistInfo.MarkArrayDirty();
			NextIdx = Playlist->DefaultFirstTeam;
			MaxPlayersOnTeam = Playlist->MaxSquadSize;


			bool bDBNO = MaxPlayersOnTeam > 1;

			GameState->bDBNOEnabledForGameMode = bDBNO;
			GameState->bDBNODeathEnabled = bDBNO;

			GM->bAlwaysDBNO = bDBNO;
			GM->bDBNOEnabled = bDBNO;

			GM->CurrentPlaylistId = Playlist->PlaylistId;
			GM->CurrentPlaylistName = Playlist->PlaylistName;

			LootTierData = StaticLoadObject<UDataTable>(UKismetStringLibrary::GetDefaultObj()->Conv_NameToString(Playlist->LootTierData.ObjectID.AssetPathName).ToString());
			LootPackages = StaticLoadObject<UDataTable>(UKismetStringLibrary::GetDefaultObj()->Conv_NameToString(Playlist->LootPackages.ObjectID.AssetPathName).ToString());

			cout << LootTierData->GetName() << endl;
			cout << LootPackages->GetName() << endl;
		}

		if (!GameState->MapInfo)
			return false;

		if (!Done2)
		{
			Done2 = true;
			GameState->OnRep_CurrentPlaylistId();
			GameState->OnRep_CurrentPlaylistInfo();

			auto Engine = GetEngine();
			auto World = GetWorld();
			FName Name = ((UKismetStringLibrary*)UKismetStringLibrary::StaticClass()->DefaultObject)->Conv_StringToName(TEXT("GameNetDriver"));
			UNetDriver* Driver = CreateNetDriver(Engine, World, Name);

			Driver->World = World;
			Driver->NetDriverName = Name;

			FString Error;
			FURL InURL = FURL();
			InURL.Port = 7777;

			InitListen(Driver, World, InURL, false, Error);
			SetWorld(Driver, World);

			World->NetDriver = Driver;
			World->LevelCollections[0].NetDriver = Driver;
			World->LevelCollections[1].NetDriver = Driver;

			for (size_t i = 0; i < GameState->CurrentPlaylistInfo.BasePlaylist->AdditionalLevels.Num(); i++)
			{
				bool Success = false;
				ULevelStreamingDynamic::GetDefaultObj()->LoadLevelInstanceBySoftObjectPtr(UWorld::GetWorld(), GameState->CurrentPlaylistInfo.BasePlaylist->AdditionalLevels[i], FVector(), FRotator(), &Success);
				GameState->AdditionalPlaylistLevelsStreamed.Add(GameState->CurrentPlaylistInfo.BasePlaylist->AdditionalLevels[i].ObjectID.AssetPathName);
				Log(GameState->CurrentPlaylistInfo.BasePlaylist->AdditionalLevels[i].ObjectID.AssetPathName.ToString());
			}

			GameState->OnRep_AdditionalPlaylistLevelsStreamed();

			if (BotsEnabled)
			{
				BotMutator = SpawnActor<AFortAthenaMutator_Bots>({}, {}, nullptr, StaticLoadObject<UClass>("/Game/Athena/AI/Phoebe/BP_Phoebe_Mutator.BP_Phoebe_Mutator_C"));
				BotMutator->CachedGameMode = GM;
				BotMutator->CachedGameState = GameState;

				GM->ServerBotManager = (UFortServerBotManagerAthena*)UGameplayStatics::GetDefaultObj()->SpawnObject(UFortServerBotManagerAthena::StaticClass(), GM);
				GM->ServerBotManager->CachedBotMutator = BotMutator;
				GM->ServerBotManager->CachedGameMode = GM;
				GM->ServerBotManager->CachedGameState = GameState;

				GM->AIDirector = SpawnActor<AAthenaAIDirector>({});
				GM->AIDirector->Activate();
			}

			TArray<AActor*> VehicleSpawners;
			UGameplayStatics::GetDefaultObj()->GetAllActorsOfClass(UWorld::GetWorld(), AFortAthenaVehicleSpawner::StaticClass(), &VehicleSpawners);

			UClass* MeatballClass = StaticLoadObject<UClass>("/Game/Athena/DrivableVehicles/Meatball/Meatball_Large/MeatballVehicle_L.MeatballVehicle_L_C");

			SwapVTable(StaticLoadObject<UClass>("/Game/Athena/DrivableVehicles/Meatball/Meatball_Large/MeatballVehicle_L.MeatballVehicle_L_C")->DefaultObject, 0xED, ServerMove);

			for (size_t i = 0; i < VehicleSpawners.Num(); i++)
			{
				auto Vehicle = VehicleSpawners[i];
				if (((AFortAthenaVehicleSpawner*)Vehicle)->GetVehicleClass() == MeatballClass)
				{
					SpawnActor<AFortAthenaVehicle>(Vehicle->K2_GetActorLocation(), Vehicle->K2_GetActorRotation(), nullptr, ((AFortAthenaVehicleSpawner*)Vehicle)->GetVehicleClass());
				}
			}

			VehicleSpawners.FreeArray();

			CIDs = GetAllObjectsOfClass<UAthenaCharacterItemDefinition>();
			Pickaxes = GetAllObjectsOfClass<UAthenaPickaxeItemDefinition>();
			Backpacks = GetAllObjectsOfClass<UAthenaBackpackItemDefinition>();
			Gliders = GetAllObjectsOfClass<UAthenaGliderItemDefinition>();
			Contrails = GetAllObjectsOfClass<UAthenaSkyDiveContrailItemDefinition>();
			Dances = GetAllObjectsOfClass<UAthenaDanceItemDefinition>();

			GM->bWorldIsReady = true;
			cout << GameState->MapInfo->SupplyDropInfoList.Num() << endl;

			GameState->MapInfo->SupplyDropInfoList[0]->SupplyDropClass = StaticLoadObject<UClass>("/Game/Athena/SupplyDrops/AthenaSupplyDrop_Holiday.AthenaSupplyDrop_Holiday_C");

			TArray<AActor*> VendingMachinesArray;

			GetStatics()->GetAllActorsOfClass(GetWorld(), UObject::FindObject<UClass>("BlueprintGeneratedClass B_Athena_VendingMachine.B_Athena_VendingMachine_C"), &VendingMachinesArray);

			for (size_t i = 0; i < VendingMachinesArray.Num(); i++)
			{
				VendingMachinesArray[i]->K2_DestroyActor();
			}

			VendingMachinesArray.FreeArray();

			SetConsoleTitleA("Fortmp is now hosting on port 7777");
			Log("Listening on port 7777");
		}
	}

	return UWorld::GetWorld()->NetDriver->ClientConnections.Num() > 0;
}

inline APawn* SpawnDefaultPawnFor(SDK::AGameMode* a1, SDK::AController* a2, SDK::AActor* a3)
{
	FTransform wow = a3->GetTransform();
	return a1->SpawnDefaultPawnAtTransform(a2, wow);
}

inline __int64 (*OnAircraftEnteredDropZoneOG)(AFortGameModeAthena*);
inline __int64 OnAircraftEnteredDropZone(AFortGameModeAthena* a1)
{
	for (size_t i = 0; i < SpawnedBots.size(); i++)
	{
		SpawnedBots[i]->State = EBotState::InBus;
	}

	return OnAircraftEnteredDropZoneOG(a1);
}

inline __int64 (*OnAircraftExitedDropZoneOG)(__int64, __int64);
inline __int64 OnAircraftExitedDropZone(__int64 a1, AFortAthenaAircraft* a2)
{
	for (size_t i = 0; i < SpawnedBots.size(); i++)
	{
		SpawnedBots[i]->State = EBotState::Landed;
		SpawnedBots[i]->ForceJump(a2);
	}

	if (IsDadBro)
	{
		AFortAthenaMutator_DadBro* Wow = (AFortAthenaMutator_DadBro*)((AFortGameStateAthena*)UWorld::GetWorld()->GameState)->GetMutatorByClass(UWorld::GetWorld()->AuthorityGameMode, AFortAthenaMutator_DadBro::StaticClass());
		Wow->DadBroSpawnLocation.Z = -193.048096f;
		AFortAIPawn* Real = SpawnActor<AFortAIPawn>(Wow->DadBroSpawnLocation, {}, nullptr, StaticLoadObject<UClass>("/Game/Athena/DADBRO/DADBRO_Pawn.DADBRO_Pawn_C"), ESpawnActorCollisionHandlingMethod::AlwaysSpawn);
		Wow->DadBroPawn = Real;
		Wow->DadBroCodeState = EDadBroState::Active;
		Wow->OnRep_DadBroPawn();
		Wow->OnRep_DadBroCodeState();
	}

	return OnAircraftExitedDropZoneOG(a1, (__int64)a2);
}
