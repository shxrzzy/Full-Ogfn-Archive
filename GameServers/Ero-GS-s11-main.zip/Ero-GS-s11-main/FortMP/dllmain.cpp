#include <Windows.h>
#include "minhook/MinHook.h"
#include "Utils.h"
#include "Tick.h"
#include "Gamemode.h"
#include "World.h"
#include "Hooking.h"
#include "Misc.h"
#include "PC.h"
#include <cstdio>

#pragma comment(lib, "minhook/minhook.lib")

using namespace std;
using namespace SDK;

DWORD InitThread(LPVOID)
{
    srand(time(0));
    
    AllocConsole();
    FILE* console;
    freopen_s(&console, "CONOUT$", "w", stdout);
    MH_Initialize();
    InitGObjects();
    Log("Initializing...");

    Sleep(15000);

    Gamemode::InitHooks();
    Tick::InitHooks();
    World::InitHooks();
    PC::InitHooks();
    Misc::InitHooks();
    Teams::InitHooks();
    Abilities::InitHooks();
    
    *(bool*)(__int64(GetModuleHandleW(0)) + 0x6F41270) = false;
    *(bool*)(__int64(GetModuleHandleW(0)) + 0x6F41271) = true;

    SpectatingName = UKismetStringLibrary::GetDefaultObj()->Conv_StringToName(TEXT("Spectating"));
    ((UGameplayStatics*)UGameplayStatics::StaticClass()->DefaultObject)->OpenLevel(GetWorld(), ((UKismetStringLibrary*)UKismetStringLibrary::StaticClass()->DefaultObject)->Conv_StringToName(TEXT("Apollo_Terrain")), true, FString());

    GetEngine()->GameInstance->LocalPlayers.FreeArray();
    
    Sleep(1500);
    Ready = true;
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD Reason, LPVOID lpReserved)
{
    switch (Reason)
    {
    case DLL_PROCESS_ATTACH:
        CreateThread(0, 0, InitThread, 0, 0, 0);
        break;
    default:
        break;
    }
    return TRUE;
}