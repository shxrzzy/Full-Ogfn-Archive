#pragma once
#include "Utils.h"

void SpawnLlamas()
{
	TArray<AActor*> BuildingFoundations;

	Log("Spawning Llamas!");

	UBlueprintGeneratedClass* LLamaClass = StaticLoadObject<UBlueprintGeneratedClass>("/Game/Athena/SupplyDrops/Llama/AthenaSupplyDrop_Llama.AthenaSupplyDrop_Llama_C");

	Log(LLamaClass ? LLamaClass->GetFullName() : "Invalid Lama Class");

	Log(LLamaClass ? LLamaClass->GetFullName() : "Invalid Lama Class");

	GetStatics()->GetAllActorsOfClass(GetWorld(), ABuildingFoundation::StaticClass(), &BuildingFoundations);

	for (size_t i = 0; i < LlamasToSpawn; i++)
	{
		FVector SpawnLocLlama = (BuildingFoundations[GetMath()->RandomIntegerInRange(0, (BuildingFoundations.Num() - 1))]->K2_GetActorLocation() + FVector(0, 0, 100));

		Log("Spawning lama at location: ");
		LogVector(SpawnLocLlama);

		SpawnActorManual(LLamaClass, SpawnLocLlama);
	}

	BuildingFoundations.FreeArray();
}