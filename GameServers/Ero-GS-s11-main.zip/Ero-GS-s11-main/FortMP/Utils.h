#pragma once
#include <string>
#include <vector>
#include <map>
#include <iostream>
#include "SDK.hpp"
#include <algorithm>

using namespace std;
using namespace SDK;


static UObject* (*StaticLoadObjectOG)(UClass* Class, UObject* InOuter, const TCHAR* Name, const TCHAR* Filename, uint32_t LoadFlags, UObject* Sandbox, bool bAllowObjectReconciliation, void*) = decltype(StaticLoadObjectOG)(__int64(GetModuleHandleW(0)) + 0x2849140);
static UObject* (*StaticFindObjectOG)(UClass*, UObject* Package, const wchar_t* OrigInName, bool ExactClass) = decltype(StaticFindObjectOG)(__int64(GetModuleHandleW(0)) + 0x2847D60);

int LlamasToSpawn = 10;
inline int CurrentPlayersOnTeam = 0;
inline int MaxPlayersOnTeam = 1;
inline uint8 NextIdx = 0;
inline UDataTable* LootTierData = nullptr;
inline UDataTable* LootPackages = nullptr;

inline bool Siphon = false;
inline bool IsDadBro = false;
inline bool IsSTW = false;
inline bool BotsEnabled = true;

inline SDK::FName SpectatingName;

#define _LOGGING true
#if _LOGGING
#define LOG(str) printf("[FortMp]: %s\n", str)
#else
#define LOG() // This isn't logging because _LOGGING is set to false
#endif

template<typename T>
inline vector<T*> GetAllObjectsOfClass(UClass* Class = T::StaticClass())
{
	std::vector<T*> Objects{};

	for (int i = 0; i < UObject::GObjects->Num(); ++i)
	{
		UObject* Object = UObject::GObjects->GetByIndex(i);

		if (!Object)
			continue;

		if (Object->GetFullName().contains("Default"))
			continue;

		if (Object->GetFullName().contains("Test"))
			continue;

		if (Object->IsA(Class) && !Object->IsDefaultObject())
		{
			Objects.push_back((T*)Object);
		}
	}

	return Objects;
}

template<typename T>
inline T* Cast(UObject* Object, bool bForceCheck = true)
{
	if (Object)
	{
		if (bForceCheck)
		{
			return Object->IsA(T::StaticClass()) ? (T*)Object : nullptr;
		}
		else
		{
			return (T*)Object;
		}
	}
	return nullptr;
}

inline UFortEngine* GetEngine()
{
	static auto engine = UObject::FindObject<UFortEngine>("FortEngine_");
	return engine;
}

inline UWorld* GetWorld()
{
	return GetEngine()->GameViewport->World;
}

inline AFortGameModeAthena* GetGameMode()
{
	return (AFortGameModeAthena*)GetWorld()->AuthorityGameMode;
}

inline UKismetMathLibrary* GetMath()
{
	return (UKismetMathLibrary*)UKismetMathLibrary::StaticClass()->DefaultObject;
}

template<typename T>
inline T* GetDefaultObject()
{
	return (T*)T::StaticClass()->DefaultObject;
}

inline AFortGameStateAthena* GetGameState()
{
	return reinterpret_cast<AFortGameStateAthena*>(UWorld::GetWorld()->GameState);
}

inline UKismetStringLibrary* GetString()
{
	return GetDefaultObject<UKismetStringLibrary>();
}

inline UGameplayStatics* GetStatics()
{
	return (UGameplayStatics*)UGameplayStatics::StaticClass()->DefaultObject;
}

inline UFortKismetLibrary* GetFortKismet()
{
	return (UFortKismetLibrary*)UFortKismetLibrary::StaticClass()->DefaultObject;
}


inline void sinCos(float* ScalarSin, float* ScalarCos, float Value)
{
	float quotient = (0.31830988618f * 0.5f) * Value;
	if (Value >= 0.0f)
	{
		quotient = (float)((int)(quotient + 0.5f));
	}
	else
	{
		quotient = (float)((int)(quotient - 0.5f));
	}
	float y = Value - (2.0f * 3.1415926535897932f) * quotient;

	float sign;
	if (y > 1.57079632679f)
	{
		y = 3.1415926535897932f - y;
		sign = -1.0f;
	}
	else if (y < -1.57079632679f)
	{
		y = -3.1415926535897932f - y;
		sign = -1.0f;
	}
	else
	{
		sign = +1.0f;
	}

	float y2 = y * y;

	*ScalarSin = (((((-2.3889859e-08f * y2 + 2.7525562e-06f) * y2 - 0.00019840874f) * y2 + 0.0083333310f) * y2 - 0.16666667f) * y2 + 1.0f) * y;

	float p = ((((-2.6051615e-07f * y2 + 2.4760495e-05f) * y2 - 0.0013888378f) * y2 + 0.041666638f) * y2 - 0.5f) * y2 + 1.0f;
	*ScalarCos = sign * p;
}

inline FQuat FRotToQuat(FRotator Rot)
{
	const float DEG_TO_RAD = 3.1415926535897932f / (180.f);
	const float DIVIDE_BY_2 = DEG_TO_RAD / 2.f;
	float SP, SY, SR;
	float CP, CY, CR;

	sinCos(&SP, &CP, Rot.Pitch * DIVIDE_BY_2);
	sinCos(&SY, &CY, Rot.Yaw * DIVIDE_BY_2);
	sinCos(&SR, &CR, Rot.Roll * DIVIDE_BY_2);

	FQuat RotationQuat;
	RotationQuat.X = CR * SP * SY - SR * CP * CY;
	RotationQuat.Y = -CR * SP * CY - SR * CP * SY;
	RotationQuat.Z = CR * CP * SY - SR * SP * CY;
	RotationQuat.W = CR * CP * CY + SR * SP * SY;

	return RotationQuat;
}

template<typename T>
T* SpawnActor(SDK::FVector Loc, SDK::FRotator Rot = SDK::FRotator(), SDK::AActor* Owner = nullptr, SDK::UClass* Class = T::StaticClass(), ESpawnActorCollisionHandlingMethod Handle = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn)
{
	SDK::FTransform Transform{};
	Transform.Scale3D = SDK::FVector{ 1,1,1 };
	Transform.Translation = Loc;
	Transform.Rotation = FRotToQuat(Rot);
	return (T*)SDK::UGameplayStatics::GetDefaultObj()->FinishSpawningActor(SDK::UGameplayStatics::GetDefaultObj()->BeginDeferredActorSpawnFromClass(SDK::UWorld::GetWorld(), Class, Transform, Handle, Owner), Transform);
}

template<typename T>
T* SpawnTrap(FVector Loc, FRotator Rot = {}, AActor* Owner = nullptr)
{
	static UGameplayStatics* statics = (UGameplayStatics*)UGameplayStatics::StaticClass()->DefaultObject;

	FTransform Transform{};
	Transform.Scale3D = FVector(1, 1, 1);
	Transform.Translation = Loc;

	return (T*)statics->FinishSpawningActor(statics->BeginDeferredActorSpawnFromClass(GetWorld(), T::StaticClass(), Transform, ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn, Owner), Transform);
}

template<typename T>
T* SpawnTrap(UClass* Class, FVector Loc, FRotator Rot = {}, AActor* Owner = nullptr)
{
	static UGameplayStatics* statics = (UGameplayStatics*)UGameplayStatics::StaticClass()->DefaultObject;

	FTransform Transform{};
	Transform.Scale3D = FVector(1, 1, 1);
	Transform.Translation = Loc;
	Transform.Rotation = FRotToQuat(Rot);

	return (T*)statics->FinishSpawningActor(statics->BeginDeferredActorSpawnFromClass(GetWorld(), Class, Transform, ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn, Owner), Transform);
}

AActor* SpawnActorManual(UClass* Class, FVector Loc = FVector(), FRotator Rot = FRotator())
{
	FTransform Transform{};
	Transform.Translation = Loc;
	Transform.Scale3D = FVector{ 1,1,1 };
	Transform.Rotation = FRotToQuat(Rot);

	return GetStatics()->FinishSpawningActor(GetStatics()->BeginDeferredActorSpawnFromClass(UWorld::GetWorld(), Class, Transform, ESpawnActorCollisionHandlingMethod::AlwaysSpawn, nullptr), Transform);
}

template <typename T>
static T* StaticFindObject(string ObjectName, UClass* ObjectClass = UObject::StaticClass())
{
	auto OrigInName = wstring(ObjectName.begin(), ObjectName.end()).c_str();

	return (T*)StaticFindObjectOG(ObjectClass, nullptr, OrigInName, false);
}

template<typename T>
T* StaticLoadObject(string name)
{
	T* Object = StaticFindObject<T>(name);

	if (!Object)
	{
		auto Name = std::wstring(name.begin(), name.end()).c_str();
		Object = (T*)StaticLoadObjectOG(T::StaticClass(), nullptr, Name, nullptr, 0, nullptr, false, nullptr);
	}

	return Object;
}

inline void SpawnPickup(FVector Loc, UFortItemDefinition* Def, EFortPickupSourceTypeFlag Flag, EFortPickupSpawnSource SpawnSource, int Count = 1, int LoadedAmmo = 0, AFortPawn* Owner = nullptr);
inline void SpawnPickup(FVector Loc, UFortItemDefinition* Def, EFortPickupSourceTypeFlag Flag, EFortPickupSpawnSource SpawnSource, int Count, int LoadedAmmo, AFortPawn* Owner)
{
	AFortPickupAthena* Pickup = SpawnActor<AFortPickupAthena>(Loc);
	Pickup->bRandomRotation = true;
	Pickup->PrimaryPickupItemEntry.ItemDefinition = Def;
	Pickup->PrimaryPickupItemEntry.Count = Count;
	Pickup->PrimaryPickupItemEntry.LoadedAmmo = LoadedAmmo;
	Pickup->OnRep_PrimaryPickupItemEntry();

	if (Flag == EFortPickupSourceTypeFlag::Container)
	{
		Pickup->bTossedFromContainer = true;
		Pickup->OnRep_TossedFromContainer();
	}

	Pickup->TossPickup(Loc, nullptr, -1, true, false, Flag, SpawnSource);
}

inline AFortPickupAthena* SpawnPickup(FVector Loc, FFortItemEntry* Entry, EFortPickupSourceTypeFlag SourceTypeFlag = EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource SpawnSource = EFortPickupSpawnSource::Unset, AFortPlayerPawn* Pawn = nullptr, int OverrideCount = 0) //test
{
	if (!Entry)
		return nullptr;

	AFortPickupAthena* NewPickup = SpawnActor<AFortPickupAthena>(Loc);
	NewPickup->bRandomRotation = true;
	//NewPickup->PrimaryPickupItemEntry.Count = OverrideCount != 0 ? OverrideCount : Entry->Count;
	//NewPickup->PrimaryPickupItemEntry.LoadedAmmo = Entry->LoadedAmmo;
	//NewPickup->PrimaryPickupItemEntry.ItemDefinition = Entry->ItemDefinition;
	//NewPickup->PrimaryPickupItemEntry.ItemGuid = Entry->ItemGuid;
	NewPickup->PrimaryPickupItemEntry = *Entry;
	NewPickup->PrimaryPickupItemEntry.Count = OverrideCount != 0 ? OverrideCount : Entry->Count;
	NewPickup->OnRep_PrimaryPickupItemEntry();
	NewPickup->PawnWhoDroppedPickup = Pawn;

	NewPickup->TossPickup(Loc, Pawn, -1, true, false, SourceTypeFlag, SpawnSource);

	if (SpawnSource == EFortPickupSpawnSource::Chest || SpawnSource == EFortPickupSpawnSource::AmmoBox)
	{
		NewPickup->bTossedFromContainer = true;
		NewPickup->OnRep_TossedFromContainer();
	}

	return NewPickup;
}

inline FString Conv_NameToString(FName name)
{
	return ((UKismetStringLibrary*)UKismetStringLibrary::StaticClass()->DefaultObject)->Conv_NameToString(name);
}

inline FName Conv_StringToName(FString str)
{
	return ((UKismetStringLibrary*)UKismetStringLibrary::StaticClass()->DefaultObject)->Conv_StringToName(str);
}


inline string SplitString(bool SecondString, string delim, string strtosplit)
{
	auto start = 0U;
	auto end = strtosplit.find(delim);
	if (SecondString)
	{
		while (end != std::string::npos)
		{
			start = end + delim.length();
			end = strtosplit.find(delim, start);
		}
	}

	return strtosplit.substr(start, end);
}

inline void Log(const char* Str)
{
	LOG(Str);
}

inline void Log(std::string Str)
{
	LOG(Str.c_str());
}

inline void LogVector(FVector Vector)
{
	Log(to_string(Vector.X) + " " + to_string(Vector.Y) + " " + to_string(Vector.Z));
}

inline void SwapVTable(void* base, int Idx, void* Detour, void** OG = nullptr);
inline void SwapVTable(void* base, int Idx, void* Detour, void** OG)
{
	if (!base)
		return;

	void** VTable = *(void***)base;
	if (!VTable || !VTable[Idx])
		return;
	if (OG)
	{
		*OG = VTable[Idx];
	}

	DWORD oldProtection;

	VirtualProtect(&VTable[Idx], sizeof(void*), PAGE_EXECUTE_READWRITE, &oldProtection);

	VTable[Idx] = Detour;

	VirtualProtect(&VTable[Idx], sizeof(void*), oldProtection, NULL);
}

inline UFortWorldItem* FindItemInstance(AFortInventory* inv, UFortItemDefinition* ItemDefinition)
{
	auto& ItemInstances = inv->Inventory.ItemInstances;

	for (int i = 0; i < ItemInstances.Num(); i++)
	{
		auto ItemInstance = ItemInstances[i];

		if (ItemInstance->ItemEntry.ItemDefinition == ItemDefinition)
			return ItemInstance;
	}

	return nullptr;
}

EFortQuickBars GetQuickBars(UFortItemDefinition* ItemDefinition)
{
	if (!ItemDefinition->IsA(UFortWeaponMeleeItemDefinition::StaticClass()) && !ItemDefinition->IsA(UFortEditToolItemDefinition::StaticClass()) &&
		!ItemDefinition->IsA(UFortBuildingItemDefinition::StaticClass()) && !ItemDefinition->IsA(UFortAmmoItemDefinition::StaticClass()) && !ItemDefinition->IsA(UFortResourceItemDefinition::StaticClass()) && !ItemDefinition->IsA(UFortTrapItemDefinition::StaticClass()))
		return EFortQuickBars::Primary;

	return EFortQuickBars::Secondary;
}

bool IsInventoryFull(AFortPlayerController* PC)
{
	int ItemNb = 0;
	auto InstancesPtr = &PC->WorldInventory->Inventory.ItemInstances;
	for (int i = 0; i < InstancesPtr->Num(); i++)
	{
		if (InstancesPtr->operator[](i))
		{
			if (GetQuickBars(InstancesPtr->operator[](i)->ItemEntry.ItemDefinition) == EFortQuickBars::Primary)
			{
				ItemNb++;

				if (ItemNb >= 5)
				{
					break;
				}
			}
		}
	}

	return ItemNb >= 5;
}

inline FFortItemEntry* FindItemEntryByGUID(AFortPlayerController* PC, FGuid ItemGuid)
{
	for (int i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
	{
		if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == ItemGuid)
			return &PC->WorldInventory->Inventory.ReplicatedEntries[i];
	}

	return nullptr;
}

inline int GetOffset(UObject* Object, std::string Name)
{
	for (UObject* ObjClass = Object->Class; ObjClass; ObjClass = *(UObject**)(__int64(ObjClass) + 0x40))
	{
		void* Property = *(void**)(__int64(ObjClass) + 0x50);

		if (Property)
		{
			FName* PropFName = (FName*)(__int64(Property) + 0x28);
			string PropName = PropFName ? PropFName->ToString() : "";

			while (Property)
			{
				if (PropName == Name)
				{
					return *(int*)(__int64(Property) + 0x4C);
				}

				Property = *(void**)(__int64(Property) + 0x20);
				PropFName = (FName*)(__int64(Property) + 0x28);
				PropName = Property ? (PropFName ? PropFName->ToString() : "None") : "None";
			}
		}
	}

	return 0;
}