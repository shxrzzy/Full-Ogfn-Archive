#pragma once
#include "Utils.h"

//saddest file ever
using namespace SDK;

static void (*SetWorld)(void*, void*) = decltype(SetWorld)(__int64(GetModuleHandleW(0)) + 0x3882F50);

inline BYTE* __fastcall ChangeGameSessionId(__int64, __int64)
{
	return 0;
}


inline __int64 GetNetMode(void*)
{
	return 1;
}