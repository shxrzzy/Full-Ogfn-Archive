#pragma once
#include <string>
#include <vector>
#include <map>
#include <iostream>
#include "SDK.hpp"
#include <algorithm>
#include <intrin.h>
#include "Utils.h"
#include <thread>

namespace POILocations
{
    struct FortnitePoisLocation
    {
        FVector Location;
        std::string LocationName;
        int MaxBots;
        int Radius; // will add x and y soon
    };
    static std::vector<FortnitePoisLocation> Locations = {
        {
            FVector(17085.8, 112747.0, 0.0), // Dirty Docks
            "Dirty Docks",
            5,
            5000
        },
        {
            FVector(81989.6, 96710.3, 2000.0), // Steamy Stacks
            "Steamy Stacks",
            5,
            5000
        },
        {
            FVector(35365.6, 45193.9, 0.0),  // Frenzy Farm
            "Frenzy Farm",
            7,
            5000
        },
        {
            FVector(97044.2, 26667.1, 0.0),     // Craggy Cliffs
            "Craggy Cliffs",
            4,
            5000
        },
        {
            FVector(33805.2, -72550.6,  0.0),    // Sweaty Sands
            "Sweaty Sands",
            10,
            5000
        },
        {
            FVector(-13311.9, -81033.7,  0.0),   // Holly Hedges
            "Holly Hedges",
            7,
            5000
        },
        {
            FVector(-64881.4, -46495.3,  0.0),    // Slurpy Swamp
            "Slurpy Swamp",
            7,
            5000
        },
        {
            FVector(-31581.6, -27604.8,  0.0),    // Weeping Woods
            "Weeping Woods",
            5,
            5000
        },
        {
            FVector(12554.8, -24382.9,  0.0),    // Salty Springs
            "Salty Springs",
            6,
            5000
        },
        {
            FVector(62435.3, -16136.0,  0.0),    // Pleasant Park
            "Pleasant Park",
            15,
            5000
        },
        {
            FVector(-46128.3, 52456.6,  9000.0),     // Lazy Lake
            "Lazy Lake",
            10,
            5000
        },
        {
            FVector(-40262.6, 95645.5,  5000.0),      // Retail Row
            "Retail Row",
            16,
            5000
        },
        {
            FVector(-89870.1, 26228.7, 2000.0),      // Misty Meadows
            "Misty Meadows",
            6,
            6000
        },
    };
}
