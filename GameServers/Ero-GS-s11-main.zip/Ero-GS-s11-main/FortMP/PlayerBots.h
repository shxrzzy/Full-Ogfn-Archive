#pragma once
#include <string>
#include <vector>
#include <map>
#include <iostream>
#include "SDK.hpp"
#include <algorithm>
#include <intrin.h>
#include "Utils.h"
#include "Quest.h"
#include "Abilities.h"
#include "Looting.h"
#include "Pois.h"
#include "Names.h"
#include <thread>

using namespace std;
using namespace SDK;

inline AFortAthenaMutator_Bots* BotMutator = nullptr;

static void (*BotManagerSetupStuffIdk)(__int64 BotManaager, __int64 Pawn, __int64 BehaviorTree, __int64 a4, DWORD* SkillLevel, __int64 idk, __int64 StartupInventory, __int64 BotNameSettings, __int64 idk_1, BYTE* CanRespawnOnDeath, unsigned __int8 BitFieldDataThing, BYTE* CustomSquadId, FFortAthenaAIBotRunTimeCustomizationData InRuntimeBotData) = decltype(BotManagerSetupStuffIdk)(__int64(GetModuleHandleW(0)) + 0x19D93F0);

inline map<AActor*, AFortAthenaAIBotController*> ChestsForBots{};
inline vector<UAthenaCharacterItemDefinition*> CIDs{};
inline vector<UAthenaPickaxeItemDefinition*> Pickaxes{};
inline vector<UAthenaBackpackItemDefinition*> Backpacks{};
inline vector<UAthenaGliderItemDefinition*> Gliders{};
inline vector<UAthenaSkyDiveContrailItemDefinition*> Contrails{};
inline vector<UAthenaDanceItemDefinition*> Dances{};

enum EBotState : uint8
{
	Warmup,
	InBus,
	SkydivingFromBus,
	Landed,
	Looting,
	MovingToZone,
	LookingForPlayers,
	Stuck,
	MAX
};

inline FRotator ToOrientationRotator(FVector Vector)
{
	static UKismetMathLibrary* Math = UKismetMathLibrary::GetDefaultObj();
	FRotator R;

	// Find yaw.
	R.Yaw = Math->Atan2(Vector.Y, Vector.X) * (180.f / 3.1415926535897932f);

	// Find pitch.
	R.Pitch = Math->Atan2(Vector.Z, Math->Sqrt(Vector.X * Vector.X + Vector.Y * Vector.Y)) * (180.f / 3.1415926535897932f);

	// Find roll.
	R.Roll = 0;

	return R;
}

struct Bot
{
public:
	AFortAthenaAIBotController* PC = nullptr;
	AFortPlayerPawnAthena* Pawn = nullptr;
	AFortPlayerStateAthena* PlayerState = nullptr;
	bool Emoting = false;
	bool ThankedBusDriver = false;
	FVector TargetPOI = FVector();
	AActor* TargetActor = nullptr;
	AActor* PreviousActor = nullptr;
	bool TickEnabled = true;
	float FloatValue = 0.f;
	bool JumpedFromBus = false;
	ABuildingActor* StuckActor = nullptr;
	bool Running = false;
	AActor* TargetGoTo = nullptr;
	FVector TargetBuildingLocation = FVector(0, 0, 0);
	FString DisplayName = L"marcellowmellow";

	EBotState State = EBotState::Warmup;
	EBotState PreviousState = EBotState::Looting;

public:
	void GiveItem(UFortItemDefinition* Def, int Count = 1, int LoadedAmmo = 0)
	{
		UFortWorldItem* Item = (UFortWorldItem*)Def->CreateTemporaryItemInstanceBP(Count, 0);
		Item->OwnerInventory = PC->Inventory;
		Item->ItemEntry.LoadedAmmo = LoadedAmmo;
		PC->Inventory->Inventory.ReplicatedEntries.Add(Item->ItemEntry);
		PC->Inventory->Inventory.ItemInstances.Add(Item);
		PC->Inventory->Inventory.MarkItemDirty(Item->ItemEntry);
		PC->Inventory->HandleInventoryLocalUpdate();
	}

	FFortItemEntry* GetEntry(UFortItemDefinition* Def)
	{
		for (size_t i = 0; i < PC->Inventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (PC->Inventory->Inventory.ReplicatedEntries[i].ItemDefinition == Def)
				return &PC->Inventory->Inventory.ReplicatedEntries[i];
		}

		return nullptr;
	}

	ABuildingSMActor* FindNearestBuildingSMActor()
	{
		return nullptr;
		static TArray<AActor*> Array;
		static bool First = false;
		if (!First)
		{
			First = true;
			UGameplayStatics::GetDefaultObj()->GetAllActorsOfClass(UWorld::GetWorld(), ABuildingSMActor::StaticClass(), &Array);
		}

		AActor* NearestPoi = nullptr;

		for (size_t i = 0; i < Array.Num(); i++)
		{
			if (!NearestPoi || (((ABuildingSMActor*)NearestPoi)->GetHealth() < 1500 && ((ABuildingSMActor*)NearestPoi)->GetHealth() > 1 && Array[i]->GetDistanceTo(Pawn) < NearestPoi->GetDistanceTo(Pawn)))
			{
				NearestPoi = Array[i];
			}
		}

		return (ABuildingSMActor*)NearestPoi;
	}

	Bot(AActor* SpawnLocator)
	{
		if (!BotsEnabled)
			return;

		auto CID = CIDs[UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(0, CIDs.size() - 1)];
		auto Backpack = Backpacks[UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(0, Backpacks.size() - 1)];
		auto Glider = Gliders[UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(0, Gliders.size() - 1)];
		auto Contrail = Contrails[UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(0, Contrails.size() - 1)];

		if (!CID || !CID->HeroDefinition || !Backpack || !Glider || !Contrail)
			return;

		static auto BotPawnClas = StaticLoadObject<UClass>("/Game/Athena/AI/Phoebe/BP_PlayerPawn_Athena_Phoebe.BP_PlayerPawn_Athena_Phoebe_C");
		Pawn = BotMutator->SpawnBot(BotPawnClas, SpawnLocator, SpawnLocator->K2_GetActorLocation(), SpawnLocator->K2_GetActorRotation(), false);
		PC = (AFortAthenaAIBotController*)Pawn->Controller;
		PlayerState = (AFortPlayerStateAthena*)PC->PlayerState;

		if (BotDisplayNames.size() != 0) {
			std::srand(static_cast<unsigned int>(std::time(0)));
			int randomIndex = std::rand() % BotDisplayNames.size();
			std::string rdName = BotDisplayNames[randomIndex];
			BotDisplayNames.erase(BotDisplayNames.begin() + randomIndex);

			int size_needed = MultiByteToWideChar(CP_UTF8, 0, rdName.c_str(), (int)rdName.size(), NULL, 0);
			std::wstring wideString(size_needed, 0);
			MultiByteToWideChar(CP_UTF8, 0, rdName.c_str(), (int)rdName.size(), &wideString[0], size_needed);


			FString CVName = FString(wideString.c_str());
			GetGameMode()->ChangeName(PC, CVName, true);
			DisplayName = CVName;

			
			PlayerState->OnRep_PlayerName();
		}

		auto PickDef = Pickaxes[UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(0, Pickaxes.size() - 1)];
		if (!PickDef)
		{
			TickEnabled = false;
			printf("Null!\n");
			return;
		}

		if (PickDef && PickDef->WeaponDefinition)
		{
			GiveItem(PickDef->WeaponDefinition);
		}

		auto Entry = GetEntry(PickDef->WeaponDefinition);
		Pawn->EquipWeaponDefinition((UFortWeaponItemDefinition*)Entry->ItemDefinition, Entry->ItemGuid);

		if (CID->HeroDefinition)
		{
			if (CID->HeroDefinition->Specializations.IsValid())
			{
				for (size_t i = 0; i < CID->HeroDefinition->Specializations.Num(); i++)
				{
					UFortHeroSpecialization* Spec = StaticLoadObject<UFortHeroSpecialization>(UKismetStringLibrary::GetDefaultObj()->Conv_NameToString(CID->HeroDefinition->Specializations[i].ObjectID.AssetPathName).ToString());
					if (Spec)
					{
						for (size_t j = 0; j < Spec->CharacterParts.Num(); j++)
						{
							UCustomCharacterPart* Part = StaticLoadObject<UCustomCharacterPart>(UKismetStringLibrary::GetDefaultObj()->Conv_NameToString(Spec->CharacterParts[j].ObjectID.AssetPathName).ToString());
							if (Part)
							{
								PlayerState->CharacterData.Parts[(uintptr_t)Part->CharacterPartType] = Part;
							}
						}
					}
				}
			}
		}

		for (size_t j = 0; j < Backpack->CharacterParts.Num(); j++)
		{
			UCustomCharacterPart* Part = Backpack->CharacterParts[j];
			if (Part)
			{
				PlayerState->CharacterData.Parts[(uintptr_t)Part->CharacterPartType] = Part;
			}
		}

		PC->CosmeticLoadoutBC.Glider = Glider;
		PC->CosmeticLoadoutBC.SkyDiveContrail = Contrail;
		Pawn->CosmeticLoadout = PC->CosmeticLoadoutBC;

		UBlackboardData* BB = StaticLoadObject<UBlackboardData>("/Game/Athena/AI/Phoebe/BehaviorTrees/BB_Phoebe.BB_Phoebe");

		for (size_t i = 0; i < PC->DigestedBotSkillSets.Num(); i++)
		{
			if (PC->DigestedBotSkillSets[i]->IsA(UFortAthenaAIBotAimingDigestedSkillSet::StaticClass()))
			{
				PC->CacheAimingDigestedSkillSet = (UFortAthenaAIBotAimingDigestedSkillSet*)PC->DigestedBotSkillSets[i];
			}

			if (PC->DigestedBotSkillSets[i]->IsA(UFortAthenaAIBotHarvestDigestedSkillSet::StaticClass()))
			{
				PC->CacheHarvestDigestedSkillSet = (UFortAthenaAIBotHarvestDigestedSkillSet*)PC->DigestedBotSkillSets[i];
			}

			if (PC->DigestedBotSkillSets[i]->IsA(UFortAthenaAIBotInventoryDigestedSkillSet::StaticClass()))
			{
				PC->CacheInventoryDigestedSkillSet = (UFortAthenaAIBotInventoryDigestedSkillSet*)PC->DigestedBotSkillSets[i];
			}

			if (PC->DigestedBotSkillSets[i]->IsA(UFortAthenaAIBotLootingDigestedSkillSet::StaticClass()))
			{
				PC->CacheLootingSkillSet = (UFortAthenaAIBotLootingDigestedSkillSet*)PC->DigestedBotSkillSets[i];
			}

			if (PC->DigestedBotSkillSets[i]->IsA(UFortAthenaAIBotMovementDigestedSkillSet::StaticClass()))
			{
				PC->CacheMovementSkillSet = (UFortAthenaAIBotMovementDigestedSkillSet*)PC->DigestedBotSkillSets[i];
			}

			if (PC->DigestedBotSkillSets[i]->IsA(UFortAthenaAIBotPerceptionDigestedSkillSet::StaticClass()))
			{
				PC->CachePerceptionDigestedSkillSet = (UFortAthenaAIBotPerceptionDigestedSkillSet*)PC->DigestedBotSkillSets[i];
			}

			if (PC->DigestedBotSkillSets[i]->IsA(UFortAthenaAIBotPlayStyleDigestedSkillSet::StaticClass()))
			{
				PC->CachePlayStyleSkillSet = (UFortAthenaAIBotPlayStyleDigestedSkillSet*)PC->DigestedBotSkillSets[i];
			}
		}

		//PC->Blackboard = BB;
		//static UProperty* Blackboard1Prop = StaticLoadObject<UProperty>("/Game/Athena/AI/Phoebe/BP_PhoebePlayerController.BP_PhoebePlayerController_C.Blackboard1");
		//UBlackboardComponent** Comp = (UBlackboardComponent**)(__int64(PC) + Blackboard1Prop->Offset);

		//PC->UseBlackboard(BB, &PC->Blackboard);
		//PC->OnUsingBlackBoard(PC->Blackboard, BB);

		//PC->UseBlackboard(BB, &(*Comp));
		//PC->OnUsingBlackBoard((*Comp), BB);

		//UBehaviorTree* Tree = StaticLoadObject<UBehaviorTree>("/Game/Athena/AI/Phoebe/BehaviorTrees/BT_Phoebe_Warmup.BT_Phoebe_Warmup"); //so uhg some proper ai phoebe code is still in the game and some evaluators arent stripped maybe so ill look into it later
		//PC->BehaviorTree = Tree;
		//PC->RunBehaviorTree(Tree);
		//PC->BlueprintOnBehaviorTreeStarted();

		PC->PathFollowingComponent->MyNavData = ((UAthenaNavSystem*)UWorld::GetWorld()->NavigationSystem)->MainNavData;
		PC->PathFollowingComponent->OnNavDataRegistered(((UAthenaNavSystem*)UWorld::GetWorld()->NavigationSystem)->MainNavData);

		PlayerState->OnRep_CharacterData();

		Pawn->CapsuleComponent->SetGenerateOverlapEvents(true);
		Pawn->CharacterMovement->bCanWalkOffLedges = true;

		//Pawn->CharacterMovement->bUseControllerDesiredRotation = true;
		//Pawn->CharacterMovement->bOrientRotationToMovement = false;
		//Pawn->bUseControllerRotationYaw = false;
		//Pawn->bUseControllerRotationPitch = false;
		//Pawn->bUseControllerRotationRoll = false;

		TargetActor = FindNearestBuildingSMActor();

		TickEnabled = true;
	}

public:
	ABuildingActor* FindNearestChest()
	{
		static auto ChestClass = StaticLoadObject<UClass>("/Game/Building/ActorBlueprints/Containers/Tiered_Chest_Athena.Tiered_Chest_Athena_C");
		TArray<AActor*> Array;
		UGameplayStatics::GetDefaultObj()->GetAllActorsOfClass(UWorld::GetWorld(), ChestClass, &Array);

		AActor* NearestPoi = nullptr;

		for (size_t i = 0; i < Array.Num(); i++)
		{
			AActor* Actor = Array[i];
			if (ChestsForBots.contains(Array[i]) && ChestsForBots[Actor] != PC)
				continue;
			if (!NearestPoi || Array[i]->GetDistanceTo(Pawn) < NearestPoi->GetDistanceTo(Pawn))
			{
				NearestPoi = Array[i];
			}
		}
		Array.FreeArray();
		return (ABuildingActor*)NearestPoi;
	}

	AFortPickupAthena* FindNearestPickup()
	{
		static auto ChestClass = AFortPickupAthena::StaticClass();
		TArray<AActor*> Array;
		UGameplayStatics::GetDefaultObj()->GetAllActorsOfClass(UWorld::GetWorld(), ChestClass, &Array);
		AActor* NearestPoi = nullptr;

		for (size_t i = 0; i < Array.Num(); i++)
		{
			if (!NearestPoi || Array[i]->GetDistanceTo(Pawn) < NearestPoi->GetDistanceTo(Pawn))
			{
				NearestPoi = Array[i];
			}
		}
		Array.FreeArray();
		return (AFortPickupAthena*)NearestPoi;
	}

	AFortPlayerPawnAthena* FindNearestPlayer()
	{
		auto GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;

		AActor* NearestPoi = nullptr;

		for (size_t i = 0; i < GameMode->AlivePlayers.Num(); i++)
		{
			if (!NearestPoi || (GameMode->AlivePlayers[i]->Pawn && GameMode->AlivePlayers[i]->Pawn->GetDistanceTo(Pawn) < NearestPoi->GetDistanceTo(Pawn)))
			{
				NearestPoi = GameMode->AlivePlayers[i]->Pawn;
			}
		}

		for (size_t i = 0; i < GameMode->AliveBots.Num(); i++)
		{
			if (GameMode->AliveBots[i]->Pawn != Pawn)
			{
				if (!NearestPoi || (GameMode->AliveBots[i]->Pawn && GameMode->AliveBots[i]->Pawn->GetDistanceTo(Pawn) < NearestPoi->GetDistanceTo(Pawn)))
				{
					NearestPoi = GameMode->AliveBots[i]->Pawn;
				}
			}
		}

		return (AFortPlayerPawnAthena*)NearestPoi;
	}

	FVector FindNearestBuildingPoiActor(FVector LocationS)
	{
		if (!TargetBuildingLocation.IsZero())
			return TargetBuildingLocation; // never AGAIN!

		FVector PawnLocation = LocationS;
		float ClosestDistance = FLT_MAX;
		FVector ClosestPOI = FVector(0, 0, 0);
		FVector OgPOI = FVector(0, 0, 0);
		for (const auto& POI : POILocations::Locations)
		{
			if (POI.MaxBots == 0) continue;

			auto RndNumberX = UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(-POI.Radius, POI.Radius);
			auto RndNumberY = UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(-POI.Radius, POI.Radius);


			float DeltaX = (POI.Location.X + RndNumberX) - PawnLocation.X;
			float DeltaY = (POI.Location.Y + RndNumberY) - PawnLocation.Y;
			float DeltaZ = POI.Location.Z - PawnLocation.Z;

			float DistanceToPOI = std::sqrt(DeltaX * DeltaX + DeltaY * DeltaY + DeltaZ * DeltaZ);

			if (DistanceToPOI < ClosestDistance)
			{
				ClosestDistance = DistanceToPOI;
				ClosestPOI = POI.Location;
				OgPOI = POI.Location;
				ClosestPOI.X += RndNumberX;
				ClosestPOI.Y += RndNumberY;
			}
		}

		for (auto& POI : POILocations::Locations)
		{
			if (POI.Location == OgPOI && POI.MaxBots > 0)
			{
				std::cout << "REMOVING 1 - " + Pawn->PlayerState->PlayerNamePrivate.ToString() + " " + POI.LocationName << std::endl;
				--POI.MaxBots;
				break;
			}
		}

		return ClosestPOI;
	}

	void GoTo(FVector Loc, float Radius = 0)
	{
		PC->MoveToLocation(Loc, 0, true, false, false, true, nullptr, true);
	}

	void GoTo(AActor* Loc, float Radius = 0)
	{
		if (TargetGoTo == Loc)
			return;

		TargetGoTo = Loc;
		PC->MoveToActor(Loc, 0, true, false, true, nullptr, true);
		Run();
	}

	void WalkForward()
	{
		Pawn->AddMovementInput(Pawn->GetActorForwardVector(), 1.f, true);
	}

	void WalkBackwards()
	{
		Pawn->AddMovementInput(UKismetMathLibrary::GetDefaultObj()->NegateVector(Pawn->GetActorForwardVector()), 1.f, true);
	}

	void WalkLeft()
	{
		Pawn->AddMovementInput(UKismetMathLibrary::GetDefaultObj()->NegateVector(Pawn->GetActorRightVector()), 1.f, true);
	}

	void WalkRight()
	{
		Pawn->AddMovementInput(Pawn->GetActorRightVector(), 1.f, true);
	}

	int GetAimMaxOffset()
	{
		return 125;
	}

	FVector GetAimDirection(AActor* Actor)
	{
		int MaxOffset = GetAimMaxOffset();
		FVector Loc = Actor->K2_GetActorLocation();
		Loc.X += UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(-MaxOffset, MaxOffset);
		Loc.Y += UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(-MaxOffset, MaxOffset);
		Loc.Z += UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(-MaxOffset, MaxOffset);
		return Loc;
	}

	void LookAt(AActor* Actor, bool Bloom = false)
	{
		if (!Actor || !Pawn || PC->GetFocusActor() == Actor)
			return;

		if (!Actor)
		{
			PC->K2_ClearFocus();
			return;
		}

		if (Bloom)
		{
			PC->K2_SetFocalPoint(GetAimDirection(Actor));
		}
		else
		{
			PC->K2_SetFocus(Actor);
		}
	}

	void LookAtLocation(FVector TargetLocation)
	{
		if (!Pawn)
			return;

		auto pawnig = Pawn->K2_GetActorLocation();
		auto LookAtRotation = UKismetMathLibrary::GetDefaultObj()->FindLookAtRotation(pawnig, TargetLocation);

		PC->SetControlRotation(LookAtRotation);
	}


	void Skydive(bool FromBus = true)
	{
		Pawn->BeginSkydiving(FromBus);
	}

	void ForceJump(AActor* a2)
	{
		if (!TickEnabled || !Pawn || JumpedFromBus)
			return;

		Pawn->K2_TeleportTo(a2->K2_GetActorLocation(), {});
		Skydive();

		TargetPOI = FindNearestChest()->K2_GetActorLocation();
		State = EBotState::Landed;
	}

	void EquipGun()
	{
		if (!Pawn || !Pawn->CurrentWeapon)
			return;

		if (Pawn->CurrentWeapon->WeaponData->IsA(UFortWeaponMeleeItemDefinition::StaticClass()))
		{
			for (size_t i = 0; i < PC->Inventory->Inventory.ReplicatedEntries.Num(); i++)
			{
				if (!PC->Inventory->Inventory.ReplicatedEntries[i].ItemDefinition->IsA(UFortWeaponMeleeItemDefinition::StaticClass()))
				{
					Pawn->EquipWeaponDefinition((UFortWeaponItemDefinition*)PC->Inventory->Inventory.ReplicatedEntries[i].ItemDefinition, PC->Inventory->Inventory.ReplicatedEntries[i].ItemGuid);
					break;
				}
			}
		}
	}

	void EquipPickaxe()
	{
		if (!Pawn || !Pawn->CurrentWeapon)
			return;

		if (!Pawn->CurrentWeapon->WeaponData->IsA(UFortWeaponMeleeItemDefinition::StaticClass()))
		{
			for (size_t i = 0; i < PC->Inventory->Inventory.ReplicatedEntries.Num(); i++)
			{
				if (PC->Inventory->Inventory.ReplicatedEntries[i].ItemDefinition->IsA(UFortWeaponMeleeItemDefinition::StaticClass()))
				{
					Pawn->EquipWeaponDefinition((UFortWeaponItemDefinition*)PC->Inventory->Inventory.ReplicatedEntries[i].ItemDefinition, PC->Inventory->Inventory.ReplicatedEntries[i].ItemGuid);
					break;
				}
			}
		}
	}

	bool HasGun()
	{
		for (size_t i = 0; i < PC->Inventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (!PC->Inventory->Inventory.ReplicatedEntries[i].ItemDefinition->IsA(UFortWeaponMeleeItemDefinition::StaticClass()))
				return true;
		}
		return false;
	}

	void StartLooting()
	{
		TargetActor = FindNearestChest();
		if (TargetActor)
		{
			ChestsForBots[TargetActor] = PC;
			LookAt(TargetActor);
			State = EBotState::Looting;
		}
	}

	void Run()
	{
		if (!Running)
		{
			Running = true;
			for (size_t i = 0; i < PlayerState->AbilitySystemComponent->ActivatableAbilities.Items.Num(); i++)
			{
				if (PlayerState->AbilitySystemComponent->ActivatableAbilities.Items[i].Ability->IsA(UFortGameplayAbility_Sprint::StaticClass()))
				{
					PlayerState->AbilitySystemComponent->ServerTryActivateAbility(PlayerState->AbilitySystemComponent->ActivatableAbilities.Items[i].Handle, PlayerState->AbilitySystemComponent->ActivatableAbilities.Items[i].InputPressed, PlayerState->AbilitySystemComponent->ActivatableAbilities.Items[i].ActivationInfo.PredictionKeyWhenActivated);
					break;
				}
			}
		}
	}

	void Emote()
	{
		if (Emoting)
			return;
		auto EmoteDef = Dances[UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(0, Dances.size() - 1)];
		if (!EmoteDef)
			return;
		Emoting = true;

		static UClass* EmoteAbilityClass = StaticLoadObject<UClass>("/Game/Abilities/Emotes/GAB_Emote_Generic.GAB_Emote_Generic_C");

		FGameplayAbilitySpec Spec{};
		AbilitySpecCtor(&Spec, reinterpret_cast<UGameplayAbility*>(EmoteAbilityClass->DefaultObject), 1, -1, EmoteDef);
		GiveAbilityAndActivateOnce(reinterpret_cast<AFortPlayerStateAthena*>(PC->PlayerState)->AbilitySystemComponent, &Spec.Handle, Spec);
	}

	virtual void Tick()
	{
		if (!TickEnabled || !Pawn)
			return;

		auto GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;

		switch (State)
		{
		case Warmup:
			break;
		case InBus:
			if (!ThankedBusDriver && UKismetMathLibrary::GetDefaultObj()->RandomBoolWithWeight(0.07f))
			{
				ThankedBusDriver = true;

				float randomDelay;
			//	if (bLateGame || bArsenal) {
				//	randomDelay = UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(0, 2);
				//}
			//	else 
			  //{
					randomDelay = UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(0, 30);
			//	}
				std::thread([randomDelay, GameState, this]()
					{
						std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<int>(randomDelay * 1000)));
						PC->ThankBusDriver();
						Pawn->K2_TeleportTo(GameState->GetAircraft(0)->K2_GetActorLocation(), {});
						Pawn->HealthSet->Health.Minimum = 0;
						Skydive(true);
						State = EBotState::SkydivingFromBus;
					}).detach();


			}
			break;
		case SkydivingFromBus:

			// Flying Down To A Location (did i skid this from zinx? Maybe (: )
			if (TargetBuildingLocation.IsZero()) {
				TargetBuildingLocation = FindNearestBuildingPoiActor(GameState->GetAircraft(0)->K2_GetActorLocation());
			}
			LookAtLocation(TargetBuildingLocation);


			GoTo(TargetBuildingLocation - Pawn->K2_GetActorLocation());

			State = EBotState::Landed;
			break;
		case Landed:
			StartLooting();
			break;
		case Looting:
			if (TargetActor)
			{
				if (Pawn->IsSkydiving())
				{
					Pawn->AddMovementInput(UKismetMathLibrary::GetDefaultObj()->GetDirectionUnitVector(Pawn->K2_GetActorLocation(), TargetActor->K2_GetActorLocation()), 1, true);
					Pawn->AddMovementInput(UKismetMathLibrary::GetDefaultObj()->NegateVector(Pawn->GetActorUpVector()), 1, true);
					Running = false;
				}
				else
				{
					GoTo(TargetActor);
					if (Pawn->GetDistanceTo(TargetActor) <= 200)
					{
						Pawn->PawnStopFire(0);
						if (!FloatValue)
						{
							FloatValue = UGameplayStatics::GetDefaultObj()->GetTimeSeconds(UWorld::GetWorld());
							Pawn->bStartedInteractSearch = true;
							Pawn->OnRep_StartedInteractSearch();
						}
						else if (UGameplayStatics::GetDefaultObj()->GetTimeSeconds(UWorld::GetWorld()) - FloatValue >= 1.5f)
						{
							SpawnLoot((ABuildingContainer*)TargetActor);
							AFortPickup* Pickup = FindNearestPickup();
							if (Pickup)
							{
								Pawn->ServerHandlePickup(Pickup, .4f, {}, true);
								if (HasGun())
								{
									EquipGun();
									State = EBotState::LookingForPlayers;
								}
							}
							else
							{
								FloatValue = 0;
								StartLooting();
								Log("Invalid Pickup");
							}
						}
					}
					else
					{
						Pawn->PawnStartFire(0);
					}
				}
			}
			else
			{
				Log("Invalid TargetActor, not enough chests????");
				StartLooting();
			}
			break;
		case MovingToZone:
			TargetActor = HasGun() ? FindNearestPlayer() : nullptr;
			if (TargetActor && Pawn->GetDistanceTo(TargetActor) < 4000)
				State = EBotState::LookingForPlayers;

			if (GameState && GameState->SafeZoneIndicator)
			{
				GoTo(GameState->SafeZoneIndicator->NextCenter, GameState->SafeZoneIndicator->NextRadius);
			}
			else
			{
				StartLooting();
			}

			break;
		case LookingForPlayers:
			if (Emoting && UGameplayStatics::GetDefaultObj()->GetTimeSeconds(UWorld::GetWorld()) - FloatValue < 3.f)
			{
				return;
			}
			else if (Emoting)
			{
				FloatValue = 0.f;
				Emoting = false;
			}
			TargetActor = HasGun() ? FindNearestPlayer() : nullptr;
			if (TargetActor && Pawn->GetDistanceTo(TargetActor) < 6000)
			{
				LookAt(TargetActor, true);
				GoTo(TargetActor);
				if (Pawn->GetDistanceTo(TargetActor) > 2000)
				{
					Pawn->Crouch(false);
					Pawn->PawnStopFire(0);
				}
				else if (PC->LineOfSightTo(TargetActor, {}, true))
				{
					Pawn->UnCrouch(false);
					if (UKismetMathLibrary::GetDefaultObj()->RandomBoolWithWeight(0.45f))
					{
						Pawn->PawnStartFire(0);
					}
					else
					{
						Pawn->PawnStopFire(0);
					}
					EquipGun();

					AFortPlayerPawnAthena* Target = (AFortPlayerPawnAthena*)TargetActor;
					if (UKismetMathLibrary::GetDefaultObj()->RandomBoolWithWeight(0.6f) && (!Target || Target->IsDead() || Target->GetHealth() <= 1))
					{
						PC->StopMovement();
						Pawn->PawnStopFire(0);
						Emote();
						FloatValue = UGameplayStatics::GetDefaultObj()->GetTimeSeconds(UWorld::GetWorld());
					}
				}
			}
			else
			{
				State = EBotState::MovingToZone;
			}
			break;
		case Stuck:
		{
			PC->StopMovement();
			//Pawn->Crouch(false);
			EquipPickaxe();
			LookAt(StuckActor);
			Pawn->PawnStartFire(0);
			float Health = StuckActor->GetHealth();
			if (!StuckActor || StuckActor->GetHealth() <= 1)
			{
				StuckActor = nullptr;
				State = PreviousState;
				cout << "Previous State" << (uintptr_t)PreviousState << endl;
				cout << TargetActor << endl;
				LookAt(TargetActor);
				GoTo(TargetActor);
				Pawn->UnCrouch(false);
				Pawn->PawnStopFire(0);
			}
			break;
		}
		case MAX:
			break;
		default:
			break;
		}
	}

	virtual void OnActorBump(AActor* OtherActor, FHitResult& Hit)
	{
		if (State == EBotState::Stuck || StuckActor == OtherActor)
			return;
		if (OtherActor->IsA(ABuildingSMActor::StaticClass()))
		{
			ABuildingSMActor* Actor = (ABuildingSMActor*)OtherActor;
			float Health = Actor->GetHealth();
			FFindFloorResult Res;

			if (Actor->bCanBeDamaged == 1 && Health > 1 && Health < 2500)
			{
				Pawn->CharacterMovement->K2_FindFloor(Pawn->CapsuleComponent->K2_GetComponentLocation(), &Res);
				if (Res.HitResult.Actor.Get() == OtherActor)
					return;
				StuckActor = Actor;
				PreviousState = State;
				State = EBotState::Stuck;
			}
		}
	}

	virtual void OnSafeZoneStateChange()
	{
		auto State = ((AFortGameStateAthena*)UWorld::GetWorld()->GameState)->GamePhaseStep;

		cout << (uintptr_t)State << endl;
	}

	virtual void OnDied(AFortPlayerStateAthena* KillerState)
	{
		if (!KillerState)
			return;

		Log("Bot Died");

		TickEnabled = false;
		FDeathInfo& DeathInfo = PlayerState->DeathInfo;

		DeathInfo.bDBNO = Pawn->bWasDBNOOnDeath;
		DeathInfo.bInitialized = true;
		DeathInfo.DeathLocation = Pawn->K2_GetActorLocation();
		//DeathInfo.DeathTags = 
		DeathInfo.Downer = KillerState;
		DeathInfo.Distance = (KillerState->GetCurrentPawn() ? KillerState->GetCurrentPawn()->GetDistanceTo(Pawn) : ((AFortPlayerPawnAthena*)Pawn)->LastFallDistance);
		DeathInfo.FinisherOrDowner = KillerState;
		DeathInfo.DeathCause = PlayerState->ToDeathCause(DeathInfo.DeathTags, DeathInfo.bDBNO);
		PlayerState->OnRep_DeathInfo();

		if (!PC->Inventory)
			return;

		for (size_t i = 0; i < PC->Inventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (PC->Inventory->Inventory.ReplicatedEntries[i].ItemDefinition->IsA(UFortWeaponMeleeItemDefinition::StaticClass()))
				continue;
			SpawnPickup(Pawn->K2_GetActorLocation(), PC->Inventory->Inventory.ReplicatedEntries[i].ItemDefinition, EFortPickupSourceTypeFlag::AI, EFortPickupSpawnSource::PlayerElimination, PC->Inventory->Inventory.ReplicatedEntries[i].Count, PC->Inventory->Inventory.ReplicatedEntries[i].LoadedAmmo);
		}

		if (Siphon)
		{
			static auto WoodDef = StaticLoadObject<UFortItemDefinition>("/Game/Items/ResourcePickups/WoodItemData.WoodItemData");
			static auto StoneDef = StaticLoadObject<UFortItemDefinition>("/Game/Items/ResourcePickups/StoneItemData.StoneItemData");
			static auto MetalDef = StaticLoadObject<UFortItemDefinition>("/Game/Items/ResourcePickups/MetalItemData.MetalItemData");

			SpawnPickup(Pawn->K2_GetActorLocation(), WoodDef, EFortPickupSourceTypeFlag::Container, EFortPickupSpawnSource::Chest, 50, 1);
			SpawnPickup(Pawn->K2_GetActorLocation(), StoneDef, EFortPickupSourceTypeFlag::Container, EFortPickupSpawnSource::Chest, 50, 1);
			SpawnPickup(Pawn->K2_GetActorLocation(), MetalDef, EFortPickupSourceTypeFlag::Container, EFortPickupSpawnSource::Chest, 50, 1);
		}

		auto KillerPC = (AFortPlayerControllerAthena*)KillerState->GetOwner();
		if (KillerPC && KillerPC->IsA(AFortPlayerControllerAthena::StaticClass()))
		{
			KillerState->KillScore++;
			GiveAccolade(KillerPC, GetDefFromEvent(EAccoladeEvent::Kill, KillerState->KillScore));

			for (size_t i = 0; i < KillerState->PlayerTeam->TeamMembers.Num(); i++)
			{
				((AFortPlayerStateAthena*)KillerState->PlayerTeam->TeamMembers[i]->PlayerState)->TeamKillScore++;
				((AFortPlayerStateAthena*)KillerState->PlayerTeam->TeamMembers[i]->PlayerState)->OnRep_TeamKillScore();
			}

			KillerState->ClientReportKill(PlayerState);
			KillerState->OnRep_Kills();
		}

		AFortGameModeAthena* GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;
		if (GameMode->AlivePlayers.Num() + GameMode->AliveBots.Num() == 50)
		{
			for (size_t i = 0; i < GameMode->AlivePlayers.Num(); i++)
			{
				GiveAccolade(GameMode->AlivePlayers[i], StaticLoadObject<UFortAccoladeItemDefinition>("/Game/Athena/Items/Accolades/AccoladeId_026_Survival_Default_Bronze.AccoladeId_026_Survival_Default_Bronze"));
			}
		}
		if (GameMode->AlivePlayers.Num() + GameMode->AliveBots.Num() == 25)
		{
			for (size_t i = 0; i < GameMode->AlivePlayers.Num(); i++)
			{
				GiveAccolade(GameMode->AlivePlayers[i], StaticLoadObject<UFortAccoladeItemDefinition>("/Game/Athena/Items/Accolades/AccoladeId_027_Survival_Default_Silver.AccoladeId_027_Survival_Default_Silver"));
			}
		}
		if (GameMode->AlivePlayers.Num() + GameMode->AliveBots.Num() == 10)
		{
			for (size_t i = 0; i < GameMode->AlivePlayers.Num(); i++)
			{
				GiveAccolade(GameMode->AlivePlayers[i], StaticLoadObject<UFortAccoladeItemDefinition>("/Game/Athena/Items/Accolades/AccoladeId_028_Survival_Default_Gold.AccoladeId_028_Survival_Default_Gold"));
			}
		}
	}
};

inline vector<Bot*> SpawnedBots{};
