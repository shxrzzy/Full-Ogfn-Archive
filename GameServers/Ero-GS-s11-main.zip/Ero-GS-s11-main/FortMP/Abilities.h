#pragma once
#include "Utils.h"
#include "minhook/MinHook.h"
#include <cstdlib>
#include <ctime>
#include "Looting.h"

#pragma comment(lib, "minhook/minhook.lib")

using namespace std;
using namespace SDK;

static __int64 (*CantBuild)(UWorld*, UObject*, FVector, FRotator, char, void*, char*) = decltype(CantBuild)(__int64(GetModuleHandleW(0)) + 0x19EE0E0);
static bool (*InitListen)(void*, void*, SDK::FURL&, bool, SDK::FString&) = decltype(InitListen)(__int64(GetModuleHandleW(0)) + 0x8EFBA0);
static void(*GiveAbility)(SDK::UAbilitySystemComponent*, SDK::FGameplayAbilitySpecHandle*, SDK::FGameplayAbilitySpec) = decltype(GiveAbility)(__int64(GetModuleHandleW(0)) + 0xB76E70);
static void (*AbilitySpecCtor)(SDK::FGameplayAbilitySpec*, SDK::UGameplayAbility*, int, int, SDK::UObject*) = decltype(AbilitySpecCtor)(__int64(GetModuleHandleW(0)) + 0xB9AF40);
static bool (*InternalTryActivateAbility)(SDK::UAbilitySystemComponent* AbilitySystemComp, SDK::FGameplayAbilitySpecHandle AbilityToActivate, SDK::FPredictionKey InPredictionKey, SDK::UGameplayAbility** OutInstancedAbility, void* OnGameplayAbilityEndedDelegate, const SDK::FGameplayEventData* TriggerEventData) = decltype(InternalTryActivateAbility)(__int64(GetModuleHandleW(0)) + 0xB78580);
static FGameplayAbilitySpecHandle(*GiveAbilityAndActivateOnce)(UAbilitySystemComponent* ASC, FGameplayAbilitySpecHandle*, FGameplayAbilitySpec) = decltype(GiveAbilityAndActivateOnce)(__int64(GetModuleHandleW(0)) + 0xB76F90);

inline void InitAbilitiesForPlayer(SDK::AFortPlayerController* PC)
{
    auto PlayerState = (AFortPlayerStateAthena*)PC->PlayerState;
    static auto AbilitySet = StaticLoadObject<UFortAbilitySet>("/Game/Abilities/Player/Generic/Traits/DefaultPlayer/GAS_AthenaPlayer.GAS_AthenaPlayer");

    if (PlayerState && AbilitySet)
    {
        for (size_t i = 0; i < AbilitySet->GameplayAbilities.Num(); i++)
        {
            Log(AbilitySet->GameplayAbilities[i].Get()->GetName());
            FGameplayAbilitySpec wow{};
            AbilitySpecCtor(&wow, (UGameplayAbility*)AbilitySet->GameplayAbilities[i].Get()->DefaultObject, 1, -1, nullptr);
            GiveAbility(PlayerState->AbilitySystemComponent, &wow.Handle, wow);
        }
    }
}

inline FGameplayAbilitySpec* FindAbilitySpecFromHandle(UFortAbilitySystemComponentAthena* ASC, FGameplayAbilitySpecHandle& Handle)
{
    for (size_t i = 0; i < ASC->ActivatableAbilities.Items.Num(); i++)
    {
        if (ASC->ActivatableAbilities.Items[i].Handle.Handle == Handle.Handle)
            return &ASC->ActivatableAbilities.Items[i];
    }
    return nullptr;
}


inline void InternalServerTryActivateAbilityHook(UFortAbilitySystemComponentAthena* AbilitySystemComponent, FGameplayAbilitySpecHandle Handle, bool InputPressed, FPredictionKey& PredictionKey, FGameplayEventData* TriggerEventData) // Broo what is this thing
{
    FGameplayAbilitySpec* Spec = FindAbilitySpecFromHandle(AbilitySystemComponent, Handle);
    if (!Spec)
        return AbilitySystemComponent->ClientActivateAbilityFailed(Handle, PredictionKey.Current);


    UGameplayAbility* AbilityToActivate = Spec->Ability;

    UGameplayAbility* InstancedAbility = nullptr;
    Spec->InputPressed = true;

    if (!InternalTryActivateAbility(AbilitySystemComponent, Handle, PredictionKey, &InstancedAbility, nullptr, TriggerEventData))
    {
        AbilitySystemComponent->ClientActivateAbilityFailed(Handle, PredictionKey.Current);
        Spec->InputPressed = false;
    }
    AbilitySystemComponent->ActivatableAbilities.MarkItemDirty(*Spec);
}
