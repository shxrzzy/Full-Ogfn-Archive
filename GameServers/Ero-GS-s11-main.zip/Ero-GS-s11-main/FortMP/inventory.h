#pragma once
#include "Utils.h"
#include <cstdlib>
#include <ctime>
#include "Looting.h"


using namespace std;
using namespace SDK;

namespace Inventory
{
    void InitInventoryForPlayer(SDK::AFortPlayerController*);
    void GiveItem(SDK::AFortPlayerController* PC, SDK::UFortItemDefinition* Def, int Count = 1, int LoadedAmmo = 0, bool Stack = false);
    void RemoveItem(SDK::AFortPlayerController* PC, SDK::UFortItemDefinition* Def, int Count = 1);
    void RemoveItem(SDK::AFortPlayerController* PC, FGuid Guid);
    void UpdateEntry(AFortPlayerController* PC, FFortItemEntry& Entry);
}


inline void Inventory::InitInventoryForPlayer(SDK::AFortPlayerController* PC) // PC: player controller
{
    if (!PC->WorldInventory)
        PC->WorldInventory = SpawnActor<AFortInventory>({}, {}, PC);

    if (!PC->ClientQuickBars)
        PC->ClientQuickBars = SpawnActor<AFortQuickBars>({}, {}, PC);

    PC->HandleWorldInventoryLocalUpdate();

    auto GM = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode; // GM: game mode

    for (size_t i = 0; i < GM->StartingItems.Num(); i++)
    {
        if (GM->StartingItems[i].Count <= 0) // How can it be <= 0 lol
            continue;
        Inventory::GiveItem(PC, GM->StartingItems[i].Item, GM->StartingItems[i].Count);
    }

    if (PC->CosmeticLoadoutPC.Pickaxe)
    {
        Inventory::GiveItem(PC, PC->CosmeticLoadoutPC.Pickaxe->WeaponDefinition);
    }
}

 void Inventory::GiveItem(SDK::AFortPlayerController* PC, SDK::UFortItemDefinition* Def, int Count, int LoadedAmmo, bool Stack)
 {
     bool Found = false;
     if (!Stack)
     {
         UFortWorldItem* Item = (UFortWorldItem*)Def->CreateTemporaryItemInstanceBP(Count, 0);
         Item->OwnerInventory = PC->WorldInventory;
         Item->SetOwningControllerForTemporaryItem(PC);
         Item->ItemEntry.LoadedAmmo = LoadedAmmo;
         FFortItemEntryStateValue Value{};
         Value.IntValue = 1;
         Value.StateType = EFortItemEntryState::ShouldShowItemToast;
         Item->ItemEntry.StateValues.Add(Value);
         PC->WorldInventory->Inventory.ReplicatedEntries.Add(Item->ItemEntry);
         PC->WorldInventory->Inventory.ItemInstances.Add(Item);
         PC->WorldInventory->Inventory.MarkItemDirty(Item->ItemEntry);
         PC->WorldInventory->HandleInventoryLocalUpdate();
     }
     else
     {
         for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
         {
             if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition == Def)
             {
                 Found = true;
                 PC->WorldInventory->Inventory.ReplicatedEntries[i].Count += Count;
                 Inventory::UpdateEntry(PC, PC->WorldInventory->Inventory.ReplicatedEntries[i]);
                 if (PC->WorldInventory->Inventory.ReplicatedEntries[i].Count > Def->MaxStackSize)
                 {
                     SpawnPickup(PC->Pawn->K2_GetActorLocation(), PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition, EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource::Unset, PC->WorldInventory->Inventory.ReplicatedEntries[i].Count - PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition->MaxStackSize, 0, PC->MyFortPawn);
                     PC->WorldInventory->Inventory.ReplicatedEntries[i].Count = Def->MaxStackSize;
                     Inventory::UpdateEntry(PC, PC->WorldInventory->Inventory.ReplicatedEntries[i]);
                 }
                 PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
                 PC->WorldInventory->HandleInventoryLocalUpdate();
                 break;
             }
         }

         if (!Found)
             Inventory::GiveItem(PC, Def, Count, LoadedAmmo, false);
     }
 }

 void Inventory::UpdateEntry(AFortPlayerController* PC, FFortItemEntry& Entry)
 {
     for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
     {
         if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == Entry.ItemGuid)
         {
             PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.Count = Entry.Count;
             PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.LoadedAmmo = Entry.LoadedAmmo;
             break;
         }
     }
 }

inline void Inventory::RemoveItem(AFortPlayerController* PC, FGuid Guid)
{
    for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
    {
        if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Guid)
        {
            PC->WorldInventory->Inventory.ReplicatedEntries.RemoveSingle(i);
            break;
        }
    }

    for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
    {
        if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == Guid)
        {
            PC->WorldInventory->Inventory.ItemInstances.RemoveSingle(i);
            break;
        }
    }

    PC->WorldInventory->Inventory.MarkArrayDirty();
    PC->WorldInventory->bRequiresLocalUpdate = true;
    PC->WorldInventory->HandleInventoryLocalUpdate();
}

inline void Inventory::RemoveItem(SDK::AFortPlayerController* PC, SDK::UFortItemDefinition* Def, int Count)
{
    if (!PC || !PC->WorldInventory)
        return;
    bool Remove = false;
    for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
    {
        if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition == Def)
        {
            PC->WorldInventory->Inventory.ReplicatedEntries[i].Count -= Count;
            Inventory::UpdateEntry(PC, PC->WorldInventory->Inventory.ReplicatedEntries[i]);
            if (PC->WorldInventory->Inventory.ReplicatedEntries[i].Count <= 0)
            {
                Remove = true;
                PC->WorldInventory->Inventory.ReplicatedEntries.RemoveSingle(i);
            }

            if (!Remove)
                PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);

            break;
        }
    }

    if (Remove)
    {
        for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
        {
            if (PC->WorldInventory->Inventory.ItemInstances[i]->GetItemDefinitionBP() == Def)
            {
                PC->WorldInventory->Inventory.ItemInstances.RemoveSingle(i);
                break;
            }
        }
    }

    PC->WorldInventory->bRequiresLocalUpdate = true;
    PC->WorldInventory->HandleInventoryLocalUpdate();
    if (Remove)
        PC->WorldInventory->Inventory.MarkArrayDirty();
}