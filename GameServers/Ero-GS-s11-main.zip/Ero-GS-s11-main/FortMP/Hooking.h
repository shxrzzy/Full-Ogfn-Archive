#pragma once
#include "Utils.h"
#include "SDK.hpp"
#include "Gamemode.h"
#include "Misc.h"
#include "PC.h"
#include "Tick.h"
#include "World.h"
#include "Abilities.h"
#include "Teams.h"
#include "minhook/MinHook.h"
#include <iostream>
#include <fstream>
#include "Looting.h"

#pragma comment(lib, "minhook/minhook.lib")

namespace Gamemode {

	inline void InitHooks()
	{
		static auto Base = __int64(GetModuleHandleW(0));
		Log("Initializing Gamemode Hooks...");

		MH_CreateHook((LPVOID)(Base + 0x1540390), ReadyToStartMatch, (LPVOID*)&ReadyToStartMatchOG);
		MH_EnableHook((LPVOID)(Base + 0x1540390));
		MH_CreateHook((LPVOID)(Base + 0x154A770), SpawnDefaultPawnFor, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x154A770));
		MH_CreateHook((LPVOID)(Base + 0x15353E0), OnAircraftEnteredDropZone, (LPVOID*)&OnAircraftEnteredDropZoneOG);
		MH_EnableHook((LPVOID)(Base + 0x15353E0));
		MH_CreateHook((LPVOID)(Base + 0x1535480), OnAircraftExitedDropZone, (LPVOID*)&OnAircraftExitedDropZoneOG);
		MH_EnableHook((LPVOID)(Base + 0x1535480));
	}
}

namespace Misc {

	void InitHooks()
	{
		static auto Base = __int64(GetModuleHandleW(0));
		Log("Initializing Misc Hooks...");

		MH_CreateHook((LPVOID)(Base + 0x27C47A0), CollectGarbageInternal, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x27C47A0));
		MH_CreateHook((LPVOID)(Base + 0x27E09E0), CollectGarbageInternal, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x27E09E0));
		MH_CreateHook((LPVOID)(Base + 0x27E8B00), Context, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x27E8B00));
		MH_CreateHook((LPVOID)(Base + 0xE2BF70), DispatchRequest, (LPVOID*)&DispatchRequestOG);
		MH_EnableHook((LPVOID)(Base + 0xE2BF70));
		MH_CreateHook((LPVOID)(Base + 0x1DCF3E0), OnCapsuleBeginOverlap, (LPVOID*)&OnCapsuleBeginOverlapOG);
		MH_EnableHook((LPVOID)(Base + 0x1DCF3E0));
		MH_CreateHook((LPVOID)(Base + 0x1DE3510), ServerOnExitVehicle, (LPVOID*)&ServerOnExitVehicleOG);
		MH_EnableHook((LPVOID)(Base + 0x1DE3510));
		MH_CreateHook((LPVOID)(Base + 0x12A7810), Inventoryw, (LPVOID*)&InventoryOG);
		MH_EnableHook((LPVOID)(Base + 0x12A7810));
		MH_CreateHook((LPVOID)(Base + 0x12AB760), OnPossessedPawnDied, (LPVOID*)&OnPossessedPawnDiedOG);
		MH_EnableHook((LPVOID)(Base + 0x12AB760));
		MH_CreateHook((LPVOID)(Base + 0x1551340), Storm, (LPVOID*)&StormOG);
		MH_EnableHook((LPVOID)(Base + 0x1551340));
		MH_CreateHook((LPVOID)(Base + 0xBE8270), MovingEmoteStopped, (LPVOID*)&MovingEmoteStoppedOG);
		MH_EnableHook((LPVOID)(Base + 0xBE8270));
		MH_CreateHook((LPVOID)(Base + 0x1780130), ABuildingSMActor_PostUpdate, (LPVOID*)&ABuildingSMActor_PostUpdateOG);
		MH_EnableHook((LPVOID)(Base + 0x1780130));
		MH_CreateHook((LPVOID)(Base + 0x1C1F540), GetSquadIdForCurrentPlayer, (LPVOID*)&GetSquadIdForCurrentPlayerOG);
		MH_EnableHook((LPVOID)(Base + 0x1C1F540));
		MH_CreateHook((LPVOID)(Base + 0x23F7310), NetMulticast_Athena_BatchedDamageCues, (LPVOID*)&NetMulticast_Athena_BatchedDamageCuesOG);
		MH_EnableHook((LPVOID)(Base + 0x23F7310));
		MH_CreateHook((LPVOID)(Base + 0x210CC00), OnReload, (LPVOID*)&OnReloadOG);
		MH_EnableHook((LPVOID)(Base + 0x210CC00));
		MH_CreateHook((LPVOID)(Base + 0x3E04860), UpdateControlRotation, (LPVOID*)&UpdateControlRotationOG);
		MH_EnableHook((LPVOID)(Base + 0x3E04860));
		MH_CreateHook((LPVOID)(Base + 0x3E495A0), OnActorBump, (LPVOID*)&OnActorBumpOG);
		MH_EnableHook((LPVOID)(Base + 0x3E495A0));
		MH_CreateHook((LPVOID)(Base + 0x1466490), GatherNearestLoot, (LPVOID*)&GatherNearestLootOG);
		MH_EnableHook((LPVOID)(Base + 0x1466490));
		MH_CreateHook((LPVOID)(Base + 0x547640), UserMathErrorFunc, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x547640));
		MH_CreateHook((LPVOID)(Base + 0x372FB80), kick, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x372FB80));

		MH_CreateHook((LPVOID)(Base + 0x154e080), StartAircraftPhaseHook, (LPVOID*)&StartAircraftPhase);
		MH_EnableHook((LPVOID)(Base + 0x154e080));

		MH_CreateHook((LPVOID)(Base + Offsets::ProcessEvent), PE, (LPVOID*)&PEOG);
		MH_EnableHook((LPVOID)(Base + Offsets::ProcessEvent));

		MH_CreateHook((*(void***)UEngine::GetEngine())[0x53], GetMaxTickRate, nullptr);
		MH_EnableHook((*(void***)UEngine::GetEngine())[0x53]);
	}
}

namespace PC {

	void InitHooks()
	{
		static auto Base = __int64(GetModuleHandleW(0));
		Log("Initializing PC Hooks...");

		MH_CreateHook((LPVOID)(Base + 0x1E3D9E0), LoadingScreenDropped, (LPVOID*)&LoadingScreenDroppedOG);
		MH_EnableHook((LPVOID)(Base + 0x1E3D9E0));
		MH_CreateHook((LPVOID)(Base + 0x1E181D0), GetPlayerViewPoint, (LPVOID*)&GetPlayerViewPointOG);
		MH_EnableHook((LPVOID)(Base + 0x1E181D0));
		MH_CreateHook((LPVOID)(Base + 0x184E490), ServerAttemptInteract, (LPVOID*)&ServerAttemptInteractOG);
		MH_EnableHook((LPVOID)(Base + 0x184E490));
		MH_CreateHook((LPVOID)(Base + 0x2176A20), OnDamageServer, (LPVOID*)&OnDamageServerOG);
		MH_EnableHook((LPVOID)(Base + 0x2176A20));
		MH_CreateHook((LPVOID)(Base + 0x2446300), ClientOnPawnDied, (LPVOID*)&ClientOnPawnDiedOG);
		MH_EnableHook((LPVOID)(Base + 0x2446300));
		MH_CreateHook((LPVOID)(Base + 0x1B06660), DestroyPickup, (LPVOID*)&DestroyPickupOG);
		MH_EnableHook((LPVOID)(Base + 0x1B06660));
		MH_CreateHook((LPVOID)(Base + 0x19A0480), HandleStartingNewPlayer, (LPVOID*)&HandleStartingNewPlayerOG);
		MH_EnableHook((LPVOID)(Base + 0x19A0480));

		SwapVTable(UFortControllerComponent_Aircraft::StaticClass()->DefaultObject, 0x82, ServerAttemptAircraftJump);
		SwapVTable(UAthenaMarkerComponent::StaticClass()->DefaultObject, 0x7D, ServerRemoveMapMarker);
		SwapVTable(UAthenaMarkerComponent::StaticClass()->DefaultObject, 0x7F, ServerAddMapMarker);
		SwapVTable(AFortPlayerStateAthena::StaticClass()->DefaultObject, 0xFC, ServerSetInAircraft, (LPVOID*)&ServerSetInAircraftOG);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass Athena_PlayerController.Athena_PlayerController_C")->DefaultObject, 0x230, ServerCreateBuildingActor);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass Athena_PlayerController.Athena_PlayerController_C")->DefaultObject, 0x10A, ServerAcknowledgePossession);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass Athena_PlayerController.Athena_PlayerController_C")->DefaultObject, 0x1C1, ServerCheat);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass Athena_PlayerController.Athena_PlayerController_C")->DefaultObject, 0x1C3, ServerPlayEmoteItem);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass Athena_PlayerController.Athena_PlayerController_C")->DefaultObject, 0x4DF, ServerPlaySquadQuickChatMessage);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass Athena_PlayerController.Athena_PlayerController_C")->DefaultObject, 0x209, ServerExecuteInventoryItem);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass Athena_PlayerController.Athena_PlayerController_C")->DefaultObject, 0x232, ServerEditBuildingActor);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass Athena_PlayerController.Athena_PlayerController_C")->DefaultObject, 0x22C, ServerRepairBuildingActor);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass Athena_PlayerController.Athena_PlayerController_C")->DefaultObject, 0x235, ServerEndEditingBuildingActor);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass Athena_PlayerController.Athena_PlayerController_C")->DefaultObject, 0x237, ServerBeginEditingBuildingActor);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass Athena_PlayerController.Athena_PlayerController_C")->DefaultObject, 0x21D, ServerAttemptInventoryDrop);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass PlayerPawn_Athena.PlayerPawn_Athena_C")->DefaultObject, 0x1D6, ServerHandlePickup);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass PlayerPawn_Athena.PlayerPawn_Athena_C")->DefaultObject, 0x1E1, ServerSendZiplineState);
		SwapVTable(UObject::FindObject<UClass>("BlueprintGeneratedClass PlayerPawn_Athena.PlayerPawn_Athena_C")->DefaultObject, 0x1BF, ServerReviveFromDBNO);
	}
}

namespace Tick {

	void InitHooks()
	{
		static auto Base = __int64(GetModuleHandleW(0));
		Log("Initializing NetDriver Hooks...");

		MH_CreateHook((LPVOID)(Base + 0x3883CD0), TickFlush, (LPVOID*)&TickFlushOG);
		MH_EnableHook((LPVOID)(Base + 0x3883CD0));
	}
}

namespace World {

	void InitHooks()
	{
		static auto Base = __int64(GetModuleHandleW(0));
		Log("Initializing World Hooks...");

		MH_CreateHook((LPVOID)(Base + 0x3B76FE0), GetNetMode, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x3B76FE0));
		MH_CreateHook((LPVOID)(Base + 0x34AF6C0), GetNetMode, nullptr);//actor get net mode should have done it seperate but what ever
		MH_EnableHook((LPVOID)(Base + 0x34AF6C0));
		MH_CreateHook((LPVOID)(Base + 0x19B1660), ChangeGameSessionId, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x19B1660));

	}
	SDK::APlayerController* SpawnPlayActor(SDK::UWorld*, SDK::UPlayer*, SDK::ENetRole, const SDK::FURL&, void*, SDK::FString&, uint8); //i shouldnt do it like this but what ever
}

namespace Abilities {

	void InitHooks()
	{
		Log("Initializing Abilities Hooks...");
		SwapVTable(UAbilitySystemComponent::GetDefaultObj(), 0xF7, InternalServerTryActivateAbilityHook);
		SwapVTable(UFortAbilitySystemComponent::GetDefaultObj(), 0xF7, InternalServerTryActivateAbilityHook);
		SwapVTable(UFortAbilitySystemComponentAthena::GetDefaultObj(), 0xF7, InternalServerTryActivateAbilityHook);

		static auto Base = __int64(GetModuleHandleW(0));

		MH_CreateHook((LPVOID)(Base + 0x174AAA0), SpawnLoot, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x174AAA0));
	}
	void InitAbilitiesForPlayer(SDK::AFortPlayerController*);
}

namespace Teams
{
	void InitHooks()
	{
		Log("Initializing Teams Hooks...");
		static auto Base = __int64(GetModuleHandleW(0));

		MH_CreateHook((LPVOID)(Base + 0x153B210), PickTeam, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x153B210));
	}

	uint8 PickTeam(SDK::AFortGameModeAthena* Gamemode, uint8 PreferredTeam, SDK::AFortPlayerControllerAthena* PC);
}
