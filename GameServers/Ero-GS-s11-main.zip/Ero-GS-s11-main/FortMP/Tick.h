#pragma once
#include "Utils.h"
#include "Gamemode.h"
#include "Misc.h"
#include "minhook/MinHook.h"

#pragma comment(lib, "minhook/minhook.lib")

using namespace SDK;
using namespace Params;
using namespace std;


inline void (*TickFlushOG)(UNetDriver* Driver, float a2);
inline void TickFlush(UNetDriver* Driver, float a2)
{
	static void (*ServerReplicateActors)(void*) = decltype(ServerReplicateActors)((*(void***)UFortReplicationGraph::StaticClass()->DefaultObject)[0x59]);
	if (ServerReplicateActors && Driver->ReplicationDriver)
		ServerReplicateActors(Driver->ReplicationDriver);

	TickFlushOG(Driver, a2);

	if (BotsEnabled)
	{
		static bool HasStartedAircraft = false;
		static bool Started = false;
		static bool First = false;
		static bool First2 = false;
		static TArray<AActor*> PlayerStarts;
		auto GameMode = (AFortGameModeAthena*)Driver->World->AuthorityGameMode;
		auto GameState = (AFortGameStateAthena*)Driver->World->GameState;

		if (!First)
		{
			UGameplayStatics::GetDefaultObj()->GetAllActorsOfClass(UWorld::GetWorld(), AFortPlayerStartWarmup::StaticClass(), &PlayerStarts);
			First = true;
		}

		if (((AFortGameStateAthena*)UWorld::GetWorld()->GameState)->GamePhase < EAthenaGamePhase::Aircraft && GameMode->AlivePlayers.Num() > 0 && (GameMode->AlivePlayers.Num() + GameMode->AliveBots.Num()) < 100)
		{
			GameState->WarmupCountdownEndTime = UGameplayStatics::GetDefaultObj()->GetTimeSeconds(UWorld::GetWorld()) + 12;

			if (UKismetMathLibrary::GetDefaultObj()->RandomBoolWithWeight(0.07f))
			{
				AActor* SpawnLocator = PlayerStarts[UKismetMathLibrary::GetDefaultObj()->RandomIntegerInRange(0, PlayerStarts.Num() - 1)];

				if (SpawnLocator)
				{
					Log("Spawning New Bot");
					SpawnedBots.push_back(new Bot(SpawnLocator));
				}
			}
		}

		if (!First2 && GameMode->AlivePlayers.Num() > 0 && GameState->GamePhase == EAthenaGamePhase::Warmup && GameState->WarmupCountdownEndTime - UGameplayStatics::GetDefaultObj()->GetTimeSeconds(UWorld::GetWorld()) <= 0 && HasStartedAircraft == false)
		{
			StartAircraft();

			HasStartedAircraft = true;

		}

		if (GetGameState()->WarmupCountdownEndTime - GetStatics()->GetTimeSeconds(GetWorld()) <= 0 && HasStartedAircraft == true)
		{
			StartAircraftPhase(GetGameMode(), 0);
		}

		if (BotsEnabled)
		{
			for (size_t i = 0; i < SpawnedBots.size(); i++)
			{
				SpawnedBots[i]->Tick();
			}
		}
	}
}