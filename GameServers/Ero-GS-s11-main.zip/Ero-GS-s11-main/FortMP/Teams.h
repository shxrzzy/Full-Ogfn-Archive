#pragma once
#include "Utils.h"
#include <cstdlib>
#include <ctime>


using namespace std;
using namespace SDK;



inline uint8 PickTeam(SDK::AFortGameModeAthena* Gamemode, uint8 PreferredTeam, SDK::AFortPlayerControllerAthena* PC)
{
    uint8 Ret = NextIdx;
    CurrentPlayersOnTeam++;

    if (CurrentPlayersOnTeam == MaxPlayersOnTeam)
    {
        NextIdx++;
        CurrentPlayersOnTeam = 0;
    }
    return Ret;
}
