![image](https://github.com/user-attachments/assets/8c265350-d49e-4e83-8a30-dc241624fe2f)

### Second gs i touched idrk if this is worse than ero s12 but it deff has less bugs but its very very skunked this was still my learning phase

**Note**: Credits to Magma for the base of the gameserver! 
