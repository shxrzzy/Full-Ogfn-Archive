#pragma once
#include "Utils.h"
#include "UE.h"
#include <vector>
#include <map>
#include <algorithm>
#include <random>
#include <unordered_set>
#include <string>
#include <cstdlib>
#include <ctime>   

struct LootItemInfo {
    UFortItemDefinition* ItemDefinition;
    int32 Probability;
    int LoadedAmmo;
};

struct ConsumableInfo {
    UFortItemDefinition* Definition;
    int Quantity;
};

struct AmoInfo {
    UFortItemDefinition* Definition;
    int Quantity;
};

struct MatsInfo {
    UFortItemDefinition* Definition;
    int Quantity;
};

//floor loot
inline TArray<LootItemInfo> AssaultRifleForFloor() {
    TArray<LootItemInfo> AssaultRifleForFloor;
    //Ar
    AssaultRifleForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Auto_Athena_C_Ore_T02.WID_Assault_Auto_Athena_C_Ore_T02"), 65 , 30});
    AssaultRifleForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Auto_Athena_UC_Ore_T03.WID_Assault_Auto_Athena_UC_Ore_T03"), 7 , 30});
    AssaultRifleForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Auto_Athena_R_Ore_T03.WID_Assault_Auto_Athena_R_Ore_T03"), 3 , 30});

    //Heavy
    AssaultRifleForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Heavy_Athena_C_Ore_T03.WID_Assault_Heavy_Athena_C_Ore_T03"), 65 , 25 });
    AssaultRifleForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Heavy_Athena_UC_Ore_T03.WID_Assault_Heavy_Athena_UC_Ore_T03"), 7 ,25 });
    AssaultRifleForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Heavy_Athena_R_Ore_T03.WID_Assault_Heavy_Athena_R_Ore_T03"), 3 , 25 });

    return AssaultRifleForFloor;
}

inline TArray<LootItemInfo> ShotgunForFloor() {
    TArray<LootItemInfo> ShotgunForFloor;
    //Lever
    ShotgunForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Swing_Athena_C.WID_Shotgun_Swing_Athena_C"), 65 , 6});
    ShotgunForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Swing_Athena_UC.WID_Shotgun_Swing_Athena_UC"), 7 , 6});
    ShotgunForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Swing_Athena_R.WID_Shotgun_Swing_Athena_R"), 3 , 6});

    //charged shotgun
    ShotgunForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Charge_Athena_UC_Ore_T03.WID_Shotgun_Charge_Athena_UC_Ore_T03"), 7 , 4});
    ShotgunForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Charge_Athena_R_Ore_T03.WID_Shotgun_Charge_Athena_R_Ore_T03"), 3 , 4});

    //Tac
    ShotgunForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_SemiAuto_Athena_UC_Ore_T03.WID_Shotgun_SemiAuto_Athena_UC_Ore_T03"), 65 , 8});
    ShotgunForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_SemiAuto_Athena_R_Ore_T03.WID_Shotgun_SemiAuto_Athena_R_Ore_T03"), 7 , 8 });
    ShotgunForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_SemiAuto_Athena_VR_Ore_T03.WID_Shotgun_SemiAuto_Athena_VR_Ore_T03"), 3 , 8});

    return ShotgunForFloor;
}

inline TArray<LootItemInfo> SMGForFloor() {
    TArray<LootItemInfo> SMGForFloor;
    //smg
    SMGForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavyPDW_Athena_C_Ore_T03.WID_Pistol_AutoHeavyPDW_Athena_C_Ore_T03"), 65 , 30 });
    SMGForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavyPDW_Athena_UC_Ore_T03.WID_Pistol_AutoHeavyPDW_Athena_UC_Ore_T03"), 7 , 30 });
    SMGForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavyPDW_Athena_R_Ore_T03.WID_Pistol_AutoHeavyPDW_Athena_R_Ore_T03"), 3 , 30});

    //supp smg
    SMGForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavySuppressed_Athena_C_Ore_T02.WID_Pistol_AutoHeavySuppressed_Athena_C_Ore_T02"), 65 , 30});
    SMGForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavySuppressed_Athena_UC_Ore_T03.WID_Pistol_AutoHeavySuppressed_Athena_UC_Ore_T03"), 7 , 30 });
    SMGForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavySuppressed_Athena_R_Ore_T03.WID_Pistol_AutoHeavySuppressed_Athena_R_Ore_T03"), 3 , 30});


    //rapid smg
    SMGForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_RapidFireSMG_Athena_C_Ore_T03.WID_Pistol_RapidFireSMG_Athena_C_Ore_T03"), 65 , 20 });
    SMGForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_RapidFireSMG_Athena_UC_Ore_T03.WID_Pistol_RapidFireSMG_Athena_UC_Ore_T03"), 7 , 20});
    SMGForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_RapidFireSMG_Athena_R_Ore_T03.WID_Pistol_RapidFireSMG_Athena_R_Ore_T03"), 3 , 20 });

    return SMGForFloor;
}

inline TArray<LootItemInfo> PistolForFloor() {
    TArray<LootItemInfo> PistolForFloor;
    //Pistol
    PistolForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_SemiAuto_Athena_C_Ore_T02.WID_Pistol_SemiAuto_Athena_C_Ore_T02"), 65 , 16 });
    PistolForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_SemiAuto_Athena_UC_Ore_T03.WID_Pistol_SemiAuto_Athena_UC_Ore_T03"), 7 ,16 });
    PistolForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_SemiAuto_Athena_R_Ore_T03.WID_Pistol_SemiAuto_Athena_R_Ore_T03"), 3 , 16 });

    return PistolForFloor;
}

inline TArray<LootItemInfo> SniperForFloor() {
    TArray<LootItemInfo> SniperForFloor;
    //Sniper
    SniperForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_BoltAction_Scope_Athena_R_Ore_T03.WID_Sniper_BoltAction_Scope_Athena_R_Ore_T03"), 7 , 1 });

    //Lever Action Rifle
    SniperForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_Cowboy_Athena_UC.WID_Sniper_Cowboy_Athena_UC"), 7 , 9});
    SniperForFloor.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_Cowboy_Athena_R.WID_Sniper_Cowboy_Athena_R"), 3 , 9 });

    return SniperForFloor;
}

// for chests
inline TArray<LootItemInfo> AssaultRifleForChest() {
    TArray<LootItemInfo> AssaultRifleForChest;
    //Ar
    AssaultRifleForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Auto_Athena_UC_Ore_T03.WID_Assault_Auto_Athena_UC_Ore_T03"), 30 , 30 });
    AssaultRifleForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Auto_Athena_R_Ore_T03.WID_Assault_Auto_Athena_R_Ore_T03"), 25 , 30});
    AssaultRifleForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_AutoHigh_Athena_VR_Ore_T03.WID_Assault_AutoHigh_Athena_VR_Ore_T03"), 7 , 30});
    AssaultRifleForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_AutoHigh_Athena_SR_Ore_T03.WID_Assault_AutoHigh_Athena_SR_Ore_T03"), 3 , 30});


    //Heavy
    AssaultRifleForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Heavy_Athena_UC_Ore_T03.WID_Assault_Heavy_Athena_UC_Ore_T03"), 30 , 25});
    AssaultRifleForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Heavy_Athena_R_Ore_T03.WID_Assault_Heavy_Athena_R_Ore_T03"), 25 , 25 });
    AssaultRifleForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Heavy_Athena_VR_Ore_T03.WID_Assault_Heavy_Athena_VR_Ore_T03"), 7 , 25});
    AssaultRifleForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Heavy_Athena_SR_Ore_T03.WID_Assault_Heavy_Athena_SR_Ore_T03"), 3 , 25});

    return AssaultRifleForChest;
}

inline TArray<LootItemInfo> ShotgunForChest() {
    TArray<LootItemInfo> ShotgunForChest;
    //Lever
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Swing_Athena_UC.WID_Shotgun_Swing_Athena_UC"), 30 , 6 });
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Swing_Athena_R.WID_Shotgun_Swing_Athena_R"), 25 , 6});
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Swing_Athena_VR.WID_Shotgun_Swing_Athena_VR"), 7 , 6});
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Swing_Athena_SR.WID_Shotgun_Swing_Athena_SR"), 3 , 6});

    //charged
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Charge_Athena_UC_Ore_T03.WID_Shotgun_Charge_Athena_UC_Ore_T03"), 30 , 4});
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Charge_Athena_R_Ore_T03.WID_Shotgun_Charge_Athena_R_Ore_T03"), 25 , 4});
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Charge_Athena_VR_Ore_T03.WID_Shotgun_Charge_Athena_VR_Ore_T03"), 7 ,5 });
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Charge_Athena_SR_Ore_T03.WID_Shotgun_Charge_Athena_SR_Ore_T03"), 3 , 5});

    //Tac
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_SemiAuto_Athena_R_Ore_T03.WID_Shotgun_SemiAuto_Athena_R_Ore_T03"), 30 , 8});
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_SemiAuto_Athena_VR_Ore_T03.WID_Shotgun_SemiAuto_Athena_VR_Ore_T03"), 25 , 8});
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_HighSemiAuto_Athena_VR_Ore_T03.WID_Shotgun_HighSemiAuto_Athena_VR_Ore_T03"), 7 , 8});
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_HighSemiAuto_Athena_SR_Ore_T03.WID_Shotgun_HighSemiAuto_Athena_SR_Ore_T03"), 3 , 8});

    //dragon
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_BreakBarrel_Dragon_Athena_VR_Ore_T03.WID_Shotgun_BreakBarrel_Dragon_Athena_VR_Ore_T03"), 7 , 4 });
    ShotgunForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_BreakBarrel_Dragon_Athena_SR_Ore_T03.WID_Shotgun_BreakBarrel_Dragon_Athena_SR_Ore_T03"), 3 , 4});

    return ShotgunForChest;
}

inline TArray<LootItemInfo> SMGForChest() {
    TArray<LootItemInfo> SMGForChest;
    //smg
    SMGForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavyPDW_Athena_UC_Ore_T03.WID_Pistol_AutoHeavyPDW_Athena_UC_Ore_T03"), 30 , 30});
    SMGForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavyPDW_Athena_R_Ore_T03.WID_Pistol_AutoHeavyPDW_Athena_R_Ore_T03"), 25 , 30});
    SMGForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavyPDW_Athena_SR_Ore_T03.WID_Pistol_AutoHeavyPDW_Athena_SR_Ore_T03"), 7 , 30});
    SMGForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavyPDW_Athena_VR_Ore_T03.WID_Pistol_AutoHeavyPDW_Athena_VR_Ore_T03"), 3 , 30});

    //supp smg
    SMGForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavySuppressed_Athena_UC_Ore_T03.WID_Pistol_AutoHeavySuppressed_Athena_UC_Ore_T03"), 30 , 30});
    SMGForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavySuppressed_Athena_R_Ore_T03.WID_Pistol_AutoHeavySuppressed_Athena_R_Ore_T03"), 25 , 30});


    //rapid smg
    SMGForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_RapidFireSMG_Athena_UC_Ore_T03.WID_Pistol_RapidFireSMG_Athena_UC_Ore_T03"), 30 , 20});
    SMGForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_RapidFireSMG_Athena_R_Ore_T03.WID_Pistol_RapidFireSMG_Athena_R_Ore_T03"), 25 , 20});
    SMGForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_RapidFireSMG_Athena_VR_Ore_T03.WID_Pistol_RapidFireSMG_Athena_VR_Ore_T03"), 7 , 26});
    SMGForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_RapidFireSMG_Athena_SR_Ore_T03.WID_Pistol_RapidFireSMG_Athena_SR_Ore_T03"), 3 , 26});

    return SMGForChest;
}

inline TArray<LootItemInfo> PistolForChest() {
    TArray<LootItemInfo> PistolForChest;
    //Pistol
    PistolForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_SemiAuto_Athena_UC_Ore_T03.WID_Pistol_SemiAuto_Athena_UC_Ore_T03"), 30 , 16});
    PistolForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_SemiAuto_Athena_R_Ore_T03.WID_Pistol_SemiAuto_Athena_R_Ore_T03"), 25 , 16});
    PistolForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_Standard_Athena_VR.WID_Pistol_Standard_Athena_VR"), 7 , 16 });
    PistolForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_Standard_Athena_SR.WID_Pistol_Standard_Athena_SR"), 3 , 16 });

    return PistolForChest;
}

inline TArray<LootItemInfo> SniperForChest() {
    TArray<LootItemInfo> SniperForChest;
    //Sniper
    SniperForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_BoltAction_Scope_Athena_R_Ore_T03.WID_Sniper_BoltAction_Scope_Athena_R_Ore_T03"), 25 , 1});
    SniperForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_BoltAction_Scope_Athena_VR_Ore_T03.WID_Sniper_BoltAction_Scope_Athena_VR_Ore_T03"), 7 , 1});
    SniperForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_BoltAction_Scope_Athena_SR_Ore_T03.WID_Sniper_BoltAction_Scope_Athena_SR_Ore_T03"), 3 , 1});

    //rifle
    SniperForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_Cowboy_Athena_UC.WID_Sniper_Cowboy_Athena_UC"), 30 , 9});
    SniperForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_Cowboy_Athena_R.WID_Sniper_Cowboy_Athena_R"), 25 , 9});
    SniperForChest.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_Cowboy_Athena_VR.WID_Sniper_Cowboy_Athena_VR"), 7 , 9});

    return SniperForChest;
};

//for supplydrops
inline TArray<LootItemInfo> AssaultRifleForSupply() {
    TArray<LootItemInfo> AssaultRifleForSupply;
    //Ar
    AssaultRifleForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_AutoHigh_Athena_VR_Ore_T03.WID_Assault_AutoHigh_Athena_VR_Ore_T03"), 7 , 30});
    AssaultRifleForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_AutoHigh_Athena_SR_Ore_T03.WID_Assault_AutoHigh_Athena_SR_Ore_T03"), 5 , 30 });

    //Heavy
    AssaultRifleForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Heavy_Athena_VR_Ore_T03.WID_Assault_Heavy_Athena_VR_Ore_T03"), 7 , 25 });
    AssaultRifleForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Heavy_Athena_SR_Ore_T03.WID_Assault_Heavy_Athena_SR_Ore_T03"), 5 , 25});

    return AssaultRifleForSupply;
}

inline TArray<LootItemInfo> ShotgunForSupply() {
    TArray<LootItemInfo> ShotgunForSupply;
    //Lever
    ShotgunForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Swing_Athena_VR.WID_Shotgun_Swing_Athena_VR"), 7 , 6});
    ShotgunForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Swing_Athena_SR.WID_Shotgun_Swing_Athena_SR"), 5 , 6 });

    //charged
    ShotgunForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Charge_Athena_VR_Ore_T03.WID_Shotgun_Charge_Athena_VR_Ore_T03"), 7 , 5});
    ShotgunForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Charge_Athena_SR_Ore_T03.WID_Shotgun_Charge_Athena_SR_Ore_T03"), 5 , 5 });

    //Tac
    ShotgunForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_HighSemiAuto_Athena_VR_Ore_T03.WID_Shotgun_HighSemiAuto_Athena_VR_Ore_T03"), 7 , 8});
    ShotgunForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_HighSemiAuto_Athena_SR_Ore_T03.WID_Shotgun_HighSemiAuto_Athena_SR_Ore_T03"), 5 , 8});

    //dragon
    ShotgunForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_BreakBarrel_Dragon_Athena_VR_Ore_T03.WID_Shotgun_BreakBarrel_Dragon_Athena_VR_Ore_T03"), 7 , 4});
    ShotgunForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_BreakBarrel_Dragon_Athena_SR_Ore_T03.WID_Shotgun_BreakBarrel_Dragon_Athena_SR_Ore_T03"), 5 , 4});

    return ShotgunForSupply;
}

inline TArray<LootItemInfo> SMGForSupply() {
    TArray<LootItemInfo> SMGForSupply;
    //smg
    SMGForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavyPDW_Athena_SR_Ore_T03.WID_Pistol_AutoHeavyPDW_Athena_SR_Ore_T03"), 7 , 30});
    SMGForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavyPDW_Athena_VR_Ore_T03.WID_Pistol_AutoHeavyPDW_Athena_VR_Ore_T03"), 5 , 30});

    //rapid smg
    SMGForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_RapidFireSMG_Athena_VR_Ore_T03.WID_Pistol_RapidFireSMG_Athena_VR_Ore_T03"), 7 , 26});
    SMGForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_RapidFireSMG_Athena_SR_Ore_T03.WID_Pistol_RapidFireSMG_Athena_SR_Ore_T03"), 5 , 26});

    return SMGForSupply;
}

inline TArray<LootItemInfo> PistolForSupply() {
    TArray<LootItemInfo> PistolForSupply;
    //Pistol
    PistolForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_Standard_Athena_VR.WID_Pistol_Standard_Athena_VR"), 7 , 16});
    PistolForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_Standard_Athena_SR.WID_Pistol_Standard_Athena_SR"), 5 , 16 });

    return PistolForSupply;
}

inline TArray<LootItemInfo> SniperForSupply() {
    TArray<LootItemInfo> SniperForSupply;
    //Sniper
    SniperForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_BoltAction_Scope_Athena_VR_Ore_T03.WID_Sniper_BoltAction_Scope_Athena_VR_Ore_T03"), 7 , 1});
    SniperForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_BoltAction_Scope_Athena_SR_Ore_T03.WID_Sniper_BoltAction_Scope_Athena_SR_Ore_T03"), 5 , 1});

    //rifle
    SniperForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_Cowboy_Athena_VR.WID_Sniper_Cowboy_Athena_VR"), 7 , 9});

    return SniperForSupply;
}

inline TArray<LootItemInfo> RPGForSupply() {
    TArray<LootItemInfo> RPGForSupply;
    //RPG
    RPGForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Launcher_Rocket_Athena_VR_Ore_T03.WID_Launcher_Rocket_Athena_VR_Ore_T03"), 7 , 1 });
    RPGForSupply.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Launcher_Rocket_Athena_SR_Ore_T03.WID_Launcher_Rocket_Athena_SR_Ore_T03"), 5 , 1 });

    return RPGForSupply;
}

//for Faction chests
inline TArray<LootItemInfo> AssaultRifleForFaction() {
    TArray<LootItemInfo> AssaultRifleForFaction;
    //Ar
    AssaultRifleForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_AutoHigh_Athena_VR_Ore_T03.WID_Assault_AutoHigh_Athena_VR_Ore_T03"), 7 , 30 });
    AssaultRifleForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_AutoHigh_Athena_SR_Ore_T03.WID_Assault_AutoHigh_Athena_SR_Ore_T03"), 5 , 30 });

    //Heavy
    AssaultRifleForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Heavy_Athena_VR_Ore_T03.WID_Assault_Heavy_Athena_VR_Ore_T03"), 7 , 25 });
    AssaultRifleForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Assault_Heavy_Athena_SR_Ore_T03.WID_Assault_Heavy_Athena_SR_Ore_T03"), 5 , 25 });

    return AssaultRifleForFaction;
}

inline TArray<LootItemInfo> ShotgunForFaction() {
    TArray<LootItemInfo> ShotgunForFaction;
    //Lever
    ShotgunForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Swing_Athena_VR.WID_Shotgun_Swing_Athena_VR"), 7 , 6 });
    ShotgunForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Swing_Athena_SR.WID_Shotgun_Swing_Athena_SR"), 5 , 6 });

    //charged
    ShotgunForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Charge_Athena_VR_Ore_T03.WID_Shotgun_Charge_Athena_VR_Ore_T03"), 7 , 5 });
    ShotgunForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_Charge_Athena_SR_Ore_T03.WID_Shotgun_Charge_Athena_SR_Ore_T03"), 5 , 5 });

    //Tac
    ShotgunForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_HighSemiAuto_Athena_VR_Ore_T03.WID_Shotgun_HighSemiAuto_Athena_VR_Ore_T03"), 7 , 8 });
    ShotgunForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_HighSemiAuto_Athena_SR_Ore_T03.WID_Shotgun_HighSemiAuto_Athena_SR_Ore_T03"), 5 , 8 });

    //dragon
    ShotgunForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_BreakBarrel_Dragon_Athena_VR_Ore_T03.WID_Shotgun_BreakBarrel_Dragon_Athena_VR_Ore_T03"), 7 , 4 });
    ShotgunForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Shotgun_BreakBarrel_Dragon_Athena_SR_Ore_T03.WID_Shotgun_BreakBarrel_Dragon_Athena_SR_Ore_T03"), 5 , 4 });

    return ShotgunForFaction;
}

inline TArray<LootItemInfo> SMGForFaction() {
    TArray<LootItemInfo> SMGForFaction;
    //smg
    SMGForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavyPDW_Athena_SR_Ore_T03.WID_Pistol_AutoHeavyPDW_Athena_SR_Ore_T03"), 7 , 30 });
    SMGForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_AutoHeavyPDW_Athena_VR_Ore_T03.WID_Pistol_AutoHeavyPDW_Athena_VR_Ore_T03"), 5 , 30 });

    //rapid smg
    SMGForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_RapidFireSMG_Athena_VR_Ore_T03.WID_Pistol_RapidFireSMG_Athena_VR_Ore_T03"), 7 , 26 });
    SMGForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_RapidFireSMG_Athena_SR_Ore_T03.WID_Pistol_RapidFireSMG_Athena_SR_Ore_T03"), 5 , 26 });

    return SMGForFaction;
}

inline TArray<LootItemInfo> PistolForFaction() {
    TArray<LootItemInfo> PistolForFaction;
    //Pistol
    PistolForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_Standard_Athena_VR.WID_Pistol_Standard_Athena_VR"), 7 , 16});
    PistolForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Pistol_Standard_Athena_SR.WID_Pistol_Standard_Athena_SR"), 5 , 16 });

    return PistolForFaction;
}

inline TArray<LootItemInfo> SniperForFaction() {
    TArray<LootItemInfo> SniperForFaction;
    //Sniper
    SniperForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_BoltAction_Scope_Athena_VR_Ore_T03.WID_Sniper_BoltAction_Scope_Athena_VR_Ore_T03"), 7 , 1 });
    SniperForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_BoltAction_Scope_Athena_SR_Ore_T03.WID_Sniper_BoltAction_Scope_Athena_SR_Ore_T03"), 5 , 1 });

    //rifle
    SniperForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Sniper_Cowboy_Athena_VR.WID_Sniper_Cowboy_Athena_VR"), 7 , 9 });

    return SniperForFaction;
}

inline TArray<LootItemInfo> RPGForFaction() {
    TArray<LootItemInfo> RPGForFaction;
    //RPG
    RPGForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Launcher_Rocket_Athena_VR_Ore_T03.WID_Launcher_Rocket_Athena_VR_Ore_T03"), 7 , 1 });
    RPGForFaction.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Weapons/WID_Launcher_Rocket_Athena_SR_Ore_T03.WID_Launcher_Rocket_Athena_SR_Ore_T03"), 5 , 1 });

    return RPGForFaction;
}

//for barrels duh!!!
inline TArray<LootItemInfo> Barrel() {
    TArray<LootItemInfo> Barrel;
    Barrel.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/FloppingRabbit/WID_Athena_FloppingRabbit.WID_Athena_FloppingRabbit"), 75 });
    Barrel.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/FloppingRabbit/WID_Athena_FloppingRabbit_HighTier.WID_Athena_FloppingRabbit_HighTier"), 35 });
    Barrel.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/HappyGhost/WID_Athena_HappyGhost.WID_Athena_HappyGhost"), 25 });
    return Barrel;
}

//for fish fridge duh!!!
inline TArray<LootItemInfo> IceBox() {
    TArray<LootItemInfo> IceBox;
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Flopper/Small/WID_Athena_FlopperSmall.WID_Athena_FlopperSmall"), 30 });
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Flopper/Effective/WID_Athena_Flopper_Effective.WID_Athena_Flopper_Effective"), 30 });
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Flopper/ShieldFlopper/WID_Athena_Flopper_Shield.WID_Athena_Flopper_Shield"), 30 });
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Flopper/BattleFlopper/WID_Athena_BattleFlopper.WID_Athena_BattleFlopper"), 30 });
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Flopper/Thermal/WID_Athena_Flopper_Thermal.WID_Athena_Flopper_Thermal"), 30 });
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Flopper/JellyFish/WID_Athena_Flopper_JellyFish.WID_Athena_Flopper_JellyFish"), 30 });
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Flopper/ZeroFlopper/WID_Athena_Flopper_Zero.WID_Athena_Flopper_Zero"), 30 });
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Flopper/RiftFlopper/WID_Athena_Flopper_Rift.WID_Athena_Flopper_Rift"), 30 });
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Flopper/SnowmanFlopper/WID_Athena_Flopper_Snowman.WID_Athena_Flopper_Snowman"), 30 });
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Flopper/WID_Athena_Flopper.WID_Athena_Flopper"), 30 });
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Bucket/WID_Athena_Bucket_Old.WID_Athena_Bucket_Old"), 30 });
    IceBox.Add({ StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Bucket/Nice/WID_Athena_Bucket_Nice.WID_Athena_Bucket_Nice"), 1 });
    return IceBox;
};


//amo/consumable/mats are all equal in spawning rate
inline TArray<ConsumableInfo> Consumable() {

    TArray<ConsumableInfo> Consumable;

    ConsumableInfo SmallShieldInfo;
    SmallShieldInfo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/ShieldSmall/Athena_ShieldSmall.Athena_ShieldSmall");
    SmallShieldInfo.Quantity = 3;
    Consumable.Add(SmallShieldInfo);

    ConsumableInfo MedkitInfo;
    MedkitInfo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Medkit/Athena_Medkit.Athena_Medkit");
    MedkitInfo.Quantity = 1;
    Consumable.Add(MedkitInfo);

    ConsumableInfo BandageInfo;
    BandageInfo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Bandage/Athena_Bandage.Athena_Bandage");
    BandageInfo.Quantity = 5;
    Consumable.Add(BandageInfo);

    ConsumableInfo ShieldsInfo;
    ShieldsInfo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Shields/Athena_Shields.Athena_Shields");
    ShieldsInfo.Quantity = 1;
    Consumable.Add(ShieldsInfo);

    ConsumableInfo GernadeInfo;
    GernadeInfo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/Grenade/Athena_Grenade.Athena_Grenade");
    GernadeInfo.Quantity = 3;
    Consumable.Add(GernadeInfo);

    ConsumableInfo ChugSplashInfo;
    ChugSplashInfo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/ChillBronco/Athena_ChillBronco.Athena_ChillBronco");
    ChugSplashInfo.Quantity = 3;
    Consumable.Add(ChugSplashInfo);

    ConsumableInfo RodInfo;
    RodInfo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/FloppingRabbit/WID_Athena_FloppingRabbit.WID_Athena_FloppingRabbit");
    RodInfo.Quantity = 1;
    Consumable.Add(RodInfo);

    ConsumableInfo ShockGrenade;
    ShockGrenade.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Consumables/ShockwaveGrenade/Athena_ShockGrenade.Athena_ShockGrenade");
    ShockGrenade.Quantity = 3;
    Consumable.Add(ShockGrenade);

    return Consumable;
}

inline TArray<AmoInfo> Amo() {

    TArray<AmoInfo> Amo;

    AmoInfo SniperAmo;
    SniperAmo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Ammo/AthenaAmmoDataBulletsHeavy.AthenaAmmoDataBulletsHeavy");
    SniperAmo.Quantity = 6;
    Amo.Add(SniperAmo);

    AmoInfo SMGAmo;
    SMGAmo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Ammo/AthenaAmmoDataBulletsLight.AthenaAmmoDataBulletsLight");
    SMGAmo.Quantity = 18;
    Amo.Add(SMGAmo);

    AmoInfo AssaultAmo;
    AssaultAmo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Ammo/AthenaAmmoDataBulletsMedium.AthenaAmmoDataBulletsMedium");
    AssaultAmo.Quantity = 10;
    Amo.Add(AssaultAmo);

    AmoInfo ShotgunInfo;
    ShotgunInfo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Ammo/AthenaAmmoDataShells.AthenaAmmoDataShells");
    ShotgunInfo.Quantity = 4;
    Amo.Add(ShotgunInfo);

    AmoInfo RocketInfo;
    RocketInfo.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Athena/Items/Ammo/AmmoDataRockets.AmmoDataRockets");
    RocketInfo.Quantity = 2;
    Amo.Add(RocketInfo);

    return Amo;
}

inline TArray<MatsInfo> Mats() {

    TArray<MatsInfo> Mats;

    MatsInfo Wood;
    Wood.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Items/ResourcePickups/WoodItemData.WoodItemData");
    Wood.Quantity = 30;
    Mats.Add(Wood);

    MatsInfo Brick;
    Brick.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Items/ResourcePickups/StoneItemData.StoneItemData");
    Brick.Quantity = 30;
    Mats.Add(Brick);

    MatsInfo Metal;
    Metal.Definition = StaticLoadObject<UFortItemDefinition>("/Game/Items/ResourcePickups/MetalItemData.MetalItemData");
    Metal.Quantity = 30;
    Mats.Add(Metal);

    return Mats;
}

