#pragma once
#include <numeric>
#include "SDK.hpp"
#include "Tarray.h"
#include "Looting.h"

using namespace std;
using namespace SDK;

EFortQuickBars GetQuickBars(UFortItemDefinition* ItemDefinition)
{
	if (!ItemDefinition->IsA(UFortWeaponMeleeItemDefinition::StaticClass()) && !ItemDefinition->IsA(UFortEditToolItemDefinition::StaticClass()) &&
		!ItemDefinition->IsA(UFortBuildingItemDefinition::StaticClass()) && !ItemDefinition->IsA(UFortAmmoItemDefinition::StaticClass()) && !ItemDefinition->IsA(UFortResourceItemDefinition::StaticClass()) && !ItemDefinition->IsA(UFortTrapItemDefinition::StaticClass()))
		return EFortQuickBars::Primary;

	return EFortQuickBars::Secondary;
}

bool IsPrimaryQuickbar(UFortItemDefinition* Def)
{
	return Def->IsA(UFortConsumableItemDefinition::StaticClass()) || Def->IsA(UFortWeaponRangedItemDefinition::StaticClass()) || Def->IsA(UFortGadgetItemDefinition::StaticClass());
}

bool IsInventoryFull(AFortPlayerController* PC)
{
	int ItemNb = 0;
	auto InstancesPtr = &PC->WorldInventory->Inventory.ItemInstances;
	for (int i = 0; i < InstancesPtr->Num(); i++)
	{
		if (InstancesPtr->operator[](i))
		{
			if (GetQuickBars(InstancesPtr->operator[](i)->ItemEntry.ItemDefinition) == EFortQuickBars::Primary)
			{
				ItemNb++;

				if (ItemNb >= 5)
				{
					break;
				}
			}
		}
	}

	return ItemNb >= 5;
}

inline int GetMagSize(UFortWeaponItemDefinition* Def)
{
	if (!Def)
		return 0;

	UDataTable* Table = Def->WeaponStatHandle.DataTable;
	if (!Table)
		return 0;
	int Ret = 0;
	auto& RowMap = *(MTMap<FName, void*>*)(__int64(Table) + 0x30);
	for (auto& Pair : RowMap)
	{
		if (Pair.Key().ToString() == Def->WeaponStatHandle.RowName.ToString())
		{
			Ret = ((FFortRangedWeaponStats*)Pair.Value())->ClipSize;
		}
	}
	return Ret;
}

inline int GetMaxStackSize(UFortItemDefinition* Def) // doesnt work with consumables for some reason
{
	float Value = *(float*)(__int64(Def) + 0x0178);
	auto Table = Def->MaxStackSize.Curve.CurveTable;
	EEvaluateCurveTableResult Res;
	float Out;
	UDataTableFunctionLibrary::EvaluateCurveTableRow(Table, Def->MaxStackSize.Curve.RowName, 0, &Res, &Out, FString());
	if (!Table || Out <= 0)
		Out = Value;
	return Out;
}

float GetMaxStack(UFortItemDefinition* Def) //consumables
{
	if (!Def->MaxStackSize.Curve.CurveTable)
		return Def->MaxStackSize.Value;
	EEvaluateCurveTableResult Result;
	float Ret;
	((UDataTableFunctionLibrary*)UDataTableFunctionLibrary::StaticClass()->DefaultObject)->EvaluateCurveTableRow(Def->MaxStackSize.Curve.CurveTable, Def->MaxStackSize.Curve.RowName, 0, &Result, &Ret, FString());
	return Ret;
}


inline void UpdateInventory(AFortPlayerController* PC, FFortItemEntry& Entry)
{
	for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
	{
		if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == Entry.ItemGuid)
		{
			PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry = Entry;
			PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			break;
		}
	}
}

void ModifyEntry(AFortPlayerControllerAthena* PC, FFortItemEntry& Entry)
{
	for (int32 i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
	{
		if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == Entry.ItemGuid)
		{
			PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry = Entry;
			PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			break;
		}
	}
}


inline void RemoveAmo(AFortPlayerController* PC, FGuid Guid)
{
	for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Guid)
		{
			PC->WorldInventory->Inventory.ReplicatedEntries.RemoveSingle(i);
			PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			break;
		}
	}
}
void RemoveAmo(AFortPlayerController* PC, UFortItemDefinition* Def, int Count = 1)
{
	for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition == Def)
		{
			PC->WorldInventory->Inventory.ReplicatedEntries[i].Count -= Count;
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].Count <= 0)
			{
				RemoveAmo(PC, PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid);
				break;
			}
			ModifyEntry((AFortPlayerControllerAthena*)PC, PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			UpdateInventory((AFortPlayerControllerAthena*)PC, PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			break;
		}
	}
}


void UpdateLoadedAmmo(AFortPlayerController* PC, AFortWeapon* Weapon)
{
	for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Weapon->ItemEntryGuid)
		{
			PC->WorldInventory->Inventory.ReplicatedEntries[i].LoadedAmmo = Weapon->AmmoCount;
			ModifyEntry((AFortPlayerControllerAthena*)PC, PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			UpdateInventory((AFortPlayerControllerAthena*)PC, PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			break;
		}
	}
}

void UpdateLoadedAmmo(AFortPlayerController* PC, AFortWeapon* Weapon, int AmountToAdd)
{
	for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Weapon->ItemEntryGuid)
		{
			PC->WorldInventory->Inventory.ReplicatedEntries[i].LoadedAmmo += AmountToAdd;
			ModifyEntry((AFortPlayerControllerAthena*)PC, PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			UpdateInventory((AFortPlayerControllerAthena*)PC, PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			break;
		}
	}
}

inline void GiveItem(AFortPlayerController* PC, UFortItemDefinition* Def, int Count, int LoadedAmmo)
{
	UFortWorldItem* Item = Cast<UFortWorldItem>(Def->CreateTemporaryItemInstanceBP(Count, 0));
	Item->SetOwningControllerForTemporaryItem(PC);
	Item->OwnerInventory = PC->WorldInventory;
	Item->ItemEntry.LoadedAmmo = LoadedAmmo;

	PC->WorldInventory->Inventory.ReplicatedEntries.Add(Item->ItemEntry);
	PC->WorldInventory->Inventory.ItemInstances.Add(Item);
	PC->WorldInventory->Inventory.MarkItemDirty(Item->ItemEntry);
	PC->WorldInventory->HandleInventoryLocalUpdate();
}

void UpdateStack(AFortPlayerController* PC, bool Update, FFortItemEntry* EntryToUpdate = nullptr)
{
	PC->WorldInventory->bRequiresLocalUpdate = true;
	PC->WorldInventory->HandleInventoryLocalUpdate();
	PC->HandleWorldInventoryLocalUpdate();
	PC->ClientForceUpdateQuickbar(EFortQuickBars::Primary);
	PC->ClientForceUpdateQuickbar(EFortQuickBars::Secondary);

	if (Update)
	{
		/*if (EntryToUpdate->ReplicationID == -1)
		{
			EntryToUpdate->ReplicationID = ++PC->WorldInventory->Inventory.IDCounter;
			if (PC->WorldInventory->Inventory.IDCounter == -1)
				PC->WorldInventory->Inventory.IDCounter++;
		}

		EntryToUpdate->ReplicationKey++;*/
		//PC->WorldInventory->Inventory.MarkArrayDirty();
		PC->WorldInventory->Inventory.MarkItemDirty(*EntryToUpdate);
	}
	else
	{
		PC->WorldInventory->Inventory.MarkArrayDirty();
	}
}

FFortItemEntry* GiveStack(AFortPlayerControllerAthena* PC, UFortItemDefinition* Def, int Count = 1, bool GiveLoadedAmmo = false, int LoadedAmmo = 0, bool Toast = false)
{
	UFortWorldItem* Item = (UFortWorldItem*)Def->CreateTemporaryItemInstanceBP(Count, 0);

	Item->SetOwningControllerForTemporaryItem(PC);
	Item->OwnerInventory = PC->WorldInventory;
	Item->ItemEntry.ItemDefinition = Def;
	Item->ItemEntry.Count = Count;


	if (GiveLoadedAmmo)
	{
		Item->ItemEntry.LoadedAmmo = LoadedAmmo;
	}
	Item->ItemEntry.ReplicationKey++;

	PC->WorldInventory->Inventory.ReplicatedEntries.Add(Item->ItemEntry);
	PC->WorldInventory->Inventory.ItemInstances.Add(Item);

	UpdateStack(PC, false);
	return &Item->ItemEntry;
}


inline void GiveItemStack(AFortPlayerController* PC, UFortItemDefinition* Def, int Count, int LoadedAmmo)
{
	EEvaluateCurveTableResult Result;
	float OutXY = 0;
	UDataTableFunctionLibrary::EvaluateCurveTableRow(Def->MaxStackSize.Curve.CurveTable, Def->MaxStackSize.Curve.RowName, 0, &Result, &OutXY, FString());
	if (!Def->MaxStackSize.Curve.CurveTable || OutXY <= 0)
		OutXY = *(float*)(__int64(Def) + 0x0178);
	FFortItemEntry* Found = nullptr;
	for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition == Def)
		{
			Found = &PC->WorldInventory->Inventory.ReplicatedEntries[i];
			PC->WorldInventory->Inventory.ReplicatedEntries[i].Count += Count;
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].Count > OutXY)
			{
				PC->WorldInventory->Inventory.ReplicatedEntries[i].Count = OutXY;
			}
			PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			UpdateInventory(PC, PC->WorldInventory->Inventory.ReplicatedEntries[i]);
			PC->WorldInventory->HandleInventoryLocalUpdate();
			return;
		}
	}

	if (!Found)
	{
		GiveItem(PC, Def, Count, LoadedAmmo);
	}
}

inline void RemoveItem(AFortPlayerController* PC, UFortItemDefinition* Def, int Count)
{
	bool Found = false;
	FFortItemEntry* Remove = nullptr;
	for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		auto& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];
		if (Entry.ItemDefinition == Def)
		{
			Found = true;
			Entry.Count -= Count;
			if (Entry.Count <= 0)
			{
				Remove = &Entry;
				PC->WorldInventory->Inventory.ReplicatedEntries.Remove(i);
			}
			else
			{
				PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
				UpdateInventory(PC, Entry);
				PC->WorldInventory->HandleInventoryLocalUpdate();
				return;
			}
			break;
		}
	}

	for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
	{
		if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == Remove->ItemGuid)
		{
			PC->WorldInventory->Inventory.ItemInstances.Remove(i);
			break;
		}
	}

	PC->WorldInventory->Inventory.MarkArrayDirty();
	PC->WorldInventory->HandleInventoryLocalUpdate();
}

inline void RemoveItem(AFortPlayerController* PC, FGuid Guid, int Count)
{
	for (auto& Entry : PC->WorldInventory->Inventory.ReplicatedEntries)
	{
		if (Entry.ItemGuid == Guid)
		{
			RemoveItem(PC, Entry.ItemDefinition, Count);
			break;
		}
	}
}

inline FFortItemEntry* FindEntry(AFortPlayerController* PC, FGuid Guid)
{
	for (auto& Entry : PC->WorldInventory->Inventory.ReplicatedEntries)
	{
		if (Entry.ItemGuid == Guid)
		{
			return &Entry;
		}
	}
	return nullptr;
}

FFortItemEntry* FindItemEntry(AFortPlayerController* PC, UFortItemDefinition* ItemDef)
{
	if (!PC || !PC->WorldInventory || !ItemDef)
		return nullptr;
	for (int i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); ++i)
	{
		if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition == ItemDef)
		{
			return &PC->WorldInventory->Inventory.ReplicatedEntries[i];
		}
	}
	return nullptr;
}


