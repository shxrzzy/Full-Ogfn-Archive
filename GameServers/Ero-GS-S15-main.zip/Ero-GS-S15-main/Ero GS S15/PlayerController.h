#pragma once
#include "Utils.h"
#include "Inventory.h"
#include "Misc.h"
#include "Abilities.h"


using namespace std;


inline void (*GetPlayerViewPointOG)(APlayerController* PlayerController, FVector outLocation, FRotator outRotation);
inline void GetPlayerViewPoint(APlayerController* PlayerController, FVector outLocation, FRotator outRotation)
{
	if (PlayerController->GetViewTarget())
	{
		outLocation = PlayerController->GetViewTarget()->K2_GetActorLocation();
		outRotation = PlayerController->GetControlRotation();
	}
	else {
		return GetPlayerViewPointOG(PlayerController, outLocation, outRotation);
	}
}

inline void (*ServerAcknowledgePossessionOG)(APlayerController* PlayerController, APawn* Pawn);
inline void ServerAcknowledgePossession(APlayerController* PlayerController, APawn* Pawn)
{
	PlayerController->AcknowledgedPawn = Pawn;
	return ServerAcknowledgePossessionOG(PlayerController, Pawn);
}

inline void (*ServerReadyToStartMatchOG)(AFortPlayerController* PlayerController);
inline void ServerReadyToStartMatch(AFortPlayerController* PlayerController)
{
	ServerReadyToStartMatchOG(PlayerController);

	static auto AbilitySet = UObject::FindObject<UFortAbilitySet>("GAS_AthenaPlayer.GAS_AthenaPlayer");

	for (int i = 0; i < AbilitySet->GameplayAbilities.Num(); i++)
	{
		if (((AFortPlayerStateAthena*)PlayerController->PlayerState)->AbilitySystemComponent)
		{
			if (AbilitySet->GameplayAbilities[i].Get())
				GiveAbility(((AFortPlayerStateAthena*)PlayerController->PlayerState)->AbilitySystemComponent, AbilitySet->GameplayAbilities[i].Get(), nullptr);
		}
	}

	static bool bSpawnedLlamas = false;

	if (Enablellamas == true && !bSpawnedLlamas) {
		SpawnLlamas();

		bSpawnedLlamas = true;
	}
	else if (Enablellamas == false) {
		Log("llamas disabled");
	}

	auto PlayerState = Cast<AFortPlayerStateAthena>(PlayerController->PlayerState);
	auto GameState = Cast<AFortGameStateAthena>(UWorld::GetWorld()->GameState);
	if (!PlayerState)
		return;

	cout << "TINDEX " << to_string(PlayerState->TeamIndex) << endl;
	cout << "SquadId " << to_string(PlayerState->SquadId) << endl;

	PlayerState->SquadId = PlayerState->TeamIndex - 2;

	PlayerState->OnRep_SquadId();
	PlayerState->OnRep_TeamIndex(0);
	PlayerState->OnRep_PlayerTeam();
	PlayerState->OnRep_PlayerTeamPrivate();

	FGameMemberInfo Info{ -1,-1,-1 };
	Info.MemberUniqueId = PlayerState->UniqueId;
	Info.SquadId = PlayerState->SquadId;
	Info.TeamIndex = PlayerState->TeamIndex;
	GameState->GameMemberInfoArray.Members.Add(Info);
	GameState->GameMemberInfoArray.MarkItemDirty(Info);


	Log("DONE SRTSM");
}

inline void (*ServerLoadingScreenDroppedOG)(AFortPlayerController* PlayerController);
inline void ServerLoadingScreenDropped(AFortPlayerController* PlayerController)
{
	Log("SLSD");
	auto PlayerState = (AFortPlayerStateAthena*)PlayerController->PlayerState;
	if (PlayerState)
	{
		auto CharacterDef = ((AFortPlayerControllerAthena*)PlayerController)->CosmeticLoadoutPC.Character;
		if (CharacterDef)
			PlayerState->HeroType = CharacterDef->HeroDefinition;
		UFortKismetLibrary::UpdatePlayerCustomCharacterPartsVisualization(PlayerState);
	}
	auto GameMode = Cast<AFortGameModeAthena>(UWorld::GetWorld()->AuthorityGameMode);
	for (size_t i = 0; i < GameMode->StartingItems.Num(); i++)
	{
		auto& Item = GameMode->StartingItems[i];
		GiveItem(PlayerController, Item.Item, Item.Count, false);
	}
	GiveItem(PlayerController, PlayerController->CosmeticLoadoutPC.Pickaxe->WeaponDefinition, false, false);
	((AFortPlayerControllerAthena*)PlayerController)->XPComponent->bRegisteredWithQuestManager = true;
	((AFortPlayerControllerAthena*)PlayerController)->XPComponent->OnRep_bRegisteredWithQuestManager();

	Log("DONE SLSD");
	return ServerLoadingScreenDroppedOG(PlayerController);
}



inline void ServerAttemptAircraftJump(UFortControllerComponent_Aircraft* Comp, FRotator ROt)
{
	auto PC = (AFortPlayerControllerAthena*)Comp->GetOwner();

	if (PC && PC->WorldInventory)
	{
		for (int i = PC->WorldInventory->Inventory.ReplicatedEntries.Num() - 1; i >= 0; i--)
		{
			if (((UFortWorldItemDefinition*)PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition)->bCanBeDropped)
			{
				int Count = PC->WorldInventory->Inventory.ReplicatedEntries[i].Count;
				RemoveItem(PC, PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid, Count);
			}
		}
	}

	GetWorld()->AuthorityGameMode->RestartPlayer(PC);

	if (PC->MyFortPawn)
		((AFortPlayerPawnAthena*)PC->MyFortPawn)->BeginSkydiving(true);
}

inline void ServerExecuteInventoryItem(AFortPlayerController* PC, FGuid Guid)
{
	if (!PC || !PC->MyFortPawn || PC->IsInAircraft())
		return;
	for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Guid)
		{
			UFortWeaponItemDefinition* WeaponDef = Cast<UFortWeaponItemDefinition>(PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition);
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition->IsA(UFortGadgetItemDefinition::StaticClass()))
			{
				WeaponDef = Cast<UFortGadgetItemDefinition>(WeaponDef)->GetWeaponItemDefinition();
			}
			if (!WeaponDef)
				return;
			PC->MyFortPawn->EquipWeaponDefinition(WeaponDef, Guid, PC->WorldInventory->Inventory.ReplicatedEntries[i].TrackerGuid);
			break;
		}
	}
}

inline void ServerCheat(AFortPlayerController* PC, FString msg)
{
	string MsgStr = msg.ToString();
	if (MsgStr == "StartAircraft")
	{
		UKismetSystemLibrary::ExecuteConsoleCommand(UWorld::GetWorld(), TEXT("startaircraft"), nullptr);
	}
}

inline void ServerCreateBuildingActor(AFortPlayerControllerAthena* PC, FCreateBuildingActorData CreateBuildingData)
{
	if (!PC || PC->IsInAircraft())
		return;

	UClass* BuildingClass = PC->BroadcastRemoteClientInfo->RemoteBuildableClass.Get();
	char a7;
	TArray<AActor*> BuildingsToRemove;
	if (!CantBuild(UWorld::GetWorld(), BuildingClass, CreateBuildingData.BuildLoc, CreateBuildingData.BuildRot, CreateBuildingData.bMirrored, &BuildingsToRemove, &a7))
	{
		auto ResDef = UFortKismetLibrary::GetDefaultObj()->K2_GetResourceItemDefinition(((ABuildingSMActor*)BuildingClass->DefaultObject)->ResourceType);
		RemoveItem(PC, ResDef, 10);

		ABuildingSMActor* NewBuilding = SpawnActor<ABuildingSMActor>(CreateBuildingData.BuildLoc, CreateBuildingData.BuildRot, PC, BuildingClass);

		NewBuilding->bPlayerPlaced = true;
		NewBuilding->InitializeKismetSpawnedBuildingActor(NewBuilding, PC, true);
		NewBuilding->TeamIndex = ((AFortPlayerStateAthena*)PC->PlayerState)->TeamIndex;
		NewBuilding->Team = EFortTeam(NewBuilding->TeamIndex);

		for (size_t i = 0; i < BuildingsToRemove.Num(); i++)
		{
			BuildingsToRemove[i]->K2_DestroyActor();
		}
		UKismetArrayLibrary::Array_Clear((TArray<int32>&)BuildingsToRemove);
		//BuildingsToRemove.FreeArray();
	}
}

inline __int64 (*OnDamageServerOG)(ABuildingSMActor* Actor, float Damage, FGameplayTagContainer DamageTags, FVector Momentum, FHitResult HitInfo, AFortPlayerControllerAthena* InstigatedBy, AActor* DamageCauser, FGameplayEffectContextHandle EffectContext);
inline __int64 OnDamageServer(ABuildingSMActor* Actor, float Damage, FGameplayTagContainer DamageTags, FVector Momentum, FHitResult HitInfo, AFortPlayerControllerAthena* InstigatedBy, AActor* DamageCauser, FGameplayEffectContextHandle EffectContext)
{
	if (!Actor || !InstigatedBy || !InstigatedBy->IsA(AFortPlayerControllerAthena::StaticClass()) || !DamageCauser->IsA(AFortWeapon::StaticClass()) || !((AFortWeapon*)DamageCauser)->WeaponData->IsA(UFortWeaponMeleeItemDefinition::StaticClass()) || Actor->bPlayerPlaced)
		return OnDamageServerOG(Actor, Damage, DamageTags, Momentum, HitInfo, InstigatedBy, DamageCauser, EffectContext);

	auto Def = UFortKismetLibrary::K2_GetResourceItemDefinition(Actor->ResourceType);

	if (Def)
	{
		auto& BuildingResourceAmountOverride = Actor->BuildingResourceAmountOverride;
		auto GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;

		FString CurveTableAssetPath = UKismetStringLibrary::Conv_NameToString(GameState->CurrentPlaylistInfo.BasePlaylist->ResourceRates.ObjectID.AssetPathName);
		static auto CurveTable = StaticLoadObject<UCurveTable>(CurveTableAssetPath.ToString());
		if (!CurveTable)
			CurveTable = StaticLoadObject<UCurveTable>("/Game/Athena/Balance/DataTables/AthenaResourceRates.AthenaResourceRates");

		float Average = 1;
		EEvaluateCurveTableResult OutCurveTable;
		UDataTableFunctionLibrary::EvaluateCurveTableRow(CurveTable, BuildingResourceAmountOverride.RowName, 0.f, &OutCurveTable, &Average, FString());
		float FinalResourceCount = round(Average / (Actor->GetMaxHealth() / Damage));

		if (FinalResourceCount > 0)
		{
			InstigatedBy->ClientReportDamagedResourceBuilding(Actor, Actor->ResourceType, FinalResourceCount, false, Damage == 100.f);
			GiveItemStack(InstigatedBy, Def, FinalResourceCount, 0);
		}
	}

	return OnDamageServerOG(Actor, Damage, DamageTags, Momentum, HitInfo, InstigatedBy, DamageCauser, EffectContext);
}

inline void ServerBeginEditingBuildingActor(AFortPlayerControllerAthena* PC, ABuildingSMActor* BuildingActorToEdit)
{
	if (!BuildingActorToEdit || !BuildingActorToEdit->bPlayerPlaced || !PC->MyFortPawn)
		return;

	AFortPlayerStateAthena* PlayerState = (AFortPlayerStateAthena*)PC->PlayerState;
	BuildingActorToEdit->SetNetDormancy(ENetDormancy::DORM_Awake);
	BuildingActorToEdit->EditingPlayer = PlayerState;
	for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
	{
		auto Item = PC->WorldInventory->Inventory.ItemInstances[i];
		if (Item->GetItemDefinitionBP()->IsA(UFortEditToolItemDefinition::StaticClass()))
		{
			PC->MyFortPawn->EquipWeaponDefinition((UFortWeaponItemDefinition*)Item->GetItemDefinitionBP(), Item->GetItemGuid(), Item->GetTrackerGuid());
			break;
		}
	}
	if (!PC->MyFortPawn->CurrentWeapon || !PC->MyFortPawn->CurrentWeapon->WeaponData || !PC->MyFortPawn->CurrentWeapon->IsA(AFortWeap_EditingTool::StaticClass()))
		return;

	AFortWeap_EditingTool* EditTool = (AFortWeap_EditingTool*)PC->MyFortPawn->CurrentWeapon;
	EditTool->EditActor = BuildingActorToEdit;
	EditTool->OnRep_EditActor();
}

inline void ServerEndEditingBuildingActor(AFortPlayerControllerAthena* PC, ABuildingSMActor* BuildingActorToEdit)
{
	if (!BuildingActorToEdit || !PC->MyFortPawn || BuildingActorToEdit->bDestroyed == 1 || BuildingActorToEdit->EditingPlayer != PC->PlayerState)
		return;
	BuildingActorToEdit->SetNetDormancy(ENetDormancy::DORM_DormantAll);
	BuildingActorToEdit->EditingPlayer = nullptr;
	for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
	{
		auto Item = PC->WorldInventory->Inventory.ItemInstances[i];
		if (Item->GetItemDefinitionBP()->IsA(UFortEditToolItemDefinition::StaticClass()))
		{
			PC->MyFortPawn->EquipWeaponDefinition((UFortWeaponItemDefinition*)Item->GetItemDefinitionBP(), Item->GetItemGuid(), Item->GetTrackerGuid());
			break;
		}
	}
	if (!PC->MyFortPawn->CurrentWeapon || !PC->MyFortPawn->CurrentWeapon->WeaponData || !PC->MyFortPawn->CurrentWeapon->IsA(AFortWeap_EditingTool::StaticClass()))
		return;

	AFortWeap_EditingTool* EditTool = (AFortWeap_EditingTool*)PC->MyFortPawn->CurrentWeapon;
	EditTool->EditActor = nullptr;
	EditTool->OnRep_EditActor();
}

inline void ServerEditBuildingActor(AFortPlayerControllerAthena* PC, ABuildingSMActor* BuildingActorToEdit, TSubclassOf<ABuildingSMActor> NewBuildingClass, uint8 RotationIterations, bool bMirrored)
{
	if (!BuildingActorToEdit || BuildingActorToEdit->EditingPlayer != PC->PlayerState || !NewBuildingClass.Get() || BuildingActorToEdit->bDestroyed == 1)
		return;

	BuildingActorToEdit->SetNetDormancy(ENetDormancy::DORM_DormantAll);
	BuildingActorToEdit->EditingPlayer = nullptr;
	ABuildingSMActor* NewActor = ReplaceBuildingActor(BuildingActorToEdit, 1, NewBuildingClass.Get(), 0, RotationIterations, bMirrored, PC);
	if (NewActor)
		NewActor->bPlayerPlaced = true;
}

void (*ClientOnPawnDiedOG)(AFortPlayerControllerZone* a1, FFortPlayerDeathReport a2);
void ClientOnPawnDied(AFortPlayerControllerAthena* DeadPC, FFortPlayerDeathReport& DeathReport)
{
	auto DeadPawn = (AFortPlayerPawnAthena*)DeadPC->Pawn;
	auto DeadPlayerState = (AFortPlayerStateAthena*)DeadPC->PlayerState;
	auto KillerPlayerState = (AFortPlayerStateAthena*)DeathReport.KillerPlayerState;
	auto KillerPawn = (AFortPlayerPawnAthena*)DeathReport.KillerPawn;
	AFortPlayerStateAthena* KillerState = (AFortPlayerStateAthena*)DeathReport.KillerPlayerState;

	if (!DeadPawn || !DeadPlayerState)
		return ClientOnPawnDiedOG(DeadPC, DeathReport);

	EDeathCause DeathCause = DeadPlayerState->ToDeathCause(DeathReport.Tags, DeadPawn->bIsDBNO);
	FDeathInfo& DeathInfo = DeadPlayerState->DeathInfo;
	DeathInfo.bInitialized = true;
	DeathInfo.bDBNO = DeadPawn->bIsDBNO;
	DeathInfo.DeathCause = DeathCause;
	DeathInfo.FinisherOrDowner = KillerPlayerState ? KillerPlayerState : DeadPlayerState;
	DeathInfo.Distance = DeathCause == EDeathCause::FallDamage ? DeadPawn->LastFallDistance : DeadPawn->GetDistanceTo(KillerPawn);
	DeathInfo.DeathLocation = DeadPawn ? DeadPawn->K2_GetActorLocation() : FVector{};

	DeadPlayerState->PawnDeathLocation = DeathInfo.DeathLocation;
	DeadPlayerState->OnRep_DeathInfo();

	if (KillerPlayerState && KillerPlayerState != DeadPlayerState)
	{
		KillerPlayerState->KillScore++;
		KillerPlayerState->TeamKillScore++;
		KillerPlayerState->ClientReportKill(DeadPlayerState);
		KillerPlayerState->OnRep_Kills();
		KillerPlayerState->OnRep_TeamScore();

		KillerPlayerState->Score++;
		KillerPlayerState->TeamScore++;
		KillerPlayerState->OnRep_Score();

	}

	if (!GetGameState()->IsRespawningAllowed(DeadPlayerState))
	{
		if (!DeadPawn->IsDBNO())
		{
			if (DeadPC->WorldInventory)
			{
				for (int i = 0; i < DeadPC->WorldInventory->Inventory.ItemInstances.Num(); i++)
				{
					if (DeadPC->WorldInventory->Inventory.ItemInstances[i]->CanBeDropped())
					{
						SpawnPickup(DeadPC->Pawn->K2_GetActorLocation(), DeadPC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemDefinition, EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::PlayerElimination, DeadPC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.Count, DeadPC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.LoadedAmmo);
						
					}
				}
			}

			FAthenaRewardResult Result;

			if (KillerState)
			{
				Log("Called2");
				AFortPlayerControllerAthena* KillerPC = (AFortPlayerControllerAthena*)KillerState->GetOwner();
				KillerPC->ClientSendEndBattleRoyaleMatchForPlayer(true, Result);
			}

			if (DeadPC)
			{
				Log("Called1");
				DeadPC->ClientSendEndBattleRoyaleMatchForPlayer(true, Result);
			}

			UFortItemDefinition* WeaponDef = nullptr;
			auto DamageCauser = DeathReport.DamageCauser;
			if (DamageCauser)
			{
				if (auto WEAPON = Cast<AFortWeapon>(DamageCauser))
				{
					WeaponDef = WEAPON->WeaponData;
				}
			}

			DeadPC->ClientSendEndBattleRoyaleMatchForPlayer(true, Result);
			RemoveFromAlivePlayerOG(GetGameMode(), DeadPC, KillerPlayerState == DeadPlayerState ? nullptr : KillerPlayerState, KillerPawn, WeaponDef, DeathInfo.DeathCause, 0);
		}
	}

	return ClientOnPawnDiedOG(DeadPC, DeathReport);
}


inline void (*ServerHandlePickupOG)(AFortPlayerPawn* Pawn, AFortPickup* Pickup, float InFlyTime, FVector InStartDirection, bool bPlayPickupSound);
inline void ServerHandlePickup(AFortPlayerPawnAthena* Pawn, AFortPickup* Pickup, float InFlyTime, const FVector& InStartDirection, bool bPlayPickupSound)
{
	if (!Pickup || !Pawn || !Pawn->Controller || Pickup->bPickedUp)
		return;

	AFortPlayerControllerAthena* PC = (AFortPlayerControllerAthena*)Pawn->Controller;

	UFortItemDefinition* Def = Pickup->PrimaryPickupItemEntry.ItemDefinition;
	FFortItemEntry* FoundEntry = nullptr;
	FFortItemEntry& PickupEntry = Pickup->PrimaryPickupItemEntry;
	float MaxStackSize = GetMaxStack(Def);
	bool Stackable = Def->IsStackable();
	UFortItemDefinition* PickupItemDef = PickupEntry.ItemDefinition;
	bool Found = false;
	FFortItemEntry* GaveEntry = nullptr;

	if (IsInventoryFull(PC))
	{
		if (Pickup->PrimaryPickupItemEntry.ItemDefinition->IsA(UFortAmmoItemDefinition::StaticClass()) || Pickup->PrimaryPickupItemEntry.ItemDefinition->IsA(UFortResourceItemDefinition::StaticClass()))
		{
			GiveItemStack(PC, Pickup->PrimaryPickupItemEntry.ItemDefinition, Pickup->PrimaryPickupItemEntry.Count, Pickup->PrimaryPickupItemEntry.LoadedAmmo);

			Pickup->PickupLocationData.bPlayPickupSound = true;
			Pickup->PickupLocationData.FlyTime = 0.3f;
			Pickup->PickupLocationData.ItemOwner = Pawn;
			Pickup->PickupLocationData.PickupGuid = Pickup->PrimaryPickupItemEntry.ItemGuid;
			Pickup->PickupLocationData.PickupTarget = Pawn;
			Pickup->OnRep_PickupLocationData();

			Pickup->bPickedUp = true;
			Pickup->OnRep_bPickedUp();
			return;
		}

		if (!Pawn->CurrentWeapon->WeaponData->IsA(UFortWeaponMeleeItemDefinition::StaticClass()))
		{
			if (Stackable)
			{
				for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
				{
					FFortItemEntry& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

					if (Entry.ItemDefinition == PickupItemDef)
					{
						Found = true;
						if ((MaxStackSize - Entry.Count) > 0)
						{
							Entry.Count += PickupEntry.Count;

							if (Entry.Count > MaxStackSize)
							{
								SpawnStack((APlayerPawn_Athena_C*)PC->Pawn, PickupItemDef, Entry.Count - MaxStackSize);
								Entry.Count = MaxStackSize;
							}

							PC->WorldInventory->Inventory.MarkItemDirty(Entry);
						}
						else
						{
							if (IsPrimaryQuickbar(PickupItemDef))
							{
								GaveEntry = GiveStack(PC, PickupItemDef, PickupEntry.Count);
							}
						}
						break;
					}
				}
				if (!Found)
				{
					for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
					{
						if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Pawn->CurrentWeapon->GetInventoryGUID())
						{
							PC->ServerAttemptInventoryDrop(Pawn->CurrentWeapon->GetInventoryGUID(), PC->WorldInventory->Inventory.ReplicatedEntries[i].Count, false);
							break;
						}
					}
					GaveEntry = GiveStack(PC, PickupItemDef, PickupEntry.Count, false, 0, true);
				}

				Pickup->PickupLocationData.bPlayPickupSound = true;
				Pickup->PickupLocationData.FlyTime = 0.3f;
				Pickup->PickupLocationData.ItemOwner = Pawn;
				Pickup->PickupLocationData.PickupGuid = Pickup->PrimaryPickupItemEntry.ItemGuid;
				Pickup->PickupLocationData.PickupTarget = Pawn;
				Pickup->OnRep_PickupLocationData();

				Pickup->bPickedUp = true;
				Pickup->OnRep_bPickedUp();
				return;
			}

			for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
			{
				if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Pawn->CurrentWeapon->GetInventoryGUID())
				{
					PC->ServerAttemptInventoryDrop(Pawn->CurrentWeapon->GetInventoryGUID(), PC->WorldInventory->Inventory.ReplicatedEntries[i].Count, false);
					break;
				}
			}
		}
	}

	if (!IsInventoryFull(PC))
	{
		if (Stackable && !Pickup->PrimaryPickupItemEntry.ItemDefinition->IsA(UFortAmmoItemDefinition::StaticClass()) ||Stackable && !Pickup->PrimaryPickupItemEntry.ItemDefinition->IsA(UFortResourceItemDefinition::StaticClass()))
		{
			for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
			{
				FFortItemEntry& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

				if (Entry.ItemDefinition == PickupItemDef)
				{
					Found = true;
					if ((MaxStackSize - Entry.Count) > 0)
					{
						Entry.Count += PickupEntry.Count;

						if (Entry.Count > MaxStackSize)
						{
							SpawnStack((APlayerPawn_Athena_C*)PC->Pawn, PickupItemDef, Entry.Count - MaxStackSize);
							Entry.Count = MaxStackSize;
						}

						PC->WorldInventory->Inventory.MarkItemDirty(Entry);
					}
					else
					{
						if (IsPrimaryQuickbar(PickupItemDef))
						{
							GaveEntry = GiveStack(PC, PickupItemDef, PickupEntry.Count);
						}
					}
					break;
				}
			}
			if (!Found)
			{
				GaveEntry = GiveStack(PC, PickupItemDef, PickupEntry.Count, false, 0, true);
			}

			Pickup->PickupLocationData.bPlayPickupSound = true;
			Pickup->PickupLocationData.FlyTime = 0.3f;
			Pickup->PickupLocationData.ItemOwner = Pawn;
			Pickup->PickupLocationData.PickupGuid = Pickup->PrimaryPickupItemEntry.ItemGuid;
			Pickup->PickupLocationData.PickupTarget = Pawn;
			Pickup->OnRep_PickupLocationData();

			Pickup->bPickedUp = true;
			Pickup->OnRep_bPickedUp();
			return;
		}
		
		if (Pickup->PrimaryPickupItemEntry.ItemDefinition->IsA(UFortAmmoItemDefinition::StaticClass()) || Pickup->PrimaryPickupItemEntry.ItemDefinition->IsA(UFortResourceItemDefinition::StaticClass()))
		{
			GiveItemStack(PC, Pickup->PrimaryPickupItemEntry.ItemDefinition, Pickup->PrimaryPickupItemEntry.Count, Pickup->PrimaryPickupItemEntry.LoadedAmmo);
		}
		else {
			GiveItem(PC, Pickup->PrimaryPickupItemEntry.ItemDefinition, Pickup->PrimaryPickupItemEntry.Count, Pickup->PrimaryPickupItemEntry.LoadedAmmo);
		}
	}

	Pickup->PickupLocationData.bPlayPickupSound = true;
	Pickup->PickupLocationData.FlyTime = 0.3f;
	Pickup->PickupLocationData.ItemOwner = Pawn;
	Pickup->PickupLocationData.PickupGuid = Pickup->PrimaryPickupItemEntry.ItemGuid;
	Pickup->PickupLocationData.PickupTarget = Pawn;
	Pickup->OnRep_PickupLocationData();

	Pickup->bPickedUp = true;
	Pickup->OnRep_bPickedUp();
}

__int64 (*OnReloadOG)(AFortWeapon* Weapon, int RemoveCount);
__int64 OnReload(AFortWeapon* Weapon, int RemoveCount)
{
	auto Ret = OnReloadOG(Weapon, RemoveCount);
	auto WeaponDef = Weapon->WeaponData;
	if (!WeaponDef)
		return Ret;

	auto AmmoDef = WeaponDef->GetAmmoWorldItemDefinition_BP();
	if (!AmmoDef)
		return Ret;

	AFortPlayerPawnAthena* Pawn = (AFortPlayerPawnAthena*)Weapon->GetOwner();
	AFortPlayerControllerAthena* PC = (AFortPlayerControllerAthena*)Pawn->Controller;
	if (!PC || !PC->Pawn || !PC->IsA(AFortPlayerControllerAthena::StaticClass()) || &PC->WorldInventory->Inventory == nullptr || GetGameState()->GamePhase >= EAthenaGamePhase::EndGame)
		return Ret;

	if (PC->bInfiniteAmmo) {
		UpdateLoadedAmmo(PC, Weapon, RemoveCount);
		return Ret;
	}

	int AmmoCount = 0;
	FFortItemEntry* FoundEntry = nullptr;
	for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		FFortItemEntry& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

		if (Entry.ItemDefinition == AmmoDef) {
			AmmoCount = Entry.Count;
			FoundEntry = &Entry;
			break;
		}
	}

	int AmmoToRemove = (RemoveCount < AmmoCount) ? RemoveCount : AmmoCount;

	if (AmmoToRemove > 0) {
		RemoveAmo(PC, AmmoDef, AmmoToRemove);
		UpdateLoadedAmmo(PC, Weapon, AmmoToRemove);
	}

	PC->WorldInventory->bRequiresLocalUpdate = true;
	//PC->WorldInventory->Inventory.MarkItemDirty();
	PC->WorldInventory->HandleInventoryLocalUpdate();

	return Ret;
}

inline void (*DestroyPickupOG)(AFortPickup*);
inline void DestroyPickup(AFortPickup* Pickup)
{
	if (!Pickup->PickupLocationData.PickupTarget)
		return DestroyPickupOG(Pickup);
	AFortPlayerControllerAthena* PC = (AFortPlayerControllerAthena*)Pickup->PickupLocationData.PickupTarget->Controller;
	if (!PC || PC->IsA(AFortAthenaAIBotController::StaticClass()))
		return DestroyPickupOG(Pickup);
	FFortItemEntry& PickupEntry = Pickup->PrimaryPickupItemEntry;
	bool Found = false;

	if (PickupEntry.ItemDefinition->IsStackable())
	{
		for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			auto& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];
			if (Entry.ItemDefinition == PickupEntry.ItemDefinition && Entry.Count < GetMaxStackSize((UFortWeaponItemDefinition*)Entry.ItemDefinition))
			{
				Found = true;
				Entry.Count += PickupEntry.Count;
				UpdateInventory(PC, Entry);

				PC->WorldInventory->Inventory.MarkItemDirty(Entry);
				PC->WorldInventory->bRequiresLocalUpdate = true;
				PC->WorldInventory->HandleInventoryLocalUpdate();
				if (Entry.Count > GetMaxStackSize((UFortWeaponItemDefinition*)Entry.ItemDefinition))
				{
					if (Entry.ItemDefinition->bAllowMultipleStacks)
					{
						GiveItem(PC, Entry.ItemDefinition, Entry.Count - GetMaxStackSize((UFortWeaponItemDefinition*)Entry.ItemDefinition), 0);
					}
					else
					{
						SpawnPickup(PC->Pawn->K2_GetActorLocation(), Entry.ItemDefinition, EFortPickupSourceTypeFlag::Tossed, EFortPickupSpawnSource::Unset, Entry.Count - GetMaxStackSize((UFortWeaponItemDefinition*)Entry.ItemDefinition), 0);
					}
					Entry.Count = GetMaxStackSize((UFortWeaponItemDefinition*)Entry.ItemDefinition);
					UpdateInventory(PC, Entry);
					PC->WorldInventory->Inventory.MarkItemDirty(Entry);
					PC->WorldInventory->HandleInventoryLocalUpdate();
					break;
				}
			}
		}
		if (!Found)
		{
			GiveItem(PC, PickupEntry.ItemDefinition, PickupEntry.Count, PickupEntry.LoadedAmmo);
		}
	}
	else
	{
		GiveItem(PC, PickupEntry.ItemDefinition, PickupEntry.Count, PickupEntry.LoadedAmmo);
	}

	return DestroyPickupOG(Pickup);
}

inline void (*NetMulticastDamageCuesOG)(AFortPlayerPawnAthena* Pawn, FAthenaBatchedDamageGameplayCues_Shared SharedData, FAthenaBatchedDamageGameplayCues_NonShared NonSharedData);
inline void NetMulticastDamageCues(AFortPlayerPawnAthena* Pawn, FAthenaBatchedDamageGameplayCues_Shared SharedData, FAthenaBatchedDamageGameplayCues_NonShared NonSharedData)
{
	cout << SharedData.Magnitude << endl;
	cout << SharedData.NonPlayerMagnitude << endl;
	cout << SharedData.bIsShield << endl;
	cout << SharedData.bIsShieldApplied << endl;
	cout << SharedData.bIsShieldDestroyed << endl;

	if (Pawn && Pawn->CurrentWeapon)
	{
		AFortPlayerControllerAthena* PC = Cast<AFortPlayerControllerAthena>(Pawn->Controller);
		if (PC)
		{
			for (auto& Entry : PC->WorldInventory->Inventory.ReplicatedEntries)
			{
				if (Entry.ItemGuid == Pawn->CurrentWeapon->GetInventoryGUID())
				{
					Entry.LoadedAmmo = Pawn->CurrentWeapon->AmmoCount;
					PC->WorldInventory->Inventory.MarkItemDirty(Entry);
					UpdateInventory(PC, Entry);
					PC->WorldInventory->HandleInventoryLocalUpdate();
					break;
				}
			}
		}
	}
	return NetMulticastDamageCuesOG(Pawn, SharedData, NonSharedData);
}

inline void (*ServerAttemptInteractOG)(UFortControllerComponent_Interaction* Comp, AActor* ReceivingActor, UPrimitiveComponent* InteractComponent, ETInteractionType InteractType, UObject* OptionalData, EInteractionBeingAttempted InteractionBeingAttempted);
inline void ServerAttemptInteractHook(UFortControllerComponent_Interaction* Comp, AActor* ReceivingActor, UPrimitiveComponent* InteractComponent, ETInteractionType InteractType, UObject* OptionalData, EInteractionBeingAttempted InteractionBeingAttempted)
{
	ServerAttemptInteractOG(Comp, ReceivingActor, InteractComponent, InteractType, OptionalData, InteractionBeingAttempted);

	std::cout << "ReceivingActor: " << ReceivingActor->GetFullName() << '\n';

	if (ReceivingActor->IsA(AFortAthenaSupplyDrop::StaticClass()))
	{
		if (ReceivingActor->GetName().starts_with("AthenaSupplyDrop_Llama_C_"))
		{

			SpawnllamaLoot((ABuildingContainer*)ReceivingActor);
		}
		else
		{
			SpawnSupplyLoot((ABuildingContainer*)ReceivingActor);
		}
	}
}

inline void ServerAttemptInventoryDrop(AFortPlayerControllerAthena* PC, FGuid ItemGuid, int Count, bool bTrash)
{
	FFortItemEntry* Entry = FindEntry(PC, ItemGuid);
	SpawnPickup(PC->Pawn->K2_GetActorLocation(), Entry->ItemDefinition, EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::Unset, Count, Entry->LoadedAmmo);
	RemoveItem(PC, ItemGuid, Count);
}