#pragma once
#include "Misc.h"
#include "UE.h"
#include "Utils.h"

inline void (*HandleNewSafeZonePhaseOG)(AFortGameModeAthena* GameMode, int32 ZoneIndex);
inline void HandleNewSafeZonePhase(AFortGameModeAthena* GameMode, int32 ZoneIndex)
{
	auto GameStateAsFort = (AFortGameStateAthena*)GameMode->GameState;

	if (!GameStateAsFort)
		return HandleNewSafeZonePhaseOG(GameMode, ZoneIndex);

	auto MapInfo = GameStateAsFort->MapInfo;
	if (!MapInfo)
		return HandleNewSafeZonePhaseOG(GameMode, ZoneIndex);

	static bool bHasBeenSetup = false;
	auto& WaitTimes = MapInfo->SafeZoneDefinition.WaitTimes();
	auto& Durations = MapInfo->SafeZoneDefinition.Durations();
	if (!bHasBeenSetup)
	{
		bHasBeenSetup = true;

		static auto GameData = StaticLoadObject<UCurveTable>(UKismetStringLibrary::Conv_NameToString(GameStateAsFort->CurrentPlaylistInfo.BasePlaylist->GameData.ObjectID.AssetPathName).ToString());
		if (!GameData)
			GameData = UObject::FindObject<UCurveTable>("AthenaGameData.AthenaGameData");
		static auto ShrinkTime_NAME = UKismetStringLibrary::Conv_StringToName(L"Default.SafeZone.ShrinkTime");
		static auto WaitTime_NAME = UKismetStringLibrary::Conv_StringToName(L"Default.SafeZone.WaitTime");

		for (size_t i = 0; i < WaitTimes.Num(); i++)
		{
			float Out;
			EEvaluateCurveTableResult Res;
			UDataTableFunctionLibrary::EvaluateCurveTableRow(GameData, WaitTime_NAME, i, &Res, &Out, FString());
			WaitTimes[i] = Out;
		}
		for (size_t i = 0; i < Durations.Num(); i++)
		{
			float Out;
			EEvaluateCurveTableResult Res;
			UDataTableFunctionLibrary::EvaluateCurveTableRow(GameData, ShrinkTime_NAME, i, &Res, &Out, FString());
			Durations[i] = Out;
		}
	}

	HandleNewSafeZonePhaseOG(GameMode, ZoneIndex);
	GameMode->SafeZoneIndicator->SafeZoneStartShrinkTime = UGameplayStatics::GetTimeSeconds(UWorld::GetWorld()) + WaitTimes[GameMode->SafeZonePhase];
	GameMode->SafeZoneIndicator->SafeZoneFinishShrinkTime = GameMode->SafeZoneIndicator->SafeZoneStartShrinkTime + Durations[GameMode->SafeZonePhase];
}

inline bool (*ReadyToStartMatchOriginal)(AFortGameModeAthena* GameMode);
inline bool ReadyToStartMatch(AFortGameModeAthena* GameMode)
{
	bool Ret = ReadyToStartMatchOriginal(GameMode);
	auto GameState = Cast<AFortGameStateAthena>(GameMode->GameState);

	if (!GameState)
		return false;

	if (!GameState->CurrentPlaylistInfo.BasePlaylist)
	{

		auto Playlist = UObject::FindObject<UFortPlaylistAthena>("Playlist_DefaultSolo.Playlist_DefaultSolo");
		if (Playlist)
		{
			GameState->CurrentPlaylistInfo.BasePlaylist = Playlist;
			GameState->CurrentPlaylistInfo.OverridePlaylist = Playlist;
			GameState->CurrentPlaylistInfo.PlaylistReplicationKey++;
			GameState->CurrentPlaylistId = Playlist->PlaylistId;
			GameState->CurrentPlaylistInfo.MarkArrayDirty();
		}

		for (int i = 0; i < GameState->CurrentPlaylistInfo.BasePlaylist->AdditionalLevels.Num(); i++)
		{
			FVector Loc{};
			FRotator Rot{};
			bool bSuccess = false;
			((ULevelStreamingDynamic*)ULevelStreamingDynamic::StaticClass()->DefaultObject)->LoadLevelInstanceBySoftObjectPtr(UWorld::GetWorld(), GameState->CurrentPlaylistInfo.BasePlaylist->AdditionalLevels[i], Loc, Rot, &bSuccess, FString());
			FAdditionalLevelStreamed NewLevel{};
			NewLevel.LevelName = GameState->CurrentPlaylistInfo.BasePlaylist->AdditionalLevels[i].ObjectID.AssetPathName;
			NewLevel.bIsServerOnly = false;
			GameState->AdditionalPlaylistLevelsStreamed.Add(NewLevel);
		}

		for (int i = 0; i < GameState->CurrentPlaylistInfo.BasePlaylist->AdditionalLevelsServerOnly.Num(); i++)
		{
			FVector Loc{};
			FRotator Rot{};
			bool bSuccess = false;
			((ULevelStreamingDynamic*)ULevelStreamingDynamic::StaticClass()->DefaultObject)->LoadLevelInstanceBySoftObjectPtr(UWorld::GetWorld(), GameState->CurrentPlaylistInfo.BasePlaylist->AdditionalLevelsServerOnly[i], Loc, Rot, &bSuccess, FString());
			FAdditionalLevelStreamed NewLevel{};
			NewLevel.LevelName = GameState->CurrentPlaylistInfo.BasePlaylist->AdditionalLevelsServerOnly[i].ObjectID.AssetPathName;
			NewLevel.bIsServerOnly = true;
			GameState->AdditionalPlaylistLevelsStreamed.Add(NewLevel);
		}

		GameState->OnRep_AdditionalPlaylistLevelsStreamed();

		GameMode->ServerBotManager = (UFortServerBotManagerAthena*)((UGameplayStatics*)UGameplayStatics::StaticClass()->DefaultObject)->SpawnObject(UFortServerBotManagerAthena::StaticClass(), GameMode);
		GameMode->ServerBotManager->CachedGameMode = GameMode;
		GameMode->ServerBotManager->CachedGameState = GameState;
		GameMode->ServerBotManager->CachedAIPopulationTracker = ((UAthenaAISystem*)UWorld::GetWorld()->AISystem)->AIPopulationTracker;

		FTransform Transform{};
		Transform.Scale3D = FVector{ 1,1,1 };
		GameMode->AIDirector = SpawnActor<AAthenaAIDirector>({});
		GameMode->AIDirector->Activate();

		((UAthenaAISystem*)UWorld::GetWorld()->AISystem)->PlayerBotManager = GameMode->ServerBotManager;
	}

	if (!GameState->MapInfo)
		return Ret;

	float TimeSeconds = GetStatics()->GetTimeSeconds(GetWorld());


	GetGameState()->WarmupCountdownEndTime = TimeSeconds + Duration;
	GameMode->WarmupCountdownDuration = Duration;
	GetGameState()->WarmupCountdownStartTime = TimeSeconds;
	GameMode->WarmupEarlyCountdownDuration = Duration;


	if (!UWorld::GetWorld()->NetDriver)
	{

		GameMode->GameSession->MaxPlayers = 100;
		auto Playlist = GameState->CurrentPlaylistInfo.BasePlaylist;

		TArray<AActor*> Spawners;
		UGameplayStatics::GetAllActorsOfClass(UWorld::GetWorld(), AFortAthenaVehicleSpawner::StaticClass(), &Spawners);
		for (size_t i = 0; i < Spawners.Num(); i++)
		{
			AFortAthenaVehicleSpawner* Spawner = Cast<AFortAthenaVehicleSpawner>(Spawners[i]);
			if (!Spawner)
				continue;
			AActor* Vehicle = UGameplayStatics::FinishSpawningActor(UGameplayStatics::BeginDeferredActorSpawnFromClass(UWorld::GetWorld(), Spawner->GetVehicleClass(), (FTransform&)Spawner->GetTransform(), ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn, nullptr), (FTransform&)Spawner->GetTransform());
			UFortAthenaVehicleFuelComponent* TestComp = Cast<UFortAthenaVehicleFuelComponent>(Vehicle->GetComponentByClass(UFortAthenaVehicleFuelComponent::StaticClass()));
			if (TestComp)
			{
				TestComp->ServerFuel = 100;
				TestComp->OnRep_ServerFuel(0);
			}
			SwapVFTs(Vehicle, 0xF0, ServerMove);
		}
		UKismetArrayLibrary::Array_Clear((TArray<int32>&)Spawners);

		FName NetDriverName = UKismetStringLibrary::Conv_StringToName(TEXT("GameNetDriver"));
		UNetDriver* NetDriver = CreateNetDriver(UEngine::GetEngine(), UWorld::GetWorld(), NetDriverName);

		NetDriver->World = UWorld::GetWorld();
		NetDriver->NetDriverName = NetDriverName;

		FString Error;
		FURL URL = FURL();
		URL.Port = 7777;

		bool bReuseAddressAndPort = false;
		InitListen(NetDriver, UWorld::GetWorld(), URL, bReuseAddressAndPort, Error);
		SetWorld = decltype(SetWorld)((*(void***)NetDriver)[0x72]);
		SetWorld(NetDriver, UWorld::GetWorld());
		UWorld::GetWorld()->NetDriver = NetDriver;
		UWorld::GetWorld()->LevelCollections[0].NetDriver = NetDriver;
		UWorld::GetWorld()->LevelCollections[1].NetDriver = NetDriver;
		GameState->AirCraftBehavior = GameState->CurrentPlaylistInfo.BasePlaylist->AirCraftBehavior;
		GameState->CachedSafeZoneStartUp = GameState->CurrentPlaylistInfo.BasePlaylist->SafeZoneStartUp;
		GameState->OnRep_CurrentPlaylistId();
		GameMode->bWorldIsReady = true;
		GameState->OnRep_CurrentPlaylistInfo();

		SetConsoleTitleA("hosting on port 7777");
		Log("Listening on port 7777");
	}
	if (GameState->TotalPlayers > 0)
		Ret = true;
	return Ret;
}

inline APawn* SpawnDefaultPawnFor(AGameModeBase* GameModeBase, AController* NewPlayer, AActor* StartSpot)
{
	if (!NewPlayer || !StartSpot)
		return nullptr;

	auto Ret = GameModeBase->SpawnDefaultPawnAtTransform(NewPlayer, (FTransform&)StartSpot->GetTransform());
	return Ret;
}

inline void (*InitializeForWorldOG)(UNavigationSystemV1* NavSystem, UWorld* World, EFNavigationSystemRunMode Mode);
inline void InitializeForWorld(UNavigationSystemV1* NavSystem, UWorld* World, EFNavigationSystemRunMode Mode)
{
	auto NavSystemAsAthena = (UAthenaNavSystem*)NavSystem;
	NavSystemAsAthena->bAutoCreateNavigationData = true;
	return InitializeForWorldOG(NavSystem, World, Mode);
}

inline __int64 PickTeam(__int64 a1, unsigned __int8 a2, __int64 a3)
{
	return 3;
}