#pragma once
#include "SDK.hpp"
#include "UE.h"
#include "Inventory.h"

using namespace SDK;
using namespace std;


inline void (*TickFlushOriginal)(UNetDriver*);
inline void TickFlush(UNetDriver* NetDriver)
{
	if (NetDriver && NetDriver->ClientConnections.Num() > 0 && NetDriver->ReplicationDriver)
		ServerReplicateActors(NetDriver->ReplicationDriver);

	static bool once = true;

	if (once == true && GetGameState()->WarmupCountdownEndTime - GetStatics()->GetTimeSeconds(GetWorld()) <= 0)
	{
		UKismetSystemLibrary::ExecuteConsoleCommand(UWorld::GetWorld(), TEXT("startaircraft"), nullptr); // very very proper :skull:

		once = false;
	}

	return TickFlushOriginal(NetDriver);
}

void (*ProcessEventOG)(void*, void*, void*);
void ProcessEvent(UObject* Obj, UFunction* Func, void* Params)
{
	return ProcessEventOG(Obj, Func, Params);
}