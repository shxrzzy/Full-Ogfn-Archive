#pragma once
#include <string>
#include "SDK.hpp"
#include "UE.h"
#include <vector>
#include <map>

using namespace SDK;
using namespace std;

inline void (*CommitAbilityOG)(UGameplayAbility* Ability);
inline bool (*InternalTryActivateAbility)(UAbilitySystemComponent* AbilitySystemComp, FGameplayAbilitySpecHandle AbilityToActivate, FPredictionKey InPredictionKey, UGameplayAbility** OutInstancedAbility, void* OnGameplayAbilityEndedDelegate, const FGameplayEventData* TriggerEventData) = decltype(InternalTryActivateAbility)(__int64(GetModuleHandleW(0)) + 0xC42BB0);

inline void ServerPlayEmoteItemHook(AFortPlayerController* PlayerController, UFortItemDefinition* EmoteAsset, float RandomEmoteNumber)
{
	UClass* AbilityClass = StaticLoadObject<UClass>("/Game/Abilities/Emotes/GAB_Emote_Generic.GAB_Emote_Generic_C");

	FGameplayAbilitySpec Spec{};
	FGameplayAbilitySpec* (*FGameplayAbilitySpecCtor)(FGameplayAbilitySpec * Spec, UGameplayAbility * Ability, int Level, int InputID, UObject * SourceObject) = decltype(FGameplayAbilitySpecCtor)(__int64(GetModuleHandleW(0)) + 0xC18600);
	FGameplayAbilitySpecCtor(&Spec, (UGameplayAbility*)AbilityClass->DefaultObject, 1, -1, EmoteAsset);
	FGameplayAbilitySpecHandle(*GiveAbilityAndActivateOnce)(UAbilitySystemComponent * ASC, FGameplayAbilitySpecHandle*, FGameplayAbilitySpec) = decltype(GiveAbilityAndActivateOnce)(__int64(GetModuleHandleW(0)) + 0xC3C010);
	GiveAbilityAndActivateOnce(((AFortPlayerStateAthena*)PlayerController->PlayerState)->AbilitySystemComponent, &Spec.Handle, Spec);
}

inline FGameplayAbilitySpecHandle(*GiveAbilityOG)(UAbilitySystemComponent* AbilitySystemComponent, FGameplayAbilitySpecHandle* OutHandle, FGameplayAbilitySpec NewSpec);
inline FGameplayAbilitySpecHandle GiveAbility(UAbilitySystemComponent* AbilitySystemComponent, UClass* AbilityClass, UObject* SourceObject)
{
	if (!AbilityClass)
		return FGameplayAbilitySpecHandle();

	FGameplayAbilitySpec Spec{};
	FGameplayAbilitySpec* (*FGameplayAbilitySpecCtor)(FGameplayAbilitySpec * Spec, UGameplayAbility * Ability, int Level, int InputID, UObject * SourceObject) = decltype(FGameplayAbilitySpecCtor)(__int64(GetModuleHandleW(0)) + 0xC18600);
	FGameplayAbilitySpecCtor(&Spec, (UGameplayAbility*)AbilityClass->DefaultObject, 1, -1, SourceObject);
	GiveAbilityOG = decltype(GiveAbilityOG)(__int64(GetModuleHandleW(0)) + 0xC3BEE0);
	FGameplayAbilitySpecHandle OutHandle;
	GiveAbilityOG(AbilitySystemComponent, &OutHandle, Spec);

	return OutHandle;
}

inline FGameplayAbilitySpec* FindAbilityFromSpecHandle(UAbilitySystemComponent* AbilitySystemComponent, FGameplayAbilitySpecHandle& SpecHandle)
{

	for (int i = 0; i < AbilitySystemComponent->ActivatableAbilities.Items.Num(); i++)
	{

		if (AbilitySystemComponent->ActivatableAbilities.Items[i].Handle.Handle == SpecHandle.Handle)
		{
			return &AbilitySystemComponent->ActivatableAbilities.Items[i];
		}
	}
	
	return nullptr;
}


inline void InternalServerTryActivateAbilityHook(UAbilitySystemComponent* AbilitySystemComponent, FGameplayAbilitySpecHandle Handle, bool InputPressed, FPredictionKey& PredictionKey, FGameplayEventData* TriggerEventData)
{
	auto Spec = FindAbilityFromSpecHandle(AbilitySystemComponent, Handle);
	if (!Spec)
		return AbilitySystemComponent->ClientActivateAbilityFailed(Handle, PredictionKey.Current);

	UGameplayAbility* AbilityToActivate = Spec->Ability;

	UGameplayAbility* InstancedAbility = nullptr;
	Spec->InputPressed = true;


	if (!InternalTryActivateAbility(AbilitySystemComponent, Handle, PredictionKey, &InstancedAbility, nullptr, TriggerEventData))
	{
		AbilitySystemComponent->ClientActivateAbilityFailed(Handle, PredictionKey.Current);
		Spec->InputPressed = false;
		AbilitySystemComponent->ActivatableAbilities.MarkItemDirty((*Spec));
	}

}