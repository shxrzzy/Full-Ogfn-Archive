#pragma once
#include <Windows.h>
#include <cstdio>
#include "Utils.h"
#include "Misc.h"
#include "GameMode.h"
#include "NetDriver.h"
#include "PlayerController.h"
#include "Inventory.h"
#include "Looting.h"
#include "Memcury.h"
#include "Bosses.h"
#include <iomanip>
#include <sstream>

#include "minhook/MinHook.h"

#pragma comment(lib, "minhook/minhook.lib")

using namespace std;
using namespace SDK;


namespace Gamemode {

	inline void InitHooks()
	{
		static auto Base = __int64(GetModuleHandleW(0));
		Log("Initializing Gamemode Hooks...");

		MH_CreateHook((LPVOID)(Base + 0x559B8D0), ReadyToStartMatch, (LPVOID*)&ReadyToStartMatchOriginal);
		MH_EnableHook((LPVOID)(Base + 0x559B8D0));
		MH_CreateHook((LPVOID)(Base + 0x559BA00), SpawnDefaultPawnFor, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x559BA00));

	}
}

namespace Misc {

	void InitHooks()
	{
		static auto Base = __int64(GetModuleHandleW(0));
		Log("Initializing Misc Hooks...");

		MH_CreateHook((LPVOID)(Base + 0x12506F0), MCP_DispatchRequestHook, (LPVOID*)&MCP_DispatchRequest);
		MH_EnableHook((LPVOID)(Base + 0x12506F0));
		MH_CreateHook((LPVOID)(Base + 0x232B2B0), HandleNewSafeZonePhase, (LPVOID*)&HandleNewSafeZonePhaseOG);
		MH_EnableHook((LPVOID)(Base + 0x232B2B0));
		MH_CreateHook((LPVOID)(Base + 0x2C2EE20), RetZero, nullptr); //kick
		MH_EnableHook((LPVOID)(Base + 0x2C2EE20));

		MH_CreateHook((*(void***)UEngine::GetEngine())[0x58], GetMaxTickRate, nullptr);
		MH_EnableHook((*(void***)UEngine::GetEngine())[0x58]);
	}
}

namespace PC {

	void InitHooks()
	{
		static auto Base = __int64(GetModuleHandleW(0));
		Log("Initializing PC Hooks...");

		SwapVFTs(AAthena_PlayerController_C::GetDefaultObj(), 0x111, ServerAcknowledgePossession, (PVOID*)&ServerAcknowledgePossessionOG);
		SwapVFTs(AAthena_PlayerController_C::StaticClass()->DefaultObject, 0x273, ServerReadyToStartMatch, (PVOID*)&ServerReadyToStartMatchOG);
		SwapVFTs(UAthenaNavSystem::StaticClass()->DefaultObject, 0x55, InitializeForWorld, (PVOID*)&InitializeForWorldOG);
		SwapVFTs(UFortControllerComponent_Aircraft::StaticClass()->DefaultObject, 0x94, ServerAttemptAircraftJump, nullptr);
		SwapVFTs(AAthena_PlayerController_C::StaticClass()->DefaultObject, 0x211, ServerExecuteInventoryItem, nullptr);
		SwapVFTs(AAthena_PlayerController_C::StaticClass()->DefaultObject, 0x275, ServerLoadingScreenDropped, (PVOID*)&ServerLoadingScreenDroppedOG);
		SwapVFTs(AAthena_PlayerController_C::StaticClass()->DefaultObject, 0x1CD, ServerPlayEmoteItemHook, nullptr);
		SwapVFTs(AAthena_PlayerController_C::StaticClass()->DefaultObject, 0x1CB, ServerCheat, nullptr);
		SwapVFTs(AAthena_PlayerController_C::StaticClass()->DefaultObject, 0x234, ServerCreateBuildingActor, nullptr);
		SwapVFTs(APlayerPawn_Athena_C::StaticClass()->DefaultObject, 0x200, ServerHandlePickup, nullptr);
		SwapVFTs(APlayerPawn_Athena_C::StaticClass()->DefaultObject, 0x11B, NetMulticastDamageCues, (LPVOID*)&NetMulticastDamageCuesOG);
		SwapVFTs(AAthena_PlayerController_C::StaticClass()->DefaultObject, 0x23B, ServerBeginEditingBuildingActor, nullptr);
		SwapVFTs(AAthena_PlayerController_C::StaticClass()->DefaultObject, 0x236, ServerEditBuildingActor, nullptr);
		SwapVFTs(AAthena_PlayerController_C::StaticClass()->DefaultObject, 0x239, ServerEndEditingBuildingActor, nullptr);
	    SwapVFTs(AAthena_PlayerController_C::StaticClass()->DefaultObject, 0x221, ServerAttemptInventoryDrop, nullptr);


		MH_CreateHook((LPVOID)(Base + 0x53206B0), GetPlayerViewPoint, (LPVOID*)&GetPlayerViewPointOG);
		MH_EnableHook((LPVOID)(Base + 0x53206B0));
		MH_CreateHook((LPVOID)(Base + 0x53206B0), GetPlayerViewPoint, (LPVOID*)&GetPlayerViewPointOG);
		MH_EnableHook((LPVOID)(Base + 0x53206B0));
		MH_CreateHook((LPVOID)(Base + 0x2707580), ServerAttemptInteractHook, (LPVOID*)&ServerAttemptInteractOG);
		MH_EnableHook((LPVOID)(Base + 0x2707580));
		MH_CreateHook((LPVOID)(Base + 0x326B200), OnDamageServer, (LPVOID*)&OnDamageServerOG);
		MH_EnableHook((LPVOID)(Base + 0x326B200));
		MH_CreateHook((LPVOID)(Base + 0x1B06660), DestroyPickup, (LPVOID*)&DestroyPickupOG);
		MH_EnableHook((LPVOID)(Base + 0x1B06660));
		MH_CreateHook((LPVOID)(Base + 0x31EB470), OnReload, (LPVOID*)&OnReloadOG);
		MH_EnableHook((LPVOID)(Base + 0x31EB470));
		MH_CreateHook((LPVOID)(Base + 0x3616800), ClientOnPawnDied, (LPVOID*)&ClientOnPawnDiedOG);
		MH_EnableHook((LPVOID)(Base + 0x3616800));
	}
}

namespace Tick {

	void InitHooks()
	{
		static auto Base = __int64(GetModuleHandleW(0));
		Log("Initializing NetDriver Hooks...");

		MH_CreateHook((LPVOID)(Base + 0x5224DC0), TickFlush, (LPVOID*)&TickFlushOriginal);
		MH_EnableHook((LPVOID)(Base + 0x5224DC0));

		MH_CreateHook((LPVOID)(0x03ABFAA0), ProcessEvent, (LPVOID*)&ProcessEventOG);
		MH_EnableHook((LPVOID)(0x03ABFAA0));
	}
}

namespace World {

	void InitHooks()
	{
		static auto Base = __int64(GetModuleHandleW(0));
		Log("Initializing World Hooks...");

		MH_CreateHook((LPVOID)(Base + 0x4E18E20), RetOne, nullptr); //what
		MH_EnableHook((LPVOID)(Base + 0x4E18E20));
		MH_CreateHook((LPVOID)(Base + 0x5520390), RetOne, nullptr); //is
		MH_EnableHook((LPVOID)(Base + 0x5520390));
		MH_CreateHook((LPVOID)(Base + 0xBE8570), RetOne, nullptr); //the
		MH_EnableHook((LPVOID)(Base + 0xBE8570));
		MH_CreateHook((LPVOID)(Base + 0x3A6A970), RetOne, nullptr); // difference
		MH_EnableHook((LPVOID)(Base + 0x3A6A970));
		MH_CreateHook((LPVOID)(Base + 0x2163DA0), RetZero, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x2163DA0));
		MH_CreateHook((LPVOID)(Base + 0x2164330), RetZero, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x2164330));
		MH_CreateHook((LPVOID)(Base + 0x38483C0), GetCommandLet, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x38483C0));
		MH_CreateHook((LPVOID)(Base + 0x2C38780), GameSessionRestart, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x2C38780));
		MH_CreateHook((LPVOID)(Base + 0x16EC420), GameSessionRestart, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x16EC420));

	   *(bool*)(__int64(GetModuleHandleW(0)) + 0x9A10500) = false; // GIsClient
	   *(bool*)(__int64(GetModuleHandleW(0)) + 0x9A10501) = true; // GIsServer

		//  uintptr_t gamesessioncrashthing = __int64(__int64(GetModuleHandleW(0)) + 0x2C13584); //not sure what this is
		// *(uint8_t*)(gamesessioncrashthing + 1) = 0x85;


	}
}

namespace Abilities {

	void InitHooks()
	{
		SwapVFTs(UFortAbilitySystemComponentAthena::StaticClass()->DefaultObject, 0xFE, InternalServerTryActivateAbilityHook, nullptr);

		SwapVFTs(UFortAbilitySystemComponent::StaticClass()->DefaultObject, 0xFE, InternalServerTryActivateAbilityHook, nullptr);

		SwapVFTs(UAbilitySystemComponent::StaticClass()->DefaultObject, 0xFE, InternalServerTryActivateAbilityHook, nullptr);

		static auto Base = __int64(GetModuleHandleW(0));

		//MH_CreateHook((LPVOID)(Base + 0x25BDDE0), SpawnLoot, nullptr);
		//MH_EnableHook((LPVOID)(Base + 0x25BDDE0));
	}
	void InitAbilitiesForPlayer(SDK::AFortPlayerController*);
}

namespace Teams
{
	void InitHooks()
	{
		Log("Initializing Teams Hooks...");
		static auto Base = __int64(GetModuleHandleW(0));

		//MH_CreateHook((LPVOID)(Base + 0x2310C20), PickTeam, nullptr);
		//MH_EnableHook((LPVOID)(Base + 0x2310C20));
	}

	//uint8 PickTeam(SDK::AFortGameModeAthena* Gamemode, uint8 PreferredTeam, SDK::AFortPlayerControllerAthena* PC);
}


namespace Looting
{
	void InitHooks()
	{
		Log("Initializing Looting Hooks...");
		static auto Base = __int64(GetModuleHandleW(0));

		MH_CreateHook((LPVOID)(Base + 0x25BDDE0), SpawnLoot, nullptr);
		MH_EnableHook((LPVOID)(Base + 0x25BDDE0));
		MH_CreateHook((LPVOID)(Base + 0x2610D70), ABuildingSMActor_PostUpdate, (LPVOID*)&ABuildingSMActor_PostUpdateOG);
		MH_EnableHook((LPVOID)(Base + 0x2610D70));
	}

}