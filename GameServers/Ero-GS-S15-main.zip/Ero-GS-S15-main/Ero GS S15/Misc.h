#pragma once
#include "SDK.hpp"
#include <intrin.h>

using namespace SDK;
using namespace std;

struct FServicePermissionsMcp {
public:
	char unknown[0x10];
	class FString Id;
};


inline __int64 RetZero()
{
	return 0;
}

inline __int64 RetOne()
{
	return 1;
}

inline const wchar_t* GetCommandLet()
{
	return L"-log -epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -skippatchcheck -nobe -fromfl=eac -fltoken=3db3ba5dcbd2e16703f3978d -AllowAllPlaylistsInShipping -caldera=eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50X2lkIjoiYmU5ZGE1YzJmYmVhNDQwN2IyZjQwZWJhYWQ4NTlhZDQiLCJnZW5lcmF0ZWQiOjE2Mzg3MTcyNzgsImNhbGRlcmFHdWlkIjoiMzgxMGI4NjMtMmE2NS00NDU3LTliNTgtNGRhYjNiNDgyYTg2IiwiYWNQcm92aWRlciI6IkVhc3lBbnRpQ2hlYXQiLCJub3RlcyI6IiIsImZhbGxiYWNrIjpmYWxzZX0.VAWQB67RTxhiWOxx7DBjnzDnXyyEnX7OljJm-j2d88G_WgwQ9wrE6lwMEHZHjBd1ISJdUO1UVUqkfLdU5nofBQ -AUTH_LOGIN=your@email.com -AUTH_PASSWORD=yourpasswordhere AUTH_TYPE=exchangecode -nosplash -DisableMMS";
	//return L"-log -epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -skippatchcheck -nobe -fromfl=eac -fltoken=3db3ba5dcbd2e16703f3978d -AllowAllPlaylistsInShipping -caldera=eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50X2lkIjoiYmU5ZGE1YzJmYmVhNDQwN2IyZjQwZWJhYWQ4NTlhZDQiLCJnZW5lcmF0ZWQiOjE2Mzg3MTcyNzgsImNhbGRlcmFHdWlkIjoiMzgxMGI4NjMtMmE2NS00NDU3LTliNTgtNGRhYjNiNDgyYTg2IiwiYWNQcm92aWRlciI6IkVhc3lBbnRpQ2hlYXQiLCJub3RlcyI6IiIsImZhbGxiYWNrIjpmYWxzZX0.VAWQB67RTxhiWOxx7DBjnzDnXyyEnX7OljJm-j2d88G_WgwQ9wrE6lwMEHZHjBd1ISJdUO1UVUqkfLdU5nofBQ -AUTH_LOGIN=your@email.com -AUTH_PASSWORD=yourpasswordhere AUTH_TYPE=exchangecode -nosplash -DisableMMS";
}

inline void GameSessionRestart(__int64)
{
	cout << __int64(_ReturnAddress()) - InSDKUtils::GetImageBase() << endl;
}

inline FServicePermissionsMcp* permsthing(__int64 a1, __int64 a2)
{

	FServicePermissionsMcp* Perms = new FServicePermissionsMcp();
	Perms->Id = L"DedicatedServer";//idk
	return Perms;

}


inline __int64(__fastcall* MCP_DispatchRequest)(void* Profile, void* Context, int a3);
inline __int64 __fastcall MCP_DispatchRequestHook(void* Profile, void* Context, int a3)
{
	return MCP_DispatchRequest(Profile, Context, 3);
}


float GetMaxTickRate()
{
	return 30.f;
}

void ServerMove(AFortPhysicsPawn* Pawn, FReplicatedPhysicsPawnState InState)
{
	UPrimitiveComponent* RootComp = (UPrimitiveComponent*)Pawn->RootComponent;
	FTransform Transform{};
	Transform.Translation = InState.Translation;
	Transform.Rotation = InState.Rotation;
	Transform.Scale3D = FVector{ 1, 1, 1 };
	RootComp->K2_SetWorldTransform(Transform, false, nullptr, true);
	RootComp->SetPhysicsLinearVelocity(InState.LinearVelocity, 0, FName());
	RootComp->SetPhysicsAngularVelocity(InState.AngularVelocity, 0, FName());
}