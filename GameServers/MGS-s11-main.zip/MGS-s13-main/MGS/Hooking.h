#pragma once
#include "Utils.h"
#include "Gamemode.h"
#include "ServerFuncs.h"
#include "Tick.h"
#include "minhook/MinHook.h"
#include "Inventory.h"
#include "Misc.h"

#pragma comment(lib, "minhook/minhook.lib")

static auto ImageBase = InSDKUtils::GetImageBase();

int True() {
	return 1;
}

int False() {
	return 0;
}

namespace Gamemode {

	inline void InitHooks()
	{
		Log("Hooking Gamemode");

		MH_CreateHook((LPVOID)(ImageBase + 0x1ec78b0), ReadyToStartMatch, (LPVOID*)&ReadyToStartMatchOG);
		MH_CreateHook((LPVOID)(ImageBase + 0x1ed2b10), SpawnDefaultPawnFor, nullptr);
		MH_CreateHook(LPVOID(ImageBase + 0x1ec0f70), PickTeam, nullptr);
	}
}

namespace Misc {

	void InitHooks()
	{
		Log("Hooking Misc");

		MH_CreateHook((LPVOID)(ImageBase + 0x349d3c0), True, nullptr); // collect garbage
		MH_CreateHook((LPVOID)(ImageBase + 0x49c50f0), True, nullptr);// validation / kick
		MH_CreateHook((LPVOID)(ImageBase + 0x247e020), False, nullptr);// change gamesession id
		MH_CreateHook((LPVOID)(ImageBase + 0x4e1a9a0), True, nullptr); // world
		MH_CreateHook((LPVOID)(ImageBase + 0x472a900), True, nullptr);// actor
		MH_CreateHook((LPVOID)(ImageBase + 0x4B131E0), True, nullptr);// SupportObjects
		MH_CreateHook((LPVOID)(ImageBase + 0x349d7a0), False, nullptr);// Null
		MH_CreateHook((LPVOID)(ImageBase + 0x2983710), False, nullptr);// Null
		MH_CreateHook((LPVOID)(ImageBase + 0x271b240), True, nullptr);// True
		MH_CreateHook((LPVOID)(ImageBase + 0x34c9c80), True, nullptr);// True
		MH_CreateHook((LPVOID)(ImageBase + 0x952570), True, nullptr);// True
		MH_CreateHook((LPVOID)(ImageBase + 0x4b2a8a0), True, nullptr);// True
		MH_CreateHook((LPVOID)(ImageBase + 0x1b1fbc0), True, nullptr);// True
		MH_CreateHook((LPVOID)(ImageBase + 0x1bada40), True, nullptr);// True

		MH_CreateHook((LPVOID)(ImageBase + 0x1312430), DispatchRequest, (LPVOID*)&DispatchRequestOG);
		MH_CreateHook((LPVOID)(ImageBase + 0x2644ec0), StreamLevelOverlay, (LPVOID*)&StreamLevelOverlayOG);
		MH_CreateHook((LPVOID)(ImageBase + 0x1ed8e20), SetZoneIndex, (LPVOID*)&SetZoneIndexOG);
		MH_CreateHook((LPVOID)(ImageBase + 0x261d8e0), CompletePickupAnimation, (LPVOID*)&CompletePickupAnimationOG);
		MH_CreateHook((LPVOID)(ImageBase + 0x308dc10), ClientOnPawnDied, (LPVOID*)&ClientOnPawnDiedOG);
		MH_CreateHook((LPVOID)(ImageBase + 0x290ca00), OnCapsuleBeginOverlap, (LPVOID*)&OnCapsuleBeginOverlapOG);

		ExecHook(StaticLoadObject<UFunction>("/Script/FortniteGame.BuildingFoundation.SetDynamicFoundationEnabled"), SetDynamicFoundationEnabled, SetDynamicFoundationEnabledOG);
		ExecHook(StaticLoadObject<UFunction>("/Script/FortniteGame.BuildingFoundation.SetDynamicFoundationTransform"), SetDynamicFoundationTransform, SetDynamicFoundationTransformOG);

	}
}

namespace ServerFuncs {

	void InitHooks()
	{
		Log("Hooking ServerFuncs");

		HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x26B, ServerLoadingScreenDropped, (LPVOID*)&ServerLoadingScreenDroppedOG);
		HookVTable(UFortControllerComponent_Aircraft::GetDefaultObj(), 0x89, ServerAttemptAircraftJump, nullptr);
		HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x10D, ServerAcknowledgePossession, (LPVOID*)&ServerAcknowledgePossessionOG);
		HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x20D, ServerExecuteInventoryItem, nullptr);
		HookVTable(APlayerPawn_Athena_C::GetDefaultObj(), 0x1F0, ServerHandlePickup, nullptr);
		HookVTable(AAthena_PlayerController_C::GetDefaultObj(), 0x21D, ServerAttemptInventoryDrop, nullptr);
		HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x269, ServerReadyToStartMatch, (LPVOID*)&ServerReadyToStartMatchOG);
		HookVTable(UFortControllerComponent_Interaction::GetDefaultObj(), 0x8b, ServerAttemptInteract, (LPVOID*)&ServerAttemptInteractOG);
		HookVTable(AFortPlayerStateAthena::StaticClass()->DefaultObject, 0xFF, ServerSetInAircraft, (PVOID*)&ServerSetInAircraftOG);
		HookVTable(AFortPlayerControllerAthena::GetDefaultObj(), 0x265, ServerReturnToMainMenu, nullptr);
	}
}

namespace Tick {

	void InitHooks()
	{
		Log("Hooking Tick");

		MH_CreateHook((LPVOID)(ImageBase + 0x4b2ac40), TickFlush, (LPVOID*)&TickFlushOG);
		MH_CreateHook((LPVOID)(ImageBase + 0x4dbfa20), GetMaxTickRate, nullptr);
	}
}

namespace Abilities {

	void InitHooks()
	{
		Log("Hooking Abilities");
		HookVTable(UAbilitySystemComponent::GetDefaultObj(), 0xFA, InternalServerTryActivateAbility, nullptr);
		HookVTable(UFortAbilitySystemComponent::GetDefaultObj(), 0xFA, InternalServerTryActivateAbility, nullptr);
		HookVTable(UFortAbilitySystemComponentAthena::GetDefaultObj(), 0xFA, InternalServerTryActivateAbility, nullptr);
	}
}

namespace Inventory {

	void InitHooks()
	{
		Log("Inventory Hooks");

		MH_CreateHook((LPVOID)(ImageBase + 0x2ca3e80), OnReload, (LPVOID*)&OnReloadOG);
		HookVTable(AFortPlayerPawnAthena::GetDefaultObj(), 0x119, NetMulticastDamageCues, (LPVOID*)&NetMulticastDamageCuesOG);

	}
}

namespace Looting {

	void InitHooks()
	{
		Log("Looting Hooks");

		MH_CreateHook((LPVOID)(ImageBase + 0x213e180), SpawnLoot, nullptr);

	}
}