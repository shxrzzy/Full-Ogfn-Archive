#pragma once
#include "Utils.h"
#include "FFrame.h"
#include "AApollo_WaterSetup.hpp"

inline bool (*ReadyToStartMatchOG)(AFortGameModeAthena* GameMode);
inline bool ReadyToStartMatch(AFortGameModeAthena* GameMode)
{

    auto GameState = (AFortGameStateAthena*)GameMode->GameState;

    static bool Initialized = false;
    static bool SetUpPlaylist = false;

    if (!GameMode || !GameState)
    {
        return false;
    }

    if (!Initialized)
    {
        Initialized = true;

        UFortPlaylistAthena* Playlist = StaticLoadObject<UFortPlaylistAthena>("/Game/Athena/Playlists/Playlist_DefaultSolo.Playlist_DefaultSolo");

        GameState->CurrentPlaylistInfo.BasePlaylist = Playlist;
        GameState->CurrentPlaylistInfo.OverridePlaylist = Playlist;
        GameState->CurrentPlaylistInfo.PlaylistReplicationKey++;
        GameState->CurrentPlaylistId = Playlist->PlaylistId;
        GameState->CurrentPlaylistInfo.MarkArrayDirty(); // make sure you add this to your sdk
        
        AFortGameSessionDedicatedAthena* GameSession = SpawnActor<AFortGameSessionDedicatedAthena>();

        //not proper
        GameSession->SessionName = UKismetStringLibrary::Conv_StringToName(FString(L"MGS"));
        GameSession->MaxPlayers = 100;
        GameMode->GameSession = GameSession;
        GameMode->FortGameSession = GameSession;
        GameMode->CurrentPlaylistId = Playlist->PlaylistId;

    	NextIdx = Playlist->DefaultFirstTeam;
		MaxPlayersOnTeam = Playlist->MaxSquadSize;
        
	   if (MaxPlayersOnTeam > 1)
	   {
		  GameMode->bDBNOEnabled = true;
		  GameState->bDBNOEnabledForGameMode = true;
		  GameState->bDBNODeathEnabled = true;
		  GameMode->bAllowSpectateAfterDeath = true;
	   }
    }

    if (!GameState->MapInfo)
    {
        return false;
    }

    if (!SetUpPlaylist)
    {
        SetUpPlaylist = true;

        if (Initialized)
        {
            GameState->OnRep_CurrentPlaylistId();
            GameState->OnRep_CurrentPlaylistInfo();
        }
    }

    return UWorld::GetWorld()->NetDriver->ClientConnections.Num() > 0;
}

inline APawn* SpawnDefaultPawnFor(AFortGameMode* GameMode, AFortPlayerController* Player, AActor* StartingLoc)
{
    AActor* StartSpot = GameMode->FindPlayerStart(Player, L"");
    FTransform Transform = StartSpot->GetTransform();
    return (AFortPlayerPawnAthena*)GameMode->SpawnDefaultPawnAtTransform(Player, Transform);
}

inline void (*DispatchRequestOG)(__int64 a1, unsigned __int64* a2, int a3);
inline void DispatchRequest(__int64 a1, unsigned __int64* a2, int a3)
{
    return DispatchRequestOG(a1, a2, 3);
}