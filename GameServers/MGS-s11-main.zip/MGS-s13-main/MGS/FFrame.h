#pragma once
#include "Utils.h"

class FOutputDevice
{
public:
    bool bSuppressEventTag;
    bool bAutoEmitLineTerminator;
    uint8_t _Padding1[0x6];
};

class FFrame : public FOutputDevice
{
public:
    void** VTable;
    UFunction* Node;
    UObject* Object;
    uint8* Code;
    uint8* Locals;
    void* MostRecentProperty;
    uint8_t* MostRecentPropertyAddress;
    uint8_t _Padding1[0x40];
    FField* PropertyChainForCompiledIn;

public:

    void StepCompiledIn(void* const Result, bool ForceExplicitProp = false)
    {
        if (Code && !ForceExplicitProp)
        {
            ((void (*)(FFrame*, UObject*, void* const))(InSDKUtils::GetImageBase() + 0x3531130))(this, Object, Result);
        }
        else
        {
            FField* _Prop = PropertyChainForCompiledIn;
            PropertyChainForCompiledIn = _Prop->Next;
            ((void (*)(FFrame*, void* const, FField*))(InSDKUtils::GetImageBase() + 0x3531160))(this, Result, _Prop);
        }
    }


    template <typename T>
    T& StepCompiledInRef() 
    {
        T TempVal{};
        MostRecentPropertyAddress = nullptr;

        if (Code)
        {
            ((void (*)(FFrame*, UObject*, void* const))(InSDKUtils::GetImageBase() + 0x3531130))(this, Object, &TempVal);
        }
        else
        {
            FField* _Prop = PropertyChainForCompiledIn;
            PropertyChainForCompiledIn = _Prop->Next;
            ((void (*)(FFrame*, void* const, UField*))(InSDKUtils::GetImageBase() + 0x3531160))(this, &TempVal, _Prop);
        }

        return MostRecentPropertyAddress ? *(T*)MostRecentPropertyAddress : TempVal;
    }

    void IncrementCode()
    {
        Code = (uint8_t*)(__int64(Code) + (bool)Code);
    }
};