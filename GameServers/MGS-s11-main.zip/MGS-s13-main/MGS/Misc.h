#pragma once
#include "Utils.h"
#include "FFrame.h"
#include "AApollo_WaterSetup.hpp"

inline __int64 PickTeam(__int64 a1, unsigned __int8 a2, __int64 a3)
{
    uint8 Ret = NextIdx;
    CurrentPlayersOnTeam++;

    if (CurrentPlayersOnTeam == MaxPlayersOnTeam)
    {
        NextIdx++;
        CurrentPlayersOnTeam = 0;
    }

    return Ret;
};

static inline void (*SetDynamicFoundationEnabledOG)(UObject*, FFrame&);
static void SetDynamicFoundationEnabled(UObject* Context, FFrame& Stack)
{
    bool bEnabled;
    Stack.StepCompiledIn(&bEnabled);
    auto Foundation = (ABuildingFoundation*)Context;
    Foundation->DynamicFoundationRepData.EnabledState = bEnabled ? EDynamicFoundationEnabledState::Enabled : EDynamicFoundationEnabledState::Disabled;
    Foundation->OnRep_DynamicFoundationRepData();
    Foundation->FoundationEnabledState = bEnabled ? EDynamicFoundationEnabledState::Enabled : EDynamicFoundationEnabledState::Disabled;
    return SetDynamicFoundationEnabledOG(Context, Stack);
}

static inline void (*SetDynamicFoundationTransformOG)(UObject* Context, FFrame& Stack);
static void SetDynamicFoundationTransform(UObject* Context, FFrame& Stack)
{
    FTransform Transform;
    Stack.StepCompiledIn(&Transform);

    auto Rotation = Transform.Rotation.Rotator();
    auto Location = Transform.Translation;
    auto Foundation = (ABuildingFoundation*)Context;
    Foundation->DynamicFoundationTransform = Transform;
    Foundation->StreamingData.FoundationLocation = Location;
    Foundation->DynamicFoundationRepData.Rotation = Rotation;
    Foundation->DynamicFoundationRepData.Translation = Location;
    Foundation->OnRep_DynamicFoundationRepData();
    if (Foundation->GetName() == "Fortilla_Foundation_MANG")
    {
        for (auto& World : Foundation->AdditionalWorlds)
        {
            ULevelStreamingDynamic::LoadLevelInstanceBySoftObjectPtr(UWorld::GetWorld(), World, Location, Rotation, nullptr, FString());
        }
    }
    return SetDynamicFoundationTransformOG(Context, Stack);
}

static inline void (*StreamLevelOverlayOG)(UFortLevelOverlayManager* LevelOverlayManager, UWorld* World, __int64 a3, ULevelStreamingDynamic* LevelStreamingDynamic);
static void StreamLevelOverlay(UFortLevelOverlayManager* LevelOverlayManager, UWorld* World, __int64 a3, ULevelStreamingDynamic* LevelStreamingDynamic)
{
    StreamLevelOverlayOG(LevelOverlayManager, World, a3, LevelStreamingDynamic);

    if (!LevelStreamingDynamic)
        return;

    static int32 LoadedCount = 0;
    static AApollo_WaterSetup_C* WaterSetup = nullptr;
    AFortGameModeAthena* GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;

    if (!WaterSetup)
    {
        TArray<AActor*> Actors;
        UGameplayStatics::GetAllActorsOfClass(UWorld::GetWorld(), AApollo_WaterSetup_C::StaticClass(), &Actors);

        if (Actors.Num() > 0)
            WaterSetup = (AApollo_WaterSetup_C*)Actors[0];

        Actors.Free();
    }

    LoadedCount++;

    static int32 RequiredLoadedCount = 0;
    if (RequiredLoadedCount == 0) switch (WaterSetup->CurrentWaterLevel) {
    case 0:
    case 1:
        RequiredLoadedCount = 159;
        break;
    case 2:
    case 3:
        RequiredLoadedCount = 160;
        break;
    case 4:
        RequiredLoadedCount = 157;
        break;
    case 5:
        RequiredLoadedCount = 153;
        break;
    case 6:
    case 7:
        RequiredLoadedCount = 150;
        break;
    }
    if (LoadedCount > RequiredLoadedCount) LoadedCount = 1;
    else if (LoadedCount == RequiredLoadedCount)
    {
        FName GameNetDriver = UKismetStringLibrary::Conv_StringToName(FString(L"GameNetDriver"));

        UNetDriver* Driver = CreateNetDriver(UEngine::GetEngine(), UWorld::GetWorld(), GameNetDriver);

        Driver->World = UWorld::GetWorld();
        Driver->NetDriverName = GameNetDriver;

        FString Error;
        FURL URL = FURL();
        URL.Port = 7777;

        InitListen(Driver, UWorld::GetWorld(), URL, false, Error);
        SetWorld(Driver, UWorld::GetWorld());

        UWorld::GetWorld()->NetDriver = Driver;
        UWorld::GetWorld()->LevelCollections[0].NetDriver = Driver;
        UWorld::GetWorld()->LevelCollections[1].NetDriver = Driver;

        GameMode->WarmupRequiredPlayerCount = 1;
        GameMode->bWorldIsReady = true;

        SetConsoleTitleA("MGS hosting on port 7777");
        Log("Listening on port 7777.");

    }
}

inline void (*SetZoneIndexOG)(AFortGameModeAthena* GameMode, int32 ZoneIndex);
void SetZoneIndex(AFortGameModeAthena* GameMode, int32 ZoneIndex)
{
    auto GameState = (AFortGameStateAthena*)GameMode->GameState;

    auto NewSafeZonePhase = ZoneIndex >= 0 ? ZoneIndex : GameMode->SafeZonePhase + 1;

    FFortSafeZoneDefinition* SafeZoneDef = &GameState->MapInfo->SafeZoneDefinition;

    TArray<float>& Durations = *(TArray<float>*)((__int64)SafeZoneDef + 0x1f8);
    TArray<float>& HoldDurations = *(TArray<float>*)((__int64)SafeZoneDef + 0x1E8);

    auto DurationSum = 0.f;
    for (auto& _v : Durations)
        DurationSum += _v;

    if (DurationSum == 0)
    {
        static UCurveTable* GameData = StaticLoadObject<UCurveTable>(UKismetStringLibrary::Conv_NameToString(GameState->CurrentPlaylistInfo.BasePlaylist->GameData.ObjectID.AssetPathName).ToString());

        if (!GameData)
            GameData = UObject::FindObject<UCurveTable>("AthenaGameData.AthenaGameData");

        auto ShrinkTime = UKismetStringLibrary::Conv_StringToName(FString(L"Default.SafeZone.ShrinkTime"));
        auto HoldTime = UKismetStringLibrary::Conv_StringToName(FString(L"Default.SafeZone.WaitTime"));

        for (int i = 0; i < Durations.Num(); i++)
        {
            UDataTableFunctionLibrary::EvaluateCurveTableRow(GameData, ShrinkTime, (float)i, nullptr, &Durations[i], FString());
        }
        for (int i = 0; i < HoldDurations.Num(); i++)
        {
            UDataTableFunctionLibrary::EvaluateCurveTableRow(GameData, HoldTime, (float)i, nullptr, &HoldDurations[i], FString());
        }
    }

    auto Duration = Durations[NewSafeZonePhase];
    auto HoldDuration = HoldDurations[NewSafeZonePhase];

    GameMode->SafeZoneIndicator->SafeZoneStartShrinkTime = (float)UGameplayStatics::GetTimeSeconds(UWorld::GetWorld()) + HoldDuration;
    GameMode->SafeZoneIndicator->SafeZoneFinishShrinkTime = GameMode->SafeZoneIndicator->SafeZoneStartShrinkTime + Duration;

    return SetZoneIndexOG(GameMode, ZoneIndex);
}

__int64 (*CompletePickupAnimationOG)(AFortPickup* Pickup);
__int64 CompletePickupAnimation(AFortPickup* Pickup)
{
	if (!Pickup) 
		return CompletePickupAnimationOG(Pickup);

	auto Statics = (UGameplayStatics*)UGameplayStatics::StaticClass()->DefaultObject;
	auto GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;

	if (GameState->WarmupCountdownEndTime - Statics->GetTimeSeconds(UWorld::GetWorld()) <= 5 && GameState->GamePhase == EAthenaGamePhase::Warmup)
		return CompletePickupAnimationOG(Pickup);

	FFortPickupLocationData& PickupLocationData = Pickup->PickupLocationData;
	AFortPlayerPawnAthena* Pawn = (AFortPlayerPawnAthena*)PickupLocationData.PickupTarget;
	AFortPlayerControllerAthena* PC = (AFortPlayerControllerAthena*)Pawn->Controller;
	FFortItemEntry& PickupEntry = Pickup->PrimaryPickupItemEntry;
	UFortItemDefinition* PickupItemDef = Pickup->PrimaryPickupItemEntry.ItemDefinition;
	FVector Loc = Pawn->K2_GetActorLocation();
	float MaxStackSize = GetMaxStack(PickupItemDef);
	int Items = 0;
	FFortItemEntry* FoundEntry = nullptr;
	bool Found = false;

	for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		FFortItemEntry& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

		if (IsPrimaryQuickbar(PickupItemDef) && IsPrimaryQuickbar(Entry.ItemDefinition))
		{
			if (Entry.ItemDefinition->GetName() == "AGID_Lotus_Mustache") {
				Items += 2;
			}
			else {
				Items++;
			}

			if (Items > 5)
			{
				for (size_t i2 = 0; i2 < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i2++)
				{
					if (PC->WorldInventory->Inventory.ReplicatedEntries[i2].ItemGuid == Entry.ItemGuid)
					{
						PC->WorldInventory->Inventory.ReplicatedEntries.RemoveSingle(i2);
						break;
					}
				}

				for (size_t i2 = 0; i2 < PC->WorldInventory->Inventory.ItemInstances.Num(); i2++)
				{
					if (PC->WorldInventory->Inventory.ItemInstances[i2]->ItemEntry.ItemGuid == Entry.ItemGuid)
					{
						PC->WorldInventory->Inventory.ItemInstances.RemoveSingle(i2);
						break;
					}
				}
			}
		}

		if (Entry.ItemDefinition == PickupItemDef && (Entry.Count < MaxStackSize))
		{
			FoundEntry = &PC->WorldInventory->Inventory.ReplicatedEntries[i];
		}
	}

	if (Items == 5 && IsPrimaryQuickbar(Pawn->CurrentWeapon->WeaponData))
	{
		FFortItemEntry* SwapEntry = nullptr;

		for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition == Pawn->CurrentWeapon->WeaponData)
			{
				SwapEntry = &PC->WorldInventory->Inventory.ReplicatedEntries[i];
				break;
			}
		}

		if (!SwapEntry || !SwapEntry->ItemDefinition)
			return CompletePickupAnimationOG(Pickup);


		float SwapMaxStackSize = GetMaxStack(SwapEntry->ItemDefinition);

		//proper? no but it works so idgaf
		bool CanMergePickup = false;
		if (PickupItemDef && PickupItemDef->IsStackable())
		{
			for (auto& Entry : PC->WorldInventory->Inventory.ReplicatedEntries)
			{
				if (Entry.ItemDefinition == PickupItemDef && Entry.Count < GetMaxStack(PickupItemDef))
				{
					CanMergePickup = true;
					break;
				}
			}
		}

		if (!CanMergePickup && (!SwapEntry->ItemDefinition->IsStackable() || SwapEntry->Count >= SwapMaxStackSize || SwapEntry->ItemDefinition != PickupItemDef))
		{
			FFortItemEntry* ItemEntry = nullptr;
			for (auto& Entry : PC->WorldInventory->Inventory.ReplicatedEntries)
			{
				if (Entry.ItemGuid == PC->MyFortPawn->CurrentWeapon->ItemEntryGuid)
				{
					ItemEntry = &Entry;
					break;
				}
			}

			if (ItemEntry)
			{
				PC->ServerAttemptInventoryDrop(ItemEntry->ItemGuid, ItemEntry->Count, false);
			}
		}
	}

	if (PickupEntry.ItemDefinition->IsStackable())
	{
		for (size_t i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			auto& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

			if (Entry.ItemDefinition == PickupItemDef)
			{
				Found = true;
				if ((MaxStackSize - Entry.Count) > 0)
				{
					Entry.Count += PickupEntry.Count;

					if (Entry.Count > MaxStackSize)
					{
						SpawnPickup(PickupItemDef, Entry.Count - MaxStackSize, Entry.LoadedAmmo, Loc, EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::Unset, (APlayerPawn_Athena_C*)PC->Pawn);
						Entry.Count = MaxStackSize;
					}

					PC->WorldInventory->Inventory.MarkItemDirty(Entry);
				}
				else
				{
					if (IsPrimaryQuickbar(PickupItemDef))
					{
						GiveItem(PC, PickupEntry.ItemDefinition, PickupEntry.Count, PickupEntry.LoadedAmmo);
					}
				}
				break;
			}
		}

		if (!Found)
		{
			GiveItem(PC, PickupEntry.ItemDefinition, PickupEntry.Count, PickupEntry.LoadedAmmo);
		}
	}
	else
	{
		GiveItem(PC, PickupEntry.ItemDefinition, PickupEntry.Count, PickupEntry.LoadedAmmo);
		PC->WorldInventory->HandleInventoryLocalUpdate();
		PC->WorldInventory->Inventory.MarkArrayDirty();
	}

	Pickup->K2_DestroyActor();
	return CompletePickupAnimationOG(Pickup);
}

//this deff needs a rewrite when i do teams
inline void (*ClientOnPawnDiedOG)(AFortPlayerControllerAthena*, FFortPlayerDeathReport);
inline void ClientOnPawnDied(AFortPlayerControllerAthena* DeadPC, FFortPlayerDeathReport DeathReport)
{

	Log("Pawn died");
	DeadPC->bMarkedAlive = false;

	auto GameState = (AFortGameStateAthena*)UWorld::GetWorld()->GameState;
	auto GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;
	AFortPlayerStateAthena* DeadState = (AFortPlayerStateAthena*)DeadPC->PlayerState;
	AFortPlayerPawnAthena* KillerPawn = (AFortPlayerPawnAthena*)DeathReport.KillerPawn;
	AFortPlayerStateAthena* KillerState = (AFortPlayerStateAthena*)DeathReport.KillerPlayerState;

	static bool Won = false;

	if (!GameState->IsRespawningAllowed(DeadState))
	{
		if (DeadPC && DeadPC->WorldInventory)
		{
			for (size_t i = 0; i < DeadPC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
			{
				if (((UFortWorldItemDefinition*)DeadPC->WorldInventory->Inventory.ReplicatedEntries[i].ItemDefinition)->bCanBeDropped)
				{
					SpawnPickup(DeadPC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemDefinition, DeadPC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.Count, DeadPC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.LoadedAmmo, DeadPC->Pawn->K2_GetActorLocation(), EFortPickupSourceTypeFlag::Player, EFortPickupSpawnSource::PlayerElimination, DeadPC->MyFortPawn);
				}
			}
		}
	}

	if (!Won && DeadPC && DeadState)
	{
		if (KillerState && KillerState != DeadState)
		{
			KillerState->KillScore++;

			for (size_t i = 0; i < KillerState->PlayerTeam->TeamMembers.Num(); i++)
			{
				((AFortPlayerStateAthena*)KillerState->PlayerTeam->TeamMembers[i]->PlayerState)->TeamKillScore++;
				((AFortPlayerStateAthena*)KillerState->PlayerTeam->TeamMembers[i]->PlayerState)->OnRep_TeamKillScore();
			}

			KillerState->ClientReportKill(DeadState);
			KillerState->OnRep_Kills();


			DeadState->PawnDeathLocation = DeadPC->Pawn->K2_GetActorLocation();
			FDeathInfo& DeathInfo = DeadState->DeathInfo;

			DeathInfo.bDBNO = DeadPC->MyFortPawn->bWasDBNOOnDeath;
			DeathInfo.bInitialized = true;
			DeathInfo.DeathLocation = DeadPC->Pawn->K2_GetActorLocation();
			DeathInfo.DeathTags = DeathReport.Tags;
			DeathInfo.Downer = KillerState;
			DeathInfo.Distance = (KillerPawn ? KillerPawn->GetDistanceTo(DeadPC->Pawn) : ((AFortPlayerPawnAthena*)DeadPC->Pawn)->LastFallDistance);
			DeathInfo.FinisherOrDowner = KillerState;
			DeathInfo.DeathCause = DeadState->ToDeathCause(DeathInfo.DeathTags, DeathInfo.bDBNO);
			DeadState->OnRep_DeathInfo();
			DeadPC->RespawnPlayerAfterDeath(true);
		}

		if (Won || !GameState->IsRespawningAllowed(DeadState))
		{
			FAthenaRewardResult Result;
			UFortPlayerControllerAthenaXPComponent* XPComponent = DeadPC->XPComponent;
			Result.TotalBookXpGained = XPComponent->TotalXpEarned;
			Result.TotalSeasonXpGained = XPComponent->TotalXpEarned;

			DeadPC->ClientSendEndBattleRoyaleMatchForPlayer(true, Result);

			FAthenaMatchStats Stats;
			FAthenaMatchTeamStats TeamStats;

			if (DeadState)
			{
				DeadState->Place = GameMode->AliveBots.Num() + GameMode->AlivePlayers.Num();
				DeadState->OnRep_Place();
			}

			for (size_t i = 0; i < 20; i++)
			{
				Stats.Stats[i] = 0;
			}

			Stats.Stats[3] = DeadState->KillScore;

			TeamStats.Place = DeadState->Place;
			TeamStats.TotalPlayers = GameState->TotalPlayers;

			DeadPC->ClientSendMatchStatsForPlayer(Stats);
			DeadPC->ClientSendTeamStatsForPlayer(TeamStats);
			FDeathInfo& DeathInfo = DeadState->DeathInfo;

			RemoveFromAlivePlayers(GameMode, DeadPC, (KillerState == DeadState ? nullptr : KillerState), KillerPawn, DeathReport.KillerWeapon ? DeathReport.KillerWeapon : nullptr, DeadState ? DeathInfo.DeathCause : EDeathCause::Rifle, 0);

			if (KillerState)
			{
				if (KillerState->Place == 1)
				{
					if (DeathReport.KillerWeapon)
					{
						((AFortPlayerControllerAthena*)KillerState->Owner)->PlayWinEffects(KillerPawn, DeathReport.KillerWeapon, EDeathCause::Rifle, false);
						((AFortPlayerControllerAthena*)KillerState->Owner)->ClientNotifyWon(KillerPawn, DeathReport.KillerWeapon, EDeathCause::Rifle);
					}

					FAthenaRewardResult Result;
					AFortPlayerControllerAthena* KillerPC = (AFortPlayerControllerAthena*)KillerState->GetOwner();
					KillerPC->ClientSendEndBattleRoyaleMatchForPlayer(true, Result);

					FAthenaMatchStats Stats;
					FAthenaMatchTeamStats TeamStats;

					for (size_t i = 0; i < 20; i++)
					{
						Stats.Stats[i] = 0;
					}

					Stats.Stats[3] = KillerState->KillScore;

					TeamStats.Place = 1;
					TeamStats.TotalPlayers = GameState->TotalPlayers;

					KillerPC->ClientSendMatchStatsForPlayer(Stats);
					KillerPC->ClientSendTeamStatsForPlayer(TeamStats);

					GameState->WinningPlayerState = KillerState;
					GameState->WinningTeam = KillerState->TeamIndex;
					GameState->OnRep_WinningPlayerState();
					GameState->OnRep_WinningTeam();
				}
			}
		}
	}

	return ClientOnPawnDiedOG(DeadPC, DeathReport);
}

void (*OnCapsuleBeginOverlapOG)(AFortPlayerPawn* Pawn, UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, FHitResult SweepResult);
void OnCapsuleBeginOverlap(AFortPlayerPawn* Pawn, UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, FHitResult SweepResult)
{
	if (OtherActor->IsA(AFortPickup::StaticClass()))
	{
		AFortPickup* Pickup = (AFortPickup*)OtherActor;

		if (Pickup->PawnWhoDroppedPickup == Pawn)
			return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);

		UFortWorldItemDefinition* Def = (UFortWorldItemDefinition*)Pickup->PrimaryPickupItemEntry.ItemDefinition;

		if (!Def) {
			return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
		}

		auto PC = (AFortPlayerControllerAthena*)Pawn->GetOwner();
		FFortItemEntry* FoundEntry = nullptr;
		auto HighestCount = 0;

		if (PC->IsA(ABP_PhoebePlayerController_C::StaticClass())) return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
		for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			FFortItemEntry& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

			if (Entry.ItemDefinition == Def && (Entry.Count <= GetMaxStack(Def)))
			{
				FoundEntry = &PC->WorldInventory->Inventory.ReplicatedEntries[i];
				if (Entry.Count > HighestCount)
					HighestCount = Entry.Count;
			}
		}
		if (Def->IsA(UFortAmmoItemDefinition::StaticClass()) || Def->IsA(UFortResourceItemDefinition::StaticClass()) || Def->IsA(UFortTrapItemDefinition::StaticClass())) {
			if (FoundEntry && HighestCount < GetMaxStack(Def)) {
				Pawn->ServerHandlePickup(Pickup, 0.40f, FVector(), true);
			}
			else if (!FoundEntry) {
				Pawn->ServerHandlePickup(Pickup, 0.40f, FVector(), true);
			}
		}
		else if (FoundEntry)
		{
			if (FoundEntry->Count < GetMaxStack(Def)) {
				Pawn->ServerHandlePickup(Pickup, 0.40f, FVector(), true);
			}
		}
	}

	return OnCapsuleBeginOverlapOG(Pawn, OverlappedComp, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
}