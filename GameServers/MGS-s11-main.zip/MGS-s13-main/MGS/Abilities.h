
#pragma once
#pragma once
#include <string>
#include "Utils.h"
#include <vector>
#include <map>

FGameplayAbilitySpec* GiveAbility(AFortPlayerController* PC, UClass* GameplayAbilityClass, UObject* CertainDef)
{
	if (!PC || !GameplayAbilityClass || !PC->MyFortPawn) {
		return nullptr;
	}

	auto AbilitySystemComponent = PC->MyFortPawn->AbilitySystemComponent;

	FGameplayAbilitySpec Spec{};

	SpecConstructor(&Spec, (UGameplayAbility*)GameplayAbilityClass->DefaultObject, 1, -1, CertainDef);
	GiveAbilityAndActivateOnce(AbilitySystemComponent, &Spec.Handle, Spec);

	return &Spec;
}

inline void GivePlayerAbilities(AFortPlayerController* PC)
{
	AFortPlayerStateAthena* PlayerState = (AFortPlayerStateAthena*)PC->PlayerState;

	UFortAbilitySet* AbilitySet = StaticLoadObject<UFortAbilitySet>("/Game/Abilities/Player/Generic/Traits/DefaultPlayer/GAS_AthenaPlayer.GAS_AthenaPlayer");

	if (PlayerState && AbilitySet)
	{
		for (int i = 0; i < AbilitySet->GameplayAbilities.Num(); i++)
		{
			if (((AFortPlayerStateAthena*)PC->PlayerState)->AbilitySystemComponent)
			{
				if (AbilitySet->GameplayAbilities[i].Get())
				{
					GiveAbility(PC, AbilitySet->GameplayAbilities[i].Get(), nullptr);
				}
			}
		}

	}
}

inline void InternalServerTryActivateAbility(UAbilitySystemComponent* AbilitySystemComponent, FGameplayAbilitySpecHandle Handle, bool InputPressed, FPredictionKey& PredictionKey, FGameplayEventData* TriggerEventData)
{
	FGameplayAbilitySpec* Spec = nullptr;

	for (size_t i = 0; i < AbilitySystemComponent->ActivatableAbilities.Items.Num(); i++)
	{
		if (AbilitySystemComponent->ActivatableAbilities.Items[i].Handle.Handle == Handle.Handle)
		{
			Spec = &AbilitySystemComponent->ActivatableAbilities.Items[i];
			break;
		}
	}

	if (!Spec)
		return AbilitySystemComponent->ClientActivateAbilityFailed(Handle, PredictionKey.Current);

	UGameplayAbility* AbilityToActivate = Spec->Ability;
	UGameplayAbility* InstancedAbility = nullptr;
	Spec->InputPressed = true;

	if (!InternalTryActivateAbility(AbilitySystemComponent, Handle, PredictionKey, &InstancedAbility, nullptr, TriggerEventData))
	{
		AbilitySystemComponent->ClientActivateAbilityFailed(Handle, PredictionKey.Current);
		Spec->InputPressed = false;
	}

	AbilitySystemComponent->ActivatableAbilities.MarkItemDirty(*Spec);
}

static void GiveModifiers(AFortPlayerControllerAthena* PC)
{
	if (!PC)
		return;

	AFortPawn* Pawn = PC->MyFortPawn;
	if (!Pawn)
		return;
	UWorld* World = UWorld::GetWorld();

	auto* GameState = (AFortGameStateAthena*)World->GameState;
	if (!GameState || !GameState->CurrentPlaylistInfo.BasePlaylist)
		return;

	const auto& ModifierList = GameState->CurrentPlaylistInfo.BasePlaylist->ModifierList;

	for (const auto& ModifierObj : ModifierList)
	{
		UFortGameplayModifierItemDefinition* ModifierDef = ModifierObj.Get();
		if (!ModifierDef)
			continue;

		for (const auto& PersistentSet : ModifierDef->PersistentAbilitySets)
		{
			if (!PersistentSet.DeliveryRequirements.bApplyToPlayerPawns)
				continue;

			for (const auto& AbilitySet : PersistentSet.AbilitySets)
			{
				UFortAbilitySet* Set = AbilitySet.Get();
				if (!Set)
					continue;

				for (int32 i = 0; i < Set->GameplayAbilities.Num(); i++)
				{
					if (UClass* Ability = Set->GameplayAbilities[i].Get())
					{
						GiveAbility(PC, Ability, nullptr);
					}
				}
			}
		}

		for (const auto& PersistentEffect : ModifierDef->PersistentGameplayEffects)
		{
			if (!PersistentEffect.DeliveryRequirements.bApplyToPlayerPawns)
				continue;

			for (const auto& EffectData : PersistentEffect.GameplayEffects)
			{
				auto* ASC = Pawn->AbilitySystemComponent;
				if (ASC && EffectData.GameplayEffect.Get())
				{
					ASC->BP_ApplyGameplayEffectToSelf(EffectData.GameplayEffect.Get(), EffectData.Level, ASC->MakeEffectContext());
				}
			}
		}
	}
}
