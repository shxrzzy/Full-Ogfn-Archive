#pragma once
#include "Utils.h"
#include <numeric>

bool IsPrimaryQuickbar(UFortItemDefinition* ItemDefinition)
{
	if (!ItemDefinition->IsA(UFortWeaponMeleeItemDefinition::StaticClass()) && !ItemDefinition->IsA(UFortEditToolItemDefinition::StaticClass()) &&
		!ItemDefinition->IsA(UFortBuildingItemDefinition::StaticClass()) && !ItemDefinition->IsA(UFortAmmoItemDefinition::StaticClass()) &&
		!ItemDefinition->IsA(UFortResourceItemDefinition::StaticClass()) && !ItemDefinition->IsA(UFortTrapItemDefinition::StaticClass())
		&& !ItemDefinition->IsA(AFortWeaponRangedForVehicle::StaticClass()))
		return true;

	return false;
}

float GetMaxStack(UFortItemDefinition* Def)
{
	if (!Def->MaxStackSize.Curve.CurveTable)
		return Def->MaxStackSize.Value;
	EEvaluateCurveTableResult Result;
	float Ret;
	((UDataTableFunctionLibrary*)UDataTableFunctionLibrary::StaticClass()->DefaultObject)->EvaluateCurveTableRow(Def->MaxStackSize.Curve.CurveTable, Def->MaxStackSize.Curve.RowName, 0, &Result, &Ret, FString());
	return Ret;
}

FFortItemEntry* GiveItem(AFortPlayerController* PC, UFortItemDefinition* Def, int Count, int LoadedAmmo)
{
	if (!PC || !Def || Count <= 0)
		return nullptr;

	UFortWorldItem* Item = Cast<UFortWorldItem>(Def->CreateTemporaryItemInstanceBP(Count, 0));
	if (!Item)
		return nullptr;

	Item->SetOwningControllerForTemporaryItem(PC);
	Item->OwnerInventory = PC->WorldInventory;
	Item->ItemEntry.ItemDefinition = Def;
	Item->ItemEntry.Count = Count;
	Item->ItemEntry.LoadedAmmo = LoadedAmmo;

	if (Def->IsA(UFortAmmoItemDefinition::StaticClass()) || Def->IsA(UFortResourceItemDefinition::StaticClass()))
	{
		FFortItemEntryStateValue Value{};
		Value.IntValue = true;
		Value.StateType = EFortItemEntryState::ShouldShowItemToast;
		Item->ItemEntry.StateValues.Add(Value);
	}

	Item->ItemEntry.ReplicationKey++;

	PC->WorldInventory->Inventory.ReplicatedEntries.Add(Item->ItemEntry);
	PC->WorldInventory->Inventory.ItemInstances.Add(Item);

	if (auto Gadget = Cast<UFortGadgetItemDefinition>(Def))
	{
		((bool(*)(UFortGadgetItemDefinition*, IInterface*, UFortWorldItem*, uint8)) (InSDKUtils::GetImageBase() + 0x22f3c70))(Gadget, GetInterface<IFortInventoryOwnerInterface>(PC), Item, 1);
	}

	PC->WorldInventory->Inventory.MarkItemDirty(Item->ItemEntry);
	PC->WorldInventory->HandleInventoryLocalUpdate();

	return &Item->ItemEntry;
}

void RemoveItem(AFortPlayerController* PC, UFortItemDefinition* Def, int Count, FGuid Guid)
{
	bool Remove = false;

	for (int i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		auto& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

		if (Entry.ItemGuid == Guid)
		{
			Entry.Count -= Count;

			if (Entry.Count <= 0)
			{
				Entry.StateValues.Free();
				PC->WorldInventory->Inventory.ReplicatedEntries.RemoveSingle(i);
				Remove = true;
			}
			else
			{
				PC->WorldInventory->Inventory.MarkItemDirty(Entry);

				for (int j = 0; j < PC->WorldInventory->Inventory.ItemInstances.Num(); j++)
				{
					if (PC->WorldInventory->Inventory.ItemInstances[j]->ItemEntry.ItemGuid == Guid)
					{
						PC->WorldInventory->Inventory.ItemInstances[j]->ItemEntry = Entry;
						PC->WorldInventory->Inventory.MarkItemDirty(Entry);
						break;
					}
				}

				PC->WorldInventory->HandleInventoryLocalUpdate();
				return;
			}

			break;
		}
	}

	if (Remove)
	{
		for (int i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
		{
			if (PC->WorldInventory->Inventory.ItemInstances[i]->GetItemGuid() == Guid)
			{
				if (auto Gadget = Cast<UFortGadgetItemDefinition>(PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemDefinition))
				{
				   ((bool(*)(UFortGadgetItemDefinition*, IInterface*, UFortWorldItem*)) (InSDKUtils::GetImageBase() + 0x22f3d30))(Gadget, GetInterface<IFortInventoryOwnerInterface>(PC), PC->WorldInventory->Inventory.ItemInstances[i]);
				}
				PC->WorldInventory->Inventory.ItemInstances.RemoveSingle(i);
				break;
			}
		}
	}

	PC->WorldInventory->Inventory.MarkArrayDirty();
	PC->WorldInventory->HandleInventoryLocalUpdate();
}

__int64 (*OnReloadOG)(AFortWeapon* Weapon, int RemoveCount);
__int64 OnReload(AFortWeapon* Weapon, int RemoveCount)
{
	Log("Called onreload");
	AFortGameModeAthena* GameMode = (AFortGameModeAthena*)UWorld::GetWorld()->AuthorityGameMode;

	auto GameState = (AFortGameStateAthena*)GameMode->GameState;

	auto Ret = OnReloadOG(Weapon, RemoveCount);
	auto WeaponDef = Weapon->WeaponData;
	if (!WeaponDef)
		return Ret;

	auto AmmoDef = WeaponDef->GetAmmoWorldItemDefinition_BP();
	if (!AmmoDef)
		return Ret;

	AFortPlayerPawnAthena* Pawn = (AFortPlayerPawnAthena*)Weapon->GetOwner();
	AFortPlayerControllerAthena* PC = (AFortPlayerControllerAthena*)Pawn->Controller;
	AFortPlayerStateAthena* PlayerState = (AFortPlayerStateAthena*)PC->PlayerState;
	if (!PC || !PC->Pawn || !PC->IsA(AFortPlayerControllerAthena::StaticClass()) || &PC->WorldInventory->Inventory == nullptr || GameState->GamePhase >= EAthenaGamePhase::EndGame)
		return Ret;

	if (PC->bInfiniteAmmo) {
		for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Weapon->ItemEntryGuid)
			{
				PC->WorldInventory->Inventory.ReplicatedEntries[i].LoadedAmmo += RemoveCount;
				for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
				{
					if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid)
					{
						PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry = PC->WorldInventory->Inventory.ReplicatedEntries[i];
						PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
						break;
					}
				}
				PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
				break;
			}
		}
		return Ret;
	}

	int AmmoCount = 0;
	FFortItemEntry* FoundEntry = nullptr;
	for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
	{
		FFortItemEntry& Entry = PC->WorldInventory->Inventory.ReplicatedEntries[i];

		if (Entry.ItemDefinition == AmmoDef) {
			AmmoCount = Entry.Count;
			FoundEntry = &Entry;
			break;
		}
	}

	int AmmoToRemove = (RemoveCount < AmmoCount) ? RemoveCount : AmmoCount;

	if (AmmoToRemove > 0) {
		RemoveItem(PC, AmmoDef, AmmoToRemove, FoundEntry->ItemGuid);
		for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Weapon->ItemEntryGuid)
			{
				PC->WorldInventory->Inventory.ReplicatedEntries[i].LoadedAmmo += AmmoToRemove;
				for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
				{
					if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid)
					{
						PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry = PC->WorldInventory->Inventory.ReplicatedEntries[i];
						PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
						break;
					}
				}
				PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
				break;
			}
		}

	}

	PC->WorldInventory->bRequiresLocalUpdate = true;
	PC->WorldInventory->HandleInventoryLocalUpdate();

	return Ret;
}

inline void (*NetMulticastDamageCuesOG)(AFortPawn* Pawn, void* SharedData, void* NonSharedData);
inline void NetMulticastDamageCues(AFortPawn* Pawn, void* SharedData, void* NonSharedData)
{
	if (!Pawn || Pawn->Controller->IsA(ABP_PhoebePlayerController_C::StaticClass()) || !NetMulticastDamageCuesOG)
		return;

	auto PC = (AFortPlayerController*)Pawn->Controller;
	auto Weapon = ((AFortPlayerPawn*)Pawn)->CurrentWeapon;

	if (Weapon)
	{
		for (int32 i = 0; i < PC->WorldInventory->Inventory.ReplicatedEntries.Num(); i++)
		{
			if (PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid == Weapon->ItemEntryGuid)
			{
				PC->WorldInventory->Inventory.ReplicatedEntries[i].LoadedAmmo = Weapon->AmmoCount;
				for (size_t i = 0; i < PC->WorldInventory->Inventory.ItemInstances.Num(); i++)
				{
					if (PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry.ItemGuid == PC->WorldInventory->Inventory.ReplicatedEntries[i].ItemGuid)
					{
						PC->WorldInventory->Inventory.ItemInstances[i]->ItemEntry = PC->WorldInventory->Inventory.ReplicatedEntries[i];
						PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
						break;
					}
				}
				PC->WorldInventory->Inventory.MarkItemDirty(PC->WorldInventory->Inventory.ReplicatedEntries[i]);
				break;
			}
		}
	}

	return NetMulticastDamageCuesOG(Pawn, SharedData, NonSharedData);
}
