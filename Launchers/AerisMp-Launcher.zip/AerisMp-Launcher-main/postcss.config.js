// Empty PostCSS config — overrides any postcss.config.mjs found in parent directories.
// This project uses @tailwindcss/vite (Tailwind v4), which handles CSS via Vite directly
// and does not need PostCSS.
export default {
  plugins: {},
};
