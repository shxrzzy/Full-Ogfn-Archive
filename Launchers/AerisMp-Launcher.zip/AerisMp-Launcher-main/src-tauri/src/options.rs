pub fn cdn_base_url() -> &'static str {
    "http://194.62.29.203/launcher-updates"
}

pub fn launcher_version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}
