use std::ffi::{CString, OsStr, OsString};
use std::fs;
use std::mem::zeroed;
use std::os::windows::process::CommandExt;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use winapi::shared::windef::HWND;
use winapi::um::processthreadsapi::GetProcessId;
use winapi::um::shellapi::{ShellExecuteExA, SEE_MASK_NOCLOSEPROCESS, SHELLEXECUTEINFOA};
use winapi::um::{handleapi::CloseHandle, winbase::CREATE_SUSPENDED, winuser::SW_SHOW};

use tauri::Emitter;
use tauri::Window;

use crate::utilities;

use serde::Deserialize;

#[derive(Debug, Deserialize)]
pub struct PakFile {
    pub name: String,
    pub size: u64,
}

const CREATE_NO_WINDOW: u32 = 0x08000000;

fn get_remote_file_size(url: &str) -> Result<u64, String> {
    let client = reqwest::blocking::Client::new();
    let response = client
        .head(url)
        .send()
        .map_err(|e| format!("Failed to get file info: {}", e))?;

    response
        .headers()
        .get(reqwest::header::CONTENT_LENGTH)
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.parse::<u64>().ok())
        .ok_or_else(|| "Could not determine remote file size".to_string())
}

fn should_skip_download(local_path: &Path, remote_url: &str) -> Result<bool, String> {
    if !local_path.exists() {
        return Ok(false);
    }

    let local_size = fs::metadata(local_path)
        .map_err(|e| format!("Failed to get local file size: {}", e))?
        .len();

    match get_remote_file_size(remote_url) {
        Ok(remote_size) => Ok(local_size == remote_size),
        Err(_) => Ok(false),
    }
}

#[tauri::command]
pub fn launch_game(
    window: Window,
    file_path: String,
    email: String,
    password: String,
    redirect_link: String,
    backend: String,
    inject_extra_dlls: bool,
    extra_dll_links: Vec<String>,
    use_custom_paks: bool,
    custom_paks_links: Vec<String>,
    extra_dll_options: Vec<std::collections::HashMap<String, String>>,
    pak_files_whitelist: Vec<PakFile>,
    backend_url: String,
    access_token: String,
    account_id: String,
) -> Result<bool, String> {
    let window = window.clone();
    let file_path = file_path.clone();
    let email = email.clone();
    let password = password.clone();
    let redirect_link = redirect_link.clone();
    let backend = backend.clone();
    let backend_url_ac = backend_url.clone();
    let access_token_ac = access_token.clone();
    let account_id_ac = account_id.clone();
    let window_ac = window.clone();

    std::thread::spawn(move || {
        if let Err(err) = run_launch(
            window.clone(),
            file_path,
            email,
            password,
            redirect_link,
            backend,
            inject_extra_dlls,
            extra_dll_links,
            use_custom_paks,
            custom_paks_links,
            extra_dll_options,
            pak_files_whitelist,
        ) {
            eprintln!("Background launch failed: {}", err);
            let _ = window.emit("launch-error", serde_json::json!({ "error": err }));
            return;
        }

        // Game launched — wait for process to stabilize, then start anticheat scanner
        std::thread::sleep(std::time::Duration::from_secs(15));
        
        println!("[AC] Starting anticheat after game launch");
        let rt = tokio::runtime::Runtime::new().unwrap();
        rt.block_on(super::anticheat::start_anticheat(
            window_ac,
            backend_url_ac,
            access_token_ac,
            account_id_ac,
        ))
        .ok();
    });

    Ok(true)
}

fn run_launch(
    window: Window,
    file_path: String,
    email: String,
    password: String,
    redirect_link: String,
    backend: String,
    inject_extra_dlls: bool,
    extra_dll_links: Vec<String>,
    use_custom_paks: bool,
    custom_paks_links: Vec<String>,
    extra_dll_options: Vec<std::collections::HashMap<String, String>>,
    pak_files_whitelist: Vec<PakFile>,
) -> Result<(), String> {
    let _ = utilities::kill_all_procs();

    let game_path = PathBuf::from(&file_path);
    let game_game_directory: &Path = game_path
        .parent()
        .expect("Failed to get parent directory")
        .parent()
        .expect("Failed to get FortniteGame directory");

    let game_dll_path = utilities::handle_game_dll_path(game_game_directory);

    if game_dll_path.exists() {
        if let Err(err) = utilities::remove_game_dll_sync(game_game_directory) {
            return Err(format!("Failed to remove game DLL: {}", err));
        }
    }

    let dll_url = &format!("{}", redirect_link);

    match should_skip_download(&game_dll_path, dll_url) {
        Ok(true) => {
            let _ = window.emit(
                "download-progress",
                serde_json::json!({
                    "type": "main_dll",
                    "file": game_dll_path.file_name().unwrap_or_default().to_string_lossy(),
                    "progress": 100,
                    "stage": "skipped"
                }),
            );
        }
        _ => {
            if let Err(err) = utilities::download_file(dll_url, &game_dll_path) {
                return Err(format!("Failed to download game DLL: {}", err));
            }
        }
    }

    let cwd = game_game_directory.join("Win64");

    let fn_launcher = cwd.join("FortniteLauncher.exe");
    let fn_shipping = cwd.join("FortniteClient-Win64-Shipping.exe");
    let eac = cwd.join("FortniteClient-Win64-Shipping_BE.exe");

    if !game_dll_path.exists() {
        return Err("Failed to find Redirect".to_string());
    }

    let mut combined_args = vec![
        "-epicapp=Fortnite",
        "-epicenv=Prod",
        "-epiclocale=en-us",
        "-epicportal",
        "-nobe",
        "-fromfl=eac",
        "-nocodeguards",
        "-nouac",
        "-fltoken=3db3ba5dcbd2e16703f3978d",
        "-caldera=eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2NvdW50X2lkIjoiYmU5ZGE1YzJmYmVhNDQwN2IyZjQwZWJhYWQ4NTlhZDQiLCJnZW5lcmF0ZWQiOjE2Mzg3MTcyNzgsImNhbGRlcmFHdWlkIjoiMzgxMGI4NjMtMmE2NS00NDU3LTliNTgtNGRhYjNiNDgyYTg2IiwiYWNQcm92aWRlciI6IkVhc3lBbnRpQ2hlYXQiLCJub3RlcyI6IiIsImZhbGxiYWNrIjpmYWxzZX0.VAWQB67RTxhiWOxx7DBjnzDnXyyEnX7OljJm-j2d88G_WgwQ9wrE6lwMEHZHjBd1ISJdUO1UVUqkfLdU5nofBQs",
        "-skippatchcheck",
        "-AUTH_TYPE=epic",
        "-useallavailablecores",
        "-steamimportavailable",
    ]
    .into_iter()
    .map(|s| s.to_string())
    .collect::<Vec<String>>();

    combined_args.insert(combined_args.len() - 3, format!("-AUTH_LOGIN={}", email));
    combined_args.insert(
        combined_args.len() - 3,
        format!("-AUTH_PASSWORD={}", password),
    );

    if redirect_link == "https://ttttttttttttttttttttttttttttttttttt.vercel.app/Tellurium.dll" {
        combined_args.push(format!("-backend={}", backend));
    }

    let paks_dir = game_path
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .join("Content")
        .join("Paks");

    std::fs::create_dir_all(&paks_dir).map_err(|e| format!("Failed to create Paks dir: {}", e))?;

    if !pak_files_whitelist.is_empty() {
        let mut validation_errors = Vec::new();

        let paks_entries = std::fs::read_dir(&paks_dir)
            .map_err(|e| format!("Failed to read Paks directory: {}", e))?;

        for entry in paks_entries {
            let entry = entry.map_err(|e| format!("Failed to read directory entry: {}", e))?;
            let path = entry.path();

            if let Some(extension) = path.extension() {
                if extension != "pak" && extension != "sig" {
                    continue;
                }
            } else {
                continue;
            }

            let filename = path
                .file_name()
                .and_then(|n| n.to_str())
                .ok_or("Invalid filename")?;

            let whitelisted = pak_files_whitelist.iter().find(|pak| pak.name == filename);

            match whitelisted {
                Some(pak_info) => {
                    let local_size = fs::metadata(&path)
                        .map_err(|e| format!("Failed to get file size for {}: {}", filename, e))?
                        .len();

                    if local_size != pak_info.size {
                        validation_errors.push(format!(
                            "{} (expected: {} bytes, found: {} bytes)",
                            filename, pak_info.size, local_size
                        ));
                    }
                }
                None => {
                    if let Err(e) = fs::remove_file(&path) {
                        let _ = window.emit(
                            "verify-build",
                            serde_json::json!({
                                "file": filename,
                                "status": "failed",
                                "error": e.to_string()
                            }),
                        );
                    } else {
                        let _ = window.emit(
                            "verify-build",
                            serde_json::json!({
                                "file": filename,
                                "status": "deleted" }),
                        );
                    }
                }
            }
        }

        if !validation_errors.is_empty() {
            let _ = window.emit(
                "build-validation-error",
                serde_json::json!({
                    "message": "Build may be corrupted - file size mismatches detected",
                    "errors": validation_errors
                }),
            );

            return Err(format!(
                "Build validation failed. The following files have incorrect sizes:\n{}",
                validation_errors.join("\n")
            ));
        }
    }

    if use_custom_paks && !custom_paks_links.is_empty() {
        for (idx, link) in custom_paks_links.iter().enumerate() {
            let link = link.trim();
            if link.is_empty() {
                continue;
            }

            let clean_url = link.split('?').next().unwrap_or(link);

            let filename = match clean_url.rsplit('/').next() {
                Some(name) if !name.is_empty() => name.to_string(),
                _ => format!("CustomPak_{}.pak", idx),
            };

            let save_path = paks_dir.join(&filename);

            match should_skip_download(&save_path, link) {
                Ok(true) => {
                    let _ = window.emit(
                        "download-progress",
                        serde_json::json!({
                            "type": "pak",
                            "file": filename,
                            "progress": 100,
                            "stage": "skipped"
                        }),
                    );
                }
                _ => {
                    let _ = window.emit(
                        "download-progress",
                        serde_json::json!({
                            "type": "pak",
                            "file": filename,
                            "progress": 0
                        }),
                    );

                    if let Err(err) = utilities::download_file(link, &save_path) {
                        return Err(format!("Failed to download custom pak '{}': {}", link, err));
                    }

                    let _ = window.emit(
                        "download-progress",
                        serde_json::json!({
                            "type": "pak",
                            "file": filename,
                            "progress": 100
                        }),
                    );
                }
            }
        }
    }

    let combined_args_os: Vec<OsString> = combined_args
        .iter()
        .map(|arg| OsString::from(arg))
        .collect();

    let combined_args_str: String = combined_args_os
        .iter()
        .map(|s| s.to_string_lossy())
        .collect::<Vec<_>>()
        .join(" ");

    let hwnd: HWND = std::ptr::null_mut();

    let exe_str = fn_shipping.to_str().ok_or("Invalid path to executable")?;
    let exe_cstring = CString::new(exe_str).map_err(|e| format!("CString error: {}", e))?;

    let args_cstring =
        CString::new(combined_args_str).map_err(|e| format!("CString error: {}", e))?;

    let lp_file = exe_cstring;
    let lp_params = args_cstring;
    let lp_verb = CString::new("runas").unwrap();

    let mut sei: SHELLEXECUTEINFOA = unsafe { zeroed() };
    sei.cbSize = std::mem::size_of::<SHELLEXECUTEINFOA>() as u32;
    sei.fMask = SEE_MASK_NOCLOSEPROCESS;
    sei.hwnd = hwnd;
    sei.lpVerb = lp_verb.as_ptr();
    sei.lpFile = lp_file.as_ptr();
    sei.lpParameters = lp_params.as_ptr();
    sei.nShow = SW_SHOW;

    let success = unsafe { ShellExecuteExA(&mut sei) };
    if success == 0 {
        return Err("ShellExecuteExA failed".to_string());
    }

    if sei.hProcess.is_null() {
        return Err("Failed to get process handle".to_string());
    }

    let pid = unsafe { GetProcessId(sei.hProcess) };
    unsafe { CloseHandle(sei.hProcess) };

    // Lock down the process so injector tools can't open it with write access
    utilities::protect_process(pid);

    std::thread::sleep(std::time::Duration::from_secs(5));

    let _eac_proc = Command::new(&eac)
        .creation_flags(CREATE_NO_WINDOW | CREATE_SUSPENDED)
        .args(
            combined_args_os
                .iter()
                .map(|arg| arg as &OsStr)
                .collect::<Vec<&OsStr>>(),
        )
        .stdout(Stdio::piped())
        .spawn()
        .map_err(|e| format!("Failed to start EAC: {}", e));

    let _launcher_proc = Command::new(&fn_launcher)
        .creation_flags(CREATE_NO_WINDOW | CREATE_SUSPENDED)
        .args(
            combined_args_os
                .iter()
                .map(|arg| arg as &OsStr)
                .collect::<Vec<&OsStr>>(),
        )
        .stdout(Stdio::piped())
        .spawn()
        .map_err(|e| format!("Failed to start Launcher: {}", e));

    std::thread::sleep(std::time::Duration::from_secs(12));

    if inject_extra_dlls {
        for (idx, link) in extra_dll_links.iter().enumerate() {
            if link.trim().is_empty() {
                continue;
            }

            let clean_url = link.split('?').next().unwrap_or(link);

            let filename = match clean_url.rsplit('/').next() {
                Some(name) if !name.is_empty() => name.replace('%', "_"),
                _ => format!("ExtraDll_{}.dll", idx),
            };

            let save_path = game_game_directory.join("Win64").join(&filename);

            match should_skip_download(&save_path, link) {
                Ok(true) => {
                    let _ = window.emit(
                        "download-progress",
                        serde_json::json!({
                            "type": "dll",
                            "file": filename,
                            "progress": 100,
                            "stage": "skipped"
                        }),
                    );
                }
                _ => {
                    let _ = window.emit(
                        "download-progress",
                        serde_json::json!({
                            "type": "dll",
                            "file": filename,
                            "progress": 0
                        }),
                    );

                    if let Err(err) = utilities::download_file(link, &save_path) {
                        return Err(format!("Failed to download extra DLL '{}': {}", link, err));
                    }

                    let _ = window.emit(
                        "download-progress",
                        serde_json::json!({
                            "type": "dll",
                            "file": filename,
                            "progress": 100
                        }),
                    );
                }
            }

            utilities::inject_dll(pid, save_path.to_str().ok_or("Invalid DLL path")?).map_err(
                |e| {
                    format!(
                        "Failed to inject extra DLL '{}': {}",
                        save_path.display(),
                        e
                    )
                },
            )?;

            std::thread::sleep(std::time::Duration::from_millis(300));
        }

        for option in extra_dll_options.iter() {
            for (_key, link) in option.iter() {
                if link.trim().is_empty() {
                    continue;
                }

                let clean_link = link.split('?').next().unwrap_or(link);

                let filename = match clean_link.rsplit('/').next() {
                    Some(name) if !name.is_empty() => name.replace('%', "_"),
                    _ => "OptionDll.dll".to_string(),
                };

                let save_path = game_game_directory.join("Win64").join(&filename);

                match should_skip_download(&save_path, link) {
                    Ok(true) => {
                        let _ = window.emit(
                            "download-progress",
                            serde_json::json!({
                                "type": "dll",
                                "file": filename,
                                "progress": 100,
                                "stage": "skipped"
                            }),
                        );
                    }
                    _ => {
                        let _ = window.emit(
                            "download-progress",
                            serde_json::json!({
                                "type": "dll",
                                "file": filename,
                                "progress": 0
                            }),
                        );

                        if let Err(err) = utilities::download_file(link, &save_path) {
                            return Err(format!(
                                "Failed to download option DLL '{}': {}",
                                link, err
                            ));
                        }

                        let _ = window.emit(
                            "download-progress",
                            serde_json::json!({
                                "type": "dll",
                                "file": filename,
                                "progress": 100
                            }),
                        );
                    }
                }

                utilities::inject_dll(pid, save_path.to_str().ok_or("Invalid DLL path")?).map_err(
                    |e| {
                        format!(
                            "Failed to inject option DLL '{}': {}",
                            save_path.display(),
                            e
                        )
                    },
                )?;

                std::thread::sleep(std::time::Duration::from_millis(300));
            }
        }
    }

    Ok(())
}

#[tauri::command]
pub fn close_game() -> Result<(), String> {
    let _ = utilities::kill_all_procs();
    Ok(())
}
