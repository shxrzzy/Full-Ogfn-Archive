use std::ffi::CStr;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use sysinfo::{ProcessExt, System, SystemExt};
use tauri::{Emitter, Manager, Window};
use winapi::shared::minwindef::{DWORD, HMODULE, MAX_PATH};
use winapi::um::psapi::{EnumProcessModules, GetModuleFileNameExA};
use winapi::um::processthreadsapi::OpenProcess;
use winapi::um::handleapi::CloseHandle;
use winapi::um::winnt::{PROCESS_QUERY_INFORMATION, PROCESS_VM_READ};

// ── Known cheat process names ────────────────────────────────────────────────
const CHEAT_PROCESSES: &[&str] = &[
    "cheatengine",
    "cheatengine-x86_64",
    "cheatengine-i386",
    "x64dbg",
    "x32dbg",
    "ollydbg",
    "ida64",
    "ida",
    "idaq",
    "idaq64",
    "windbg",
    "processhacker",
    "processhacker2",
    "process hacker",
    "artmoney",
    "tsearch",
    "pkhacker",
    "wireshark",
    "fiddler",
    "charles",
    "httpdebugger",
    "httpdebuggerui",
    "proxifier",
    "reclass",
    "reclass.net",
    "dnspy",
    "de4dot",
    "dotpeek",
    "ilspy",
    "reflexil",
    "scylla",
    "scylla_x64",
    "scylla_x86",
    "lordpe",
    "peid",
    "exeinfope",
    "die",
    "detect-it-easy",
    "hxd",
    "hexworkshop",
    "010editor",
    "wpe pro",
    "wpepro",
    "injector",
    "extreme injector",
    "xenos",
    "xenos64",
    "gdinjector",
    "remoteinjector",
    "dllinjector",
    "manual map",
    "manualmap",
    "kiero",
    "minhook",
    "reshade",
    "fraps",
    "afterburner",
    "rtss",
    "nohboard",
    "autohotkey",
    "autohotkey_l",
    "ahk",
    "autoit3",
    "autoit",
    "macro",
    "logitech ghub",
    "lghub",
    "razer synapse",
    "synapse3",
    "corsair icue",
    "icue",
    "steelseries gg",
    "ggapp",
];

const MAX_WARNINGS: u32 = 3;

static SCAN_RUNNING: AtomicBool = AtomicBool::new(false);

// ── Strike persistence ───────────────────────────────────────────────────────

fn strikes_path(window: &Window) -> PathBuf {
    window
        .app_handle()
        .path()
        .app_data_dir()
        .unwrap_or_else(|_| PathBuf::from("."))
        .join("ac_strikes.json")
}

fn load_strikes(window: &Window, account_id: &str) -> u32 {
    let path = strikes_path(window);
    if let Ok(data) = std::fs::read_to_string(&path) {
        if let Ok(map) = serde_json::from_str::<serde_json::Value>(&data) {
            return map
                .get(account_id)
                .and_then(|v| v.as_u64())
                .unwrap_or(0) as u32;
        }
    }
    0
}

fn save_strikes(window: &Window, account_id: &str, strikes: u32) {
    let path = strikes_path(window);
    let mut map: serde_json::Map<String, serde_json::Value> = std::fs::read_to_string(&path)
        .ok()
        .and_then(|d| serde_json::from_str(&d).ok())
        .unwrap_or_default();

    map.insert(account_id.to_string(), serde_json::json!(strikes));

    let _ = std::fs::create_dir_all(path.parent().unwrap_or(&PathBuf::from(".")));
    let _ = std::fs::write(&path, serde_json::to_string_pretty(&map).unwrap_or_default());
}

// ── Process helpers ──────────────────────────────────────────────────────────

fn get_fortnite_pid() -> Option<u32> {
    let mut sys = System::new_all();
    sys.refresh_processes();
    for (pid, proc) in sys.processes() {
        if proc
            .name()
            .to_lowercase()
            .contains("fortniteclient-win64-shipping")
        {
            return Some(pid.to_string().parse::<u32>().unwrap_or(0));
        }
    }
    None
}

fn kill_fortnite() {
    let procs = [
        "FortniteClient-Win64-Shipping.exe",
        "FortniteLauncher.exe",
        "FortniteClient-Win64-Shipping_BE.exe",
        "FortniteClient-Win64-Shipping_EAC.exe",
        "EasyAntiCheat_EOS.exe",
    ];
    let mut sys = System::new_all();
    sys.refresh_processes();
    for proc in sys.processes().values() {
        if procs.iter().any(|p| proc.name().eq_ignore_ascii_case(p)) {
            proc.kill();
        }
    }
}

fn scan_cheat_processes() -> Option<String> {
    let mut sys = System::new_all();
    sys.refresh_processes();
    for proc in sys.processes().values() {
        let name = proc.name().to_lowercase();
        for cheat in CHEAT_PROCESSES {
            if name.contains(cheat) {
                return Some(proc.name().to_string());
            }
        }
    }
    None
}

fn scan_fortnite_modules(pid: u32, window: &Window) -> Option<String> {
    unsafe {
        let h_process = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 0, pid);
        if h_process.is_null() {
            println!("[AC] Failed to open process {}", pid);
            let _ = window.emit("ac-debug", serde_json::json!({
                "message": format!("Failed to open process {}", pid)
            }));
            return None;
        }

        let mut modules: Vec<HMODULE> = vec![std::ptr::null_mut(); 1024];
        let mut needed: DWORD = 0;

        let ok = EnumProcessModules(
            h_process,
            modules.as_mut_ptr(),
            (modules.len() * std::mem::size_of::<HMODULE>()) as DWORD,
            &mut needed,
        );

        if ok == 0 {
            println!("[AC] EnumProcessModules failed");
            let _ = window.emit("ac-debug", serde_json::json!({
                "message": "EnumProcessModules failed"
            }));
            CloseHandle(h_process);
            return None;
        }

        let count = needed as usize / std::mem::size_of::<HMODULE>();
        let mut buf = [0u8; MAX_PATH];

        println!("[AC] Scanning {} modules in PID {}", count, pid);
        let _ = window.emit("ac-debug", serde_json::json!({
            "message": format!("Scanning {} modules in PID {}", count, pid)
        }));

        // Strict whitelist - ONLY allow these specific paths
        let safe_paths = [
            "\\windows\\system32\\",
            "\\windows\\syswow64\\",
            "\\windows\\winsxs\\",
            "c:\\windows\\system32\\",
            "c:\\windows\\syswow64\\",
        ];

        // Get the Fortnite installation directory from the first module (the .exe itself)
        let mut fortnite_dir = String::new();
        if count > 0 && !modules[0].is_null() {
            let len = GetModuleFileNameExA(
                h_process,
                modules[0],
                buf.as_mut_ptr() as *mut i8,
                MAX_PATH as DWORD,
            );
            if len > 0 {
                let exe_path = CStr::from_ptr(buf.as_ptr() as *const i8)
                    .to_string_lossy()
                    .to_lowercase();
                // Extract the Fortnite installation directory (e.g., "c:\program files\epic games\fortnite\")
                if let Some(pos) = exe_path.rfind("\\fortnite\\") {
                    fortnite_dir = exe_path[..pos + 10].to_string(); // Include "\fortnite\"
                }
                println!("[AC] Fortnite dir: {}", fortnite_dir);
                let _ = window.emit("ac-debug", serde_json::json!({
                    "message": format!("Fortnite dir: {}", fortnite_dir)
                }));
            }
        }

        for &module in &modules[..count] {
            if module.is_null() {
                continue;
            }
            let len = GetModuleFileNameExA(
                h_process,
                module,
                buf.as_mut_ptr() as *mut i8,
                MAX_PATH as DWORD,
            );
            if len == 0 {
                continue;
            }
            let path = CStr::from_ptr(buf.as_ptr() as *const i8)
                .to_string_lossy()
                .to_lowercase();

            // Allow Windows system DLLs
            if safe_paths.iter().any(|safe| path.starts_with(safe)) {
                continue;
            }

            // Allow DLLs from the Fortnite installation directory
            if !fortnite_dir.is_empty() && path.starts_with(&fortnite_dir) {
                continue;
            }

            // Allow specific known-safe DLLs by name (graphics drivers, etc.)
            let filename = PathBuf::from(&path)
                .file_name()
                .map(|f| f.to_string_lossy().to_lowercase())
                .unwrap_or_default();

            let safe_dlls = [
                "nvoglv64.dll",
                "nvoglv32.dll",
                "atig6pxx.dll",
                "aticfx64.dll",
                "aticfx32.dll",
                "atioglxx.dll",
                "ig4icd64.dll",
                "ig4icd32.dll",
                "igdumd64.dll",
                "igdumd32.dll",
                "d3d11.dll",
                "dxgi.dll",
                "d3d9.dll",
                "d3d10.dll",
                "opengl32.dll",
                "vulkan-1.dll",
            ];

            if safe_dlls.contains(&filename.as_str()) {
                continue;
            }

            // If we get here, it's a suspicious DLL — flag it
            println!("[AC] DETECTED SUSPICIOUS DLL: {} (path: {})", filename, path);
            let _ = window.emit("ac-debug", serde_json::json!({
                "message": format!("DETECTED: {} at {}", filename, path)
            }));
            CloseHandle(h_process);
            return Some(filename);
        }

        CloseHandle(h_process);
    }
    None
}

// ── Detection handler ────────────────────────────────────────────────────────

async fn handle_detection(
    window: &Window,
    backend_url: &str,
    access_token: &str,
    account_id: &str,
    reason: &str,
) {
    // Kill the game immediately
    kill_fortnite();

    // Restore and focus the launcher window
    let _ = window.unminimize();
    let _ = window.show();
    let _ = window.set_focus();

    let strikes = load_strikes(window, account_id) + 1;
    save_strikes(window, account_id, strikes);

    let remaining = MAX_WARNINGS.saturating_sub(strikes);

    if strikes >= MAX_WARNINGS {
        // Final strike — ban them
        let _ = window.emit(
            "anticheat-banned",
            serde_json::json!({
                "reason": reason,
                "message": "You have been permanently banned from AerisMP for repeated cheat violations."
            }),
        );

        let client = reqwest::Client::new();
        let _ = client
            .post(format!("{}/anticheat/inject", backend_url))
            .header("Authorization", format!("bearer {}", access_token))
            .header("Content-Type", "application/json")
            .json(&serde_json::json!({ "reason": reason }))
            .send()
            .await;
    } else {
        // Warning — show message, don't ban yet
        let _ = window.emit(
            "anticheat-warning",
            serde_json::json!({
                "strikes": strikes,
                "remaining": remaining,
                "reason": reason,
                "message": format!(
                    "Well, well, well... it looks like you were trying to inject a DLL that may be a cheat for all we know.\n\nThis is strike {} of {}. You have {} chance{} remaining before a permanent ban.\n\nDo not try this again.",
                    strikes,
                    MAX_WARNINGS,
                    remaining,
                    if remaining == 1 { "" } else { "s" }
                )
            }),
        );
    }
}

// ── Public commands ──────────────────────────────────────────────────────────

#[tauri::command]
pub async fn start_anticheat(
    window: Window,
    backend_url: String,
    access_token: String,
    account_id: String,
) -> Result<(), String> {
    if SCAN_RUNNING.swap(true, Ordering::SeqCst) {
        println!("[AC] Anticheat already running");
        return Ok(());
    }

    println!("[AC] Starting anticheat scanner");
    let _ = window.emit("ac-debug", serde_json::json!({
        "message": "Anticheat scanner started"
    }));

    std::thread::spawn(move || {
        let rt = tokio::runtime::Runtime::new().unwrap();

        loop {
            if !SCAN_RUNNING.load(Ordering::SeqCst) {
                println!("[AC] Scanner stopped");
                break;
            }

            let pid = match get_fortnite_pid() {
                Some(p) => {
                    println!("[AC] Found Fortnite PID: {}", p);
                    p
                },
                None => {
                    println!("[AC] Fortnite not running, stopping scanner");
                    let _ = window.emit("ac-debug", serde_json::json!({
                        "message": "Fortnite not running"
                    }));
                    SCAN_RUNNING.store(false, Ordering::SeqCst);
                    break;
                }
            };

            if let Some(cheat_proc) = scan_cheat_processes() {
                let reason = format!("Cheat process detected: {}", cheat_proc);
                println!("[AC] {}", reason);
                rt.block_on(handle_detection(
                    &window, &backend_url, &access_token, &account_id, &reason,
                ));
                SCAN_RUNNING.store(false, Ordering::SeqCst);
                break;
            }

            if let Some(cheat_dll) = scan_fortnite_modules(pid, &window) {
                let reason = format!("Cheat DLL detected in game process: {}", cheat_dll);
                println!("[AC] {}", reason);
                rt.block_on(handle_detection(
                    &window, &backend_url, &access_token, &account_id, &reason,
                ));
                SCAN_RUNNING.store(false, Ordering::SeqCst);
                break;
            }

            // Scan every 3 seconds for faster detection
            std::thread::sleep(std::time::Duration::from_secs(3));
        }
    });

    Ok(())
}

#[tauri::command]
pub fn stop_anticheat() {
    SCAN_RUNNING.store(false, Ordering::SeqCst);
}
