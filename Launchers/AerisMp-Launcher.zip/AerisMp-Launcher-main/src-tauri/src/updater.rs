use crate::options;
use anyhow::{bail, Context, Result};
use futures_util::StreamExt;
use reqwest::Client;
use serde::{Deserialize, Serialize};
use std::cmp::Ordering;
use std::path::Path;
use std::process::Command;
use tokio::io::AsyncWriteExt;
use tokio::time::{sleep, Duration};

const MANIFEST_FILE_NAME: &str = "manifest.json";
const TEMP_UPDATE_DIR: &str = "ImperialLauncherUpdater";
const INSTALLER_SETTLE_DELAY_MS: u64 = 1500;
const RELAUNCH_DELAY_MS: u64 = 1200;

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct UpdateManifest {
    version: String,
    msi_url: String,
    #[serde(default)]
    changelog: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UpdateInfo {
    pub current_version: String,
    pub latest_version: String,
    pub update_available: bool,
    pub msi_url: String,
    pub changelog: Option<String>,
}

pub struct LauncherUpdater {
    client: Client,
    manifest_url: String,
    current_version: String,
}

impl LauncherUpdater {
    pub fn new() -> Self {
        let manifest_url = format!(
            "{}/{}",
            options::cdn_base_url().trim_end_matches('/'),
            MANIFEST_FILE_NAME
        );

        Self {
            client: Client::new(),
            manifest_url,
            current_version: options::launcher_version().to_string(),
        }
    }

    pub async fn check(&self) -> Result<UpdateInfo> {
        let manifest = self.fetch_manifest().await?;

        if !is_valid_msi_url(&manifest.msi_url) {
            bail!("Manifest MSI URL is missing or not an MSI file");
        }

        let update_available = version_is_newer(&manifest.version, &self.current_version);

        Ok(UpdateInfo {
            current_version: self.current_version.clone(),
            latest_version: manifest.version,
            update_available,
            msi_url: manifest.msi_url,
            changelog: manifest.changelog,
        })
    }

    pub async fn install_latest(&self) -> Result<()> {
        let info = self.check().await?;

        if !info.update_available {
            return Ok(());
        }

        self.install_from_url(&info.msi_url).await
    }

    pub async fn install_from_url(&self, url: &str) -> Result<()> {
        let url = url.trim();

        if !is_valid_msi_url(url) {
            bail!("Only MSI installer URLs are supported");
        }

        let temp_dir = std::env::temp_dir().join(TEMP_UPDATE_DIR);
        tokio::fs::create_dir_all(&temp_dir)
            .await
            .context("Failed to create update temp directory")?;

        let file_name = extract_file_name(url)?;
        let installer_path = temp_dir.join(file_name);

        self.download_file(url, &installer_path).await?;

        let current_exe = std::env::current_exe().ok();
        let child = launch_msi(&installer_path)?;

        if let Some(exe) = current_exe.as_deref() {
            relaunch_after_install(child.id(), exe)?;
        }

        sleep(Duration::from_millis(INSTALLER_SETTLE_DELAY_MS)).await;
        Ok(())
    }

    async fn fetch_manifest(&self) -> Result<UpdateManifest> {
        self.client
            .get(&self.manifest_url)
            .send()
            .await
            .context("Failed to request update manifest")?
            .error_for_status()
            .context("Update manifest returned bad status")?
            .json::<UpdateManifest>()
            .await
            .context("Failed to deserialize update manifest")
    }

    async fn download_file(&self, url: &str, destination: &Path) -> Result<()> {
        let response = self
            .client
            .get(url)
            .send()
            .await
            .with_context(|| format!("Failed to request installer: {url}"))?
            .error_for_status()
            .with_context(|| format!("Installer request failed: {url}"))?;

        let partial = destination.with_extension("part");
        let mut file = tokio::fs::File::create(&partial)
            .await
            .with_context(|| format!("Failed to create {}", partial.display()))?;

        let mut stream = response.bytes_stream();

        while let Some(chunk) = stream.next().await {
            let bytes = chunk.context("Failed while downloading installer bytes")?;
            file.write_all(&bytes).await?;
        }

        file.flush().await?;
        tokio::fs::rename(&partial, destination).await?;
        Ok(())
    }
}

pub async fn check_launcher_update() -> Result<UpdateInfo> {
    LauncherUpdater::new().check().await
}

pub async fn install_launcher_update() -> Result<()> {
    LauncherUpdater::new().install_latest().await
}

fn is_valid_msi_url(url: &str) -> bool {
    let lower = url.trim().to_ascii_lowercase();
    (lower.starts_with("http://") || lower.starts_with("https://")) && lower.contains(".msi")
}

fn extract_file_name(url: &str) -> Result<String> {
    let clean = url.split('?').next().unwrap_or(url);
    let name = clean.rsplit('/').next().unwrap_or("").trim();

    if name.is_empty() {
        bail!("Installer URL does not contain a file name");
    }

    if !name.to_ascii_lowercase().ends_with(".msi") {
        bail!("Installer file is not an MSI");
    }

    Ok(name.to_string())
}

fn launch_msi(installer_path: &Path) -> Result<std::process::Child> {
    Command::new("msiexec")
        .arg("/i")
        .arg(installer_path)
        .arg("/passive")
        .arg("/norestart")
        .spawn()
        .with_context(|| format!("Failed to launch MSI installer {}", installer_path.display()))
}

#[cfg(windows)]
fn relaunch_after_install(installer_pid: u32, launcher_path: &Path) -> Result<()> {
    use std::os::windows::process::CommandExt;

    let launcher = launcher_path.to_string_lossy().replace('\'', "''");

    let script = format!(
        "$ErrorActionPreference = 'SilentlyContinue'; \
         try {{ Wait-Process -Id {installer_pid}; }} catch {{}}; \
         Start-Sleep -Milliseconds {RELAUNCH_DELAY_MS}; \
         if (Test-Path '{launcher}') {{ Start-Process '{launcher}' | Out-Null }}"
    );

    const CREATE_NO_WINDOW: u32 = 0x08000000;

    Command::new("powershell.exe")
        .arg("-NoProfile")
        .arg("-NonInteractive")
        .arg("-WindowStyle")
        .arg("Hidden")
        .arg("-ExecutionPolicy")
        .arg("Bypass")
        .arg("-Command")
        .arg(script)
        .creation_flags(CREATE_NO_WINDOW)
        .spawn()
        .context("Failed to start relaunch helper")?;

    Ok(())
}

#[cfg(not(windows))]
fn relaunch_after_install(_installer_pid: u32, _launcher_path: &Path) -> Result<()> {
    Ok(())
}

fn version_is_newer(remote: &str, local: &str) -> bool {
    match (parse_version(remote), parse_version(local)) {
        (Some(a), Some(b)) => compare_versions(&a, &b) == Ordering::Greater,
        _ => remote.trim() != local.trim(),
    }
}

fn parse_version(value: &str) -> Option<Vec<u64>> {
    let trimmed = value.trim();
    if trimmed.is_empty() {
        return None;
    }

    let mut out = Vec::new();
    for part in trimmed.split('.') {
        out.push(part.trim().parse::<u64>().ok()?);
    }

    Some(out)
}

fn compare_versions(a: &[u64], b: &[u64]) -> Ordering {
    let max = a.len().max(b.len());

    for i in 0..max {
        let left = *a.get(i).unwrap_or(&0);
        let right = *b.get(i).unwrap_or(&0);

        match left.cmp(&right) {
            Ordering::Equal => continue,
            other => return other,
        }
    }

    Ordering::Equal
}
