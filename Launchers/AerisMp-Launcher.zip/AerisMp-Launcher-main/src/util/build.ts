interface Build {
  url: string;
  format: "zip" | "rar";
}

const BUILDS = new Map<string, Build>([
  ["9.10", { url: "https://fnbuilds.site/Aeris-9.10-CL-6639283.rar", format: "rar" }],
]);

export function getBuild(version: string): Build | null {
  return BUILDS.get(version) ?? null;
}
