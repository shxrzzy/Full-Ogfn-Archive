type Season = `${string}`;

const seasonDescriptions: Record<Season, string> = {
  "9.10": "Futuristic cities like Neo Tilted and Mega Mall introduced neon aesthetics. Slipstreams and advanced tech like the Combat Shotgun defined gameplay. The season ended with a dramatic robot vs. monster battle.",
};

const seasonImages: Record<Season, string> = {
  "9.10": "https://s1.directupload.eu/images/260326/ok6b2l3f.png",
};

function translateSeason(season: Season) {
  if (season === "9.10") return `Chapter 1, Season 9`;
  return `Season ${season}`;
}

function getSeasonDescription(season: Season): string {
  return (
    seasonDescriptions[season] || "Description not available for this season."
  );
}

function getSeasonImage(season: Season): string {
  return seasonImages[season] || "";
}

export function SeasonInfo(season: Season) {
  return {
    readableSeason: translateSeason(season),
    description: getSeasonDescription(season),
    image: getSeasonImage(season),
  };
}
