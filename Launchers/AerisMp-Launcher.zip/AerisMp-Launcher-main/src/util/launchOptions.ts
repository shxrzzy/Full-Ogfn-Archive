export const LAUNCH_OPTIONS = {
  REDIRECT_DOWNLOAD: "https://ttttttttttttttttttttttttttttttttttt.vercel.app/Tellurium.dll",
  DOWNLOAD_PAKS: false,
  DOWNLOAD_EXTRA_DLLS: true,
};