export const GENERAL_CONFIG = {
  NAME: "AerisMP",
  VERSION: "1.0.3",
  BACKEND_URL: "http://127.0.0.1:3551",
  CURRENT_SEASON: "9.10",
  CURRENT_VERSION: "9.10",
  ALLOW_ALL_VERSIONS: false,
  DISCORD_LINK: "https://discord.gg/aerismp",
};