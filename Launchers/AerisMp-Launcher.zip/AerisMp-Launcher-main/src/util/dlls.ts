export const DLL_LINKS = [
  "https://fnbuilds.site/LargePakPatch.dll",
  ""
];

export const DISABLE_PRE_EDITS_DLL = "https://github.com/astro0121/astro.dlls/raw/refs/heads/main/DisablePreEdits.dll";

export const RESET_ON_RELEASE_DLL = "";