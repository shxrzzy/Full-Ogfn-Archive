import { GENERAL_CONFIG } from "../util/general";
import { ContentPagesResult } from "../vite-env";

const URL = GENERAL_CONFIG.BACKEND_URL;

type ApiResponse<T> = {
  success: boolean;
  data?: T;
  error?: string;
};

async function request<T>(
  endpoint: string,
  options?: RequestInit,
): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(`${URL}${endpoint}`, {
      ...options,
      headers: {
        ...(options?.headers ?? {}),
      },
    });

    if (!response.ok) {
      const text = await response.text();
      return {
        success: false,
        error: text || `Request failed: ${response.status}`,
      };
    }

    const contentType = response.headers.get("content-type") || "";
    const data = contentType.includes("application/json")
      ? await response.json()
      : await response.text();

    return { success: true, data };
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : "Unknown error",
    };
  }
}

export const ENDPOINTS = {
  CONTENT_PAGES: "/content/api/pages/fortnite-game",
  SHOP: "/fortnite/api/storefront/v2/catalog",
  LOGIN: "/account/api/oauth/token",

  MCP_QUERY_PROFILE: "/fortnite/api/game/v2/profile",
} as const;

export const api = {
  getContentPages: () => request<ContentPagesResult>(ENDPOINTS.CONTENT_PAGES),

  getShopCatalog: () => request<any>(ENDPOINTS.SHOP),

  login: (email: string, password: string) =>
    request<any>(ENDPOINTS.LOGIN, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        // Standard EG1 launcher client credentials
        Authorization: `Basic ${btoa("ec684b8c687f479fadea3cb2ad83f5c6:202cb962ac59075b964b07152d234b70")}`,
      },
      body: new URLSearchParams({
        grant_type: "password",
        username: email,
        password: password,
      }).toString(),
    }),

  postQueryProfile: (
    accountId: string,
    profileId: "athena" | "common_core",
    token: string,
    rvn: number = -1,
  ) =>
    request<any>(
      `${ENDPOINTS.MCP_QUERY_PROFILE}/${accountId}/client/QueryProfile?profileId=${profileId}&rvn=${rvn}`,
      {
        method: "POST",
        headers: {
          Authorization: `bearer ${token}`,
          "Content-Type": "application/json",
        },
      },
    ),

  getAvatar: (accountId: string) =>
    request<{ avatarUrl: string }>(`/api/launcher/avatar/${accountId}`),

  getAvatarByEmail: (email: string) =>
    request<{ avatarUrl: string }>(`/api/launcher/avatar/email/${encodeURIComponent(email)}`),

  getDiscordUser: (accountId: string) =>
    request<{ discordUsername: string; avatarUrl?: string }>(`/api/launcher/discord/${accountId}`),

  getArenaLeaderboard: () =>
    request<{ entries: { displayName: string; account: string; value: number }[] }>(
      `/api/launcher/leaderboard/arena`
    ),

  getPaks: () =>
    request<
      {
        name: string;
        size: number;
      }[]
    >("/api/launcher/paks"),

  getLauncherServers: () => request<any>("/api/v1/launcher/servers"),
};
