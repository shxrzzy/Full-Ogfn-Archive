/// <reference types="vite/client" />

export type ContentPagesResult = {
  battleroyalenewsv2?: {
    news: {
      motds: Array<{
        id: string;
        image: string;
        title: string;
        body: string;
        hidden: boolean;
      }>;
    };
  };
};

export type Build = {
  path: string;
  splash?: string | null;
  open: boolean;
  enabled: boolean;
  version: string;
  season: string;
};

export type LibraryState = {
  build: Build[];
  addItem: (item: Build) => void;
  removeItem: (path: string) => void;
  toggleOpen: (path: string) => void;
  toggleEnabled: (path: string) => void;
  clearLibrary: () => void;
};

export type Profile = {
  accountId: string | null;
  displayName: string | null;
  discordUsername: string | null;
  email: string | null;
  password: string | null;
  discordId: string | null;
  avatarUrl: string | null;
  hydrated: boolean;
  setProfile: (profile: {
    accountId?: string | null;
    displayName?: string | null;
    email: string | null;
    password: string | null;
    accessToken: string;
  }) => void;
  clearProfile: () => void;
  login: (profile: {
    accountId: string;
    displayName: string;
    email: string | null;
    password: string | null;
    accessToken: string;
    discordId?: string | null;
    discordUsername?: string | null;
  }) => void;
  logout: () => void;
  setHydrated: () => void;
  setAvatarUrl: (url: string) => void;
  setDiscordUsername: (username: string) => void;
  accessToken: string;
};

export type ShopItem = {
  id: string;
  name: string;
  description: string;
  price: number;
  images: {
    featured?: string;
    icon: string;
  };
  rarity: {
    value: string;
    displayValue: string;
  };
};

export type View = "home" | "library" | "shop" | "settings";

export type ConfigState = {
  theme: string;

  editOnRelease: boolean;
  editAndRelease: boolean;
  resetOnRelease: boolean;
  disablePreEdits: boolean;
  alwaysOnTop: boolean;
  christmasSnow: boolean;
  expandedSidebar: boolean;

  // appearance extras
  compactMode: boolean;
  blurEffects: boolean;
  animations: boolean;
  showClock: boolean;
  glowEffects: boolean;

  setExpandedSidebar: (value: boolean) => void;
  setEditOnRelease: (value: boolean) => void;
  setEditAndRelease: (value: boolean) => void;
  setResetOnRelease: (value: boolean) => void;
  setDisablePreEdits: (value: boolean) => void;
  setAlwaysOnTop: (value: boolean) => void;
  setChristmasSnow: (value: boolean) => void;
  setCompactMode: (value: boolean) => void;
  setBlurEffects: (value: boolean) => void;
  setAnimations: (value: boolean) => void;
  setShowClock: (value: boolean) => void;
  setGlowEffects: (value: boolean) => void;
  setTheme: (theme: string) => void;
};

export type Theme = {
  background: {
    primary: string;
    secondary: string;
  };

  text: {
    primary: string;
    secondary: string;
  };

  button: {
    base: string;
    hover: string;
    active: string;
  };

  border: string;

  gradient: {
    from: string;
    to: string;
  };
};