"use client";

import { ReactNode } from "react";
import { SnowOverlay } from "./SnowOverlay";
import { useConfigStore } from "../stores/settings";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const expandedSidebar = useConfigStore((s) => s.expandedSidebar);

  return (
    <div className="relative min-h-screen w-full">
      <main 
        className="fixed top-0 right-0 bottom-0 overflow-auto bg-transparent transition-all duration-300"
        style={{
            left: expandedSidebar ? "220px" : "60px",
            paddingTop: "48px",
        }}
      >
        <SnowOverlay />

        <div className="relative z-10">
          {children}
        </div>
      </main>
    </div>
  );
}