"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { themes } from "../../styles";
import { ToggleOption } from "./ToggleOption";
import { useConfigStore } from "../../../stores/settings";

export function AppearanceTab() {
  const config = useConfigStore();
  const [applying, setApplying] = useState(false);
  const [pendingTheme, setPendingTheme] = useState<string | null>(null);

  const handleTheme = (key: string) => {
    if (key === config.theme || applying) return;
    setPendingTheme(key);
    setApplying(true);
  };

  // Apply the theme after the fade-out completes (~300ms), then clear after 1.5s
  useEffect(() => {
    if (!applying || !pendingTheme) return;

    const applyTimer = setTimeout(() => {
      config.setTheme(pendingTheme);
    }, 300);

    const doneTimer = setTimeout(() => {
      setApplying(false);
      setPendingTheme(null);
    }, 1800);

    return () => {
      clearTimeout(applyTimer);
      clearTimeout(doneTimer);
    };
  }, [applying, pendingTheme]);

  return (
    <div className="flex flex-col gap-6 p-2 h-full min-h-0 overflow-hidden">
      <div className="flex flex-col gap-4">
        <div className="flex justify-between items-end">
          <div>
            <h3 className="text-white font-bold text-sm">Theme</h3>
            <p className="text-zinc-500 text-[12px]">Switch launcher colors between preset themes.</p>
          </div>
          <button
            onClick={() => handleTheme("midnight")}
            className="text-[10px] bg-zinc-800/50 hover:bg-zinc-700 px-3 py-1.5 rounded-md text-zinc-300 transition-colors uppercase font-bold border border-white/5 cursor-pointer"
          >
            Reset Default
          </button>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-7 gap-3">
          {Object.keys(themes).map((key) => {
            const isActive = (pendingTheme ?? config.theme) === key;
            const themeData = themes[key];
            const bg = `linear-gradient(135deg, ${themeData.gradient.from} 0%, ${themeData.gradient.to} 100%)`;

            return (
              <div key={key} className="flex items-center justify-center">
                <button
                  onClick={() => handleTheme(key)}
                  disabled={applying}
                  className="relative cursor-pointer group outline-none disabled:cursor-not-allowed"
                  style={{ width: 44, height: 44 }}
                >
                  <div
                    className={`absolute -inset-1 rounded-full border-2 transition-all duration-200 ${
                      isActive
                        ? "border-white opacity-100 scale-110"
                        : "border-transparent opacity-0 group-hover:opacity-40 group-hover:border-white group-hover:scale-105"
                    }`}
                  />
                  <div
                    className="w-full h-full rounded-full border border-white/15 shadow-lg shadow-black/30"
                    style={{ background: bg }}
                  />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      <div className="pt-5 border-t border-white/5 space-y-4">
        <ToggleOption
          label="Christmas Snow"
          description="Adds a falling snow overlay to the launcher."
          value={config.christmasSnow}
          onChange={(enabled) => config.setChristmasSnow(enabled)}
        />
        <ToggleOption
          label="Expanded Sidebar"
          description="Shows text labels next to the sidebar icons."
          value={config.expandedSidebar}
          onChange={(enabled) => config.setExpandedSidebar(enabled)}
        />
        <ToggleOption
          label="Blur Effects"
          description="Enables frosted glass blur on panels and overlays."
          value={config.blurEffects}
          onChange={(enabled) => config.setBlurEffects(enabled)}
        />
      </div>

      {/* Full-screen fade overlay while applying */}
      <AnimatePresence>
        {applying && (
          <motion.div
            className="fixed inset-0 z-40 pointer-events-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            style={{ background: "rgba(0,0,0,0.45)", backdropFilter: "blur(4px)" }}
          />
        )}
      </AnimatePresence>

      {/* Applying toast */}
      <AnimatePresence>
        {applying && (
          <motion.div
            initial={{ opacity: 0, y: 14, scale: 0.93 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.95 }}
            transition={{ duration: 0.22 }}
            className="fixed bottom-5 left-1/2 -translate-x-1/2 flex items-center gap-2.5 px-4 py-2.5 rounded-xl shadow-2xl z-50 pointer-events-none"
            style={{
              background: "rgba(14,14,20,0.95)",
              border: "1px solid rgba(255,255,255,0.1)",
              backdropFilter: "blur(16px)",
            }}
          >
            <svg className="animate-spin flex-shrink-0" width="14" height="14" viewBox="0 0 14 14" fill="none">
              <circle cx="7" cy="7" r="5.5" stroke="rgba(255,255,255,0.15)" strokeWidth="2" />
              <path d="M7 1.5A5.5 5.5 0 0 1 12.5 7" stroke="white" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <span className="text-white text-xs font-medium tracking-wide">Applying theme...</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
