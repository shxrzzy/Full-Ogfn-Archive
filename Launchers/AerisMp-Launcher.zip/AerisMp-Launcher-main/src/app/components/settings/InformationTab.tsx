"use client";

import { motion, AnimatePresence } from "framer-motion";
import { LogOut, Eye, EyeOff } from "lucide-react";
import { useTheme } from "../../../hooks/useTheme";
import { GENERAL_CONFIG } from "../../../util/general";
import { useUserStore } from "../../../stores/user";
import { useState } from "react";

export function InformationTab() {
  const colors = useTheme();
  const user = useUserStore();
  const [showModal, setShowModal] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="space-y-4 h-full min-h-0 overflow-y-auto">
      <div className={`rounded-3xl overflow-hidden border ${colors.current.border} shadow-xl ${colors.current.background.secondary}`}>
        <div
          className="relative h-12"
          style={{
            background: `linear-gradient(135deg, ${colors.current.gradient.from} 0%, ${colors.current.gradient.to} 100%)`,
          }}
        >
          <div className="absolute inset-0 bg-black/15 mix-blend-overlay" />
        </div>

        <div className="p-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-center gap-4">
              <div className={`w-20 h-20 rounded-3xl border-4 ${colors.current.border} bg-zinc-950 overflow-hidden shadow-xl`}>
                {user.avatarUrl ? (
                  <img src={user.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-[#5865F2]">
                    <svg viewBox="0 0 127.14 96.36" fill="white" className="w-10 h-8">
                      <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/>
                    </svg>
                  </div>
                )}
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.3em] text-zinc-500 mb-2"></p>
                <h2 className="text-2xl font-bold text-white">
                  {user.discordUsername ? `@${user.discordUsername}` : user.displayName || "Unknown User"}
                </h2>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => setShowModal(true)}
              className="inline-flex items-center gap-2 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-2 text-sm text-red-300 transition hover:bg-red-500/20"
            >
              <LogOut className="h-4 w-4" />
              Log out
            </motion.button>
          </div>
        </div>
      </div>

      <div className={`rounded-3xl border ${colors.current.border} ${colors.current.background.secondary} shadow-xl overflow-hidden`}>
        <div className="p-6 border-b border-white/10">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-zinc-500"></p>
            <h3 className="mt-2 text-2xl font-bold text-white">Secure profile info</h3>
          </div>
        </div>

        <div className="p-6 grid gap-4">
          {[
            { title: "Account ID", value: user.accountId || "-" },
            { title: "Email", value: user.email || "-" },
            { title: "Username", value: user.displayName || "-" },
          ].map((field) => (
            <div key={field.title} className={`rounded-3xl border ${colors.current.border} ${colors.current.background.primary} p-4`}>
              <p className="text-lg font-semibold text-white">{field.title}</p>
              <p className="mt-2 text-lg font-semibold text-white break-all">{field.value}</p>
            </div>
          ))}
          
          <div className={`rounded-3xl border ${colors.current.border} ${colors.current.background.primary} p-4`}>
            <div className="flex items-center justify-between mb-2">
              <p className="text-lg font-semibold text-white">Password</p>
              <button
                onClick={() => setShowPassword(!showPassword)}
                className="text-zinc-400 hover:text-white transition-colors"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            <p className="mt-2 text-lg font-semibold text-white break-all">
              {showPassword ? (user.password || "-") : (user.password ? "••••••••" : "-")}
            </p>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showModal && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className={`rounded-2xl p-8 w-[400px] ${colors.current.background.secondary} border ${colors.current.border} text-center shadow-xl`}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3, type: "spring", bounce: 0.4 }}
            >
              <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 text-red-500 flex items-center justify-center mx-auto mb-4">
                <LogOut className="w-8 h-8" />
              </div>
              <h2 className={`text-2xl font-bold mb-2 ${colors.current.text.primary}`}>
                Confirm Logout
              </h2>
              <p className={`text-sm mb-8 ${colors.current.text.secondary}`}>
                Are you sure you want to log out of {GENERAL_CONFIG.NAME}? You will need to re-enter your credentials.
              </p>
              <div className="flex justify-center gap-3">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowModal(false)}
                  className={`flex-1 py-2.5 rounded-xl ${colors.current.background.primary} hover:bg-zinc-800 text-white font-medium border ${colors.current.border} transition-colors`}
                >
                  Cancel
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setShowModal(false);
                    user.logout();
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold shadow-lg shadow-red-500/20 transition-colors"
                >
                  Log Out
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
