"use client";

import { ShopItem } from "../../../vite-env";
import { BigFeaturedCard } from "./BigFeaturedCard";

export function FeaturedRow({ items }: { items: ShopItem[] }) {
  if (!items.length) {
    return <p className="text-zinc-500 text-sm">No featured items available.</p>;
  }

  return (
    <div
      className="grid gap-3 w-full"
      style={{
        gridTemplateColumns: `repeat(${Math.min(items.length, 4)}, 1fr)`,
      }}
    >
      {items.map((item) => (
        <BigFeaturedCard key={item.id} item={item} />
      ))}
    </div>
  );
}
