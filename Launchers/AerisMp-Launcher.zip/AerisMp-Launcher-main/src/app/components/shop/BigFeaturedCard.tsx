"use client";

import { motion, AnimatePresence } from "framer-motion";
import { ShopItem } from "../../../vite-env";

export function BigFeaturedCard({ item }: { item: ShopItem }) {
  const getRarityGradient = (rarity: string) => {
    switch (rarity.toLowerCase()) {
      case "common":
        return "from-[#6b727d] via-[#989fa4] to-[#474c54]";

      case "uncommon":
        return "from-[#a1fe00] via-[#61bf00] to-[#024f03]";

      case "rare":
        return "from-[#00afff] via-[#0077c8] to-[#00458a]";

      case "epic":
        return "from-[#ce59ff] via-[#8b32cc] to-[#4c197b]";

      case "legendary":
        return "from-[#ff8b19] via-[#d45c10] to-[#8a3c1d]";

      case "crystal":
        return "from-[#606de0] via-[#6991ff] to-[#284d9c]";

      case "icon":
      case "icon series":
        return "from-[#5cf2f3] via-[#00e0ff] to-[#004c71]";

      case "dc":
        return "from-[#19193f] via-[#212138] to-[#000033]";

      default:
        return "from-neutral-600 via-neutral-700 to-neutral-800";
    }
  };

  return (
    <motion.div
      whileHover={{ scale: 1.03 }}
      className="relative w-full aspect-[3/4] rounded-lg overflow-hidden shadow-xl border border-stone-800 bg-black"
    >
      <div
        className={`absolute inset-0 bg-radial ${getRarityGradient(item.rarity.value)}`}
      />

      <div className="absolute inset-0 bg-gradient-radial from-transparent via-transparent to-black/60" />

      <AnimatePresence mode="wait">
        <motion.img
          key={item.id}
          src={item.images.featured || item.images.icon}
          initial={{ opacity: 0, scale: 1.08 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.92 }}
          transition={{ duration: 0.4 }}
          className="absolute inset-0 m-auto object-contain w-full h-full max-w-full max-h-full drop-shadow-2xl"
          draggable={false}
          onError={(e) => {
            (e.target as HTMLImageElement).src = item.images.icon;
          }}
        />
      </AnimatePresence>

      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/95 via-black/80 to-transparent px-5 py-4">
        <h3 className="text-white text-lg font-extrabold uppercase leading-tight line-clamp-1">
          {item.name}
        </h3>

        <p className="text-gray-300 text-sm leading-snug line-clamp-2 mt-1">
          {item.description || "No description available."}
        </p>

        <div className="flex items-center gap-2 mt-2">
          <img
            src="https://image.fnbr.co/price/icon_vbucks_50x.png"
            className="w-4 h-4"
            draggable={false}
          />
          <span className="text-white font-bold text-base">
            {item.price.toLocaleString()}
          </span>
        </div>
      </div>
    </motion.div>
  );
}
