"use client";

import {
  Download,
  Home,
  Folder,
  Cog,
  Store,
  Trophy,
} from "lucide-react";
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useLocation, useNavigate } from "react-router-dom";
import { useTheme } from "../../hooks/useTheme";
import { useConfigStore } from "../../stores/settings";
import { useUserStore } from "../../stores/user";

type NavItem =
  | "brand"
  | "home"
  | "library"
  | "shop"
  | "settings"
  | "download"
  | "leaderboard";

export function Sidebar({ isDownloading }: { isDownloading: boolean }) {
  const [hoveredItem, setHoveredItem] = useState<NavItem | null>(null);
  const nav = useNavigate();
  const location = useLocation();
  const colors = useTheme();
  const isExpanded = useConfigStore((state) => state.expandedSidebar);
  const showClock = useConfigStore((state) => state.showClock);
  const { displayName, avatarUrl, discordUsername } = useUserStore();
  const [avatarHovered, setAvatarHovered] = useState(false);
  const [, setClock] = useState(() => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }));

  useEffect(() => {
    if (!showClock) return;
    const t = setInterval(() => setClock(new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })), 1000);
    return () => clearInterval(t);
  }, [showClock]);
  const defaultText = colors.current.text.secondary;
  const activeText = colors.current.text.primary;
  const sidebarBackgroundColor = colors.current.background.secondary.startsWith("bg-[")
    ? colors.current.background.secondary.slice(3, -1)
    : undefined;
  const collapsedWidth = 60;
  const expandedWidth = 220;

  const navItems = [
    { id: "home" as NavItem, path: "/", icon: Home, label: "Home" },
    { id: "library" as NavItem, path: "/library", icon: Folder, label: "Library" },
    { id: "shop" as NavItem, path: "/shop", icon: Store, label: "Shop" },
    { id: "leaderboard" as NavItem, path: "/leaderboard", icon: Trophy, label: "Leaderboard" },
  ];

  const isHovered = (id: NavItem) => hoveredItem === id;

  const isActive = (path: string) => {
    if (path === "/") return location.pathname === "/";
    return location.pathname.startsWith(path);
  };

  const routeTo = (path: string) => {
    nav(path);
  };

  if (isDownloading) return null;

  return (
    <motion.div
      initial={false}
      animate={{ width: isExpanded ? expandedWidth : collapsedWidth }}
      transition={{ duration: 0.45, ease: "easeOut" }}
      className={`fixed left-0 top-0 bottom-0 z-40 flex flex-col pt-2 pb-4 overflow-hidden border-r border-white/10 dark:border-white/10 ${colors.current.background.secondary}`}
      style={{
        backgroundColor: sidebarBackgroundColor,
        backgroundImage: `linear-gradient(180deg, ${colors.current.gradient.from} 0%, ${colors.current.gradient.to} 100%)`,
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
      }}
    >
      <motion.div
        className="flex items-center h-16 px-0"
        animate={{ justifyContent: isExpanded ? "flex-start" : "center", paddingLeft: isExpanded ? 12 : 0 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
      >
        <img src="/icon.png" alt="Logo" className="h-10 w-10 object-contain" />
      </motion.div>
      <nav className="flex flex-col gap-0 flex-1 items-center px-0 pt-1">
        {navItems.map(({ id, path, icon: Icon, label }) => (
          <button
            key={id}
            onClick={() => routeTo(path)}
            onMouseEnter={() => setHoveredItem(id)}
            onMouseLeave={() => setHoveredItem(null)}
            className={`relative group cursor-pointer flex items-center gap-3 h-11 rounded-xl transition-all duration-200 ${isExpanded ? "px-3 w-full justify-start" : "w-11 mx-auto justify-center"} ${isActive(path) ? `${colors.current.button.active} ${activeText}` : isHovered(id) ? `${colors.current.button.hover} ${activeText}` : `bg-transparent ${defaultText}`}`}
          >
            <Icon
              size={22}
              className={`flex-shrink-0 transition-colors duration-200 ${isActive(path) || isHovered(id) ? activeText : defaultText}`}
              strokeWidth={1.5}
            />

            {isExpanded && (
              <span className={`font-medium text-sm transition-colors duration-200 whitespace-nowrap text-left ${isActive(path) || isHovered(id) ? activeText : defaultText}`}>
                {label}
              </span>
            )}

            {!isExpanded && (
              <div
                className={`absolute left-full ml-4 top-1/2 -translate-y-1/2 px-3 py-1.5 ${colors.current.background.primary} ${activeText} text-xs font-medium rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap border border-transparent shadow-xl z-50`}
              >
                {label}
              </div>
            )}
          </button>
        ))}
      </nav>

      <div className="flex flex-col gap-0.5 mt-auto px-0">
        <div className="mx-3 mb-2 h-px bg-white/10" />
        <button
          onClick={() => routeTo("/download")}          onMouseEnter={() => setHoveredItem("download")}
          onMouseLeave={() => setHoveredItem(null)}
          className={`relative group cursor-pointer flex items-center gap-3 h-11 rounded-xl transition-all duration-200 ${isExpanded ? "px-3 w-full justify-start" : "w-11 mx-auto justify-center"} ${isActive("/download") ? `${colors.current.button.active} ${activeText}` : isHovered("download") ? `${colors.current.button.hover} ${activeText}` : `bg-transparent ${defaultText}`}`}
        >
            <Download
              size={22}
              className={`flex-shrink-0 transition-colors duration-200 ${isActive("/download") || isHovered("download") ? activeText : defaultText}`}
              strokeWidth={1.5}
            />

            {isExpanded && (
              <span className={`font-medium text-sm transition-colors duration-200 whitespace-nowrap text-left ${isActive("/download") || isHovered("download") ? activeText : defaultText}`}>
                Downloads
              </span>
            )}

            {!isExpanded && (
            <div
              className={`absolute left-full ml-4 top-1/2 -translate-y-1/2 px-3 py-1.5 ${colors.current.background.primary} ${activeText} text-xs font-medium rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap border border-transparent shadow-xl z-50`}
            >
              Downloads
            </div>
          )}
        </button>
        <div
          className={`flex items-center gap-2.5 mt-1 mb-0.5 rounded-xl transition-all duration-200 ${isExpanded ? "px-3 py-2 w-full" : "w-11 mx-auto justify-center py-2"} bg-white/5 hover:bg-white/10`}
        >
          <button
            onClick={() => routeTo("/settings")}
            onMouseEnter={() => setAvatarHovered(true)}
            onMouseLeave={() => setAvatarHovered(false)}
            className="relative flex-shrink-0 w-8 h-8 rounded-full overflow-hidden focus:outline-none"
            title="Settings"
          >
            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt="avatar"
                className={`w-full h-full object-cover transition-opacity duration-200 ${avatarHovered ? "opacity-20" : "opacity-100"}`}
              />
            ) : (
              <div className={`w-full h-full flex items-center justify-center bg-[#5865F2] transition-opacity duration-200 ${avatarHovered ? "opacity-20" : "opacity-100"}`}>
                <svg viewBox="0 0 127.14 96.36" fill="white" className="w-5 h-4">
                  <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/>
                </svg>
              </div>
            )}
            {avatarHovered && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Cog size={16} className="text-white" strokeWidth={2.5} />
              </div>
            )}
          </button>

          {isExpanded && (
            <div className="flex flex-col min-w-0">
              <span className={`text-xs font-semibold truncate ${activeText}`}>
                {discordUsername ? `@${discordUsername}` : displayName ?? "Guest"}
              </span>
              <span className="text-[10px] text-white/40 truncate">Discord</span>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}