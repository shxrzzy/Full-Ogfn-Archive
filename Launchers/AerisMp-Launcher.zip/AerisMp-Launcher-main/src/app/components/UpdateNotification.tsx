import { useEffect, useState } from "react";
import { invoke } from "@tauri-apps/api/core";

interface UpdateInfo {
  currentVersion: string;
  latestVersion: string;
  updateAvailable: boolean;
  msiUrl: string;
  changelog?: string;
}

export function UpdateNotification() {
  const [update, setUpdate] = useState<UpdateInfo | null>(null);
  const [installing, setInstalling] = useState(false);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    const checkUpdate = async () => {
      try {
        const info = await invoke<UpdateInfo>("check_launcher_update");
        if (info.updateAvailable) {
          setUpdate(info);
          setShowModal(true);
          setInstalling(true);
          try {
            await invoke("install_launcher_update");
          } catch (err) {
            console.error("Installation failed:", err);
            setInstalling(false);
          }
        }
      } catch (err) {
        console.error("Update check failed:", err);
      }
    };

    checkUpdate();
    const interval = setInterval(checkUpdate, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  if (!showModal || !update) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg px-8 py-6 max-w-md text-center shadow-lg">
        <div className="text-xl font-semibold mb-2">New Update Available</div>
        <div className="text-gray-600 mb-6">Version {update.latestVersion}</div>
        
        {installing ? (
          <div className="mb-6">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-blue-600"></div>
            <p className="text-gray-600 mt-2">Downloading update...</p>
          </div>
        ) : (
          <p className="text-gray-600 mb-6">Update ready to install</p>
        )}

        <button
          onClick={() => setShowModal(false)}
          disabled={installing}
          className="bg-gray-200 text-gray-800 px-6 py-2 rounded font-medium hover:bg-gray-300 disabled:opacity-50"
        >
          {installing ? "Updating..." : "Cancel"}
        </button>
      </div>
    </div>
  );
}

