"use client";
import { X, Minus } from "lucide-react";
import { getCurrentWindow } from "@tauri-apps/api/window";
import { useState } from "react";

export function Frame() {
  const [isHoveringClose, setIsHoveringClose] = useState(false);
  const [isHoveringMin, setIsHoveringMin] = useState(false);

  const dragRegionStyles = { WebkitAppRegion: "drag", MozAppRegion: "drag" } as any;
  const noDragStyles = { WebkitAppRegion: "no-drag", MozAppRegion: "no-drag" } as any;

  const appWindow = getCurrentWindow();

  const handleMinimize = async () => {
    await appWindow.minimize();
  };

  const handleClose = async () => {
    await appWindow.close();
  };

  return (
    <>
      <div
        data-tauri-drag-region
        className="fixed top-0 left-0 right-0 z-40 h-12"
        style={{
          ...dragRegionStyles,
          backgroundColor: "transparent",
          backgroundImage: "none",
          boxShadow: "none",
          border: "none",
        }}
      />

      <div
        className="fixed top-3 right-2 z-50 flex items-center gap-1 select-none pointer-events-auto"
        style={{
          backgroundColor: "transparent",
          backgroundImage: "none",
          boxShadow: "none",
          border: "none",
        }}
      >
        <button
          onClick={handleMinimize}
          onMouseEnter={() => setIsHoveringMin(true)}
          onMouseLeave={() => setIsHoveringMin(false)}
          className="w-9 h-9 flex items-center justify-center rounded-md cursor-pointer transition-all duration-150 bg-transparent hover:bg-white/10"
          aria-label="Minimize"
          data-tauri-drag-region="false"
          style={noDragStyles}
        >
          <Minus
            size={16}
            className={`transition-colors duration-150 ${
              isHoveringMin ? "text-white" : "text-zinc-400"
            }`}
            strokeWidth={2}
          />
        </button>

        <button
          onClick={handleClose}
          onMouseEnter={() => setIsHoveringClose(true)}
          onMouseLeave={() => setIsHoveringClose(false)}
          className="w-9 h-9 flex items-center justify-center rounded-md cursor-pointer transition-all duration-150 bg-transparent hover:bg-white/10"
          aria-label="Close"
          data-tauri-drag-region="false"
          style={noDragStyles}
        >
          <X
            size={16}
            className={`transition-colors duration-150 ${
              isHoveringClose ? "text-white" : "text-zinc-400"
            }`}
            strokeWidth={2}
          />
        </button>
      </div>
    </>
  );
}
