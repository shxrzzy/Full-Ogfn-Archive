"use client";

import { useRef, useState, useEffect } from "react";
import { Volume2, VolumeX, SkipForward } from "lucide-react";

interface TrailerModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoUrl: string;
}

export function TrailerModal({ isOpen, onClose, videoUrl }: TrailerModalProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    console.log("TrailerModal isOpen:", isOpen);
    if (isOpen && videoRef.current) {
      console.log("Playing video:", videoUrl);
      videoRef.current.play().catch((e) => console.error("Play error:", e));
    }
  }, [isOpen, videoUrl]);

  useEffect(() => {
    if (videoRef.current) {
      if (isMuted) {
        videoRef.current.muted = true;
      } else {
        videoRef.current.muted = false;
        videoRef.current.volume = volume;
      }
    }
  }, [volume, isMuted]);

  const handleVideoEnd = () => {
    console.log("Video ended");
    onClose();
  };

  const handleSkip = (e: React.MouseEvent) => {
    e.stopPropagation();
    console.log("Skip clicked");
    onClose();
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsMuted(!isMuted);
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div 
      className="fixed inset-0 z-50 bg-black w-screen h-screen flex items-center justify-center"
    >
      <video
        ref={videoRef}
        muted={isMuted}
        playsInline
        onEnded={handleVideoEnd}
        className="w-full h-full object-cover"
        crossOrigin="anonymous"
      >
        <source src={videoUrl} type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      <div className="absolute top-8 left-8 flex items-center gap-4 z-[100]">
        <button
          onClick={toggleMute}
          className="p-3 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/30 transition-all"
        >
          {isMuted ? (
            <VolumeX size={24} className="text-white" />
          ) : (
            <Volume2 size={24} className="text-white" />
          )}
        </button>

        {!isMuted && (
          <div className="flex items-center gap-2">
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="w-24 h-1 rounded-full bg-white/20 cursor-pointer"
            />
          </div>
        )}
      </div>

      <button
        onClick={handleSkip}
        className="absolute bottom-8 right-8 flex items-center gap-2 px-6 py-3 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/30 transition-all z-[100] text-white font-semibold"
      >
        <SkipForward size={20} />
        Skip
      </button>
    </div>
  );
}
