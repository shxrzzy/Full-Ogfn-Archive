"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useTheme } from "../../../hooks/useTheme";

export function NotImplemented({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  const colors = useTheme();
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 25 }}
            onClick={(e) => e.stopPropagation()}
            className={`${colors.current.background.primary} border ${colors.current.border} text-center rounded-xl w-full max-w-md p-6`}
          >
            <h2 className="text-white text-2xl font-bold">Not Implemented</h2>
            <p className="text-zinc-400">
              This has not been implemented in the launcher yet. Sorry for the
              inconvenience!
            </p>

            <button
              onClick={onClose}
              className={`text-white/60 mt-2 rounded-lg p-2 px-4 font-bold cursor-pointer hover:text-white transition disabled:opacity-50 ${colors.current.button.base}`}
            >
              Close
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
