"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useTheme } from "../../../hooks/useTheme";

export function CustomPathModal({
  isOpen,
  onYes,
  onNo,
  onClose,
}: {
  isOpen: boolean;
  onYes: () => void;
  onNo: () => void;
  onClose: () => void;
}) {
  const colors = useTheme();

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.98, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.98, opacity: 0 }}
            transition={{ type: "spring", stiffness: 250, damping: 24 }}
            onClick={(e) => e.stopPropagation()}
            className={`w-full max-w-md rounded-[32px] border ${colors.current.border} ${colors.current.background.secondary} p-6 shadow-[0_30px_80px_rgba(0,0,0,0.45)]`}
          >
            <div className="mb-4">
              <h2 className="text-2xl font-semibold text-white">
                Download location
              </h2>
            </div>

            <p className="text-sm text-white/70 mb-6 leading-6">
              Choose a custom download folder, or save the build automatically to
              <span className="font-semibold text-white"> C:\AerisMP 9.10</span>.
            </p>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={onNo}
                className="rounded-2xl border border-zinc-700/80 bg-zinc-900/80 px-4 py-3 text-sm font-semibold text-white/90 transition hover:bg-zinc-900"
              >
                No default
              </button>
              <button
                onClick={onYes}
                className="rounded-2xl border border-zinc-700/80 bg-zinc-900/90 px-4 py-3 text-sm font-semibold text-white/90 transition hover:bg-zinc-800"
              >
                Yes choose path
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
