"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { useDownloadStore } from "../../../stores/download";

import { open } from "@tauri-apps/plugin-dialog";
import { showToast } from "../toaster";
import { useTheme } from "../../../hooks/useTheme";

export function ChooseDownloadPathModal({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  const setPath = useDownloadStore((s) => s.setPath);

  const [selectedPath, setSelectedPath] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [imported, setImported] = useState(false);

  const colors = useTheme();

  const choosePath = async () => {
    const path = await open({ directory: true });

    if (!path) {
      showToast.error(
        "No folder selected. Please choose a folder to download the build.",
      );
      return;
    }

    setSelectedPath(path);
  };

  const confirmPath = async () => {
    if (!selectedPath) {
      showToast.error("Please select a folder first.");
      return;
    }

    setLoading(true);
    setPath(selectedPath);

    setTimeout(() => {
      setLoading(false);
      setImported(true);
    }, 500);
  };

  const handlePrimaryClick = () => {
    if (!selectedPath) return choosePath();
    if (imported) return onClose();
    return confirmPath();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 25 }}
            onClick={(e) => e.stopPropagation()}
            className={`${colors.current.background.primary} border ${colors.current.border} text-center rounded-xl w-full max-w-md p-6`}
          >
            <h3 className="text-xl font-semibold mb-1">
              Choose Download Location
            </h3>
            <p className="text-white/60 text-sm mb-6">
              Select where you want this build to be downloaded.
            </p>

            <div className="rounded-lg bg-zinc-800/60 border border-zinc-700 px-3 py-2 text-sm text-white/80 break-all">
              {selectedPath || "No folder selected"}
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={onClose}
                disabled={loading}
                className="text-white/60 hover:text-white transition disabled:opacity-50"
              >
                Cancel
              </button>

              <button
                onClick={handlePrimaryClick}
                disabled={loading}
                className="rounded-lg cursor-pointer bg-white text-black px-4 py-2 font-medium transition disabled:opacity-50 flex items-center gap-2 min-w-22.5 justify-center"
              >
                {loading ? (
                  <span className="h-4 w-4 border-2 border-black/40 border-t-black rounded-full animate-spin" />
                ) : imported ? (
                  "Finish"
                ) : (
                  "Import"
                )}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
