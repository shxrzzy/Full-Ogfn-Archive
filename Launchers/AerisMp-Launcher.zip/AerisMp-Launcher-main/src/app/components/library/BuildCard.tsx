"use client";

import {
  Loader2,
  Lock,
  Play,
  Trash2,
  MoreHorizontal,
  Pause,
  X,
  CheckCircle2,
  TriangleAlert,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { listen } from "@tauri-apps/api/event";
import { useLibraryStore } from "../../../stores/library";
import { exit } from "../../../util/build/close";
import { start } from "../../../util/build/launch";
import { useTheme } from "../../../hooks/useTheme";
import { useAuth } from "../../../hooks/useAuth";

interface Item {
  path: string;
  build: any;
  options: string | null;
  setOptions: (path: string | null) => void;
  handleDeleteBuild: (path: string) => void;
  isPublicBuild: boolean;
}

interface DownloadState {
  file: string;
  progress: number;
  stage:
  | "downloading"
  | "injecting"
  | "launching"
  | "verifying"
  | "done"
  | null;
  active: boolean;
}

interface ValidationError {
  message: string;
  errors: string[];
}

export function BuildCard({
  path,
  build,
  options,
  setOptions,
  handleDeleteBuild,
  isPublicBuild,
}: Item) {
  const [hover, setHover] = useState(false);
  const [downloadState, setDownloadState] = useState<DownloadState>({
    file: "",
    progress: 0,
    stage: null,
    active: false,
  });
  const [validationError, setValidationError] =
    useState<ValidationError | null>(null);
  const [verifyingFiles, setVerifyingFiles] = useState<string[]>([]);
  const [acWarning, setAcWarning] = useState<{ message: string; strikes: number; remaining: number } | null>(null);
  const [acBanned, setAcBanned] = useState<string | null>(null);

  const { isValidSession } = useAuth.user();
  const patchBuild = useLibraryStore((state) => state.patch);
  const imageUrl = "https://s1.directupload.eu/images/260326/ok6b2l3f.png";

  // useEffect(() => {
  //   const unlisten = listen("download-progress", (event: any) => {
  //     const payload = event.payload;

  //     if (payload.stage === "done") {
  //       setDownloadState({
  //         file: payload.file || "",
  //         progress: 100,
  //         stage: "launching",
  //         active: true,
  //       });

  //       setTimeout(() => {
  //         setDownloadState({
  //           file: "",
  //           progress: 0,
  //           stage: null,
  //           active: false,
  //         });
  //       }, 1500);

  //       return;
  //     }

  //     setDownloadState({
  //       file: payload.file || "",
  //       progress: payload.progress ?? 0,
  //       stage: payload.stage ?? "downloading",
  //       active: true,
  //     });
  //   });

  //   return () => {
  //     setDownloadState((prev) => ({
  //       ...prev,
  //       stage: "done",
  //       active: false,
  //     }));
  //     unlisten.then((f) => f());
  //   };
  // }, []);

  async function Launch() {
    if (!isPublicBuild) return;

    if (build.open) {
      const result = await exit(path);
      if (result) {
        patchBuild(path, { open: false });
      }
      return;
    }

    patchBuild(path, { open: true });
    performLaunch();
  }

  async function performLaunch() {
    setDownloadState({
      file: "",
      progress: 0,
      stage: null,
      active: false,
    });
    setValidationError(null);
    setVerifyingFiles([]);

    const unlistenDownload = await listen("download-progress", (event: any) => {
      const payload = event.payload;
      setDownloadState({
        file: payload.file || "",
        progress: payload.progress ?? 0,
        stage: payload.stage ?? "downloading",
        active: true,
      });
    });

    const unlistenVerify = await listen("verify-build", (event: any) => {
      const payload = event.payload;
      setDownloadState((prev) => ({
        ...prev,
        active: true,
        stage: "verifying",
      }));

      if (payload.status === "deleted") {
        setVerifyingFiles((prev) => [...prev, `Removed: ${payload.file}`]);
      } else if (payload.status === "failed") {
        setVerifyingFiles((prev) => [
          ...prev,
          `Failed to remove: ${payload.file}`,
        ]);
      }
    });

    const unlistenValidation = await listen(
      "build-validation-error",
      (event: any) => {
        const payload = event.payload;
        setValidationError({
          message: payload.message,
          errors: payload.errors,
        });
        setDownloadState({
          file: "",
          progress: 0,
          stage: null,
          active: true,
        });
        unlistenDownload();
        unlistenVerify();
        unlistenValidation();
        unlistenLaunchFinished();
      },
    );

    let unlistenLaunchFinished: () => void = () => {};
    unlistenLaunchFinished = await listen("launch-finished", async (_event: any) => {

      setDownloadState({ file: "", progress: 0, stage: null, active: false });
      setVerifyingFiles([]);
      unlistenDownload();
      unlistenVerify();
      unlistenValidation();
      unlistenLaunchFinished();
    });

    // Anticheat events
    const unlistenAcWarning = await listen("anticheat-warning", (event: any) => {
      const { message, strikes, remaining } = event.payload;
      setAcWarning({ message, strikes, remaining });
      setDownloadState({ file: "", progress: 0, stage: null, active: false });
    });

    const unlistenAcBanned = await listen("anticheat-banned", (event: any) => {
      setAcBanned(event.payload.message);
      setDownloadState({ file: "", progress: 0, stage: null, active: false });
      unlistenAcWarning();
      unlistenAcBanned();
    });

    setDownloadState({
      file: "",
      progress: 100,
      stage: "launching",
      active: true,
    });
    start(path, isValidSession, true)
      .catch((error) => {
        console.error("Launch error:", error);
        unlistenDownload();
        unlistenVerify();
        unlistenValidation();
        unlistenLaunchFinished();
      });
  }

  const colors = useTheme();

  const getStatusText = () => {
    switch (downloadState.stage) {
      case "injecting":
        return "Injecting DLL...";
      case "launching":
        return "Launching...";
      case "done":
        return "Finished!";
      default:
        return "Downloading...";
    }
  };

  const getDescriptionText = () => {
    if (validationError) {
      return validationError.message;
    }

    if (downloadState.stage === "verifying") {
      return "Checking build integrity...";
    }

    if (downloadState.stage === "launching") {
      return `Preparing ${build.season}...`;
    }
    return downloadState.file || "Preparing...";
  };

  return (
    <>
      {downloadState.active && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                {validationError ? (
                  <TriangleAlert className="w-6 h-6 text-red-400" />
                ) : downloadState.stage === "verifying" ? (
                  <Loader2 className="w-6 h-6 text-blue-400 animate-spin" />
                ) : (
                  <Loader2 className="w-6 h-6 text-blue-400 animate-spin" />
                )}
                <h3
                  className={`text-xl font-semibold ${validationError ? "text-red-400" : "text-white"}`}
                >
                  {getStatusText()}
                </h3>
              </div>
              {downloadState.stage !== "launching" && (
                <button
                  onClick={() => {
                    setDownloadState((prev) => ({ ...prev, active: false }));
                    setValidationError(null);
                    setVerifyingFiles([]);
                  }}
                  className="text-zinc-400 hover:text-white transition-colors p-2 hover:bg-zinc-800 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>

            <p
              className={`mb-6 ${validationError ? "text-red-300" : "text-zinc-400"}`}
            >
              {getDescriptionText()}
            </p>

            {validationError ? (
              <div className="space-y-4">
                <div className="bg-red-950/30 border border-red-900/50 rounded-lg p-4 max-h-60 overflow-y-auto">
                  <h4 className="text-red-400 font-semibold mb-2 text-sm">
                    Corrupted Files:
                  </h4>
                  <ul className="space-y-1">
                    {validationError.errors.map((error, idx) => (
                      <li
                        key={idx}
                        className="text-xs text-red-300/80 font-mono"
                      >
                        • {error}
                      </li>
                    ))}
                  </ul>
                </div>
                <button
                  onClick={() => {
                    setDownloadState((prev) => ({ ...prev, active: false }));
                    setValidationError(null);
                    setVerifyingFiles([]);
                  }}
                  className="w-full bg-red-600 hover:bg-red-700 text-white py-2.5 rounded-lg font-medium transition-colors"
                >
                  Close
                </button>
              </div>
            ) : downloadState.stage === "verifying" ? (
              <div className="space-y-4">
                {verifyingFiles.length > 0 && (
                  <div className="bg-zinc-800/50 border border-zinc-700 rounded-lg p-4 max-h-40 overflow-y-auto">
                    <h4 className="text-zinc-300 font-semibold mb-2 text-sm">
                      Cleaning up:
                    </h4>
                    <ul className="space-y-1">
                      {verifyingFiles.map((file, idx) => (
                        <li
                          key={idx}
                          className="text-xs text-zinc-400 font-mono flex items-center gap-2"
                        >
                          <CheckCircle2 className="w-3 h-3 text-green-400 flex-shrink-0" />
                          {file}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                <div className="flex items-center justify-center gap-2 text-sm text-zinc-400">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying pak files...</span>
                </div>
              </div>
            ) : downloadState.stage !== "launching" ? (
              <>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-zinc-400">Current File</span>
                      <span className="text-white font-medium">
                        {downloadState.file}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-zinc-400">Progress</span>
                      <span className="text-white font-medium">
                        {downloadState.progress.toFixed(1)}%
                      </span>
                    </div>
                  </div>

                  <div className="w-full bg-zinc-800 rounded-full h-2 overflow-hidden">
                    <motion.div
                      className="h-full bg-gradient-to-r from-blue-500 to-blue-600"
                      initial={{ width: 0 }}
                      animate={{ width: `${downloadState.progress}%` }}
                      transition={{ duration: 0.3 }}
                    />
                  </div>
                </div>
              </>
            ) : null}
          </motion.div>
        </motion.div>
      )}


      {/* Anticheat Warning Modal */}
      <AnimatePresence>
        {acWarning && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-zinc-900 border border-yellow-600/50 rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl"
            >
              <div className="flex items-center gap-3 mb-4">
                <TriangleAlert className="w-7 h-7 text-yellow-400 flex-shrink-0" />
                <h3 className="text-xl font-black text-yellow-400 uppercase tracking-wide">
                  Anti-Cheat Warning
                </h3>
              </div>
              <p className="text-zinc-200 text-sm leading-relaxed whitespace-pre-line mb-6">
                {acWarning.message}
              </p>
              <div className="flex gap-2 mb-6">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className={`flex-1 h-2 rounded-full ${i < acWarning.strikes ? "bg-yellow-500" : "bg-zinc-700"}`} />
                ))}
              </div>
              <button
                onClick={() => setAcWarning(null)}
                className="w-full bg-yellow-600 hover:bg-yellow-500 text-black font-bold py-2.5 rounded-lg transition-colors"
              >
                I Understand
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Anticheat Ban Modal */}
      <AnimatePresence>
        {acBanned && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/95 backdrop-blur-sm z-50 flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-zinc-900 border border-red-600/50 rounded-2xl p-8 max-w-md w-full mx-4 shadow-2xl"
            >
              <div className="flex items-center gap-3 mb-4">
                <X className="w-7 h-7 text-red-400 flex-shrink-0" />
                <h3 className="text-xl font-black text-red-400 uppercase tracking-wide">
                  Permanently Banned
                </h3>
              </div>
              <p className="text-zinc-300 text-sm leading-relaxed mb-6">{acBanned}</p>
              <div className="flex gap-2 mb-6">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="flex-1 h-2 rounded-full bg-red-600" />
                ))}
              </div>
              <p className="text-zinc-500 text-xs text-center">
                You may appeal your ban in our Discord server.
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        layout
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
        className={`relative group ${colors.current.background.primary} border ${colors.current.border} max-w-xs rounded-xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-black/20`}
      >
        <div className="relative aspect-[10/10] overflow-hidden bg-zinc-900">
          <img
            src={imageUrl}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />

          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

          <AnimatePresence>
            {hover && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                className="absolute top-3 right-3"
              >
                <div className="relative">
                  <button
                    onClick={() => setOptions(options === path ? null : path)}
                    className="p-2.5 cursor-pointer bg-zinc-900/90 hover:bg-zinc-800/90 backdrop-blur-sm rounded-lg transition-all duration-200 border border-zinc-700/50"
                  >
                    <MoreHorizontal className="text-white" size={18} />
                  </button>

                  <AnimatePresence>
                    {options === path && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95, y: -10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: -10 }}
                        className="absolute top-full right-0 mt-2 bg-zinc-900/95 backdrop-blur-xl border border-zinc-800 rounded-lg overflow-hidden shadow-2xl min-w-[160px]"
                      >
                        <button
                          onClick={() => handleDeleteBuild(path)}
                          className="w-full flex items-center gap-3 px-4 py-3 text-sm text-red-400 hover:bg-red-950/50 hover:text-red-300 transition-colors border-t border-zinc-800"
                        >
                          <Trash2 size={16} />
                          Delete
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {hover && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute inset-x-3 bottom-3 transition-all duration-200"
              >
                <button
                  onClick={Launch}
                  disabled={!isPublicBuild || build.loading}
                  className="w-full py-2.5 px-4 cursor-pointer rounded-lg font-semibold text-sm transition-all duration-200 flex items-center justify-center gap-2 bg-zinc-900/90 hover:bg-zinc-800/90 text-white border border-zinc-700/50 backdrop-blur-sm"
                >
                  {!isPublicBuild ? (
                    <>
                      <Lock size={16} />
                      Locked
                    </>
                  ) : build.loading ? (
                    <>
                      <Loader2 className="animate-spin" size={16} />
                      Launching...
                    </>
                  ) : build.open ? (
                    <>
                      <Pause size={16} />
                      Close
                    </>
                  ) : (
                    <>
                      <Play size={16} />
                      Launch
                    </>
                  )}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="p-4 space-y-3">
          <div>
            <h3 className="text-lg font-bold text-white mb-1 truncate">
              Fortnite {build.season}
            </h3>
            <div className="flex items-center gap-2">
              {build.version.includes("CL") && (
                <span className="text-xs text-zinc-600">{build.version}</span>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
}
