export function EmptyState() {
  return (
    <div className="flex flex-col hide-scroll items-center justify-center h-full text-center px-4">
      <h3 className="text-2xl font-bold text-white mb-3 bg-gradient-to-r from-white to-stone-300 bg-clip-text">
        No Builds <small className="text-xs text-gray-600"></small>
      </h3>

      <p className="text-stone-400 mb-8 max-w-md text-base leading-relaxed">
        Sadly it looks like you don't have any builds :\ . So click the{" "}
        <span className={`font-bold text-white`}>Import</span> button to the our build and get start playing!
      </p>
    </div>
  );
}

export default EmptyState;
