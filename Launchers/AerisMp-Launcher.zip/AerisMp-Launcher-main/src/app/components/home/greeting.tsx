import { useProfileStore } from "../../../stores/profile";
import { useUserStore } from "../../../stores/user";
import { useTheme } from "../../../hooks/useTheme";

const VBUCKS_ICON = "/fortnite-v-bucks.png";
const BATTLE_PASS_ICON = "/battlepass_premium.png";

// Arena division thresholds matching the backend
const DIVISIONS = [
  { name: "Open League", min: 0,     color: "from-gray-500 to-gray-600" },
  { name: "Open League", min: 250,   color: "from-gray-500 to-gray-600" },
  { name: "Open League", min: 500,   color: "from-gray-500 to-gray-600" },
  { name: "Contender",   min: 1000,  color: "from-blue-500 to-blue-700" },
  { name: "Contender",   min: 1500,  color: "from-blue-500 to-blue-700" },
  { name: "Contender",   min: 2500,  color: "from-blue-500 to-blue-700" },
  { name: "Champion",    min: 4000,  color: "from-yellow-400 to-amber-600" },
  { name: "Champion",    min: 6000,  color: "from-yellow-400 to-amber-600" },
  { name: "Champion",    min: 12000, color: "from-yellow-400 to-amber-600" },
  { name: "Elite",       min: 16000, color: "from-purple-500 to-purple-700" },
];

function getDivision(hype: number) {
  let div = DIVISIONS[0];
  for (const d of DIVISIONS) {
    if (hype >= d.min) div = d;
  }
  const idx = DIVISIONS.lastIndexOf(div);
  const next = DIVISIONS[idx + 1];
  const progress = next ? Math.min(100, Math.round(((hype - div.min) / (next.min - div.min)) * 100)) : 100;
  return { ...div, divNum: idx + 1, next, progress };
}

const cardBaseClasses =
  "flex items-center gap-4 rounded-lg w-full min-w-[280px]";

function GreetingCard() {
  const favoriteCharacter =
    useProfileStore((s) => s.getFavoriteCharacter()) ||
    "cid_001_athena_commando_f_default";
  const displayName = useUserStore((s) => s.displayName);

  const colors = useTheme();

  const iconUrl = `https://fortnite-api.com/images/cosmetics/br/${favoriteCharacter.toLowerCase()}/icon.png`;

  return (
    <div
      className={`${cardBaseClasses} ${colors.current.background.primary} text-white`}
      style={{ height: 80 }}
    >
      <img
        src={iconUrl}
        alt={favoriteCharacter}
        className="w-20 h-20 rounded-md object-cover shadow-md flex-shrink-0"
        draggable={false}
      />
      <div className="flex flex-col justify-center leading-tight w-full">
        <span className="text-xs text-gray-300">Welcome,</span>
        <span className="text-lg font-bold truncate">{displayName}</span>
      </div>
    </div>
  );
}

function TierCard() {
  const tier =
    useProfileStore((s) => s.profiles?.athena?.stats?.attributes?.level) ?? 0;

  return (
    <div
      className={`${cardBaseClasses} bg-linear-to-r px-2 from-[#c77e27] to-[#993e19] text-white`}
      style={{ height: 80 }}
    >
      <img
        src={BATTLE_PASS_ICON}
        className="w-17 h-15 flex-shrink-0"
        draggable={false}
      />
      <div className="flex flex-col justify-center leading-tight w-full">
        <span className="text-xs uppercase text-[#d8fd8db6]">Battle Pass</span>
        <span className="text-lg font-bold truncate">
          Tier {tier.toLocaleString()}
        </span>
      </div>
    </div>
  );
}

function VbucksCard() {
  const vbucks =
    useProfileStore(
      (s) =>
        s.profiles?.common_core?.items?.["Currency:MtxPurchased"]?.quantity,
    ) ?? 0;

  return (
    <div
      className={`${cardBaseClasses} bg-linear-to-r pl-2 from-cyan-500 via-cyan-600 to-cyan-700 text-white`}
      style={{ height: 80 }}
    >
      <img
        src={VBUCKS_ICON}
        alt="V-Bucks"
        className="w-20 h-20 shrink-0"
        draggable={false}
      />
      <div className="flex flex-col justify-center leading-tight w-full">
        <span className="text-xs uppercase text-cyan-100/90">V-Bucks</span>
        <span className="text-lg font-bold truncate">
          {vbucks.toLocaleString()}
        </span>
      </div>
    </div>
  );
}

function ArenaHypeCard() {
  const hype = useProfileStore(
    (s) => s.profiles?.athena?.stats?.attributes?.arena_hype,
  ) ?? 0;

  const { name, divNum, color, progress, next } = getDivision(hype);

  return (
    <div
      className={`${cardBaseClasses} bg-gradient-to-r ${color} px-3 text-white`}
      style={{ height: 80 }}
    >
      <img
        src="https://media.fortniteapi.io/images/arena_hype.png"
        alt="Hype"
        className="w-12 h-12 flex-shrink-0 drop-shadow-lg"
        draggable={false}
        onError={(e) => {
          const el = e.target as HTMLImageElement;
          el.style.display = "none";
          const span = document.createElement("span");
          span.textContent = "🏅";
          span.className = "text-3xl flex-shrink-0";
          el.parentNode?.insertBefore(span, el);
        }}
      />
      <div className="flex flex-col justify-center leading-tight w-full gap-1">
        <div className="flex items-center justify-between">
          <span className="text-xs uppercase font-semibold tracking-wide text-white/80">
            {name} · Div {divNum}
          </span>
          <span className="text-xs font-bold text-white/90">{hype.toLocaleString()} hype</span>
        </div>
        <div className="w-full h-1.5 rounded-full bg-black/30 overflow-hidden">
          <div
            className="h-full rounded-full bg-white/80 transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        {next && (
          <span className="text-[10px] text-white/60">
            {(next.min - hype).toLocaleString()} hype to next division
          </span>
        )}
      </div>
    </div>
  );
}

export function ProfileCardsRow() {
  return (
    <div className="flex gap-4 justify-center items-center">
      <GreetingCard />
      <TierCard />
      <VbucksCard />
      <ArenaHypeCard />
    </div>
  );
}
