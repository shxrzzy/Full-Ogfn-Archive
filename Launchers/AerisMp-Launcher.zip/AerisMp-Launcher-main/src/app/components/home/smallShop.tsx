"use client";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useTheme } from "../../../hooks/useTheme";
import { ShopItem } from "../../../vite-env";

interface SmallShopProps {
  items: ShopItem[];
  loading: boolean;
  label: string;
}

export function SmallShop({ items, loading, label }: SmallShopProps) {
  const [index, setIndex] = useState(0);
  const colors = useTheme();

  useEffect(() => {
    setIndex(0);
  }, [items]);

  useEffect(() => {
    if (!items.length) return;
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % items.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [items]);

  const getRarityGradient = (rarity: string) => {
    switch (rarity.toLowerCase()) {
      case "common": return "from-zinc-500 via-zinc-600 to-zinc-700";
      case "uncommon": return "from-lime-500 via-lime-600 to-lime-700";
      case "rare": return "from-sky-500 via-sky-600 to-sky-700";
      case "epic": return "from-purple-500 via-purple-600 to-purple-700";
      case "legendary": return "from-orange-500 via-orange-600 to-orange-700";
      case "mythic": return "from-yellow-400 via-yellow-500 to-yellow-600";
      case "marvel": return "from-red-600 via-red-700 to-red-800";
      case "dc": return "from-blue-600 via-blue-700 to-blue-800";
      case "icon series": return "from-cyan-500 via-cyan-600 to-cyan-700";
      case "star wars": return "from-slate-700 via-slate-800 to-slate-900";
      default: return "from-neutral-600 via-neutral-700 to-neutral-800";
    }
  };

  if (loading) {
    return (
      <div className="w-full h-full min-h-[250px] flex flex-col">
        <div className="px-4 pt-3 pb-2 flex-shrink-0">
          <p className="text-[10px] text-white/40 uppercase tracking-widest font-semibold">Item Shop</p>
          <h3 className="text-sm font-bold text-white">{label}</h3>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className={`w-8 h-8 border-4 border-white/20 border-t-white/70 rounded-full animate-spin`} />
        </div>
      </div>
    );
  }

  if (!items.length) {
    return (
      <div className="w-full h-full min-h-[250px] flex flex-col">
        <div className="px-4 pt-3 pb-2 flex-shrink-0">
          <p className="text-[10px] text-white/40 uppercase tracking-widest font-semibold">Item Shop</p>
          <h3 className="text-sm font-bold text-white">{label}</h3>
        </div>
        <div className="flex-1 flex items-center justify-center text-zinc-500 text-sm">No items available</div>
      </div>
    );
  }

  const item = items[index];

  return (
    <div className="w-full h-full min-h-[250px] flex flex-col">
      {/* Label header */}
      <div className="px-4 pt-3 pb-2 flex-shrink-0 z-10">
        <p className="text-[10px] text-white/40 uppercase tracking-widest font-semibold">Item Shop</p>
        <h3 className="text-sm font-bold text-white">{label}</h3>
      </div>

      {/* Card */}
      <div className="relative flex-1 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={`bg-${index}`}
            className={`absolute inset-0 bg-gradient-to-br ${getRarityGradient(item.rarity.value)}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            style={{ filter: "brightness(0.8)" }}
          />
        </AnimatePresence>

        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

        <AnimatePresence mode="wait">
          <motion.div
            key={`img-${index}`}
            initial={{ opacity: 0, scale: 1.08 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.4 }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <img
              src={item.images.featured || item.images.icon}
              className="max-w-full max-h-full object-contain drop-shadow-2xl"
              onError={(e) => { (e.target as HTMLImageElement).src = item.images.icon; }}
              draggable={false}
            />
          </motion.div>
        </AnimatePresence>

        <div className="absolute inset-x-0 bottom-0 px-4 py-3">
          <AnimatePresence mode="wait">
            <motion.div
              key={`info-${index}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="space-y-1"
            >
              <h3 className="text-white text-base font-extrabold leading-tight drop-shadow-md line-clamp-1">
                {item.name}
              </h3>
              <p className="text-gray-300 text-xs leading-snug line-clamp-2">
                {item.description || "No description available."}
              </p>
              <div className="flex items-center gap-1.5 mt-1">
                <img src="https://image.fnbr.co/price/icon_vbucks_50x.png" className="w-4 h-4" draggable={false} />
                <span className="text-white font-bold text-sm">{item.price.toLocaleString()}</span>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Dot indicators */}
        <div className="absolute bottom-3 right-3 flex gap-1">
          {items.slice(0, 6).map((_, i) => (
            <button
              key={i}
              onClick={() => setIndex(i)}
              className={`h-1 rounded-full transition-all duration-300 ${i === index ? "w-4 bg-white" : "w-1.5 bg-white/30 hover:bg-white/60"}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
