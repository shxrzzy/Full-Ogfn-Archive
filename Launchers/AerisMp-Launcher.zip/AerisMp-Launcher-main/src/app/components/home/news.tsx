import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

import { GENERAL_CONFIG } from "../../../util/general";
import { SeasonInfo } from "../../../util/seasonInfo";

import { api } from "../../../lib/api";

type NewsMessage = {
  image: string;
  adspace?: string;
  title: string;
  body: string;
};

type ContentPagesWithSTW = {
  savetheworldnews?: {
    news?: {
      messages?: NewsMessage[];
    };
  };
};

export function News() {
  const [news, setNews] = useState<NewsMessage[]>([]);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    (async () => {
      const res = await api.getContentPages();
      if (!res.success || !res.data) return;

      const pages = res.data as ContentPagesWithSTW;
      const messages = pages.savetheworldnews?.news?.messages ?? [];

      setNews(messages);
    })();
  }, []);

  const { readableSeason, description, image } = SeasonInfo(
    GENERAL_CONFIG.CURRENT_SEASON.toString(),
  );

  const imageProxy = "https://images.weserv.nl/?url=";

  const getProxiedUrl = (url: string) => {
    if (url.startsWith("https://static.wikia.nocookie.net")) {
      return imageProxy + encodeURIComponent(url.replace(/^https?:\/\//, ""));
    }
    return url;
  };

  const seasonSlide: NewsMessage = {
    image,
    title: readableSeason,
    adspace: GENERAL_CONFIG.NAME,
    body: description,
  };

  const carouselItems = [seasonSlide, ...news];

  useEffect(() => {
    if (carouselItems.length <= 1) return;

    const interval = setInterval(() => {
      setIndex((i) => (i + 1) % carouselItems.length);
    }, 6000);

    return () => clearInterval(interval);
  }, [carouselItems.length]);

  const current = carouselItems[index];

  const containerClasses =
    "relative h-[350px] mb-4 rounded-lg overflow-hidden shadow-xl shadow-black/20";

  return (
    <div className={containerClasses}>
      <AnimatePresence mode="wait">
        <motion.div
          key={index}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -30 }}
          transition={{ duration: 0.5 }}
          className="absolute inset-0"
        >
          {current.image && (
            <img
              src={getProxiedUrl(current.image)}
              className="absolute inset-0 w-full h-full object-cover"
              onError={(e) => {
                const t = e.target as HTMLImageElement;
                t.src = "/placeholder.png";
              }}
            />
          )}

          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/10" />

          <div className="absolute bottom-0 left-0 right-0 p-5">
            {current.adspace && (
              <span className="text-xs font-bold text-zinc-300 uppercase">
                {current.adspace}
              </span>
            )}

            <h3 className="text-xl font-extrabold text-white uppercase tracking-wide mt-1">
              {current.title}
            </h3>

            <p className="text-sm text-gray-200 mt-1 max-w-xl line-clamp-2">
              {current.body}
            </p>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
