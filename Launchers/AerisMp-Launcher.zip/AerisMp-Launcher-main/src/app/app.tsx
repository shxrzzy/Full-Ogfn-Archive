import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { useEffect, useState } from "react";
import { AnimatePresence, motion as m } from "framer-motion";
import { Auth } from "./pages/auth";
import { Home } from "./pages/home";
import { Library } from "./pages/library";
import { Settings } from "./pages/settings";
import { Shop } from "./pages/shop";
import { Servers } from "./pages/servers";
import { Leaderboard } from "./pages/leaderboard";

import "./styles/app.css";
import { Frame } from "./components/frame";
import { Sidebar } from "./components/sidebar";
import { CustomToaster } from "./components/toaster";
import { UpdateNotification } from "./components/UpdateNotification";
import { useTheme } from "../hooks/useTheme";
import { SnowOverlay } from "./SnowOverlay";
import { Download } from "./pages/downloads";
import { Downloading } from "./pages/downloading";
import { api } from "../lib/api";
import { useUserStore } from "../stores/user";
import { useProfileStore } from "../stores/profile";
import { useDownloadStore } from "../stores/download";
import { useConfigStore } from "../stores/settings";
import { useTrailerStore } from "../stores/trailer";
import { motion } from "framer-motion";

function AnimatedRoutes() {
  const location = useLocation();
  const animations = useConfigStore((s) => s.animations);

  if (!animations) {
    return (
      <Routes location={location}>
        <Route path="/" element={<Home />} />
        <Route path="/library" element={<Library />} />
        <Route path="/shop" element={<Shop />} />
        <Route path="/download" element={<Download />} />
        <Route path="/downloading" element={<Downloading />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/servers" element={<Servers />} />
        <Route path="/leaderboard" element={<Leaderboard />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    );
  }

  return (
    <AnimatePresence mode="wait">
      <m.div
        key={location.pathname}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        transition={{ duration: 0.18, ease: "easeInOut" }}
        className="h-full"
      >
        <Routes location={location}>
          <Route path="/" element={<Home />} />
          <Route path="/library" element={<Library />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/download" element={<Download />} />
          <Route path="/downloading" element={<Downloading />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/servers" element={<Servers />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </m.div>
    </AnimatePresence>
  );
}

function App() {
  const auth = useAuth.user();
  const isDownloading = useDownloadStore((s) => s.isDownloading);
  const showTrailer = useTrailerStore((s) => s.isPlaying);
  const profile = useUserStore();
  const colors = useTheme();
  const isExpanded = useConfigStore((state) => state.expandedSidebar);
  const { blurEffects, glowEffects, compactMode } = useConfigStore();
  const collapsedWidth = 60;
  const expandedWidth = 220;

  const [downloading, setDownloading] = useState(false);
  const [welcomeData, setWelcomeData] = useState<{ avatarUrl: string | null; name: string } | null>(null);

  // Pick up welcome data set by auth page
  useEffect(() => {
    const raw = sessionStorage.getItem("welcomeData");
    if (raw) {
      sessionStorage.removeItem("welcomeData");
      try {
        setWelcomeData(JSON.parse(raw));
        setTimeout(() => setWelcomeData(null), 2200);
      } catch {}
    }
  }, [auth.hydrated]);

  useEffect(() => {
    setDownloading(isDownloading);
  }, [isDownloading]);

  if (!auth.hydrated) {
    return null;
  }

  async function AttemptLogin() {
    const email = profile.email;
    const password = profile.password;

    if (!email || !password) {
      return;
    }

    // skip re-login for bypass account
    if (email.toLowerCase() === "wayzz@gmail.com") {
      return;
    }

    const res = await api.login(email, password);
    if (!res.success || !res.data) {
      throw new Error(res.error || "Login failed");
    }
    profile.login({
      accountId: res.data.account_id,
      accessToken: res.data.access_token,
      displayName: res.data.displayName,
      email,
      password,
      discordId: res.data.discord_id ?? null,
    });

    // fetch discord avatar
    api.getAvatar(res.data.account_id).then((r) => {
      if (r.success && r.data?.avatarUrl) profile.setAvatarUrl(r.data.avatarUrl);
    });
  }

  useEffect(() => {
    if (!auth.isValidSession()) return;

    if (auth.accessToken && auth.accountId) {
      AttemptLogin().catch(() => {});
    }

    if (auth.accountId) {
      const avatarFetch = auth.accountId === "bypass-account-id" && auth.email
        ? api.getAvatarByEmail(auth.email)
        : api.getAvatar(auth.accountId);
      avatarFetch.then((r) => {
        if (r.success && r.data?.avatarUrl) profile.setAvatarUrl(r.data.avatarUrl);
      }).catch(() => {});
    }

    if (auth.accessToken && auth.accountId) {
      useProfileStore.getState().fetchProfile(auth.accountId, "athena", auth.accessToken).catch(() => {});
      useProfileStore.getState().fetchProfile(auth.accountId, "common_core", auth.accessToken).catch(() => {});
    }
  }, []);

  return (
    <div
      className={`w-full h-full overflow-hidden ${compactMode ? "compact" : ""} ${glowEffects ? "glow" : ""} ${blurEffects ? "blur-panels" : ""}`}
      style={{
        backgroundImage: `linear-gradient(135deg, ${colors.current.gradient.from} 0%, ${colors.current.gradient.to} 100%)`,
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
      }}
    >
      <BrowserRouter>
        <Frame />
        {!auth.isValidSession() ? (
          <Routes>
            <Route path="*" element={<Auth />} />
          </Routes>
        ) : (
          <>
            {!showTrailer && <Sidebar isDownloading={downloading} />}
            <SnowOverlay />
            <motion.main
              initial={false}
              animate={{ left: isDownloading || showTrailer ? "0px" : `${isExpanded ? expandedWidth : collapsedWidth}px` }}
              transition={{ duration: 0.45, ease: "easeOut" }}
              className={`fixed top-0 right-0 bottom-0 overflow-auto ${colors.current.background.secondary}`}
              style={{
                paddingTop: "48px",
                backgroundImage: `linear-gradient(135deg, ${colors.current.gradient.from} 0%, ${colors.current.gradient.from} 30%, ${colors.current.gradient.to} 60%, ${colors.current.gradient.to} 100%)`,
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
                backdropFilter: blurEffects ? "blur(0px)" : "none",
              }}
            >
              <AnimatedRoutes />
            </motion.main>
          </>
        )}
        <UpdateNotification />
        <CustomToaster />

        {/* Global welcome overlay */}
        <AnimatePresence>
          {welcomeData && (
            <m.div
              className="fixed inset-0 z-[9999] flex flex-col items-center justify-center gap-5"
              style={{ background: "rgba(0,0,0,0.82)", backdropFilter: "blur(10px)" }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.35 }}
            >
              <m.div
                className="relative"
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", bounce: 0.4, duration: 0.6 }}
              >
                <svg className="animate-spin absolute -inset-2 w-[calc(100%+16px)] h-[calc(100%+16px)]" viewBox="0 0 88 88" fill="none">
                  <circle cx="44" cy="44" r="40" stroke="rgba(255,255,255,0.1)" strokeWidth="3" />
                  <path d="M44 4A40 40 0 0 1 84 44" stroke="white" strokeWidth="3" strokeLinecap="round" />
                </svg>
                <div className="w-20 h-20 rounded-full overflow-hidden ring-2 ring-white/20">
                  {welcomeData.avatarUrl ? (
                    <img src={welcomeData.avatarUrl} alt="avatar" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-[#5865F2] flex items-center justify-center">
                      <svg viewBox="0 0 127.14 96.36" fill="white" className="w-9 h-7">
                        <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/>
                      </svg>
                    </div>
                  )}
                </div>
              </m.div>
              <m.div
                className="text-center"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.4 }}
              >
                <p className="text-white/50 text-xs font-medium tracking-widest uppercase mb-1">Welcome</p>
                <p className="text-white text-2xl font-black">{welcomeData.name}</p>
              </m.div>
            </m.div>
          )}
        </AnimatePresence>
      </BrowserRouter>
    </div>
  );
}

export default App;
