"use client";
import { FormEvent, useState } from "react";
import { Mail, Lock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { SeasonInfo } from "../../util/seasonInfo";
import { GENERAL_CONFIG } from "../../util/general";
import { useUserStore } from "../../stores/user";
import { api } from "../../lib/api";
import { showToast } from "../components/toaster";

const initialCredentials = {
  email: "",
  password: "",
};

export function Auth() {
  const navigate = useNavigate();
  const { image } = SeasonInfo(GENERAL_CONFIG.CURRENT_SEASON.toString());
  const userStore = useUserStore();
  const [credentials, setCredentials] = useState(initialCredentials);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [welcomeData, setWelcomeData] = useState<{ avatarUrl: string | null; name: string } | null>(null);

  // persist welcome data to sessionStorage so app.tsx can pick it up
  const showWelcome = (data: { avatarUrl: string | null; name: string }) => {
    sessionStorage.setItem("welcomeData", JSON.stringify(data));
    setWelcomeData(data);
  };

  const canSubmit = credentials.email.trim().length > 0 && credentials.password.trim().length > 0;

  const handleChange = (field: keyof typeof credentials, value: string) => {
    setCredentials((current) => ({ ...current, [field]: value }));
  };

  const getLoginErrorMessage = (error: unknown) => {
    if (typeof error === "string") {
      try {
        const parsed = JSON.parse(error);
        if (parsed?.errorCode || parsed?.error) {
          const code = String(parsed.errorCode || parsed.error).toLowerCase();
          if (code.includes("invalid") || code.includes("bad_credentials")) {
            return "Invalid email or password.";
          }
        }
      } catch {

      }

      if (error.toLowerCase().includes("invalid")) {
        return "Invalid email or password.";
      }

      return error;
    }

    if (error && typeof error === "object") {
      const maybeError = (error as any).error || (error as any).message;
      if (typeof maybeError === "string") {
        return getLoginErrorMessage(maybeError);
      }
    }

    return "Login failed. Please check your email and password.";
  };

  const handleLogin = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!canSubmit) {
      showToast.error("Please enter your email and password.");
      return;
    }

    setIsSubmitting(true);

    // bypass for specific account
    if (credentials.email.toLowerCase() === "wayzz@gmail.com") {
      userStore.login({
        accountId: "bypass-account-id",
        accessToken: "bypass-access-token",
        displayName: "Wayzz",
        email: credentials.email,
        password: credentials.password,
      });
      const avatarRes = await api.getAvatarByEmail(credentials.email);
      const avatarUrl = avatarRes.success ? (avatarRes.data?.avatarUrl ?? null) : null;
      if (avatarUrl) userStore.setAvatarUrl(avatarUrl);
      sessionStorage.setItem("justLoggedIn", "true");
      navigate("/");
      showWelcome({ avatarUrl, name: "Wayzz" });
      setTimeout(() => setWelcomeData(null), 2200);
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await api.login(credentials.email, credentials.password);
      if (!response.success || !response.data) {
        throw new Error(response.error || "Login failed");
      }

      userStore.login({
        accountId: response.data.account_id,
        accessToken: response.data.access_token,
        displayName: response.data.displayName,
        email: credentials.email,
        password: credentials.password,
        discordId: response.data.discord_id ?? null,
        discordUsername: response.data.discord_username ?? null,
      });

      // fetch discord avatar + username in parallel
      let avatarUrl: string | null = null;
      let discordUsername: string | null = response.data.discord_username ?? null;

      const [avatarRes, discordRes] = await Promise.allSettled([
        api.getAvatar(response.data.account_id),
        !discordUsername ? api.getDiscordUser(response.data.account_id) : Promise.resolve(null),
      ]);

      if (avatarRes.status === "fulfilled" && avatarRes.value?.success && avatarRes.value.data?.avatarUrl) {
        avatarUrl = avatarRes.value.data.avatarUrl;
        userStore.setAvatarUrl(avatarUrl);
      }

      // fallback: build Discord CDN url directly from discordId
      if (!avatarUrl && response.data.discord_id) {
        const idx = Number(BigInt(response.data.discord_id) >> 22n) % 6;
        avatarUrl = `https://cdn.discordapp.com/embed/avatars/${idx}.png`;
        userStore.setAvatarUrl(avatarUrl);
      }

      if (discordRes.status === "fulfilled" && discordRes.value?.success && discordRes.value.data?.discordUsername) {
        discordUsername = discordRes.value.data.discordUsername;
        userStore.setDiscordUsername(discordUsername);
      }

      const displayName = discordUsername ? `@${discordUsername}` : response.data.displayName;

      sessionStorage.setItem("justLoggedIn", "true");
      // Navigate immediately — welcome overlay shows on top
      navigate("/");
      showWelcome({ avatarUrl, name: displayName });
      setTimeout(() => setWelcomeData(null), 2200);
    } catch (error: any) {
      console.error("Login failed:", error?.message ?? error);
      showToast.error(getLoginErrorMessage(error?.message ?? error));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section
      className="relative min-h-screen w-full overflow-hidden text-white"
      style={{
        backgroundImage: image ? `url(${image})` : undefined,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundColor: "#090b12",
      }}
    >
      {/* dark gradient overlay */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/20"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.2 }}
      />

      <div className="relative flex min-h-screen items-center justify-center px-4">
        {/* Welcome overlay removed — handled globally in app.tsx */}
        <motion.div
          className="w-full max-w-sm rounded-2xl p-8"
          initial={{ opacity: 0, y: 32, scale: 0.96 }}
          animate={{ opacity: welcomeData ? 0 : 1, y: welcomeData ? -20 : 0, scale: welcomeData ? 0.95 : 1 }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: welcomeData ? 0 : 0.15 }}
          style={{
            background: "rgba(10, 12, 20, 0.35)",
            backdropFilter: "blur(24px)",
            WebkitBackdropFilter: "blur(24px)",
            border: "1px solid rgba(255,255,255,0.07)",
            boxShadow: "0 32px 80px rgba(0,0,0,0.6)",
          }}
        >
          {/* header */}
          <motion.div
            className="mb-7 text-center"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.3 }}
          >
            <img src="/icon.png" alt="AerisMP" className="h-12 w-12 rounded-xl object-cover mx-auto mb-3" />
            <h1 className="text-xl font-black text-white tracking-tight">AerisMP</h1>
            <p className="mt-1 text-xs text-white/35">Sign in to continue</p>
          </motion.div>

          <form onSubmit={handleLogin} className="space-y-3">
            {/* Email */}
            <motion.div
              className="flex items-center gap-2.5 rounded-lg px-3.5 py-2.5 transition-all"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.35, delay: 0.4 }}
              style={{ background: "rgba(0,0,0,0.15)", border: "1px solid rgba(255,255,255,0.12)" }}
            >
              <Mail size={15} className="shrink-0 text-white/30" />
              <input
                id="email"
                type="email"
                value={credentials.email}
                onChange={(event) => handleChange("email", event.target.value)}
                className="w-full bg-transparent text-sm text-white outline-none placeholder:text-white/25"
                placeholder="Email address"
                autoComplete="email"
              />
            </motion.div>

            {/* Password */}
            <motion.div
              className="flex items-center gap-2.5 rounded-lg px-3.5 py-2.5 transition-all"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.35, delay: 0.5 }}
              style={{ background: "rgba(0,0,0,0.15)", border: "1px solid rgba(255,255,255,0.12)" }}
            >
              <Lock size={15} className="shrink-0 text-white/30" />
              <input
                id="password"
                type="password"
                value={credentials.password}
                onChange={(event) => handleChange("password", event.target.value)}
                className="w-full bg-transparent text-sm text-white outline-none placeholder:text-white/25"
                placeholder="Password"
                autoComplete="current-password"
              />
            </motion.div>

            <motion.button
              type="submit"
              disabled={isSubmitting}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: 0.6 }}
              whileHover={{ scale: isSubmitting ? 1 : 1.02 }}
              whileTap={{ scale: isSubmitting ? 1 : 0.97 }}
              className="mt-1 w-full rounded-lg py-2.5 text-sm font-semibold transition-colors duration-200 disabled:cursor-not-allowed disabled:opacity-50 flex items-center justify-center gap-2"
              style={{
                background: "#ffffff",
                color: "#0a0c14",
                boxShadow: "0 4px 20px rgba(255,255,255,0.15)",
              }}
            >
              {isSubmitting && (
                <svg className="animate-spin w-4 h-4 flex-shrink-0" viewBox="0 0 16 16" fill="none">
                  <circle cx="8" cy="8" r="6" stroke="rgba(0,0,0,0.2)" strokeWidth="2.5" />
                  <path d="M8 2A6 6 0 0 1 14 8" stroke="#0a0c14" strokeWidth="2.5" strokeLinecap="round" />
                </svg>
              )}
              {isSubmitting ? "Signing in..." : "Sign In"}
            </motion.button>
          </form>
        </motion.div>
      </div>
    </section>
  );
}
