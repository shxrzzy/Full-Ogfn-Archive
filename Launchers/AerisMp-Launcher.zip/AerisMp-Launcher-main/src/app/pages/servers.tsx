"use client";

import { useEffect, useMemo, useState } from "react";
import { useTheme } from "../../hooks/useTheme";
import { api } from "../../lib/api";
import { Server as ServerIcon, Users, Activity, Globe, Play, Lock, RefreshCw } from "lucide-react";

interface ServerStatus {
  id: string;
  name: string;
  status: "joinable" | "in_game" | "restarting" | "offline";
  region: string;
  gameMode: string;
  currentPlayers: number;
  maxPlayers: number;
}

const STATUS_METADATA = {
  joinable: {
    label: "Online & Joinable",
    className: "text-emerald-400 bg-emerald-400/10 border-emerald-400/20",
  },
  in_game: {
    label: "In Game",
    className: "text-blue-400 bg-blue-400/10 border-blue-400/20",
  },
  restarting: {
    label: "Restarting",
    className: "text-amber-400 bg-amber-400/10 border-amber-400/20",
  },
  offline: {
    label: "Offline",
    className: "text-zinc-400 bg-zinc-400/10 border-zinc-400/20",
  },
};

export function Servers() {
  const colors = useTheme();
  const [servers, setServers] = useState<ServerStatus[]>([]);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState(false);

  const refreshServerList = async () => {
    setLoading(true);
    const response = await api.getLauncherServers();

    if (response.success && response.data?.servers) {
      setServers(response.data.servers);
      setFetchError(false);
    } else {
      setFetchError(true);
    }

    setLoading(false);
  };

  useEffect(() => {
    refreshServerList();
    const interval = window.setInterval(refreshServerList, 15000);
    return () => window.clearInterval(interval);
  }, []);

  const serverStatusClass = useMemo(
    () => (status: ServerStatus["status"]) => STATUS_METADATA[status].className,
    [],
  );

  const serverStatusLabel = useMemo(
    () => (status: ServerStatus["status"]) => STATUS_METADATA[status].label,
    [],
  );

  return (
    <div className="w-full h-full p-8 overflow-y-auto">
      <div className="flex items-center justify-between mb-8 max-w-6xl mx-auto py-4">
        <div>
          <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
            <ServerIcon className="w-8 h-8 text-blue-500" />
            Active Servers
          </h1>
          <p className="text-zinc-400 text-lg">Browse and join community servers</p>
        </div>
        <button
          onClick={refreshServerList}
          disabled={loading}
          className={`px-5 py-2.5 rounded-xl flex items-center gap-2 transition-all font-medium border
            ${loading ? "opacity-50 cursor-not-allowed" : "hover:scale-105"} 
            ${colors.current.button.hover} ${colors.current.border} text-white`}
        >
          <RefreshCw className={`w-5 h-5 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      <div className={`max-w-6xl mx-auto border ${colors.current.border} ${colors.current.background.secondary} rounded-2xl overflow-hidden shadow-2xl`}>
        {loading && servers.length === 0 ? (
          <div className="p-16 flex flex-col items-center justify-center text-zinc-400">
            <RefreshCw className="w-10 h-10 animate-spin mb-4 text-blue-500" />
            <p className="text-xl font-medium">Scanning for servers...</p>
          </div>
        ) : fetchError ? (
          <div className="p-16 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mb-6 border border-red-500/20">
              <Activity className="w-10 h-10 text-red-500" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Servers Offline</h3>
            <p className="text-zinc-400 max-w-md">Imperial servers are currently unavailable. Please try again in a few minutes.</p>
          </div>
        ) : servers.length === 0 ? (
          <div className="p-16 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 bg-zinc-800/50 rounded-full flex items-center justify-center mb-6">
              <ServerIcon className="w-10 h-10 text-zinc-500" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">No servers online</h3>
            <p className="text-zinc-400 max-w-md">There are currently no active servers to display. Please check back later</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
            {servers.map((server) => (
              <div
                key={server.id}
                className={`relative group p-6 rounded-xl border transition-all duration-300 transform hover:-translate-y-1 hover:shadow-xl
                  ${colors.current.background.primary} ${colors.current.border} hover:border-blue-500/50`}
              >
                <div className="absolute top-0 right-0 p-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold border flex items-center gap-1.5 ${serverStatusClass(server.status)}`}>
                    <Activity className="w-3.5 h-3.5" />
                    {serverStatusLabel(server.status)}
                  </span>
                </div>

                <div className="mt-2 mb-6">
                  <h3 className="text-xl font-bold text-white mb-1 truncate pr-24" title={server.name}>
                    {server.name}
                  </h3>
                  <div className="flex items-center gap-2 text-sm text-zinc-400">
                    <Globe className="w-4 h-4" />
                    <span className="font-medium">{server.region}</span>
                  </div>
                </div>

                <div className="bg-black/20 rounded-lg p-4 mb-6 border border-white/5 space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-zinc-400 flex items-center gap-2">
                      <Play className="w-4 h-4" /> Mode
                    </span>
                    <span className="text-white font-medium">{server.gameMode}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-zinc-400 flex items-center gap-2">
                      <Users className="w-4 h-4" /> Players
                    </span>
                    <span className="text-white font-medium">
                      {server.currentPlayers} <span className="text-zinc-500">/</span> {server.maxPlayers}
                    </span>
                  </div>

                  { }
                  <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden mt-2">
                    <div
                      className={`h-full rounded-full ${server.currentPlayers >= server.maxPlayers ? 'bg-red-500' : 'bg-blue-500'}`}
                      style={{ width: `${Math.min(100, Math.max(0, (server.currentPlayers / server.maxPlayers) * 100))}%` }}
                    />
                  </div>
                </div>

                <button
                  disabled={server.status !== "joinable"}
                  className={`w-full py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition-all
                    ${server.status === "joinable"
                      ? "bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-500/20"
                      : "bg-zinc-800 text-zinc-500 cursor-not-allowed border border-white/5"}`}
                >
                  {server.status === "joinable" ? (
                    <>
                      <Play className="w-5 h-5 fill-current" />
                      Join Server
                    </>
                  ) : (
                    <>
                      <Lock className="w-5 h-5" />
                      {server.status === "in_game" ? "Match in Progress" : "Currently Unavailable"}
                    </>
                  )}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
