"use client";

import { useState } from "react";
import { User, Palette, Sliders, LogOut, Eye, EyeOff, Shield, Copy, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useTheme } from "../../hooks/useTheme";
import { useConfigStore } from "../../stores/settings";
import { useUserStore } from "../../stores/user";
import { AppearanceTab } from "../components/settings/AppearanceTab";
import { ToggleOption } from "../components/settings/ToggleOption";
import { GENERAL_CONFIG } from "../../util/general";
import { RESET_ON_RELEASE_DLL, DISABLE_PRE_EDITS_DLL } from "../../util/dlls";

type TabId = "profile" | "appearance" | "gameplay";

const NAV: Array<{ id: TabId; label: string; icon: typeof User }> = [
  { id: "profile",    label: "Profile",    icon: User    },
  { id: "appearance", label: "Appearance", icon: Palette },
  { id: "gameplay",   label: "Gameplay",   icon: Sliders },
];

function CopyField({ label, value }: { label: string; value: string | null | undefined }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    if (!value) return;
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <div className="flex items-center justify-between py-3 px-4 rounded-xl bg-white/[0.03] border border-white/[0.06]">
      <div className="min-w-0 flex-1">
        <p className="text-[10px] uppercase tracking-widest text-white/30 font-semibold mb-0.5">{label}</p>
        <p className="text-sm text-white font-mono truncate">{value ?? "—"}</p>
      </div>
      {value && (
        <button onClick={copy} className="ml-3 flex-shrink-0 p-1.5 rounded-lg text-white/20 hover:text-white hover:bg-white/10 transition-all">
          {copied ? <Check size={13} className="text-green-400" /> : <Copy size={13} />}
        </button>
      )}
    </div>
  );
}

export function Settings() {
  const colors = useTheme();
  const config = useConfigStore();
  const user = useUserStore();
  const [tab, setTab] = useState<TabId>("profile");
  const [logoutModal, setLogoutModal] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const supportsReset = Boolean(RESET_ON_RELEASE_DLL);
  const supportsDisablePreEdits = Boolean(DISABLE_PRE_EDITS_DLL);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.25 }}
      className="h-full w-full flex flex-col overflow-hidden"
      style={{ background: `linear-gradient(135deg, ${colors.current.gradient.from} 0%, ${colors.current.gradient.to} 100%)` }}
    >
      {/* Top header — tabs only */}
      <div className="flex-shrink-0 flex flex-col items-center pt-5 pb-3 px-6 gap-4 border-b border-white/5">
        <div
          className="flex items-center gap-1 p-1 rounded-xl"
          style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.07)" }}
        >
          {NAV.map(({ id, label, icon: Icon }) => {
            const active = tab === id;
            return (
              <button
                key={id}
                onClick={() => setTab(id)}
                className={`relative flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  active ? "text-white" : "text-white/40 hover:text-white/70"
                }`}
              >
                {active && (
                  <motion.div
                    layoutId="tab-pill"
                    className="absolute inset-0 rounded-lg"
                    style={{ background: "rgba(255,255,255,0.1)" }}
                    transition={{ type: "spring", bounce: 0.2, duration: 0.35 }}
                  />
                )}
                <Icon size={14} className="relative z-10" />
                <span className="relative z-10">{label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-xl mx-auto px-6 py-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={tab}
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -16 }}
              transition={{ duration: 0.18 }}
            >

              {/* ── Profile tab ── */}
              {tab === "profile" && (
                <div className="flex flex-col gap-5">
                  {/* Hero card */}
                  <div className="relative rounded-2xl overflow-hidden border border-white/[0.07]">
                    <div
                      className="h-20 w-full"
                      style={{ background: `linear-gradient(135deg, ${colors.current.gradient.from}, ${colors.current.gradient.to})` }}
                    />
                    <div className="px-6 pb-5">
                      <div className="flex items-end justify-between -mt-6 mb-4">
                        <div className="w-14 h-14 rounded-2xl overflow-hidden ring-2 ring-white/10 bg-zinc-900 flex-shrink-0">
                          {user.avatarUrl ? (
                            <img src={user.avatarUrl} alt="avatar" className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full bg-[#5865F2] flex items-center justify-center">
                              <svg viewBox="0 0 127.14 96.36" fill="white" className="w-7 h-5">
                                <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/>
                              </svg>
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => setLogoutModal(true)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-all text-xs font-medium"
                          style={{ border: "1px solid rgba(239,68,68,0.15)" }}
                        >
                          <LogOut size={12} />
                          Sign out
                        </button>
                      </div>
                      <h2 className="text-xl font-black text-white leading-tight">
                        {user.discordUsername ? `@${user.discordUsername}` : user.displayName ?? "Guest"}
                      </h2>
                      <p className="text-white/30 text-xs mt-0.5">{user.email ?? "No email set"}</p>
                    </div>
                  </div>

                  {/* Account details */}
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Shield size={13} className="text-white/30" />
                      <p className="text-xs uppercase tracking-widest text-white/30 font-semibold">Account Details</p>
                    </div>
                    <div className="flex flex-col gap-2">
                      <CopyField label="Username" value={user.displayName} />
                      <CopyField label="Email" value={user.email} />
                      <CopyField label="Account ID" value={user.accountId} />
                      <CopyField label="Discord ID" value={user.discordId} />
                      <div className="flex items-center justify-between py-3 px-4 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                        <div className="min-w-0 flex-1">
                          <p className="text-[10px] uppercase tracking-widest text-white/30 font-semibold mb-0.5">Password</p>
                          <p className="text-sm text-white font-mono">
                            {showPassword ? (user.password ?? "—") : (user.password ? "••••••••••" : "—")}
                          </p>
                        </div>
                        <button
                          onClick={() => setShowPassword(!showPassword)}
                          className="ml-3 flex-shrink-0 p-1.5 rounded-lg text-white/20 hover:text-white hover:bg-white/10 transition-all"
                        >
                          {showPassword ? <EyeOff size={13} /> : <Eye size={13} />}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ── Appearance tab ── */}
              {tab === "appearance" && (
                <div className="flex flex-col gap-4">
                  <div>
                    <h2 className="text-2xl font-black text-white">Appearance</h2>
                    <p className="text-white/40 text-sm mt-1">Themes and display preferences</p>
                  </div>
                  <div
                    className="rounded-2xl p-5"
                    style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}
                  >
                    <AppearanceTab />
                  </div>
                </div>
              )}

              {/* ── Gameplay tab ── */}
              {tab === "gameplay" && (
                <div className="flex flex-col gap-4">
                  <div>
                    <h2 className="text-2xl font-black text-white">Gameplay</h2>
                    <p className="text-white/40 text-sm mt-1">In-game behaviour options</p>
                  </div>
                  <div
                    className="rounded-2xl divide-y divide-white/5 overflow-hidden"
                    style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}
                  >
                    {(supportsReset || supportsDisablePreEdits) ? (
                      <div className="p-5 flex flex-col gap-5">
                        {supportsReset && (
                          <ToggleOption
                            label="Reset on Release"
                            description="Automatically confirms reset when you release the key."
                            value={config.editAndRelease}
                            onChange={(v) => { config.setEditAndRelease(v); config.setResetOnRelease(v); }}
                          />
                        )}
                        {supportsDisablePreEdits && (
                          <ToggleOption
                            label="Disable Pre Edits"
                            description="Stops automatic pre-selected edits from triggering."
                            value={config.disablePreEdits}
                            onChange={config.setDisablePreEdits}
                          />
                        )}
                      </div>
                    ) : (
                      <div className="px-5 py-10 text-center text-white/25 text-sm">
                        No gameplay options available for this build.
                      </div>
                    )}
                  </div>
                </div>
              )}

            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Logout modal */}
      <AnimatePresence>
        {logoutModal && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          >
            <motion.div
              className="w-[360px] rounded-2xl p-7 text-center shadow-2xl"
              style={{ background: "rgba(15,15,20,0.95)", border: "1px solid rgba(255,255,255,0.08)" }}
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.92, opacity: 0 }}
              transition={{ type: "spring", bounce: 0.3, duration: 0.3 }}
            >
              {signingOut ? (
                <div className="flex flex-col items-center gap-4 py-4">
                  <div className="relative w-14 h-14">
                    <svg className="animate-spin w-full h-full" viewBox="0 0 56 56" fill="none">
                      <circle cx="28" cy="28" r="24" stroke="rgba(239,68,68,0.2)" strokeWidth="4" />
                      <path d="M28 4A24 24 0 0 1 52 28" stroke="#ef4444" strokeWidth="4" strokeLinecap="round" />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <LogOut className="w-5 h-5 text-red-400" />
                    </div>
                  </div>
                  <p className="text-white font-semibold text-base">Signing out...</p>
                </div>
              ) : (
                <>
                  <div className="w-14 h-14 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-4">
                    <LogOut className="w-6 h-6 text-red-400" />
                  </div>
                  <h3 className="text-white font-bold text-lg mb-1">Sign out?</h3>
                  <p className="text-white/40 text-sm mb-6">
                    You'll need to re-enter your credentials to access {GENERAL_CONFIG.NAME}.
                  </p>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setLogoutModal(false)}
                      className="flex-1 py-2.5 rounded-xl text-sm font-medium text-white/60 hover:text-white transition-colors"
                      style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        setSigningOut(true);
                        setTimeout(() => {
                          setLogoutModal(false);
                          setSigningOut(false);
                          user.logout();
                        }, 2000);
                      }}
                      className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white bg-red-600 hover:bg-red-500 transition-colors"
                    >
                      Sign out
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
