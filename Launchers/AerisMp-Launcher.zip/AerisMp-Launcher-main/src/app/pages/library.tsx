"use client";

import { useMemo, useState } from "react";
import { AnimatePresence } from "framer-motion";
import { Plus, Loader2 } from "lucide-react";
import { BuildGrid } from "../components/library/BuildGrid";
import EmptyState from "../components/library/EmptyState";
import { useTheme } from "../../hooks/useTheme";
import { useLibraryStore } from "../../stores/library";
import { handleAddBuild } from "../../util/build/import";
import { useAuth } from "../../hooks/useAuth";

export function Library() {
  const entries = useLibraryStore((state) => state.entries);
  const builds = useMemo(() => Array.from(entries.entries()), [entries]);

  const deleteBuild = useLibraryStore((state) => state.delete);

  const [isImporting, setIsImporting] = useState(false);
  const [options, setOptions] = useState<string | null>(null);

  const colors = useTheme();

  const user = useAuth.user();

  if (!user.isValidSession()) {
    return null;
  }

  const handleDeleteBuild = (key: string) => {
    deleteBuild(key);
  };

  const importBuild = async () => {
    setIsImporting(true);
    try {
      await handleAddBuild();
    } catch (error) {
      console.error(error);
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <div className="h-full overflow-hidden">
      <div className="h-full flex flex-col">
        <div className="flex-shrink-0 px-8 pt-6">
          <div className="flex items-end justify-between mb-5">
            <div>
              <p className="text-xs text-white/40 uppercase tracking-widest font-semibold mb-1">AerisMP</p>
              <h1 className="text-4xl font-black text-white tracking-tight">Library</h1>
              <p className="text-sm text-white/40 mt-1">Your installed builds</p>
            </div>
          </div>
        </div>

        <div className="flex-1 min-h-0 px-8 pb-8 overflow-y-auto overflow-x-hidden">
          <AnimatePresence mode="wait">
            {builds.length === 0 ? (
              <div key="empty">
                <EmptyState />
              </div>
            ) : (
              <div key="grid">
                <BuildGrid
                  builds={builds}
                  options={options}
                  setOptions={setOptions}
                  handleDeleteBuild={handleDeleteBuild}
                />
              </div>
            )}
          </AnimatePresence>
        </div>

        <div className="fixed bottom-8 right-8 flex gap-3 z-20">
          <button
            onClick={importBuild}
            disabled={isImporting}
            className={`group cursor-pointer relative p-4 ${colors.current.button.base} ${colors.current.button.hover} disabled:cursor-not-allowed text-white rounded-2xl transition-all duration-200`}
          >
            {isImporting ? (
              <Loader2 className="animate-spin" size={20} />
            ) : (
              <Plus size={20} />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
