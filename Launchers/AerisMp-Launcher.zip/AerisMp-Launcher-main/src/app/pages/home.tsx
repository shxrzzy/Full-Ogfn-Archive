"use client";

import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Folder as FolderIcon, ChevronLeft, ArrowRight } from "lucide-react";
import { useAuth } from "../../hooks/useAuth.ts";
import { useTheme } from "../../hooks/useTheme.ts";
import { useShopItems } from "../../hooks/useShopItems.ts";
import { useTrailerStore } from "../../stores/trailer.ts";
import { motion, AnimatePresence } from "framer-motion";
import { GENERAL_CONFIG } from "../../util/general.ts";
import { Library } from "./library.tsx";
import { TrailerModal } from "../components/TrailerModal";
import { SmallShop } from "../components/home/smallShop";

const HERO_DATA = [
  {
    id: 0,
    title: "Chapter 1 Season 9",
    displayTitle: "Chapter 1 Season 9",
    subtitle: "Welcome to Chapter 1 Season 9",
    description: "Futuristic cities like Neo Tilted and Mega Mall introduced a sleek, neon-lit aesthetic.",
    image: "https://s1.directupload.eu/images/260326/ok6b2l3f.png",
  },
  {
    id: 1,
    title: "Battle Pass",
    displayTitle: "Battle Pass",
    subtitle: "Chapter 1 Season 9 - Battle Pass",
    description: "Classic locations were rebuilt into futuristic versions.",
    image: "https://s1.directupload.eu/images/260326/nlwo9ykr.jpg",
  },
  {
    id: 2,
    title: "Neo",
    displayTitle: "Neo",
    subtitle: "Chapter 1 Season 9 - Neo",
    description: "The Combat Shotgun defined close-range combat with fast fire rate and range.",
    image: "https://s1.directupload.eu/images/260326/lyxlpw9s.jpg",
  }
];

export function Home() {
  const auth = useAuth.user();
  const colors = useTheme();
  const navigate = useNavigate();
  const setTrailerPlaying = useTrailerStore((s) => s.setIsPlaying);

  const [view, setView] = useState<"home" | "library">("home");
  const [activeTab, setActiveTab] = useState(0);
  const [showTrailer, setShowTrailer] = useState(false);

  useEffect(() => {
    const justLoggedIn = sessionStorage.getItem("justLoggedIn");
    if (justLoggedIn) {
      sessionStorage.removeItem("justLoggedIn");
      setShowTrailer(true);
      setTrailerPlaying(true);
    }
  }, [setTrailerPlaying]);

  useEffect(() => {
    if (view !== "home") return;
    const interval = setInterval(() => {
      setActiveTab((prev) => (prev + 1) % HERO_DATA.length);
    }, 15000);
    return () => clearInterval(interval);
  }, [view]);

  const { featured, daily, loading: shopLoading } = useShopItems();
  const shopItems = useMemo(() => (featured.length ? featured : daily), [featured, daily]);
  const [activeShopIndex, setActiveShopIndex] = useState(0);

  useEffect(() => {
    if (!shopItems.length) return;
    setActiveShopIndex(0);
    const interval = window.setInterval(() => {
      setActiveShopIndex((prev) => (prev + 1) % shopItems.length);
    }, 5000);
    return () => window.clearInterval(interval);
  }, [shopItems]);

  const activeHero = useMemo(
    () => HERO_DATA.find((hero) => hero.id === activeTab) || HERO_DATA[0],
    [activeTab],
  );

  if (!auth.isValidSession()) return null;

  return (
    <div
      className="w-full h-full overflow-hidden text-white"
      style={{
        backgroundImage: `linear-gradient(135deg, ${colors.current.gradient.from} 0%, ${colors.current.gradient.from} 30%, ${colors.current.gradient.to} 60%, ${colors.current.gradient.to} 100%)`,
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
      }}
    >
      <AnimatePresence mode="wait">
        {view === "home" ? (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="flex flex-col gap-1 px-5 pt-4 pb-4 w-full h-full overflow-y-auto"
          >
            {/* Hero banner */}
            <div className="relative w-full h-[300px] rounded-2xl overflow-hidden shadow-2xl border border-white/10 flex-shrink-0">
              <AnimatePresence mode="wait">
                <motion.img
                  key={activeHero.image}
                  initial={{ opacity: 0, scale: 1.04 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.7 }}
                  src={activeHero.image}
                  className="absolute inset-0 w-full h-full object-cover"
                  alt="Hero"
                />
              </AnimatePresence>

              <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/40 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

              <div className="relative h-full flex flex-col justify-between p-5">
                <motion.div
                  key={`content-${activeTab}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.4 }}
                  className="max-w-lg"
                >

                  <h1 className="text-3xl font-black uppercase tracking-tight leading-tight mb-2">
                    {activeHero.displayTitle}
                  </h1>

                  <p className="text-sm text-zinc-300 max-w-sm leading-5 mb-4 line-clamp-2">
                    {activeHero.description}
                  </p>

                  <div className="flex items-center gap-2">
                    <a
                      href={GENERAL_CONFIG.DISCORD_LINK}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/15 text-white px-4 py-1.5 rounded-full font-semibold transition-all text-xs no-underline"
                    >
                      <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="currentColor">
                        <path d="M20.317 4.369a19.791 19.791 0 0 0-4.885-1.515.07.07 0 0 0-.075.037 13.84 13.84 0 0 0-.605 1.256 18.756 18.756 0 0 0-5.74 0 12.23 12.23 0 0 0-.613-1.256.07.07 0 0 0-.075-.037c-1.67.275-3.31.768-4.885 1.515A.064.064 0 0 0 3 4.72C.913 9.27.362 13.675.78 18.005a.082.082 0 0 0 .031.056c2.052 1.516 4.03 2.468 5.942 3.084a.073.073 0 0 0 .08-.027c.46-.63.868-1.3 1.217-1.995a.073.073 0 0 0-.041-.1c-.652-.247-1.27-.537-1.856-.874a.073.073 0 0 1-.011-.123c.125-.097.25-.195.368-.296a.074.074 0 0 1 .076-.01c3.906 1.787 8.129 1.787 12.02 0a.073.073 0 0 1 .078.009c.12.1.246.199.372.296.044.037.062.094.043.15-.566.338-1.178.628-1.833.875a.073.073 0 0 0-.04.1 14.645 14.645 0 0 1 1.226 1.996.073.073 0 0 0 .08.028c1.913-.616 3.894-1.568 5.946-3.084a.083.083 0 0 0 .03-.056c.5-5.177-.838-9.517-2.864-13.286a.061.061 0 0 0-.053-.035zm-11.84 9.19c-1.183 0-2.153-1.085-2.153-2.42 0-1.335.955-2.42 2.153-2.42 1.21 0 2.18 1.1 2.153 2.42 0 1.335-.955 2.42-2.153 2.42zm7.676 0c-1.183 0-2.153-1.085-2.153-2.42 0-1.335.955-2.42 2.153-2.42 1.21 0 2.18 1.1 2.153 2.42 0 1.335-.943 2.42-2.153 2.42z"/>
                      </svg>
                      Discord
                    </a>
                    <button
                      onClick={() => navigate("/library")}
                      className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/15 text-white px-4 py-1.5 rounded-full font-semibold transition-all text-xs"
                    >
                      <FolderIcon size={13} /> Library
                    </button>
                  </div>
                </motion.div>

                {/* Dot indicators */}
                <div className="flex items-center gap-1.5">
                  {HERO_DATA.map((hero) => (
                    <button
                      key={hero.id}
                      onClick={() => setActiveTab(hero.id)}
                      className={`h-1.5 rounded-full transition-all duration-300 ${activeTab === hero.id ? 'w-8 bg-white' : 'w-3 bg-white/30 hover:bg-white/60'}`}
                      aria-label={`Show hero ${hero.title}`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Dual shop cards */}
            <div className="w-full flex items-stretch rounded-2xl overflow-hidden border border-white/10 flex-shrink-0">
              <div className="flex-1 min-w-0">
                <SmallShop items={featured} loading={shopLoading} label="Featured" />
              </div>
              {/* Divider */}
              <div className="flex-shrink-0 w-px relative">
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/50 to-transparent" />
              </div>
              <div className="flex-1 min-w-0">
                <SmallShop items={daily} loading={shopLoading} label="Daily" />
              </div>
            </div>



          </motion.div>
        ) : (
          <motion.div
            key="library"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ duration: 0.2 }}
            className="w-full h-full relative flex flex-col"
          >
            <div className="px-8 pt-6 flex-shrink-0">
              <button
                onClick={() => setView("home")}
                className="flex items-center gap-2 text-zinc-500 hover:text-white transition-colors cursor-pointer group"
              >
                <ChevronLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
                <span className="text-[10px] uppercase font-bold tracking-widest">Back to Overview</span>
              </button>
            </div>
            <div className="flex-1 overflow-hidden">
              <Library />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <TrailerModal
        isOpen={showTrailer}
        onClose={() => {
          setShowTrailer(false);
          setTrailerPlaying(false);
        }}
        videoUrl="/trailer.mp4"
      />
    </div>
  );
}
