import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useLeaderboardStore } from "../../stores/leaderboard";
import { useTheme } from "../../hooks/useTheme";
import { useUserStore } from "../../stores/user";
import { motion, AnimatePresence } from "framer-motion";
import { Trophy, ChevronUp } from "lucide-react";

const RANK_COLORS = [
  "from-yellow-400 to-amber-500",
  "from-slate-300 to-slate-400",
  "from-amber-600 to-amber-700",
];
const RANK_GLOW = [
  "shadow-yellow-500/40",
  "shadow-slate-400/30",
  "shadow-amber-600/30",
];
const RANK_BADGE = ["🥇", "🥈", "🥉"];

function Podium({ entries }: { entries: { displayName: string; account: string; value: number }[] }) {
  const top3 = entries.slice(0, 3);
  const order = [top3[1], top3[0], top3[2]].filter(Boolean);
  const orderRank = [1, 0, 2];
  const heights = ["h-20", "h-28", "h-16"];

  return (
    <div className="flex items-end justify-center gap-3 mb-6 px-4">
      {order.map((entry, i) => {
        const rank = orderRank[i];
        return (
          <motion.div
            key={entry.account}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1, duration: 0.4 }}
            className="flex flex-col items-center gap-1 flex-1 max-w-[120px]"
          >
            <span className="text-2xl">{RANK_BADGE[rank]}</span>
            <span className="text-xs font-bold text-white/80 truncate max-w-full text-center px-1">
              {entry.displayName}
            </span>
            <span className="text-sm font-black text-white">{entry.value.toLocaleString()} pts</span>
            <div className={`w-full ${heights[i]} rounded-t-xl bg-gradient-to-b ${RANK_COLORS[rank]} shadow-lg ${RANK_GLOW[rank]} flex items-start justify-center pt-2`}>
              <span className="text-white font-black text-lg">#{rank + 1}</span>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}

export function Leaderboard() {
  const { entries, loading, fetchLeaderboard } = useLeaderboardStore();
  const colors = useTheme();
  const userAccountId = useUserStore.getState().accountId;
  const listRef = useRef<HTMLDivElement>(null);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    fetchLeaderboard();
  }, [fetchLeaderboard]);

  const userIndex = useMemo(
    () => entries.findIndex((e) => e.account === userAccountId),
    [entries, userAccountId],
  );
  const userEntry = userIndex !== -1 ? entries[userIndex] : null;

  const scrollToUser = useCallback(() => {
    if (userIndex === -1 || !listRef.current) return;
    const el = listRef.current.querySelector(`[data-index='${userIndex}']`) as HTMLElement | null;
    el?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [userIndex]);

  return (
    <div
      className="w-full h-full flex flex-col overflow-hidden text-white"
      style={{
        backgroundImage: `linear-gradient(135deg, ${colors.current.gradient.from} 0%, ${colors.current.gradient.to} 100%)`,
      }}
    >
      {/* Header */}
      <div className="px-6 pt-5 pb-4 flex-shrink-0">
        <div className="flex items-center gap-3 mb-1">
          <h1 className="text-2xl font-black tracking-tight">Arena Leaderboard</h1>
        </div>
        <p className="text-white/50 text-sm">Top players ranked by hype points</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden relative px-6 pb-4 flex flex-col">
        {loading ? (
          <div className="flex flex-col gap-2">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-12 rounded-xl bg-white/5 animate-pulse" />
            ))}
          </div>
        ) : entries.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-white/40 gap-2">
            <Trophy size={32} />
            <span className="text-sm">No data available</span>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            <motion.div
              key="arena"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className="flex flex-col flex-1 overflow-hidden"
            >
              {entries.length >= 3 && <Podium entries={entries} />}


              <div
                ref={listRef}
                className="flex-1 overflow-y-auto flex flex-col gap-1 pr-1"
                onScroll={(e) => setShowScrollTop(e.currentTarget.scrollTop > 200)}
                style={{ scrollbarWidth: "thin", scrollbarColor: "rgba(255,255,255,0.1) transparent" }}
              >
                {entries.map((entry, index) => {
                  const isMe = entry.account === userAccountId;
                  const isTop3 = index < 3;
                  return (
                    <motion.div
                      key={entry.account}
                      data-index={index}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: Math.min(index * 0.02, 0.3) }}
                      className={`flex items-center justify-between px-4 py-2.5 rounded-xl transition-all duration-150 border ${
                        isMe
                          ? "bg-yellow-500/15 border-yellow-400/40 ring-1 ring-yellow-400/20"
                          : isTop3
                          ? "bg-white/8 border-white/10"
                          : "bg-white/5 hover:bg-white/8 border-transparent"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-7 text-center text-sm font-black ${
                          index === 0 ? "text-yellow-400" :
                          index === 1 ? "text-slate-300" :
                          index === 2 ? "text-amber-600" :
                          "text-white/40"
                        }`}>
                          {isTop3 ? RANK_BADGE[index] : `#${index + 1}`}
                        </span>
                        <span className={`font-semibold text-sm ${isMe ? "text-yellow-300" : "text-white"}`}>
                          {entry.displayName}
                          {isMe && <span className="ml-2 text-[10px] font-bold text-yellow-400/80 uppercase tracking-wider">You</span>}
                        </span>
                      </div>
                      <span className={`font-black text-sm tabular-nums ${isMe ? "text-yellow-300" : "text-white/80"}`}>
                        {entry.value.toLocaleString()}
                      </span>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </AnimatePresence>
        )}

        {/* Scroll to top */}
        <AnimatePresence>
          {showScrollTop && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={() => listRef.current?.scrollTo({ top: 0, behavior: "smooth" })}
              className="absolute bottom-6 right-8 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center transition-all"
            >
              <ChevronUp size={18} />
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      {/* Your rank sticky bar */}
      {userEntry && (
        <motion.div
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.3 }}
          className="flex-shrink-0 mx-6 mb-4 px-5 py-3 rounded-2xl bg-yellow-500/10 border border-yellow-400/30 flex items-center justify-between cursor-pointer hover:bg-yellow-500/15 transition-all"
          onClick={scrollToUser}
        >
          <div className="flex items-center gap-3">
            <Trophy size={16} className="text-yellow-400" />
            <span className="text-sm font-bold text-yellow-300">Your Rank</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-white/60 font-semibold">{userEntry.value.toLocaleString()} hype</span>
            <span className="text-lg font-black text-yellow-400">#{userIndex + 1}</span>
          </div>
        </motion.div>
      )}
    </div>
  );
}
