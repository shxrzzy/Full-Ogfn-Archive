"use client";

import { useEffect, useRef, useState } from "react";
import { listen } from "@tauri-apps/api/event";
import { motion, AnimatePresence } from "framer-motion";
import { X, CheckCircle2, Download, PackageOpen, Terminal } from "lucide-react";
import { useDownloadStore } from "../../stores/download";
import { useNavigate } from "react-router-dom";

interface LogEntry {
  id: string;
  message: string;
  timestamp: string;
  type: "info" | "success" | "process";
}

export function Downloading() {
  const [downloadedGB, setDownloadedGB] = useState(0);
  const [totalGB, setTotalGB] = useState<string | undefined>(undefined);
  const [progress, setProgress] = useState(0);
  const [currentFile, setCurrentFile] = useState("");
  const [phase, setPhase] = useState<"downloading" | "extracting" | "finished">("downloading");
  const [logs, setLogs] = useState<LogEntry[]>([]);

  const [extractProgress, setExtractProgress] = useState({ current: 0, total: 0 });

  const { cancelDownload } = useDownloadStore();
  const hasStartedDownload = useDownloadStore((store) => store.hasStartedDownload);
  const isDownloading = useDownloadStore((store) => store.isDownloading);
  const nav = useNavigate();
  const lastFileRef = useRef("");

  const addLog = (message: string, type: LogEntry["type"] = "info") => {
    const newLog = {
      id: Math.random().toString(36).substr(2, 9),
      message,
      type,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };
    setLogs(prev => [newLog, ...prev].slice(0, 50));
  };

  useEffect(() => {
    let progressUnlisten: any = null;
    let extractUnlisten: any = null;
    let finishUnlisten: any = null;

    const setup = async () => {
      addLog("Listening for download events...", "info");

      progressUnlisten = await listen("download-progress", (event: any) => {
        const { downloadedGB, progress, currentFile, totalBytes } = event.payload;
        console.log("Progress event received:", { downloadedGB, progress });
        if (phase !== "downloading") setPhase("downloading");

        setDownloadedGB(downloadedGB);
        setProgress(progress);

        if (currentFile && currentFile !== lastFileRef.current) {
          addLog(`Downloading: ${currentFile}`, "info");
          lastFileRef.current = currentFile;
        }

        setCurrentFile(currentFile || "");
        setTotalGB((totalBytes / 1024 ** 3).toFixed(2));
      });

      extractUnlisten = await listen("extract-progress", (event: any) => {
        const { currentFile, index, total } = event.payload;
        setPhase("extracting");
        setCurrentFile(currentFile);
        setExtractProgress({ current: index, total });
        addLog(`Extracting (${index}/${total}): ${currentFile}`, "process");
      });

      finishUnlisten = await listen("download-finished", () => {
        setProgress(100);
        setPhase("finished");
        setCurrentFile("All processes completed.");
        addLog("Installation finished successfully!", "success");
      });
    };

    setup();

    return () => {
      if (typeof progressUnlisten === "function") progressUnlisten();
      if (typeof extractUnlisten === "function") extractUnlisten();
      if (typeof finishUnlisten === "function") finishUnlisten();
    };
  }, [nav, phase]);

  const getPhaseInfo = () => {
    switch (phase) {
      case "downloading": return { text: "Downloading Assets", icon: <Download className="text-blue-400" size={24} /> };
      case "extracting": return { text: "Extracting Files", icon: <PackageOpen className="text-yellow-400" size={24} /> };
      case "finished": return { text: "Installation Complete", icon: <CheckCircle2 className="text-green-400" size={24} /> };
    }
  };

  const phaseInfo = getPhaseInfo();

  if (!isDownloading && !hasStartedDownload) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="min-h-screen px-8 py-12 text-white flex flex-col items-center justify-center"
      >
        <div className="w-full max-w-md text-center">
          <h2 className="text-2xl font-bold mb-4">Download Details</h2>
          <p className="text-zinc-300 text-lg mb-8">sorry you didnt started a download</p>
          <button
            onClick={() => nav("/download")}
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-600/20 transition-all font-bold"
          >
            Go Back to Download
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen px-8 py-12 text-white flex flex-col items-center"
    >
      { }
      <div className="w-full max-w-6xl rounded-2xl border border-white/10 bg-black/40 backdrop-blur-xl shadow-2xl overflow-hidden">

        { }
        <div className="px-8 py-6 border-b border-white/10 flex items-center justify-between bg-white/[0.03]">
          <div className="flex items-center gap-5">
            <div className="p-3 bg-white/5 rounded-xl border border-white/10">
              {phaseInfo.icon}
            </div>
            <div>
              <h2 className="text-3xl font-bold tracking-tight">{phaseInfo.text}</h2>
              <p className="text-white/50 font-mono text-sm mt-1">{currentFile || "Initializing..."}</p>
            </div>
          </div>

          <div className="flex gap-3">
            {phase !== "finished" ? (
              <button
                onClick={() => { cancelDownload(); nav("/download"); }}
                className="px-6 py-2.5 rounded-xl bg-red-500/10 hover:bg-red-500 border border-red-500/20 transition-all flex items-center gap-2 text-sm font-bold"
              >
                <X size={18} /> Cancel Process
              </button>
            ) : (
              <button
                onClick={() => nav("/download")}
                className="px-8 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-600/20 transition-all font-bold"
              >
                Finish & Go Back
              </button>
            )}
          </div>
        </div>

        <div className="p-8 grid grid-cols-1 lg:grid-cols-3 gap-8">

          { }
          <div className="lg:col-span-2 space-y-8">
            <div>
              <div className="flex justify-between items-end mb-4">
                <span className="text-sm font-bold uppercase tracking-widest text-white/30">Main Progress</span>
                <span className="text-4xl font-black text-blue-400">
                  {phase === "downloading" ? `${Math.floor(progress)}%` : phase === "extracting" ? "Extracting" : "100%"}
                </span>
              </div>

              <div className="h-6 w-full bg-white/5 rounded-full border border-white/10 p-1">
                <motion.div
                  className={`h-full rounded-full ${phase === "finished" ? "bg-green-500" : "bg-gradient-to-r from-blue-600 to-blue-400"}`}
                  animate={{ width: phase === "downloading" ? `${progress}%` : phase === "extracting" ? `${(extractProgress.current / extractProgress.total) * 100}%` : "100%" }}
                />
              </div>

              {phase === "downloading" && totalGB && (
                <div className="mt-4 flex gap-4">
                  <div className="bg-white/5 border border-white/10 rounded-lg px-4 py-2">
                    <span className="text-[10px] uppercase text-white/40 block">Downloaded</span>
                    <span className="text-lg font-mono">{downloadedGB.toFixed(2)} <span className="text-sm opacity-50">GB</span></span>
                  </div>
                  <div className="bg-white/5 border border-white/10 rounded-lg px-4 py-2">
                    <span className="text-[10px] uppercase text-white/40 block">Total Size</span>
                    <span className="text-lg font-mono">{totalGB} <span className="text-sm opacity-50">GB</span></span>
                  </div>
                </div>
              )}
            </div>
          </div>

          { }
          <div className="bg-black/40 rounded-xl border border-white/10 flex flex-col h-[250px]">
            <div className="px-4 py-3 border-b border-white/10 flex items-center gap-2 bg-white/5">
              <Terminal size={14} className="text-blue-400" />
              <span className="text-xs font-bold uppercase tracking-tighter opacity-60">Process Log</span>
            </div>
            <div className="p-4 overflow-y-auto font-mono text-[11px] space-y-2 flex flex-col-reverse">
              <AnimatePresence initial={false}>
                {logs.map((log) => (
                  <motion.div
                    key={log.id}
                    initial={{ opacity: 0, x: -5 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex gap-3 border-l border-white/5 pl-2"
                  >
                    <span className="text-white/20 whitespace-nowrap">{log.timestamp}</span>
                    <span className={log.type === "success" ? "text-green-400" : log.type === "process" ? "text-yellow-400" : "text-white/70"}>
                      {log.message}
                    </span>
                  </motion.div>
                ))}
              </AnimatePresence>
              {logs.length === 0 && <span className="text-white/20 italic">Waiting for activity...</span>}
            </div>
          </div>

        </div>
      </div>
    </motion.div>
  );
}