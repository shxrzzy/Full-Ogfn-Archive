"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useShopItems } from "../../hooks/useShopItems";
import { FeaturedRow } from "../components/shop/FeaturedRow";
import { DailyGrid } from "../components/shop/DailyGrid";
import { useProfileStore } from "../../stores/profile";

export function Shop() {
  const { featured, daily, loading, expiration } = useShopItems();
  const [timeLeft, setTimeLeft] = useState("∞");

  useEffect(() => {
    if (!expiration) return;

    const nextRefresh = new Date(expiration).getTime();

    const tick = () => {
      const remaining = Math.max(0, nextRefresh - Date.now());
      const totalSeconds = Math.floor(remaining / 1000);
      const days = Math.floor(totalSeconds / 86400);
      const hours = Math.floor((totalSeconds % 86400) / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;

      if (remaining <= 0) {
        setTimeLeft("00:00:00");
        return;
      }

      if (days > 0) {
        setTimeLeft(`${days}d ${hours.toString().padStart(2, "0")}h`);
        return;
      }

      setTimeLeft(
        `${hours.toString().padStart(2, "0")}:${minutes
          .toString()
          .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`,
      );
    };

    tick();
    const interval = window.setInterval(tick, 1000);
    return () => window.clearInterval(interval);
  }, [expiration]);

  const currentVbucks =
    useProfileStore(
      (s) =>
        s.profiles?.common_core?.items?.["Currency:MtxPurchased"]?.quantity,
    ) ?? 0;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="bg-transparent h-5 w-5 border border-white border-t-transparent animate-spin rounded-full" />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="px-6 py-6 overflow-y-auto h-full"
    >
      {/* Header row */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="text-xs text-white/40 uppercase tracking-widest font-semibold mb-1">AerisMP</p>
          <h1 className="text-4xl font-black text-white tracking-tight">Item Shop</h1>
        </div>

        <div className={`flex items-center gap-3 px-4 py-2.5 rounded-xl border border-white/10 bg-white/5 font-semibold text-white text-sm`}>
          <div className="flex items-center gap-1.5">
            <img src="https://image.fnbr.co/price/icon_vbucks_50x.png" className="w-4 h-4" draggable={false} />
            <span>{currentVbucks.toLocaleString()}</span>
          </div>
          <div className="h-4 w-px bg-white/20" />
          <div className="flex items-center gap-1.5 text-white/70">
            <motion.svg width="14" height="14" viewBox="0 0 24 24" fill="none"
              animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 6, ease: "linear" }}>
              <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" />
              <path d="M12 7V12L15 14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </motion.svg>
            <span className="text-xs">{timeLeft}</span>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-8 justify-start">
        <div className="w-full text-left">
          <h2 className="text-2xl font-bold text-white mb-6">Featured Items</h2>
          <FeaturedRow items={featured} />
        </div>

        <div className="w-full text-left mt-12">
          <h2 className="text-2xl font-bold text-white mb-6">Daily Items</h2>
          <div className="flex flex-wrap gap-4 justify-start">
            <DailyGrid items={daily} />
          </div>
        </div>
      </div>
    </motion.div>
  );
}