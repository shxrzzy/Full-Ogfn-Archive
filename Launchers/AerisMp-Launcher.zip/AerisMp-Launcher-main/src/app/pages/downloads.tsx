"use client";

import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Download as DownloadIcon } from "lucide-react";
import { useState } from "react";

import { GENERAL_CONFIG } from "../../util/general";
import { useDownloadStore } from "../../stores/download";
import { getBuild } from "../../util/build";
import { open } from "@tauri-apps/plugin-dialog";
import { showToast } from "../components/toaster";
import { CustomPathModal } from "../components/download/CustomPathModal";

export function Download() {
  const navigate = useNavigate();
  const setPath = useDownloadStore((store) => store.setPath);
  const startDownload = useDownloadStore((store) => store.startDownload);

  const [showModal, setShowModal] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const versionId = GENERAL_CONFIG.CURRENT_VERSION;
  const downloadFolderName = "AerisMP 9.10";

  const handleCustomPath = async () => {
    setShowModal(false);
    setIsProcessing(true);

    const selectedPath = await open({ directory: true });
    const normalizedPath = Array.isArray(selectedPath)
      ? selectedPath[0]
      : selectedPath;

    if (!normalizedPath || typeof normalizedPath !== "string") {
      showToast.error("No folder selected. Download cancelled.");
      setIsProcessing(false);
      return;
    }

    const downloadPath = `${normalizedPath.replace(/\\$/g, "")}\\${downloadFolderName}`;
    await proceedWithDownload(downloadPath);
  };

  const handleDefaultPath = async () => {
    setShowModal(false);
    setIsProcessing(true);
    const defaultPath = `C:\\${downloadFolderName}`;
    await proceedWithDownload(defaultPath);
  };

  const proceedWithDownload = async (downloadPath: string) => {
    const selectedBuild = getBuild(versionId);
    if (!selectedBuild) {
      showToast.error("Build is not available.");
      setIsProcessing(false);
      return;
    }

    setPath(downloadPath);

    try {
      await startDownload(selectedBuild.url);
      navigate("/downloading");
    } catch (error) {
      console.error("download start error", error);
      showToast.error(
        typeof error === "string"
          ? error
          : error instanceof Error
          ? error.message
          : "Could not start the download.",
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const beginDownload = async () => {
    if (isProcessing) return;
    setShowModal(true);
  };

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className="min-h-screen px-10 py-10 text-white"
    >
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Downloads</h1>
        <p className="text-zinc-400 mt-1 font-medium text-sm">Install the build to get started playing AerisMP</p>
      </div>

      <div
        onClick={beginDownload}
        className="relative w-64 h-[340px] rounded-[20px] overflow-hidden cursor-pointer group shadow-2xl border border-white/10"
      >
        <img
          src="https://s1.directupload.eu/images/260326/ok6b2l3f.png"
          alt="Chapter 1 Season 9"
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />

        <div className="absolute inset-0 bg-black/40 transition-colors duration-300 group-hover:bg-black/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

        <div className="absolute inset-0 flex items-center justify-center">
          <DownloadIcon
            size={64}
            strokeWidth={1}
            className="text-white drop-shadow-xl opacity-80 group-hover:opacity-100 transition-all duration-300 group-hover:scale-110 group-hover:-translate-y-2"
          />
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-5 flex items-end justify-between">
          <div>
            <h3 className="text-2xl font-bold text-white drop-shadow-lg leading-none mb-1">
              {GENERAL_CONFIG.CURRENT_VERSION}
            </h3>
            <p className="text-xs text-zinc-300 font-medium drop-shadow-md">
              Chapter 1 Season 9
            </p>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigate("/downloading");
            }}
            className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/5 px-3 py-1.5 rounded-lg text-xs font-semibold text-zinc-200 hover:text-white transition-colors"
          >
            Details
          </button>
        </div>
      </div>

      <CustomPathModal
        isOpen={showModal}
        onYes={handleCustomPath}
        onNo={handleDefaultPath}
        onClose={() => setShowModal(false)}
      />
    </motion.div>
  );
}