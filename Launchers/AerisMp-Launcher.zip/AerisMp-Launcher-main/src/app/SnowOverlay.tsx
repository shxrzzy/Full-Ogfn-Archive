"use client";

import { useMemo } from 'react';
import { useConfigStore } from '../stores/settings';

export function SnowOverlay() {
    const isEnabled = useConfigStore((state) => state.christmasSnow);

    const flakes = useMemo(() => {
        return [...Array(50)].map((_, i) => ({
            id: i,
            width: Math.random() * 5 + 2,
            left: Math.random() * 100,
            duration: Math.random() * 5 + 7,
            delay: Math.random() * -10,
        }));
    }, []);

    if (!isEnabled) return null;

    return (
        <div className="fixed inset-0 pointer-events-none z-[99999] overflow-hidden w-full h-full">
            {flakes.map((flake) => (
                <div
                    key={flake.id}
                    className="absolute bg-white rounded-full opacity-70"
                    style={{
                        width: `${flake.width}px`,
                        height: `${flake.width}px`,
                        left: `${flake.left}%`,
                        top: `-20px`,
                        animation: `fall ${flake.duration}s linear infinite`,
                        animationDelay: `${flake.delay}s`,
                        filter: 'blur(1px)',
                        boxShadow: '0 0 5px white'
                    }}
                />
            ))}
            <style dangerouslySetInnerHTML={{
                __html: `
                @keyframes fall {
                    0% { transform: translateY(0) translateX(0); }
                    33% { transform: translateY(33vh) translateX(20px); }
                    66% { transform: translateY(66vh) translateX(-20px); }
                    100% { transform: translateY(110vh) translateX(0); }
                }
                `
            }} />
        </div>
    );
}