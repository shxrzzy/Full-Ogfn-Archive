import { create } from "zustand";

type TrailerState = {
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
};

export const useTrailerStore = create<TrailerState>((set) => ({
  isPlaying: false,
  setIsPlaying: (playing) => set({ isPlaying: playing }),
}));
