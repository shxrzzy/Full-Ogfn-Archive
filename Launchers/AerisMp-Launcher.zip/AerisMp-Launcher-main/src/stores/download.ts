import { create } from "zustand";
import { persist } from "zustand/middleware";
import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";

type DownloadState = {
  path: string | null;
  progress: number;
  downloadedGB: number;
  totalGB: number;
  isDownloading: boolean;
  speed: number;
  speedHistory: number[];
  cancelToken: boolean;
  hasStartedDownload: boolean;
  setPath: (path: string) => void;
  start: (totalGB: number) => void;
  updateProgress: (downloadedGB: number, speed?: number) => void;
  finish: () => void;
  reset: () => void;
  startDownload: (url: string) => Promise<void>;
  cancelDownload: () => void;
};

export const useDownloadStore = create<DownloadState>()(
  persist(
    (set, get) => ({
      path: null,
      progress: 0,
      downloadedGB: 0,
      totalGB: 0,
      isDownloading: false,
      speed: 0,
      speedHistory: [],
      cancelToken: false,
      hasStartedDownload: false,

      setPath: (path) => set({ path }),

      start: (totalGB) =>
        set({
          isDownloading: true,
          totalGB,
          downloadedGB: 0,
          progress: 0,
          speed: 0,
          speedHistory: [],
          cancelToken: false,
          hasStartedDownload: true,
        }),

      updateProgress: (downloadedGB, speed = 0) => {
        const { totalGB, speedHistory } = get();
        const progress = totalGB
          ? Math.min((downloadedGB / totalGB) * 100, 100)
          : 0;
        const newHistory = [...speedHistory.slice(-19), speed];
        set({
          downloadedGB,
          progress,
          speed,
          speedHistory: newHistory,
        });
      },

      finish: () =>
        set({
          isDownloading: false,
          progress: 100,
          speed: 0,
          speedHistory: [],
          cancelToken: false,
          hasStartedDownload: true,
        }),

      reset: () =>
        set({
          path: null,
          progress: 0,
          downloadedGB: 0,
          totalGB: 0,
          isDownloading: false,
          speed: 0,
          speedHistory: [],
          cancelToken: false,
          hasStartedDownload: false,
        }),

      cancelDownload: () => {
        set({ cancelToken: true, isDownloading: false, hasStartedDownload: false });
        invoke("cancel_download").catch(console.error);
      },

      startDownload: async (url: string) => {
        const path = get().path;
        if (!path) throw new Error("Download path is not set.");

        set({
          isDownloading: true,
          downloadedGB: 0,
          progress: 0,
          speed: 0,
          speedHistory: [],
          cancelToken: false,
          hasStartedDownload: true,
        });

        const progressUnlisten = await listen("download-progress", (event: any) => {
          if (get().cancelToken) return;
          const { downloadedGB, progress, speed } = event.payload;
          set({
            downloadedGB,
            progress,
            speed,
            speedHistory: [...get().speedHistory.slice(-19), speed],
          });
        });

        const cancelledUnlisten = await listen("download-cancelled", () => {
          set({ isDownloading: false, hasStartedDownload: false });
        });

        try {
          set({ isDownloading: true });
          await invoke("download_build", { url, folderPath: path, folder_path: path });
          if (!get().cancelToken) get().finish();
        } catch (e) {
          console.error(e);
          if (!get().cancelToken) set({ isDownloading: false });
          throw e;
        } finally {
          progressUnlisten();
          cancelledUnlisten();
        }
      },
    }),
    {
      name: "storage:download",
      version: 1,
      migrate: (persistedState: any) => {
        if (!persistedState) return persistedState;

        return {
          ...persistedState,
          isDownloading: false,
          progress: 0,
          downloadedGB: 0,
          speed: 0,
          speedHistory: [],
          cancelToken: false,
          hasStartedDownload: false,
        };
      },
      partialize: (state) => ({
        path: state.path,
        totalGB: state.totalGB,
      }),
    },
  ),
);
