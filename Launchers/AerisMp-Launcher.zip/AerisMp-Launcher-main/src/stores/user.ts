import { create } from "zustand";
import { persist } from "zustand/middleware";
import { Profile } from "../vite-env";

export const useUserStore = create<Profile>()(
  persist(
    (set) => ({
      accountId: null,
      accessToken: "",
      displayName: null,
      discordUsername: null,
      email: null,
      password: null,
      discordId: null,
      avatarUrl: null,
      hydrated: false,

      setHydrated: () => set({ hydrated: true }),

      setProfile: (user) => set((state) => ({ ...state, ...user })),

      setAvatarUrl: (url: string) => set({ avatarUrl: url }),

      setDiscordUsername: (username: string) => set({ discordUsername: username }),

      clearProfile: () =>
        set({
          accountId: null,
          displayName: null,
          discordUsername: null,
          accessToken: "",
          email: null,
          password: null,
          discordId: null,
          avatarUrl: null,
        }),

      login: (user) =>
        set({
          accountId: user.accountId,
          accessToken: user.accessToken,
          displayName: user.displayName,
          discordUsername: user.discordUsername ?? null,
          email: user.email,
          password: user.password,
          discordId: user.discordId ?? null,
        }),

      logout: () =>
        set({
          accountId: null,
          displayName: null,
          discordUsername: null,
          accessToken: "",
          email: null,
          password: null,
          discordId: null,
          avatarUrl: null,
        }),
    }),
    {
      name: "storage:user",
      partialize: (state) => ({
        accountId: state.accountId,
        accessToken: state.accessToken,
        displayName: state.displayName,
        discordUsername: state.discordUsername,
        email: state.email,
        password: state.password,
        discordId: state.discordId,
        avatarUrl: state.avatarUrl,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated();
      },
    },
  ),
);
