import { create } from "zustand";
import { persist } from "zustand/middleware";
import { ConfigState } from "../vite-env";
import { invoke } from "@tauri-apps/api/core";

export const useConfigStore = create<ConfigState>()(
  persist(
    (set) => ({
      theme: "obsidian",
      editOnRelease: false,
      editAndRelease: false,
      resetOnRelease: false,
      disablePreEdits: false,
      alwaysOnTop: false,
      christmasSnow: false,
      expandedSidebar: true,
      compactMode: false,
      blurEffects: true,
      animations: true,
      showClock: false,
      glowEffects: false,

      setExpandedSidebar: (value: boolean) => set({ expandedSidebar: value }),
      setEditOnRelease: (value) => set({ editOnRelease: value }),
      setEditAndRelease: (value) => set({ editAndRelease: value }),
      setResetOnRelease: (value) => set({ resetOnRelease: value }),
      setDisablePreEdits: (value) => set({ disablePreEdits: value }),
      setChristmasSnow: (value: boolean) => set({ christmasSnow: value }),
      setCompactMode: (value: boolean) => set({ compactMode: value }),
      setBlurEffects: (value: boolean) => set({ blurEffects: value }),
      setAnimations: (value: boolean) => set({ animations: value }),
      setShowClock: (value: boolean) => set({ showClock: value }),
      setGlowEffects: (value: boolean) => set({ glowEffects: value }),

      setAlwaysOnTop: async (value) => {
        await invoke("set_always_on_top", { alwaysOnTop: value });
        set({ alwaysOnTop: value });
      },

      setTheme: (theme) => set({ theme }),
    }),
    {
      name: "settings",
    },
  ),
);