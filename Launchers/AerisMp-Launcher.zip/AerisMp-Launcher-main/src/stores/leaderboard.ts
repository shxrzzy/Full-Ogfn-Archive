import { create } from "zustand";
import { api } from "../lib/api";

export type LeaderboardEntry = {
  displayName: string;
  account: string;
  value: number;
};

type LeaderboardState = {
  entries: LeaderboardEntry[];
  loading: boolean;
  error?: string;
  fetchLeaderboard: () => Promise<void>;
};

export const useLeaderboardStore = create<LeaderboardState>((set) => ({
  entries: [],
  loading: false,

  fetchLeaderboard: async () => {
    set({ loading: true, error: undefined });

    const res = await api.getArenaLeaderboard();

    if (!res.success || !res.data) {
      set({ loading: false, error: res.error || "Failed to load leaderboard" });
      return;
    }

    set({ entries: res.data.entries, loading: false });
  },
}));
