bun tauri build
