#pragma once

#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <windows.h>
#include <thread>
#include <iostream>
#include <algorithm>
#include <numeric>
#include <map>
#include <intrin.h>
#include <sstream>
#include <array>
#include <tlhelp32.h>
#include <future>
#include <set>
#include <Psapi.h>
#include <immintrin.h>
#include <cstdint>
#include <cstddef>
#include <utility>
#include <type_traits>
#include <string>
#include <iostream>
#include <filesystem>
#include <string> 
#include <wintrust.h>
#include <softpub.h>
#include <tlhelp32.h>
#include <WinDNS.h>
#include <winsock.h>
#include <fstream>
#include <AclAPI.h>
#include <sstream>
#include <iomanip>
#include <map>
#include <array>
#include <Psapi.h>
#include "Globals.h"
#include "minhook/MinHook.h"
#pragma comment(lib, "minhook/minhook.lib")
#include "ixwebsocket/IXWebSocket.h"
#define CURL_STATICLIB
#include "curl/curl.h"
#pragma comment(lib, "libcurl.lib")
#pragma comment(lib, "Ws2_32.lib")  
#pragma comment(lib, "Crypt32.lib")

void connectWebSocket(const std::string& url, const std::string& auth);
void sendMessage(const std::string& message);

extern inline bool isOpen = false;