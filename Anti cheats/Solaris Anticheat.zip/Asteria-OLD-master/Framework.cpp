#include "Framework.h"
#include "Source/Public/HWID.h"
#include <Windows.h>

static std::unique_ptr<ix::WebSocket> webSocketPtr = nullptr;

void connectWebSocket(const std::string& url, const std::string& auth) {
    webSocketPtr = std::make_unique<ix::WebSocket>();
    
    webSocketPtr->setUrl(url);
    ix::WebSocketHttpHeaders headers;
    headers["Authorization"] = auth;
    webSocketPtr->setExtraHeaders(headers);
    
    auto onMessageCallback = [auth](const ix::WebSocketMessagePtr& msg) {
        if (msg->type == ix::WebSocketMessageType::Open) {
            std::string hwid = GenHWID();
            isOpen = true;
            webSocketPtr->send(hwid);
            webSocketPtr->send(auth); 
        }
        else if (msg->type == ix::WebSocketMessageType::Message) {
            printf("message: %s\n", msg->str.c_str());
        }
        else if (msg->type == ix::WebSocketMessageType::Error) {
            printf("e: %s\n", msg->errorInfo.reason.c_str());
    HANDLE currentProcess = GetCurrentProcess();
    TerminateProcess(currentProcess, 0);
        }
        else if (msg->type == ix::WebSocketMessageType::Close) {
            printf("conn closed. code: %d, reason: %s\n", 
                   msg->closeInfo.code, msg->closeInfo.reason.c_str());
            isOpen = false;
    HANDLE currentProcess = GetCurrentProcess();
    TerminateProcess(currentProcess, 0);
        }
    };
    
    webSocketPtr->setOnMessageCallback(onMessageCallback);
    webSocketPtr->start();
    
    while (!isOpen) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

void sendMessage(const std::string& message) {
    if (webSocketPtr && isOpen) {
        webSocketPtr->send(message);
    } else {
        printf("e: ws is not open.\n");
        if (!isOpen) {
    HANDLE currentProcess = GetCurrentProcess();
    TerminateProcess(currentProcess, 0);
        }
    }
}