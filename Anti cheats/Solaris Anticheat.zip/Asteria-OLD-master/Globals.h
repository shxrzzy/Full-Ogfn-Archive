#pragma once
#include "Libraries/skCrypter.h"

namespace Globals {
	inline auto RedirectURL = skCrypt(L"https://avalon-fortnite-api.solarisfn.org");
}