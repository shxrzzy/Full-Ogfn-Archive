/*
 * Copyright 2017 - 2020 Justas Masiulis
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define OBF_DISABLE_AVX_INTRINSICS 

#ifndef OBF_HPP
#define OBF_HPP

 //#ifndef _DEBUG
#if false
#define INLINE __forceinline
#else
#define INLINE
#endif

 /*
  * MIT License https://github.com/Android1337/crycall/blob/main/LICENSE
  *
  * Copyright (c) 2023 Android1337
  *
  * Permission is hereby granted, free of charge, to any person obtaining a copy
  * of this software and associated documentation files (the "Software"), to deal
  * in the Software without restriction, including without limitation the rights
  * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  * copies of the Software, and to permit persons to whom the Software is
  * furnished to do so, subject to the following conditions:
  *
  * The above copyright notice and this permission notice shall be included in all
  * copies or substantial portions of the Software.
  *
  * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  * SOFTWARE.
  */

#ifndef CRYCALL_HPP
#define CRYCALL_HPP
#include <memory> // std::unique_ptr
#include "cstack.h"

#ifdef _MSC_VER
#define OBF_FORCEINLINE INLINE
#else
#define OBF_FORCEINLINE __attribute__((always_inline)) inline
#endif

#ifdef _MSC_VER
#define OBF_LFORCEINLINE [[msvc::forceinline]]
#else
#define OBF_LFORCEINLINE __attribute__((always_inline)) inline
#endif


namespace vt
{
    template <typename ret_type>
    class vtCall {
    public:
        template <typename func_type>
        OBF_FORCEINLINE vtCall(func_type&& func) : storage(new vtHolder<func_type>(std::forward<func_type>(func))) {}

        OBF_FORCEINLINE ret_type operator()() const {
            return storage->invoke();
        }

    private:
        struct vtBase {
            OBF_FORCEINLINE virtual ret_type invoke() const = 0;
            OBF_FORCEINLINE virtual ~vtBase() = default;
        };

        template <typename func_type>
        struct vtHolder : vtBase {
            func_type func;

            OBF_FORCEINLINE vtHolder(func_type&& f) : func(std::forward<func_type>(f)) {
            }

            OBF_FORCEINLINE ret_type invoke() const override {
                return func();
            }
        };

        std::unique_ptr<vtBase> storage;
    };
}

//#ifdef _DEBUG
#if true
#define crycall(ret_type, func, ...) func(__VA_ARGS__)
#define crycall_virtual(ret_type, _this, idx, ...) [&]() OBF_LFORCEINLINE { \
    ret_type (*func)(__int64, ...); \
    func = decltype(func)(*(__int64*)(*(__int64*)__int64(_this) + (idx * sizeof(__int64)))); \
    return func(); \
}()
#else
#define crycall(ret_type, func, ...) [&]() OBF_LFORCEINLINE { \
    vt::vtCall<ret_type> f([&]() OBF_LFORCEINLINE { \
        SPOOF_FUNC; \
        return func(__VA_ARGS__); \
    }); \
    return f(); \
}()

#define crycall_virtual(ret_type, _this, idx, ...) [&]() OBF_LFORCEINLINE { \
    ret_type (*func)(__int64, ...); \
    func = decltype(func)(*(__int64*)(*(__int64*)__int64(_this) + (idx * sizeof(__int64)))); \
    vt::vtCall<ret_type> f([&]() OBF_LFORCEINLINE { \
        SPOOF_FUNC; \
        return func(__int64(_this), __VA_ARGS__); \
    }); \
    return f(); \
}()
#endif

#endif

#if defined(__clang__) || defined(__GNUC__)
#define OBF_LOAD_FROM_REG(x) ::obf::detail::load_from_reg(x)
#else
#define OBF_LOAD_FROM_REG(x) (x)
#endif

#define obf(str) ::obf::xor_string([]() OBF_LFORCEINLINE { return str; }, std::integral_constant<std::size_t, sizeof(str) / sizeof(*str)>{}, std::make_index_sequence<::obf::detail::_buffer_size<sizeof(str)>()>{})
#define obfn(num) ::obf::xor_num([]() OBF_LFORCEINLINE { return num; }, std::integral_constant<std::size_t, 1>{}, std::make_index_sequence<::obf::detail::_buffer_size<8>()>{})
#define obf_(str) obf(str).crypt_get()
//#ifdef _DEBUG
#if true
#define obf_str(s) (char *) s
#define obf_num(s) s
#else
#define obf_str(STR) obf(STR).crypt_get()
#define obf_num(STR) obfn(STR).crypt_get()
#endif

//#ifdef _DEBUG
#if true
#define obf_fn(f, m) f
#else
#define obf_fn(f, m) []() OBF_LFORCEINLINE { \
    HMODULE mod = nullptr; \
    if (MCache[std::string(obf_str(m))]) { \
        mod = MCache[std::string(obf_str(m))]; \
    } \
    else { \
        mod = crycall(HMODULE, LoadLibraryA, obf_str(m)); \
        MCache[std::string(obf_str(m))] = mod; \
    } \
    /*if (!mod) return decltype(&f)(nullptr);*/ \
    FARPROC func = crycall(FARPROC, GetProcAddress, mod, obf_str(#f)); \
    return decltype(&f)(func); \
}()
#endif
//#define obf_fn(f, m) f

namespace obf {

    namespace detail {

        template<std::size_t Size>
        OBF_FORCEINLINE constexpr std::size_t _buffer_size()
        {
            return ((Size / 16) + (Size % 16 != 0)) * 2;
        }

        template<std::uint32_t Seed>
        OBF_FORCEINLINE constexpr std::uint32_t key4() noexcept
        {
            std::uint32_t value = Seed;
            for (char c : __TIME__)
                value = static_cast<std::uint32_t>((value ^ c) * 16777619ull);
            return value;
        }

        OBF_FORCEINLINE constexpr unsigned long long cs(const char* input) {
            return *input ? static_cast<unsigned long long>(*input) + (33 + __COUNTER__ & 0xff) * cs(input + 1) : 5381;
        }

        template<std::size_t S>
        OBF_FORCEINLINE constexpr std::uint64_t key8()
        {
            constexpr auto first_part = key4<2166136261 + S>();
            constexpr auto second_part = key4<first_part>();
            return ((static_cast<std::uint64_t>(first_part) << 32) | second_part) ^ cs(__DATE__ __TIME__);
        }

        // loads up to 8 characters of string into uint64 and xors it with the key
        template<std::size_t N, class CharT>
        OBF_FORCEINLINE constexpr std::uint64_t
            load_xored_str8(std::uint64_t key, std::size_t idx, const CharT* str) noexcept
        {
            using cast_type = typename std::make_unsigned<CharT>::type;
            constexpr auto value_size = sizeof(CharT);
            constexpr auto idx_offset = 8 / value_size;

            std::uint64_t value = key;
            for (std::size_t i = 0; i < idx_offset && i + idx * idx_offset < N; ++i)
                value ^=
                (std::uint64_t{ static_cast<cast_type>(str[i + idx * idx_offset]) }
            << ((i % idx_offset) * 8 * value_size));

            return value;
        }

        OBF_FORCEINLINE constexpr std::uint64_t
            load_xored_long(std::uint64_t key, unsigned long long val) noexcept
        {

            std::uint64_t value = key;
            value ^= val;

            return value;
        }

        // forces compiler to use registers instead of stuffing constants in rdata
        inline OBF_FORCEINLINE std::uint64_t load_from_reg(std::uint64_t value) noexcept {
#if defined(__clang__) || defined(__GNUC__)
            asm("" : "=r"(value) : "0"(value) : );
#endif
            return value;
        }

        template<std::uint64_t V>
        struct uint64_v {
            constexpr static std::uint64_t value = V;
        };

    } // namespace detail

    template<class CharT, std::size_t Size, class Keys, class Indices>
    class xor_string;

    template<class CharT, std::size_t Size, std::uint64_t... Keys, std::size_t... Indices>
    class xor_string<CharT, Size, std::integer_sequence<std::uint64_t, Keys...>, std::index_sequence<Indices...>> {
#ifndef OBF_DISABLE_AVX_INTRINSICS
        constexpr static inline std::uint64_t alignment = ((Size > 16) ? 32 : 16);
#else
        constexpr static inline std::uint64_t alignment = 16;
#endif

        alignas(alignment) std::uint64_t _storage[sizeof...(Keys)];

    public:
        using value_type = CharT;
        using size_type = std::size_t;
        using pointer = CharT*;
        using const_pointer = const CharT*;

        template<class L>
        OBF_FORCEINLINE xor_string(L l, std::integral_constant<std::size_t, Size>, std::index_sequence<Indices...>) noexcept
            : _storage{ OBF_LOAD_FROM_REG(detail::uint64_v<detail::load_xored_str8<Size>(Keys, Indices, l())>::value)... }
        {}

        OBF_FORCEINLINE constexpr size_type size() const noexcept
        {
            return Size - 1;
        }

        OBF_FORCEINLINE virtual void crypt() noexcept
        {
#if defined(__clang__)
            alignas(alignment)
                std::uint64_t arr[]{ OBF_LOAD_FROM_REG(Keys)... };
            std::uint64_t* keys =
                (std::uint64_t*)OBF_LOAD_FROM_REG((std::uint64_t)arr);
#else
            alignas(alignment) std::uint64_t keys[]{ OBF_LOAD_FROM_REG(Keys)... };
#endif

#ifndef OBF_DISABLE_AVX_INTRINSICS
            ((Indices >= sizeof(_storage) / 32 ? static_cast<void>(0) : _mm256_store_si256(
                reinterpret_cast<__m256i*>(_storage) + Indices,
                _mm256_xor_si256(
                    _mm256_load_si256(reinterpret_cast<const __m256i*>(_storage) + Indices),
                    _mm256_load_si256(reinterpret_cast<const __m256i*>(keys) + Indices)))), ...);

            if constexpr (sizeof(_storage) % 32 != 0)
                _mm_store_si128(
                    reinterpret_cast<__m128i*>(_storage + sizeof...(Keys) - 2),
                    _mm_xor_si128(_mm_load_si128(reinterpret_cast<const __m128i*>(_storage + sizeof...(Keys) - 2)),
                        _mm_load_si128(reinterpret_cast<const __m128i*>(keys + sizeof...(Keys) - 2))));
#else
            ((Indices >= sizeof(_storage) / 16 ? static_cast<void>(0) : _mm_store_si128(
                reinterpret_cast<__m128i*>(_storage) + Indices,
                _mm_xor_si128(_mm_load_si128(reinterpret_cast<const __m128i*>(_storage) + Indices),
                    _mm_load_si128(reinterpret_cast<const __m128i*>(keys) + Indices)))), ...);
#endif
        }

        OBF_FORCEINLINE const_pointer get() const noexcept
        {
            return reinterpret_cast<const_pointer>(_storage);
        }

        OBF_FORCEINLINE pointer get() noexcept
        {
            return reinterpret_cast<pointer>(_storage);
        }

        OBF_FORCEINLINE pointer crypt_get_vt() noexcept
        {
            // crypt() function inlined by hand, because MSVC linker chokes when you have a lot of strings
            // on 32 bit builds, so don't blame me for shit code :pepekms:
#if defined(__clang__)
            alignas(alignment)
                std::uint64_t arr[]{ OBF_LOAD_FROM_REG(Keys)... };
            std::uint64_t* keys =
                (std::uint64_t*)OBF_LOAD_FROM_REG((std::uint64_t)arr);
#else
            alignas(alignment) std::uint64_t keys[]{ OBF_LOAD_FROM_REG(Keys)... };
#endif

#ifndef OBF_DISABLE_AVX_INTRINSICS
            ((Indices >= sizeof(_storage) / 32 ? static_cast<void>(0) : _mm256_store_si256(
                reinterpret_cast<__m256i*>(_storage) + Indices,
                _mm256_xor_si256(
                    _mm256_load_si256(reinterpret_cast<const __m256i*>(_storage) + Indices),
                    _mm256_load_si256(reinterpret_cast<const __m256i*>(keys) + Indices)))), ...);

            if constexpr (sizeof(_storage) % 32 != 0)
                _mm_store_si128(
                    reinterpret_cast<__m128i*>(_storage + sizeof...(Keys) - 2),
                    _mm_xor_si128(_mm_load_si128(reinterpret_cast<const __m128i*>(_storage + sizeof...(Keys) - 2)),
                        _mm_load_si128(reinterpret_cast<const __m128i*>(keys + sizeof...(Keys) - 2))));
#else
            ((Indices >= sizeof(_storage) / 16 ? static_cast<void>(0) : _mm_store_si128(
                reinterpret_cast<__m128i*>(_storage) + Indices,
                _mm_xor_si128(_mm_load_si128(reinterpret_cast<const __m128i*>(_storage) + Indices),
                    _mm_load_si128(reinterpret_cast<const __m128i*>(keys) + Indices)))), ...);
#endif
            return (pointer)(_storage);
        }

        OBF_FORCEINLINE virtual pointer crypt_get() noexcept
        {
            crycall_virtual(void, this, 0x0);
            return (pointer)(_storage);
        }
    };

    template<class L, std::size_t Size, std::size_t... Indices>
    xor_string(L l, std::integral_constant<std::size_t, Size>, std::index_sequence<Indices...>) -> xor_string<
        std::remove_const_t<std::remove_reference_t<decltype(l()[0])>>,
        Size,
        std::integer_sequence<std::uint64_t, detail::key8<Indices>()...>,
        std::index_sequence<Indices...>>;

    template<class CharT, std::size_t Size, class Keys, class Indices>
    class xor_num;

    template<class CharT, std::size_t Size, std::uint64_t... Keys, std::size_t... Indices>
    class xor_num<CharT, Size, std::integer_sequence<std::uint64_t, Keys...>, std::index_sequence<Indices...>> {
#ifndef OBF_DISABLE_AVX_INTRINSICS
        constexpr static inline std::uint64_t alignment = ((Size > 16) ? 32 : 16);
#else
        constexpr static inline std::uint64_t alignment = 16;
#endif

        alignas(alignment) std::uint64_t _storage[sizeof...(Keys)];

    public:
        using size_type = std::size_t;
        using pointer = CharT;
        using const_pointer = const CharT;

        template<class L>
        OBF_FORCEINLINE xor_num(L l, std::integral_constant<std::size_t, Size>, std::index_sequence<Indices...>) noexcept
            : _storage{ OBF_LOAD_FROM_REG(detail::uint64_v<detail::load_xored_long(Keys, l())>::value)... }
        {}

        OBF_FORCEINLINE constexpr size_type size() const noexcept
        {
            return Size - 1;
        }

        OBF_FORCEINLINE virtual void crypt() noexcept
        {
#if defined(__clang__)
            alignas(alignment)
                std::uint64_t arr[]{ OBF_LOAD_FROM_REG(Keys)... };
            std::uint64_t* keys =
                (std::uint64_t*)OBF_LOAD_FROM_REG((std::uint64_t)arr);
#else
            alignas(alignment) std::uint64_t keys[]{ OBF_LOAD_FROM_REG(Keys)... };
#endif

#ifndef OBF_DISABLE_AVX_INTRINSICS
            ((Indices >= sizeof(_storage) / 32 ? static_cast<void>(0) : _mm256_store_si256(
                reinterpret_cast<__m256i*>(_storage) + Indices,
                _mm256_xor_si256(
                    _mm256_load_si256(reinterpret_cast<const __m256i*>(_storage) + Indices),
                    _mm256_load_si256(reinterpret_cast<const __m256i*>(keys) + Indices)))), ...);

            if constexpr (sizeof(_storage) % 32 != 0)
                _mm_store_si128(
                    reinterpret_cast<__m128i*>(_storage + sizeof...(Keys) - 2),
                    _mm_xor_si128(_mm_load_si128(reinterpret_cast<const __m128i*>(_storage + sizeof...(Keys) - 2)),
                        _mm_load_si128(reinterpret_cast<const __m128i*>(keys + sizeof...(Keys) - 2))));
#else
            ((Indices >= sizeof(_storage) / 16 ? static_cast<void>(0) : _mm_store_si128(
                reinterpret_cast<__m128i*>(_storage) + Indices,
                _mm_xor_si128(_mm_load_si128(reinterpret_cast<const __m128i*>(_storage) + Indices),
                    _mm_load_si128(reinterpret_cast<const __m128i*>(keys) + Indices)))), ...);
#endif
        }

        OBF_FORCEINLINE const_pointer get() const noexcept
        {
            return reinterpret_cast<const_pointer>(_storage);
        }

        OBF_FORCEINLINE pointer get() noexcept
        {
            return reinterpret_cast<pointer>(_storage);
        }

        OBF_FORCEINLINE pointer crypt_get_vt() noexcept
        {
            // crypt() function inlined by hand, because MSVC linker chokes when you have a lot of strings
            // on 32 bit builds, so don't blame me for shit code :pepekms:
#if defined(__clang__)
            alignas(alignment)
                std::uint64_t arr[]{ OBF_LOAD_FROM_REG(Keys)... };
            std::uint64_t* keys =
                (std::uint64_t*)OBF_LOAD_FROM_REG((std::uint64_t)arr);
#else
            alignas(alignment) std::uint64_t keys[]{ OBF_LOAD_FROM_REG(Keys)... };
#endif

#ifndef OBF_DISABLE_AVX_INTRINSICS
            ((Indices >= sizeof(_storage) / 32 ? static_cast<void>(0) : _mm256_store_si256(
                reinterpret_cast<__m256i*>(_storage) + Indices,
                _mm256_xor_si256(
                    _mm256_load_si256(reinterpret_cast<const __m256i*>(_storage) + Indices),
                    _mm256_load_si256(reinterpret_cast<const __m256i*>(keys) + Indices)))), ...);

            if constexpr (sizeof(_storage) % 32 != 0)
                _mm_store_si128(
                    reinterpret_cast<__m128i*>(_storage + sizeof...(Keys) - 2),
                    _mm_xor_si128(_mm_load_si128(reinterpret_cast<const __m128i*>(_storage + sizeof...(Keys) - 2)),
                        _mm_load_si128(reinterpret_cast<const __m128i*>(keys + sizeof...(Keys) - 2))));
#else
            ((Indices >= sizeof(_storage) / 16 ? static_cast<void>(0) : _mm_store_si128(
                reinterpret_cast<__m128i*>(_storage) + Indices,
                _mm_xor_si128(_mm_load_si128(reinterpret_cast<const __m128i*>(_storage) + Indices),
                    _mm_load_si128(reinterpret_cast<const __m128i*>(keys) + Indices)))), ...);
#endif
            return (pointer)(_storage);
        }

        OBF_FORCEINLINE virtual pointer crypt_get() noexcept
        {
            crycall_virtual(void, this, 0x0);
            return (pointer)(_storage[0]);
        }
    };

    template<class L, std::size_t Size, std::size_t... Indices>
    xor_num(L l, std::integral_constant<std::size_t, Size>, std::index_sequence<Indices...>) -> xor_num<
        std::remove_const_t<std::remove_reference_t<decltype(l())>>,
        Size,
        std::integer_sequence<std::uint64_t, detail::key8<Indices>()...>,
        std::index_sequence<Indices...>>;

} // namespace obf

#endif // include guard