@echo off
set __dir=%CD%
del /f /s /q build
mkdir build
clang -Xclang -emit-pch -fpass-plugin="%__dir%\ObfuscationPlugin.dll" "%CD%\pch.cpp" -std=c++26 -I %CD% -c -o "%CD%/build/Arc.pch" -O2 -g -gcodeview -fpch-instantiate-templates -masm=intel -Wno-c++11-narrowing -ffunction-sections -fdata-sections -fexceptions -fasync-exceptions
call :treeProcess
clang -E -xc -DRC_INVOKED Arc.rc -o build\Arc.rc
llvm-rc build\Arc.rc /Fobuild\Arc.res
clang -flto -fuse-ld=lld build\*.obj build\Arc.res -o build\Arc.exe -luser32 -g -Wl,/pdb:build\Arc.pdb -Wl,/MANIFEST:EMBED -Wl,/MANIFESTINPUT:app.manifest -Wl,/opt:ref -Wl,/opt:icf -lshell32 -ladvapi32 -lgdi32 -Wl,/map -Wno-c++11-narrowing -fexceptions -fasync-exceptions
goto :eof

:treeProcess
for %%f in (*.cpp) do (
    if /I "%%f"=="Fortnite_functions.cpp" (
        clang -include-pch "%__dir%\build\Arc.pch" %CD%\%%f -std=c++26 -I %__dir% -c -o %__dir%/build/%%f.obj -g -gcodeview -O2 -fpch-instantiate-templates -masm=intel -Wno-c++11-narrowing -ffunction-sections -fdata-sections -fexceptions -fasync-exceptions
    ) else (
        clang -include-pch "%__dir%\build\Arc.pch" -fpass-plugin="%__dir%\ObfuscationPlugin.dll" %CD%\%%f -std=c++26 -I %__dir% -c -o %__dir%/build/%%f.obj -g -gcodeview -O2 -fpch-instantiate-templates -masm=intel -Wno-c++11-narrowing -ffunction-sections -fdata-sections -fexceptions -fasync-exceptions
    )
)
for /D %%d in (*) do (
    if /I NOT "%%d"=="build" (
        cd %%d
        call :treeProcess
        cd ..
    )
)
