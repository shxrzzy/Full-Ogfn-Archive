#include "pch.h"
#include "../../Headers/Shared.h"
#include "../../Headers/Encryption.h"
#include "../../../aes256.h"
using namespace ProjectArc;

#define encKey                                                                                                                                                                     \
    _ns("\x9c\xfe\xeb\x1d\x0c\x89\xc1\x99\xa3\x62\x8a\x1c\x3f\x3d\xb4\x8f\x81\x42\xd9\xcd\x27\x50\x44\x7a\x93\xc2\x04\x04\xf3\xad\x5f\x59")

__declspec(noinline) std::vector<unsigned char> Encryption::EncryptMessage(const char* str, uint8* sig)
{
    GUARD_RET({});
    // VMStart();
    fuckIda;
    /*auto ctx = EVP_CIPHER_CTX_new();

    EVP_EncryptInit(ctx, EVP_aes_256_ctr(), (uint8*) (key), (uint8*) (iv));
    int outlen;
    auto outbuf = (unsigned char*)LI_FN_CACHED(malloc)(strlen(str));
    EVP_EncryptUpdate(ctx, outbuf, &outlen, (unsigned char*)str, (int)strlen(str));
    int len2;
    EVP_EncryptFinal(ctx, outbuf + outlen, &len2);*/
    uint8 iv[16] = {};
    for (int i = 0; i < 16; i++)
        iv[i] = rand() & 0xff;

    aes256_context ctx {};
    rfc3686_blk ctr = *(rfc3686_blk*)iv;

    // auto _key = malloc(32);
    // memcpy(_key, encKey, 32);
    aes256_init(&ctx, (unsigned char*)encKey);
    aes256_setCtrBlk(&ctx, &ctr);
    auto outlen = strlen(str);
    auto outbuf = (unsigned char*)malloc(outlen);
    memcpy(outbuf, str, outlen);
    aes256_encrypt_ctr(&ctx, outbuf, outlen);

    std::vector<unsigned char> Out;
    Out.reserve(outlen + 48);
    for (int i = 0; i < outlen; i++)
    {
        Out.push_back(outbuf[i]);
    }
    for (int i = 0; i < 16; i++)
    {
        Out.push_back(iv[i]);
    }
    for (int i = 0; i < 32; i++)
    {
        Out.push_back(sig[i]);
    }
    free(outbuf);
    // free(_key);
    // VMEnd();
    return Out;
}

__declspec(noinline) const char* Encryption::DecryptMessage(std::vector<unsigned char> data)
{
    GUARD_RET("");
    // VMStart();
    fuckIda;
    /*auto ctx = EVP_CIPHER_CTX_new();

    auto sub = 32;
    EVP_DecryptInit(ctx, EVP_aes_256_ctr(), (uint8*)(key), (uint8*)(iv));
    int outlen;
    auto outbuf = (unsigned char*) new uint8[data.size() - sub + 1];
    EVP_DecryptUpdate(ctx, outbuf, &outlen, (unsigned char*)data.data(), (int)data.size() - sub);
    int len2;
    EVP_DecryptFinal(ctx, outbuf + outlen, &len2);*/

    aes256_context ctx {};
    rfc3686_blk ctr = *(rfc3686_blk*)(data.data() + data.size() - 48);

    // auto _key = malloc(32);
    // memcpy(_key, encKey, 32);
    aes256_init(&ctx, (unsigned char*)encKey);
    aes256_setCtrBlk(&ctx, &ctr);
    auto outlen = data.size() - 48;
    auto outbuf = (unsigned char*)new uint8[outlen + 1];
    memcpy(outbuf, data.data(), outlen);
    aes256_decrypt_ctr(&ctx, outbuf, outlen);

    outbuf[outlen] = 0;
    // EVP_CIPHER_CTX_free(ctx);
    // VMEnd();
    // free(_key);
    return (const char*)outbuf;
}
