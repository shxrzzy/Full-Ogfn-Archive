#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
using namespace ProjectArc::Types;
INIT_MODULE(Integrity);

void IntegrityThr(void*, uint8_t* ThrLdr)
{
    fuckIda;
    //*ThrLdr = 1;

    auto text = GetSect(__ThisBase, _(".text"));
    auto rdata = GetSect(gameBase, _(".rdata"));

    if (!text || !rdata)
        while (true)
            Sleep(1000);

    auto ThisTextBuf = (void*)(__int64(__ThisBase) + text->VirtualAddress);
    auto ThisTextSize = text->Misc.VirtualSize;
    auto RDataBuf = (void*)(__int64(gameBase) + rdata->VirtualAddress);
    auto RDataSize = rdata->Misc.VirtualSize;
    json DetectionInfo;

    DetectionInfo[_("type")] = _("detection");
    DetectionInfo[_("ban")] = true;

    auto InitialHash = crc32(ThisTextBuf, (uint32)ThisTextSize, 0);
    auto InitialRDataHash = crc32(RDataBuf, (uint32)RDataSize, 0);

    auto dosHeader = (IMAGE_DOS_HEADER*)gameBase;
    auto ntHeader = (IMAGE_NT_HEADERS*)(__int64(gameBase) + dosHeader->e_lfanew);

    while (true)
    {
        if (bResetHash)
        {
            bResetHash = false;

            InitialHash = crc32(ThisTextBuf, (uint32)ThisTextSize, 0);
        }
        else if (!bResetLock && crc32(ThisTextBuf, (uint32)ThisTextSize, 0) != InitialHash) [[unlikely]]
        {
            DetectionInfo[_("code")] = AntiCheatPatched;
            goto _end;
        }

        if (FortniteCL < 15685441 && bWipedPEHdr)
        {
            for (int i = 0; i < sizeof(IMAGE_DOS_HEADER) - 4; i += 2)
                if (*(uint16_t*)(__int64(gameBase) + i) != 0x0)
                {
                    DetectionInfo[_("code")] = PEDataModified;
                    goto _end;
                }

            if (ntHeader->Signature != 0 || ntHeader->FileHeader.Machine != 0 || ntHeader->FileHeader.TimeDateStamp != 0)
            {
                DetectionInfo[_("code")] = PEDataModified;
                goto _end;
            }
        }
        /*    if (crc32(RDataBuf, (uint32)RDataSize, 0) != InitialRDataHash) [[unlikely]]
            {
                DetectionInfo[_("code")] = RDataPatched;
                goto _end;
            }*/

        Sleep(100);
    }
_end:
    SendDetectionReport(DetectionInfo);
}

void MMIntegrityThr(void*, uint8_t* ThrLdr)
{
    fuckIda;
    //*ThrLdr = 1;
    
    json DetectionInfo;

    DetectionInfo[_("type")] = _("detection");
    DetectionInfo[_("ban")] = true;

    auto PEB = (PEB_T*)__readgsqword(0x60);
    auto PEBBase = (char**)(__int64(PEB) + 0x10);
    while (true)
    {
        if (*PEBBase != __ThisBase)
        {
            DetectionInfo[_("code")] = ManualMapReverted;
            goto _end;
        }
        else if (FortniteCL >= 4204761)
        {
            auto Entry = (LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
            auto Head = (LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;

            do
            {
                if (gameBase == Entry->DllBase)
                {
                    DetectionInfo[_("code")] = ManualMapReverted;
                    goto _end;
                }
            }
            while ((Entry = (LDR_DATA_TABLE_ENTRY_T*)Entry->InLoadOrderLinks.Flink) && Entry != Head);
        }

        Sleep(100);
    }
_end:
    SendDetectionReport(DetectionInfo); 
}

void Integrity__Init()
{
    SpawnThread(MMIntegrityThr, true, true);
}
