#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
#include "../../Headers/Encryption.h"
#include "../../../hmac_sha256.h"
ENGINE_MODULE(Travel);
using namespace ProjectArc::Bootstrapper;

bool is_number(const std::wstring& s)
{
    return !s.empty()
        && std::find_if(s.begin(), s.end(),
               [](wchar_t c)
               {
                   return !std::isdigit(c);
               })
        == s.end();
}

void (*ClientTravelOG)(AActor* PlayerController, FFrame& Stack);
void ClientTravel(AActor* PlayerController, FFrame& Stack)
{
    if (ArcToken.size() == 0)
        return ClientTravelOG(PlayerController, Stack);

    SDKFString& Options = *(SDKFString*)Stack.Locals;

    std::wstring s = Options.CStr();

    auto optStart = s.find(L'?');
    auto host = s.substr(0, optStart);
    if (host.starts_with(L'/'))
        return ClientTravelOG(PlayerController, Stack);

    int Port = 7777;
    std::wstring IP = host;
    size_t PortPos = std::wstring::npos;

    if ((PortPos = host.rfind(L':')) != std::wstring::npos)
    {
        IP = host.substr(0, PortPos);
        auto PortStr = host.substr(PortPos + 1);

        if (is_number(PortStr))
            Port = std::stoi(PortStr);
    }

    json TravelPayload;

    TravelPayload[_("type")] = _("travel");
    TravelPayload[_("ip")] = IP;
    TravelPayload[_("port")] = Port;

    Send(TravelPayload);
    s += _(L"?ArcToken=");
    s += std::wstring(ArcToken.begin(), ArcToken.end());

    Options = s.c_str();
    return ClientTravelOG(PlayerController, Stack);
}

void Travel__EngineInit()
{
    fuckIda;

    Hook(DefaultObjImpl(_("PlayerController"))->GetFunction(_("ClientTravelInternal"))->ExecFunction, ClientTravel, ClientTravelOG);
}