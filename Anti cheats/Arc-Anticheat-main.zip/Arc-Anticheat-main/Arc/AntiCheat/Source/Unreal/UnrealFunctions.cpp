#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
ENGINE_MODULE(UnrealFunctions);
using namespace ProjectArc::Bootstrapper;

void (*ProcessEventOG)(UObject* Ctx, UFunction* Func, void* Params);
void ProcessEventHook(UObject* Ctx, UFunction* Func, void* Params)
{
    fuckIda;
    auto Ret = _ReturnAddress();

    if (uint64_t(Ret) < uint64_t(gameBase) + gameText->VirtualAddress || uint64_t(Ret) >= uint64_t(gameBase) + gameText->Misc.VirtualSize) [[unlikely]]
    {
        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = ProcessEventCall;
        DetectionInfo[_("ban")] = true;
        SendDetectionReport(DetectionInfo);
        return;
    }

    auto NativeFunc = Func ? Func->ExecFunction : nullptr;
    if (NativeFunc && (uint64_t(NativeFunc) < uint64_t(gameBase) || uint64_t(NativeFunc) >= uint64_t(gameBase) + gameSize)
        && (uint64_t(NativeFunc) < uint64_t(__ThisBase) || uint64_t(NativeFunc) >= uint64_t(__ThisBase) + __ThisSize)) [[unlikely]]
    {
        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = ExecFunctionHooked;
        DetectionInfo[_("ban")] = true;
        SendDetectionReport(DetectionInfo);
        return;
    }

    return ProcessEventOG(Ctx, Func, Params);
}

void (*Actor__ProcessEventOG)(UObject* Ctx, UFunction* Func, void* Params);
void Actor__ProcessEventHook(UObject* Ctx, UFunction* Func, void* Params)
{
    fuckIda;
    auto Ret = _ReturnAddress();

    if (uint64_t(Ret) < uint64_t(gameBase) + gameText->VirtualAddress || uint64_t(Ret) >= uint64_t(gameBase) + gameText->Misc.VirtualSize) [[unlikely]]
    {
        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = ProcessEventCall;
        DetectionInfo[_("ban")] = true;
        SendDetectionReport(DetectionInfo);
        return;
    }

    return Actor__ProcessEventOG(Ctx, Func, Params);
}

void (*MNC__ProcessEventOG)(UObject* Ctx, UFunction* Func, void* Params);
void MNC__ProcessEventHook(UObject* Ctx, UFunction* Func, void* Params)
{
    fuckIda;
    auto Ret = _ReturnAddress();

    if (uint64_t(Ret) < uint64_t(gameBase) + gameText->VirtualAddress || uint64_t(Ret) >= uint64_t(gameBase) + gameText->Misc.VirtualSize) [[unlikely]]
    {
        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = ProcessEventCall;
        DetectionInfo[_("ban")] = true;
        SendDetectionReport(DetectionInfo);
        return;
    }

    return MNC__ProcessEventOG(Ctx, Func, Params);
}

void UObject::ProcessEvent(UFunction* Func, void* Params) const
{
    return ProcessEventOG((UObject*)this, Func, Params);
}

void* ObjPE = nullptr;
void* ActorPE = nullptr;
void* MncPE = nullptr;
void CheckForPEHooks(void*, uint8_t* ThrLdr)
{
    fuckIda;
    //*ThrLdr = 1;

    json DetectionInfo;

    DetectionInfo[_("type")] = _("detection");
    DetectionInfo[_("ban")] = true;

    auto ObjPE__Bytes = *(uint64_t*)ObjPE;
    auto ActorPE__Bytes = *(uint64_t*)ActorPE;
    auto MncPE__Bytes = *(uint64_t*)MncPE;
    while (true)
    {
        if (ObjPE && *(uint64_t*)ObjPE != ObjPE__Bytes) [[unlikely]]
        {
            DetectionInfo[_("code")] = EngineRenderHooked;
            goto _end;
        }
        else if (ActorPE && * (uint64_t*)ActorPE != ActorPE__Bytes) [[unlikely]]
        {
            DetectionInfo[_("code")] = EngineRenderHooked;
            goto _end;
        }
        else if (MncPE && * (uint64_t*)MncPE != MncPE__Bytes) [[unlikely]]
        {
            DetectionInfo[_("code")] = EngineRenderHooked;
            goto _end;
        }

        Sleep(100);
    }
_end:
    SendDetectionReport(DetectionInfo);
}

void UnrealFunctions__EngineInit()
{
    fuckIda;

    if (Offsets::ProcessEventVft && VersionInfo.FortniteVersion != 25.09)
    {
        auto FirstObj = TUObjectArray::GetObjectByIndex(0);
        auto ActorDefault = AActor::GetDefaultObj();
        auto MeshNetworkComponentDefault = DefaultObjImpl(_("MeshNetworkComponent"));

        Hook(ObjPE = (void*)Offsets::ProcessEvent, ProcessEventHook, ProcessEventOG);
        Hook(ActorPE = ActorDefault->Vft[Offsets::ProcessEventVft], Actor__ProcessEventHook, Actor__ProcessEventOG);
        if (MeshNetworkComponentDefault)
            Hook(MncPE = MeshNetworkComponentDefault->Vft[Offsets::ProcessEventVft], MNC__ProcessEventHook, MNC__ProcessEventOG);

        SpawnThread(CheckForPEHooks, true, true);
    }

    wipeFunction(UnrealFunctions__EngineInit);
}
