#include "pch.h"
#include "../../Headers/Shared.h"
LATE_MODULE(Quickbar);

struct FGuid
{
    int32 A;
    int32 B;
    int32 C;
    int32 D;

    bool operator==(FGuid& _Rhs) {
        return A == _Rhs.A && B == _Rhs.B && C == _Rhs.C && D == _Rhs.D;
    }
};

enum class EFortQuickBars : uint8
{
    Primary = 0,
    Secondary = 1,
    Creative = 2,
    Max_None = 3,
    EFortQuickBars_MAX = 4,
};

struct FQuickBarSlot
{
public:
    USCRIPTSTRUCT_COMMON_MEMBERS(FQuickBarSlot);

    DEFINE_STRUCT_PROP(Items, TArray<FGuid>);
    DEFINE_STRUCT_BITFIELD_PROP(bEnabled);
    DEFINE_STRUCT_BITFIELD_PROP(bIsDirty);
    DEFINE_STRUCT_BITFIELD_PROP(bIsReserved);
    DEFINE_STRUCT_BITFIELD_PROP(bIsOccupied);
    DEFINE_STRUCT_PROP(UsedBySlotIndex, int32);
    DEFINE_STRUCT_PROP(UsedByItemGuid, FGuid);
};

struct FQuickBar
{
public:
    USCRIPTSTRUCT_COMMON_MEMBERS(FQuickBar);
    DEFINE_STRUCT_PROP(Slots, TArray<FQuickBarSlot>);
    DEFINE_STRUCT_PROP(CurrentFocusedSlot, int32);
    DEFINE_STRUCT_PROP(PreviousFoucsedSlot, int32);
    DEFINE_STRUCT_PROP(SecondaryFocusedSlot, int32);

    int NextSlot()
    {
        int n = Slots.Num();
        for (int i = 0; i < n; ++i)
            if (Slots[i].Items.Num() == 0)
                return i;
        return -1;
    }
};

class EFortWeaponType
{
public:
    UENUM_COMMON_MEMBERS(EFortWeaponType);

    DEFINE_ENUM_PROP(None);
    DEFINE_ENUM_PROP(RangedAny);
    DEFINE_ENUM_PROP(Pistol);
    DEFINE_ENUM_PROP(Shotgun);
    DEFINE_ENUM_PROP(Rifle);
    DEFINE_ENUM_PROP(SMG);
    DEFINE_ENUM_PROP(Sniper);
    DEFINE_ENUM_PROP(GrenadeLauncher);
    DEFINE_ENUM_PROP(RocketLauncher);
    DEFINE_ENUM_PROP(Bow);
    DEFINE_ENUM_PROP(Minigun);
    DEFINE_ENUM_PROP(LMG);
    DEFINE_ENUM_PROP(BiplaneGun);
    DEFINE_ENUM_PROP(MeleeAny);
    DEFINE_ENUM_PROP(Harvesting);
    DEFINE_ENUM_PROP(MAX);
};

struct FGameplayTag
{
    FName TagName;

    static int32 Size()
    {
        return VersionInfo.FortniteVersion >= 20.00 ? 4 : 8;
    }
};

struct FGameplayTagContainer
{
public:
    TArray<FGameplayTag> GameplayTags;
    TArray<FGameplayTag> ParentTags;

    bool HasTag(const FGameplayTag& TagToCheck) const
    {
        for (int x = 0; x < GameplayTags.Num(); x++)
        {
            auto& Tag = GameplayTags.Get(x, FGameplayTag::Size());
            if (Tag.TagName == TagToCheck.TagName)
                return true;
        }

        for (int x = 0; x < ParentTags.Num(); x++)
        {
            auto& Tag = ParentTags.Get(x, FGameplayTag::Size());
            if (Tag.TagName == TagToCheck.TagName)
                return true;
        }

        return false;
    }
};

class UFortItemDefinition : public UObject
{
public:
    UCLASS_COMMON_MEMBERS(UFortItemDefinition);

    DEFINE_PROP(NumberOfSlotsToTake, uint8);
    DEFINE_PROP(ItemType, uint8);
    DEFINE_PROP(GameplayTags, FGameplayTagContainer);
    DEFINE_PROP(Rarity, uint8);

    long long GetWeaponType()
    {
        for (auto& GameplayTag : GameplayTags.GameplayTags)
        {
            auto TagName = GameplayTag.TagName.ToString();

            if (TagName.contains(_("Item.Weapon.Ranged.Shotgun")))
                return EFortWeaponType::GetShotgun();

            if (TagName.contains(_("Weapon.Ranged.Assault")))
                return EFortWeaponType::GetRifle();

            if (TagName.contains(_("Item.Weapon.Ranged.SMG")))
                return EFortWeaponType::GetSMG();

            if (TagName.contains(_("Weapon.Ranged.Pistol")))
                return EFortWeaponType::GetPistol();

            if (TagName.contains(_("Weapon.Ranged.Sniper")))
                return EFortWeaponType::GetSniper();

            if (TagName.contains(_("Athena.Item.Utility")))
                return EFortWeaponType::GetRangedAny();

            if (TagName.contains(_("Item.Consumable")))
                return EFortWeaponType::GetHarvesting();
        }

        return EFortWeaponType::GetNone();
    }
};

struct FFortItemEntry : public FFastArraySerializerItem
{
public:
    USCRIPTSTRUCT_COMMON_MEMBERS(FFortItemEntry);

    DEFINE_STRUCT_PROP(ItemDefinition, UFortItemDefinition*);
};

class UFortWorldItem : public UObject
{
public:
    UCLASS_COMMON_MEMBERS(UFortWorldItem);

    DEFINE_PROP(ItemEntry, FFortItemEntry);
};

class AFortPlayerController : public AActor
{
public:
    UCLASS_COMMON_MEMBERS(AFortPlayerController);

    DEFINE_FUNC(BP_GetInventoryItemWithGuid, UFortWorldItem*);
};

class AFortQuickBars : public AActor 
{
public:
    UCLASS_COMMON_MEMBERS(AFortQuickBars);

    DEFINE_PROP(PrimaryQuickBar, FQuickBar);
};

std::unordered_map<long long, int> PreferredSlots;
static std::unordered_map<std::wstring, long long> WeaponNameToType;

static int GetPreferredSlot(long long WeaponType)
{
    for (auto& p : PreferredSlots)
        if (p.first == WeaponType)
            return p.second;
    return -1;
}

void (*AddItemInternalOG)(AFortQuickBars*, FGuid, EFortQuickBars, int) = nullptr;
void AddItemInternalHook(AFortQuickBars* QuickBars, FGuid ItemGuid, EFortQuickBars InQuickBar, int Slot)
{
    if (!QuickBars)
        return AddItemInternalOG(QuickBars, ItemGuid, InQuickBar, Slot);

    AFortPlayerController* PC = (AFortPlayerController*)QuickBars->GetOwner();
    if (!PC)
        return AddItemInternalOG(QuickBars, ItemGuid, InQuickBar, Slot);

    UFortWorldItem* Item = PC->BP_GetInventoryItemWithGuid(ItemGuid);
    if (!Item || !Item->ItemEntry.ItemDefinition)
        return AddItemInternalOG(QuickBars, ItemGuid, InQuickBar, Slot);

    UFortItemDefinition* Def = Item->ItemEntry.ItemDefinition;
    auto WeaponType = Def->GetWeaponType();

    if (WeaponType == EFortWeaponType::GetNone())
        return AddItemInternalOG(QuickBars, ItemGuid, InQuickBar, Slot);

    int PreferredSlot = GetPreferredSlot(WeaponType);
    if (PreferredSlot <= -1)
        return AddItemInternalOG(QuickBars, ItemGuid, InQuickBar, Slot);

    FQuickBar* PrimaryBar = &QuickBars->PrimaryQuickBar;
    TArray<FQuickBarSlot>& Slots = PrimaryBar->Slots;

    if (!Slots.Data || !Slots.IsValidIndex(PreferredSlot))
        return AddItemInternalOG(QuickBars, ItemGuid, InQuickBar, Slot);

    FQuickBarSlot& TargetSlot = Slots.Get(PreferredSlot, FQuickBarSlot::Size());

    if (!TargetSlot.Items.Data || (uintptr_t)TargetSlot.Items.Data == 0xFFFFFFFFFFFFFFFF || TargetSlot.Items.Num() == 0)
    {
        Slot = PreferredSlot;
        return AddItemInternalOG(QuickBars, ItemGuid, InQuickBar, Slot);
    }

    if (!TargetSlot.Items.IsValidIndex(0))
        return AddItemInternalOG(QuickBars, ItemGuid, InQuickBar, Slot);

    FGuid& ExistingGuid = TargetSlot.Items[0];
    if (ExistingGuid.A == 0 && ExistingGuid.B == 0 && ExistingGuid.C == 0 && ExistingGuid.D == 0)
    {
        Slot = PreferredSlot;
        return AddItemInternalOG(QuickBars, ItemGuid, InQuickBar, Slot);
    }

    UFortWorldItem* ExistingItem = PC->BP_GetInventoryItemWithGuid(ExistingGuid);
    if (!ExistingItem || !ExistingItem->ItemEntry.ItemDefinition)
        return AddItemInternalOG(QuickBars, ItemGuid, InQuickBar, Slot);

    UFortItemDefinition* ExistingDef = ExistingItem->ItemEntry.ItemDefinition;
    auto ExistingType = ExistingDef->GetWeaponType();

    if (WeaponType == ExistingType && ExistingDef->Rarity < Def->Rarity)
    {
        int FreeSlot = PrimaryBar->NextSlot();
        if (FreeSlot != -1 && Slots.IsValidIndex(FreeSlot))
        {
            AddItemInternalOG(QuickBars, ExistingGuid, InQuickBar, FreeSlot);
            Slot = PreferredSlot;
        }
    }

    AddItemInternalOG(QuickBars, ItemGuid, InQuickBar, Slot);
}

void Quickbar__LateInit()
{
    WeaponNameToType = {
        { _(L"Consumable"), EFortWeaponType::GetHarvesting() },
        { _(L"Utility"), EFortWeaponType::GetRangedAny() },
        { _(L"Pistol"), EFortWeaponType::GetPistol() },
        { _(L"Shotgun"), EFortWeaponType::GetShotgun() },
        { _(L"Rifle"), EFortWeaponType::GetRifle() },
        { _(L"SMG"), EFortWeaponType::GetSMG() },
        { _(L"Sniper"), EFortWeaponType::GetSniper() },
        { _(L"Grenade"), EFortWeaponType::GetGrenadeLauncher() },
        { _(L"Rocket"), EFortWeaponType::GetRocketLauncher() },
        { _(L"Bow"), EFortWeaponType::GetBow() },
        { _(L"Minigun"), EFortWeaponType::GetMinigun() },
        { _(L"LMG"), EFortWeaponType::GetLMG() },
        { _(L"Melee"), EFortWeaponType::GetMeleeAny() },
    };

    std::wstring CommandLine = GetCommandLineW();
    std::wstring key = _(L"-preferreditems=");

    size_t start = CommandLine.find(key);
    if (start == std::wstring::npos)
        return;

    start += key.length();

    size_t end = CommandLine.find(L' ', start);
    std::wstring list = CommandLine.substr(start, end - start);

    std::wstringstream ss(list);
    std::wstring pair;

    while (std::getline(ss, pair, L','))
    {
        size_t colon = pair.find(L':');
        if (colon == std::wstring::npos)
            continue;

        std::wstring name = pair.substr(0, colon);
        std::wstring slotStr = pair.substr(colon + 1);

        name.erase(0, name.find_first_not_of(_(L" \t")));
        name.erase(name.find_last_not_of(_(L" \t")) + 1);

        int slot = std::stoi(slotStr);

        auto it = WeaponNameToType.find(name);
        if (it == WeaponNameToType.end())
            continue;

        PreferredSlots[it->second] = slot;
    }

    uintptr_t Address = Memcury::Scanner::FindPattern(_("40 55 53 57 41 54 41 55 48 8D AC 24 ? ? ? ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 85 ? ? ? ? 45 0F B6 E0")).Get();
    if (!Address)
        return;

    Hook(Address, AddItemInternalHook, AddItemInternalOG);
}