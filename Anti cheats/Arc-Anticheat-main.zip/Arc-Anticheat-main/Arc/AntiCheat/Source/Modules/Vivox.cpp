#include "pch.h"
#include "../../Headers/Shared.h"
ENGINE_MODULE(Vivox);

void Vivox__EngineInit()
{
    if (!bIsFortnite || VersionInfo.FortniteVersion >= 11)
        return;

#if WITH_SOCKET
    if (!ServerConfiguration.contains(_("fortnite")))
        return;
    const json& Fortnite = ServerConfiguration[_("fortnite")];
    if (!Fortnite.is_object())
        return;
    bool EnableVivox = false;
    if (auto it = Fortnite.find(_("patch_vivox")); it != Fortnite.end() && it->is_boolean())
        EnableVivox = it->get<bool>();
    if (!EnableVivox)
        return;
#endif

    
    auto JoinTokenPatchRef = Memcury::Scanner::FindStringRef<const wchar_t*>(_(L"Failed to get join token: OSS Unavailable"));

    if (!JoinTokenPatchRef.IsValid())
        return;

    auto JoinTokenPatch = JoinTokenPatchRef.ScanFor({ 0x74, 0x10 }, false).Get();

    *(uint8_t*)JoinTokenPatch = 0xEB;
}