#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
#include "../../../Tellurium/Headers/Hooks.h"
INIT_MODULE(VEH);
using namespace ProjectArc::Bootstrapper;

LONG WINAPI ArcUnhandledExceptionFilter(LPEXCEPTION_POINTERS ExceptionInfo)
{
    fuckIda;
    static bool bGay = false;

    if (ExceptionInfo->ExceptionRecord->ExceptionCode == STATUS_GUARD_PAGE_VIOLATION)
    {
        if (FortniteCL < 15685441)
            if (!bGay && ExceptionInfo->ExceptionRecord->ExceptionAddress >= gameBase && ExceptionInfo->ExceptionRecord->ExceptionAddress < LPVOID(__int64(gameBase) + gameSize))
            {
                if ((__int64(ExceptionInfo->ContextRecord->Rip) & ~0xfff) == (StartingGame & ~0xfff))
                {
                    ExceptionInfo->ContextRecord->EFlags |= 0x100;

                    return EXCEPTION_CONTINUE_EXECUTION;
                }
                else
                {
                    bGay = true;
                    for (auto& PreSDKInitter : PreSDKInits)
                        PreSDKInitter();

                    SDK::Init();

                    auto dosHeader = (IMAGE_DOS_HEADER*)gameBase;
                    auto ntHeader = (IMAGE_NT_HEADERS*)(__int64(gameBase) + dosHeader->e_lfanew);
                    for (int i = 0; i < sizeof(IMAGE_DOS_HEADER) - 4; i += 2)
                        *(uint16_t*)(__int64(gameBase) + i) = 0x0;
                    ntHeader->Signature = 0x0;
                    ntHeader->FileHeader.Machine = 0x0;
                    ntHeader->FileHeader.TimeDateStamp = 0x0;
                    bWipedPEHdr = true;

                    return EXCEPTION_CONTINUE_EXECUTION;
                }
            }

        /*json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = GuardPageException;
        DetectionInfo[_("ban")] = true;
        SendDetectionReport(DetectionInfo);*/
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    else if (!bGay && ExceptionInfo->ExceptionRecord->ExceptionCode == STATUS_SINGLE_STEP)
    {
        if (bIsFortnite && FortniteCL < 15685441)
        {
            auto dosHeader = (IMAGE_DOS_HEADER*)gameBase;
            auto peHeader = (IMAGE_NT_HEADERS*)(__int64(gameBase) + dosHeader->e_lfanew);
            auto entryPoint = __int64(gameBase) + peHeader->OptionalHeader.AddressOfEntryPoint;

            bool bDidEPHooks = false;
            if (!bDidEPHooks && ExceptionInfo->ExceptionRecord->ExceptionAddress == LPVOID(entryPoint + 9))
            {
                ExceptionInfo->ContextRecord->Dr7 &= ~0x1;
                ExceptionInfo->ContextRecord->EFlags |= (1 << 16);
                bDidEPHooks = true;

                for (auto& UnpackInit : UnpackInits)
                    UnpackInit();

                Tellurium::Hooks::Init();
                if (SplashHWnd)
                {
                    bDisableSplashClose = true;
                    PostMessageA(SplashHWnd, WM_CLOSE, 0, 0);
                }
                // MessageBoxA(nullptr, std::format("{:x}", uint64_t(ExceptionInfo->ExceptionRecord->ExceptionAddress) - uint64_t(gameBase)).c_str(), "skid", MB_OK);
                return EXCEPTION_CONTINUE_EXECUTION;
            }

            DWORD og;

            VirtualProtect(LPVOID(StartingGame), 1, PAGE_EXECUTE_READWRITE | PAGE_GUARD, &og);
        }

        return EXCEPTION_CONTINUE_EXECUTION;
    }
    else if (ExceptionInfo->ExceptionRecord->ExceptionCode == EXCEPTION_BREAKPOINT)
    {
        /* json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = DetectedBreakpoint;
        DetectionInfo[_("ban")] = true;
        SendDetectionReport(DetectionInfo);*/

        //return EXCEPTION_CONTINUE_EXECUTION;
    }
    /* else
    {
        static HMODULE __AppXDeploymentClient = 0;
        static size_t __AppxDeploymentClient__Size = 0;
        static HMODULE __SHCore = 0;
        static size_t __SHCore__Size = 0;

        if (!__AppXDeploymentClient)
        {
            __AppXDeploymentClient = _li(GetModuleHandleA)(_("AppXDeploymentClient.dll"));

            if (__AppXDeploymentClient)
            {
                auto dosHeader = (IMAGE_DOS_HEADER*)__AppXDeploymentClient;
                auto peHeader = (IMAGE_NT_HEADERS*)(__int64(__AppXDeploymentClient) + dosHeader->e_lfanew);

                __AppxDeploymentClient__Size = peHeader->OptionalHeader.SizeOfImage;
            }

            __SHCore = _li(GetModuleHandleA)(_("SHCore.dll"));

            if (__SHCore)
            {
                auto dosHeader = (IMAGE_DOS_HEADER*)__SHCore;
                auto peHeader = (IMAGE_NT_HEADERS*)(__int64(__SHCore) + dosHeader->e_lfanew);

                __SHCore__Size = peHeader->OptionalHeader.SizeOfImage;
            }
        }

        auto _Ret = *(void**)ExceptionInfo->ContextRecord->Rsp;
        /*if (ExceptionInfo->ExceptionRecord->ExceptionAddress <= PVOID(0x600000))
                MessageBoxA(nullptr, std::format("{:x}", __int64(_Ret)).c_str(), "tiva", MB_OK);* /

        if ((_Ret >= __AppXDeploymentClient && _Ret < LPVOID(__int64(__AppXDeploymentClient) + __AppxDeploymentClient__Size)) || (_Ret >= __SHCore && _Ret <
    LPVOID(__int64(__SHCore) + __SHCore__Size)))
        {
            ExceptionInfo->ContextRecord->Rax = 1;
            ExceptionInfo->ContextRecord->Rip = uint64_t(_Ret);
            return EXCEPTION_CONTINUE_EXECUTION;
        }
    }*/

    return EXCEPTION_CONTINUE_SEARCH;
}

LONG WINAPI ArcCrashExceptionHandler(LPEXCEPTION_POINTERS ExceptionInfo)
{
/* -- PLOOSH WILL NOT LIKE THIS CODE - andr1ww -- */
    switch (ExceptionInfo->ExceptionRecord->ExceptionCode)
    {
    case EXCEPTION_ACCESS_VIOLATION:
    case EXCEPTION_ILLEGAL_INSTRUCTION:
    case EXCEPTION_STACK_OVERFLOW:
    //case EXCEPTION_IN_PAGE_ERROR:
    case EXCEPTION_PRIV_INSTRUCTION:
    case EXCEPTION_ARRAY_BOUNDS_EXCEEDED:
    case EXCEPTION_DATATYPE_MISALIGNMENT:
    case EXCEPTION_INT_DIVIDE_BY_ZERO:
    case EXCEPTION_FLT_DIVIDE_BY_ZERO:
        break; 
    default:
        return EXCEPTION_CONTINUE_SEARCH;
    }

    if (!ExceptionInfo->ContextRecord || ExceptionInfo->ContextRecord->Rip == 0)
        return EXCEPTION_CONTINUE_SEARCH;

    /*if (ExceptionInfo->ExceptionRecord->ExceptionCode == EXCEPTION_ACCESS_VIOLATION || ExceptionInfo->ExceptionRecord->ExceptionCode == EXCEPTION_IN_PAGE_ERROR)
    {
        auto type = ExceptionInfo->ExceptionRecord->ExceptionInformation[0];
        auto addr = (uintptr_t)ExceptionInfo->ExceptionRecord->ExceptionInformation[1];

        if (addr == 0xFFFFF78000000900ULL) 
            return EXCEPTION_CONTINUE_SEARCH;

        MEMORY_BASIC_INFORMATION mbi{};
        if (_li(VirtualQuery)((LPCVOID)addr, &mbi, sizeof(mbi)) != sizeof(mbi) || mbi.State != MEM_COMMIT)
            return EXCEPTION_CONTINUE_SEARCH;

        if (type == 8) // execute - andr1ww
        {
            MEMORY_BASIC_INFORMATION mbiRip{};
            if (_li(VirtualQuery)((LPCVOID)ExceptionInfo->ContextRecord->Rip, &mbiRip, sizeof(mbiRip)) != sizeof(mbiRip) || mbiRip.State != MEM_COMMIT)
                return EXCEPTION_CONTINUE_SEARCH;

            DWORD p = mbiRip.Protect & 0xFF;
            if (!(p == PAGE_EXECUTE || p == PAGE_EXECUTE_READ || p == PAGE_EXECUTE_READWRITE || p == PAGE_EXECUTE_WRITECOPY))
                return EXCEPTION_CONTINUE_SEARCH;
        }
    }*/

    /* -- END PLOOSH WILL NOT LIKE THIS CODE - andr1ww --  */

    auto thrHandle = _li(GetCurrentThread)();
    auto currentThrId = _li(GetThreadId)(thrHandle);
    auto currentPrcId = _li(GetProcessIdOfThread)(thrHandle);
    HANDLE h = _li(CreateToolhelp32Snapshot)(TH32CS_SNAPTHREAD, 0);
    if (h != INVALID_HANDLE_VALUE)
    {
        THREADENTRY32 te;
        te.dwSize = sizeof(te);
        if (_li(Thread32First)(h, &te))
        {
            do
            {
                if (te.dwSize >= FIELD_OFFSET(THREADENTRY32, th32OwnerProcessID) + sizeof(te.th32OwnerProcessID))
                {
                    if (te.th32ThreadID != currentThrId && te.th32OwnerProcessID == currentPrcId)
                    {
                        auto thr = _li(OpenThread)(THREAD_ALL_ACCESS, false, te.th32ThreadID);

                        if (thr != INVALID_HANDLE_VALUE)
                        {
                            _li(SuspendThread)(thr);
                            _li(CloseHandle)(thr);
                        }
                    }
                }
                te.dwSize = sizeof(te);
            } while (_li(Thread32Next)(h, &te));
        }
        _li(CloseHandle)(h);
    }

    STACKFRAME64 stackFrame{};

    char symName[1024 * sizeof(TCHAR)];
    char symStorage[sizeof(IMAGEHLP_SYMBOL64) + sizeof(symName)];
    auto sym = (IMAGEHLP_SYMBOL64*)symStorage;

    auto currentPrc = _li(GetCurrentProcess)();
    auto currentThr = _li(GetCurrentThread)();
    DWORD64 displacement = 0;
    stackFrame.AddrPC.Offset = ExceptionInfo->ContextRecord->Rip;
    stackFrame.AddrPC.Mode = AddrModeFlat;
    stackFrame.AddrStack.Offset = ExceptionInfo->ContextRecord->Rsp;
    stackFrame.AddrStack.Mode = AddrModeFlat;
    stackFrame.AddrFrame.Offset = ExceptionInfo->ContextRecord->Rbp;
    stackFrame.AddrFrame.Mode = AddrModeFlat;

    _li(SymCleanup)(currentPrc);

    auto InitResult = _li(SymInitialize)(currentPrc, nullptr, true);

    std::stringstream reportStream;

    reportStream << _("[Arc] Caught unhandled exception (Code: ");
    char code[9];

    switch (ExceptionInfo->ExceptionRecord->ExceptionCode)
    {
#define NAMED_EX(x)                                                                                                                                                                \
    case x:                                                                                                                                                                        \
        reportStream << #x;                                                                                                                                                        \
        break;

        NAMED_EX(EXCEPTION_ACCESS_VIOLATION);
        NAMED_EX(EXCEPTION_ARRAY_BOUNDS_EXCEEDED);
        NAMED_EX(EXCEPTION_BREAKPOINT);
        NAMED_EX(EXCEPTION_DATATYPE_MISALIGNMENT);
        NAMED_EX(EXCEPTION_FLT_DENORMAL_OPERAND);
        NAMED_EX(EXCEPTION_FLT_DIVIDE_BY_ZERO);
        NAMED_EX(EXCEPTION_FLT_INEXACT_RESULT);
        NAMED_EX(EXCEPTION_FLT_INVALID_OPERATION);
        NAMED_EX(EXCEPTION_FLT_OVERFLOW);
        NAMED_EX(EXCEPTION_FLT_STACK_CHECK);
        NAMED_EX(EXCEPTION_FLT_UNDERFLOW);
        NAMED_EX(EXCEPTION_ILLEGAL_INSTRUCTION);
        NAMED_EX(EXCEPTION_INT_DIVIDE_BY_ZERO);
        NAMED_EX(EXCEPTION_INT_OVERFLOW);
        NAMED_EX(EXCEPTION_INVALID_DISPOSITION);
        NAMED_EX(EXCEPTION_NONCONTINUABLE_EXCEPTION);
        NAMED_EX(EXCEPTION_PRIV_INSTRUCTION);
        NAMED_EX(EXCEPTION_SINGLE_STEP);
        NAMED_EX(EXCEPTION_STACK_OVERFLOW);

#undef NAMED_EX
    default:
        snprintf(code, 9, _("%08x"), ExceptionInfo->ExceptionRecord->ExceptionCode);
        reportStream << code;
    }
    reportStream << ")";

    if (ExceptionInfo->ExceptionRecord->ExceptionCode == EXCEPTION_ACCESS_VIOLATION || ExceptionInfo->ExceptionRecord->ExceptionCode == EXCEPTION_IN_PAGE_ERROR)
    {
        switch (ExceptionInfo->ExceptionRecord->ExceptionInformation[0])
        {
        case 0:
            reportStream << _("\n- Trying to read ");
            break;
        case 1:
            reportStream << _("\n- Trying to write ");
            break;
        case 8:
            reportStream << "\n- Trying to execute ";
            break;
        }
        if (ExceptionInfo->ExceptionRecord->ExceptionInformation[1] == 0xFFFFF78000000900) // fn anti debug check ig
            return EXCEPTION_CONTINUE_SEARCH;

        char addr[19];
        snprintf(addr, 19, _("0x%016llx"), ExceptionInfo->ExceptionRecord->ExceptionInformation[1]);
        reportStream << addr;
    }
    reportStream << _("\nImageBase: 0x") << std::hex << __int64(gameBase) << "\n";
    reportStream << _("ImageSize: 0x") << std::hex << __int64(gameSize) << "\n";
    reportStream << _("ArcBase: 0x") << std::hex << __int64(__ThisBase) << "\n";
    reportStream << _("ArcSize: 0x") << std::hex << __int64(__ThisSize) << "\n";
    reportStream << std::dec;
    reportStream << "\n\n";

    for (int frame = 0;; frame++)
    {
        auto contextCpy = *ExceptionInfo->ContextRecord;
        contextCpy.ContextFlags = CONTEXT_ALL;

        auto result
            = StackWalk(IMAGE_FILE_MACHINE_AMD64, currentPrc, currentThr, &stackFrame, ExceptionInfo->ContextRecord, NULL, _li(SymFunctionTableAccess64), _li(SymGetModuleBase64), NULL);

        if (result == false)
            break;

        char addr[19];
        snprintf(addr, 19, _("0x%016llx"), stackFrame.AddrPC.Offset);
        reportStream << addr;

        auto imageBase = _li(SymGetModuleBase64)(currentPrc, stackFrame.AddrPC.Offset);
        if (imageBase)
        {
            char path[1024];
            _li(GetModuleFileNameA)(HMODULE(imageBase), path, 1024);

            auto filteredPath = strrchr(path, '\\');

            char offsetStr[19];
            snprintf(offsetStr, 19, _("0x%llx"), stackFrame.AddrPC.Offset - imageBase);
            reportStream << _(" (") << (filteredPath ? filteredPath + 1 : path) << _("+") << offsetStr << _(")");
        }
        reportStream << ": ";

        sym->SizeOfStruct = sizeof(symStorage);
        sym->MaxNameLength = sizeof(symName);

        BOOL SymResult = _li(SymGetSymFromAddr64)(currentPrc, (ULONG64)stackFrame.AddrPC.Offset, &displacement, sym);
        if (SymResult == false)
            reportStream << _("[unknown]\n");
        else
        {
            _li(UnDecorateSymbolName)(sym->Name, (PSTR)symName, sizeof(symName), UNDNAME_COMPLETE);

            reportStream << sym->Name << _("()");
            IMAGEHLP_LINE64 ImageHelpLine = { 0 };
            ImageHelpLine.SizeOfStruct = sizeof(ImageHelpLine);
            if (_li(SymGetLineFromAddr64)(currentPrc, (ULONG64)stackFrame.AddrPC.Offset, (::DWORD*)&displacement, &ImageHelpLine))
            {
                auto filteredName = strrchr(ImageHelpLine.FileName, '\\');
                reportStream << _(" [") << (filteredName ? filteredName + 1 : ImageHelpLine.FileName) << _(":") << ImageHelpLine.LineNumber << _("]");
            }
            reportStream << "\n";
        }
    }

#if WITH_SOCKET
    json CrashInfo;

    CrashInfo[_("type")] = _("crash");
	CrashInfo[_("info")] = reportStream.str();
    SendDetectionReport(CrashInfo);
#else
    MessageBoxA(nullptr, reportStream.str().c_str(), _("Arc"), MB_OK);
#endif

    _li(SymCleanup)(currentPrc);
    _li(TerminateProcess)(currentPrc, ExceptionInfo->ExceptionRecord->ExceptionCode);

    return EXCEPTION_CONTINUE_EXECUTION;
}

void VEH__Init()
{
    fuckIda;
    AddVectoredExceptionHandler(1, ArcUnhandledExceptionFilter);
//	AddVectoredExceptionHandler(0, ArcCrashExceptionHandler);
}