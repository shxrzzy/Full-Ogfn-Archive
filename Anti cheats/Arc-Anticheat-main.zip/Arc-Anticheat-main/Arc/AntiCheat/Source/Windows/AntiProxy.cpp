#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
#include <winhttp.h>
#pragma comment(lib, "winhttp.lib")
INIT_MODULE(AntiProxy);

BOOL WINAPI WinHttpGetDefaultProxyConfiguration_Hk(PWINHTTP_PROXY_INFO proxyInfo)
{
    proxyInfo->lpszProxy = nullptr;
    return true;
}

BOOL WINAPI WinHttpGetIEProxyConfigForCurrentUser_Hk(PWINHTTP_CURRENT_USER_IE_PROXY_CONFIG proxyInfo)
{
    proxyInfo->lpszProxy = nullptr;
    return true;
}

void AntiProxy__Init()
{
    fuckIda;
    Hook(_li(WinHttpGetDefaultProxyConfiguration), WinHttpGetDefaultProxyConfiguration_Hk);
    Hook(_li(WinHttpGetIEProxyConfigForCurrentUser), WinHttpGetIEProxyConfigForCurrentUser_Hk);

    wipeFunction(AntiProxy__Init);
}