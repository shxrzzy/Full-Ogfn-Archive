#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
INIT_MODULE(Threads);
using namespace ProjectArc::Bootstrapper;

int (*BaseThreadInitThunkOG)(int _StartThread__Cond, void* _StartAddress, void* _Param);
int BaseThreadInitThunkHook(int _StartThread__Cond, void* _StartAddress, void* _Param)
{
    fuckIda;

    //if (_StartAddress == Bro && uint64_t(_Param) >= uint64_t(__ThisBase) && uint64_t(_Param) <= uint64_t(__ThisBase) + __ThisSize)
    //    return BaseThreadInitThunkOG(_StartThread__Cond, _StartAddress, _Param);

    if (!IsAddrInLoadedModule(_StartAddress)) [[unlikely]]
    {
        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = BadThreadCreate;
        DetectionInfo[_("ban")] = false;
        SendDetectionReport(DetectionInfo);
        ExitThread(0);
        return 0;
    }

    if (_StartAddress == _li(LoadLibraryA) || _StartAddress == _li(LoadLibraryW))
    {
        ExitThread(0);
        return 0;
    }

    return BaseThreadInitThunkOG(_StartThread__Cond, _StartAddress, _Param);
}

HANDLE(__stdcall* CreateThreadOG)(
    LPSECURITY_ATTRIBUTES lpThreadAttributes, SIZE_T dwStackSize, LPTHREAD_START_ROUTINE lpStartAddress, LPVOID lpParameter, DWORD dwCreationFlags, LPDWORD lpThreadId);
HANDLE __stdcall CreateThreadHook(
    LPSECURITY_ATTRIBUTES lpThreadAttributes, SIZE_T dwStackSize, LPTHREAD_START_ROUTINE lpStartAddress, LPVOID lpParameter, DWORD dwCreationFlags, LPDWORD lpThreadId)
{
    fuckIda;

    //if (lpStartAddress == Bro && uint64_t(lpParameter) >= uint64_t(__ThisBase) && uint64_t(lpParameter) <= uint64_t(__ThisBase) + __ThisSize)
    //    return CreateThreadOG(lpThreadAttributes, dwStackSize, lpStartAddress, lpParameter, dwCreationFlags, lpThreadId);
    // auto ChkRet = IsInLMNotSHCore(lpStartAddress);
    // if (ChkRet == 0) [[unlikely]]
    if (!IsAddrInLoadedModule(lpStartAddress)) [[unlikely]]
    {
        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = BadThreadCreate;
        DetectionInfo[_("ban")] = false;
        SendDetectionReport(DetectionInfo);
        // Crash();
        //*(uint64_t*)_AddressOfReturnAddress() = 0;
        return 0;
    }
    // else if (ChkRet == 2)
    //     return 0;

    bool bFound = false;
    auto RetAddr = _ReturnAddress();

    if (uint64_t(RetAddr) >= uint64_t(gameBase) && uint64_t(RetAddr) <= uint64_t(gameBase) + gameSize) [[unlikely]]
        bFound = true;
    if (!bFound && uint64_t(RetAddr) >= uint64_t(__ThisBase) && uint64_t(RetAddr) <= uint64_t(__ThisBase) + __ThisSize) [[unlikely]]
        bFound = true;

    if (!bFound)
    {
        auto PEB = (li::detail::win::PEB_T*)__readgsqword(0x60);
        auto Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
        auto Head = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;

        do
        {
            if (RetAddr >= Entry->DllBase && RetAddr <= Entry->DllBase + Entry->SizeOfImage) [[unlikely]]
            {
                bFound = true;

                if ((const char*)lpStartAddress < Entry->DllBase || (const char*)lpStartAddress > Entry->DllBase + Entry->SizeOfImage)
                {
                    json DetectionInfo;

                    DetectionInfo[_("type")] = _("detection");
                    DetectionInfo[_("code")] = BadThreadCreate;
                    DetectionInfo[_("ban")] = false;
                    SendDetectionReport(DetectionInfo);
                    // Crash();
                    //*(uint64_t*)_AddressOfReturnAddress() = 0;
                    return 0;
                }
            }
        }
        while ((Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)Entry->InLoadOrderLinks.Flink) && Entry != Head);

        if (!bFound)
        {
            json DetectionInfo;

            DetectionInfo[_("type")] = _("detection");
            DetectionInfo[_("code")] = BadThreadCreate;
            DetectionInfo[_("ban")] = false;
            SendDetectionReport(DetectionInfo);
            // Crash();
            //*(uint64_t*)_AddressOfReturnAddress() = 0;
            return 0;
        }
    }

    return CreateThreadOG(lpThreadAttributes, dwStackSize, lpStartAddress, lpParameter, dwCreationFlags, lpThreadId);
}

void CheckForThreadHooks(void*, uint8_t* ThrLdr)
{
    fuckIda;
    //*ThrLdr = 1;
    json DetectionInfo;

    DetectionInfo[_("type")] = _("detection");
    DetectionInfo[_("ban")] = true;

    auto BaseThreadInitThunk_ = LI_FN_NO_DEF(BaseThreadInitThunk).get();
    auto CreateThread_ = LI_FN_NO_DEF(CreateThread).get();
    auto BaseThreadInitThunk__Bytes = *(uint64_t*)BaseThreadInitThunk_;
    auto CreateThread__Bytes = *(uint64_t*)CreateThread_;
    while (true)
    {
        if (*(uint64_t*)BaseThreadInitThunk_ != BaseThreadInitThunk__Bytes) [[unlikely]]
        {
            DetectionInfo[_("code")] = ThreadChecksHooked;
            goto _end;
        }
        else if (*(uint64_t*)CreateThread_ != CreateThread__Bytes) [[unlikely]]
        {
            DetectionInfo[_("code")] = ThreadChecksHooked;
            goto _end;
        }

        Sleep(100);
    }
_end:
    SendDetectionReport(DetectionInfo);
}

void Threads__Init()
{
    fuckIda;
    Hook(LI_FN_NO_DEF(BaseThreadInitThunk).cached(), BaseThreadInitThunkHook, BaseThreadInitThunkOG);
    Hook(_li(CreateThread), CreateThreadHook, CreateThreadOG);

    SpawnThread(CheckForThreadHooks, true, true);
}