#include "pch.h"
#include "../../../Bootstrapper/Headers/Shared.h"
#include "../../Headers/Shared.h"
#include <processthreadsapi.h>
#include <psapi.h>
INIT_MODULE(External);

long ScreenX;
long ScreenY;
HWND DesktopWindow;

extern "C" BOOL WINAPI GetWindowBand(HWND hWnd, PDWORD pdwBand);

BOOL WindowEnumProc(HWND hWnd, LPARAM)
{
    fuckIda;
    LONG_PTR Style = _li(GetWindowLongPtrA)(hWnd, GWL_STYLE);

    if (hWnd == DesktopWindow)
        return TRUE;
    if ((Style & WS_VISIBLE) == 0)
        return TRUE;
    if (Style & WS_DISABLED)
        return TRUE;

    LONG_PTR ExStyle = _li(GetWindowLongPtrA)(hWnd, GWL_EXSTYLE);
    if (ExStyle & WS_EX_NOREDIRECTIONBITMAP)
        return TRUE;

    constexpr auto ExStyles = WS_EX_LAYERED | WS_EX_TRANSPARENT;
    constexpr auto ExStylesBanded = WS_EX_TOPMOST | WS_EX_NOACTIVATE;
    if ((ExStyle & ExStyles) == ExStyles /* && (ExStyle & (WS_EX_TOPMOST | WS_EX_TOOLWINDOW)*/)
    {
        if (!(Style & WS_POPUP))
            return TRUE;
    }
    else if ((ExStyle & ExStylesBanded) == ExStylesBanded)
    {
        DWORD band = 0;
        _li(GetWindowBand)(hWnd, &band);
        if (band <= 1)
            return TRUE;
    }
    else
        return TRUE;

    RECT WindowRect;
    _li(GetWindowRect)(hWnd, &WindowRect);
    auto ResX = WindowRect.right - WindowRect.left;
    auto ResY = WindowRect.bottom - WindowRect.top;

    if (ResX >= ScreenX && ResY >= ScreenY)
    {
        DWORD percsId;
        _li(GetWindowThreadProcessId)(hWnd, &percsId);
        auto percs = _li(OpenProcess)(PROCESS_QUERY_INFORMATION | PROCESS_TERMINATE, false, percsId);
        std::stringstream Info;

        char FileName[1024] {};
        _li(K32GetModuleFileNameExA)(percs, nullptr, FileName, 1024);
        Info << "Process: ";
        Info << FileName;

        Info << ", Class: ";
        char ClassName[1024] {};
        _li(GetClassNameA)(hWnd, ClassName, 1024);
        Info << ClassName;

        Info << ", Name: ";
        char WindowName[1024] {};
        _li(GetWindowTextA)(hWnd, WindowName, 1024);
        Info << WindowName;

        Info << ", Style: ";
        Info << std::hex << Style;

        Info << ", ExStyle: ";
        Info << std::hex << ExStyle;

        if (strcmp(ClassName, _("CEF-OSC-WIDGET")) == 0 || strstr(ClassName, _("{18E91349-E229-4995-8049-7437243BBCC3}")) || strstr(ClassName, _("QWindowIcon"))
            || strcmp(ClassName, _("FindMyMouse")) == 0 || strstr(ClassName, _("QWindowToolSaveBits")) || strcmp(ClassName, _("UnityWndClass")) == 0
            || strcmp(ClassName, _("#32770")) == 0 || strcmp(ClassName, _("MonitorIdentify")) == 0 || strcmp(ClassName, _("OOPO_WINDOWS_CLASS")) == 0
            || strcmp(WindowName, _("owingameosr_Exclusive mode - index")) == 0)
            return TRUE;

        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = CreatedOverlay;
        DetectionInfo[_("ban")] = false;
        DetectionInfo[_("info")] = Info.str();
        SendDetectionReport(DetectionInfo);

        if (!_li(TerminateProcess)(percs, 0))
        {
            _li(TerminateProcess)(_li(GetCurrentProcess)(), 0);
            *(uint64_t*)_AddressOfReturnAddress() = 0;
        }
    }

    return TRUE;
}

void ExternalDetectionThr(void*, uint8_t* ThrLdr)
{
    fuckIda;
    //*ThrLdr = 1;

    while (true)
    {
        auto windowHandle2 = _li(FindWindowA)(NULL, _("Aimmy"));

        if (windowHandle2)
        {
            DWORD pid;
            _li(GetWindowThreadProcessId)(windowHandle2, &pid);
            auto proc = _li(OpenProcess)(PROCESS_TERMINATE, false, pid);
            if (!_li(TerminateProcess)(proc, 0))
            {
                _li(TerminateProcess)(_li(GetCurrentProcess)(), 0);
                *(uint64_t*)_AddressOfReturnAddress() = 0;
                return;
            }
        }

        DesktopWindow = _li(GetDesktopWindow)();
        RECT DesktopRect;
        _li(GetWindowRect)(DesktopWindow, &DesktopRect);

        ScreenX = DesktopRect.right - DesktopRect.left;
        ScreenY = DesktopRect.bottom - DesktopRect.top;

        _li(EnumWindows)(WindowEnumProc, NULL);

        Sleep(100);
    }
}

void External__Init()
{
    fuckIda;
    // CreateThread(0, 0, LPTHREAD_START_ROUTINE(ExternalDetectionThr), 0, 0, 0);
    SpawnThread(ExternalDetectionThr, true);

    wipeFunction(External__Init);
}
