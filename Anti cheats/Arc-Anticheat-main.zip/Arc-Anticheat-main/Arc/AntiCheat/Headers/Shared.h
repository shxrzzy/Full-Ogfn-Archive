#pragma once
#include "../../Bootstrapper/Headers/Shared.h"
#include "../../Bootstrapper/Headers/Configuration.h"
#include "../../pch.h"
#include "../../crc32.h"
#include <cstdint>
#include <filesystem>
#include <string>
#include <unordered_map>
using namespace ProjectArc::Bootstrapper;
using namespace nlohmann;

inline bool bIsFortnite = false;
inline char* __ThisBase = nullptr;
inline size_t __ThisSize = 0;
inline easywsclient::WebSocket* _socket;
inline bool bReadyToLaunch = false;
inline int FortniteCL = 0;
inline HANDLE hMainThread;
inline std::string ArcToken;
inline uint64_t StartingGame = 0;
inline bool bWipedPEHdr = false;
inline bool bResetHash = false;
inline bool bResetLock = false;
inline bool bDeath = false;
inline uint64_t utocPatchAddr = 0;
inline uint8_t utocPatchBytes[8];
inline uint64_t pakPatchAddr = 0;
inline uint8_t pakPatchBytes[6];
inline uint64_t missingSignature = 0;
inline uint8_t missingSignatureBytes[4];
inline HWND SplashHWnd = NULL;
inline std::wstring errorText = L"";
inline bool bDisableSplashClose = false;
inline bool bEnableCWHook = false;
inline bool splashClosed = false;
inline PIMAGE_SECTION_HEADER gameText = 0;
inline PIMAGE_SECTION_HEADER thisText = 0;

inline std::vector<void (*)()> ModuleInits;
inline std::vector<void (*)()> PreSDKInits;
inline std::vector<void (*)()> EngineInits;
inline std::vector<void (*)()> LateInits;
inline std::vector<void (*)()> UnpackInits;
inline std::unordered_map<std::string, void*> _Hooks;
inline std::vector<HANDLE> AntiCheatThreads;
inline std::vector<HANDLE> VerifyCtxThreads;


#define GUARD                                                                                                                                                                      \
    {                                                                                                                                                                              \
        auto Ret = uint64_t(_ReturnAddress());                                                                                                                                     \
        if (Ret < uint64_t(__ThisBase) || Ret >= uint64_t(__ThisBase) + __ThisSize)                                                                                                \
        {                                                                                                                                                                          \
            *(uint64_t*)_AddressOfReturnAddress() = 0;                                                                                                                             \
            TerminateProcess(GetCurrentProcess(), 0);                                                                                                                              \
            return;                                                                                                                                                                \
        }                                                                                                                                                                          \
    }

#define GUARD_RET(R)                                                                                                                                                               \
    {                                                                                                                                                                              \
        auto Ret = uint64_t(_ReturnAddress());                                                                                                                                     \
        if (Ret < uint64_t(__ThisBase) || Ret >= uint64_t(__ThisBase) + __ThisSize)                                                                                                \
        {                                                                                                                                                                          \
            *(uint64_t*)_AddressOfReturnAddress() = 0;                                                                                                                             \
            TerminateProcess(GetCurrentProcess(), 0);                                                                                                                              \
            return R;                                                                                                                                                              \
        }                                                                                                                                                                          \
    }

#define INIT_MODULE(Name)                                                                                                                                                          \
    void Name##__Init();                                                                                                                                                           \
    static auto Initter__##Name = ([]() { ModuleInits.push_back(Name##__Init); return 1; })();
#define UNPACK_MODULE(Name)                                                                                                                                                           \
    void Name##__UnpackInit();                                                                                                                                                        \
    static auto UnpackInitter__##Name = ([]() { UnpackInits.push_back(Name##__UnpackInit); return 1; })();
#define ENGINE_MODULE(Name)                                                                                                                                                        \
    void Name##__EngineInit();                                                                                                                                                     \
    static auto EngineInitter__##Name = ([]() { EngineInits.push_back(Name##__EngineInit); return 1; })();
#define LATE_MODULE(Name)                                                                                                                                                          \
    void Name##__LateInit();                                                                                                                                                       \
    static auto LateInitter__##Name = ([]() { LateInits.push_back(Name##__LateInit); return 1; })();
#define PRESDK_MODULE(Name)                                                                                                                                                        \
    void Name##__PreSDKInit();                                                                                                                                                     \
    static auto PreSDKInitter__##Name = ([]() { PreSDKInits.push_back(Name##__PreSDKInit); return 1; })();

#define ADD_IMPORT_HOOK(Fn, Hk) _Hooks[_(#Fn)] = Hk;

inline void* __nullptrForHook = nullptr;
template <class _T, class _Ot = void*>
__forceinline void Hook(_T _Ptr, void* _Detour, _Ot& _Orig = __nullptrForHook)
{
    MinHook::MH_CreateHook((LPVOID)_Ptr, _Detour, (LPVOID*)(std::is_same_v<_Ot, void*> ? nullptr : &_Orig));
    MinHook::MH_EnableHook(LPVOID(_Ptr));
}

template <class _T>
__forceinline void UnHook(_T _Ptr)
{
    MinHook::MH_DisableHook(LPVOID(_Ptr));
}

void Erase();
bool InitSocket(bool bReconnection = false);
void Send(json&);

__forceinline void SendDetectionReport(json& Report, bool bPopup = true)
{
    bool bBan = Report.contains(_("ban")) && (bool)Report[_("ban")];
    bool bClose = bBan || (Report.contains(_("close")) && (bool)Report[_("close")]);

    if (bClose)
        *(uint64_t*)_AddressOfReturnAddress() = 0;
    Send(Report);

	if (bBan)
		bDeath = true;

#if !WITH_SOCKET
    if (bPopup)
    {
        std::string Message;

        Message += _("AntiCheat error detected!\n");

        if (Report.contains(_("code")))
            Message += _("Code: #") + std::to_string((int)Report[_("code")]);
        else if (Report.contains(_("message")))
            Message += Report[_("message")];

        Message += _("\n\n");
        if (Report.contains(_("info")))
            Message += Report[_("info")];
        else
            Message += _("There is no additional info at this time.");

        _li(MessageBoxA)(nullptr, Message.c_str(), _("Arc"), MB_ICONERROR | MB_OK | MB_TOPMOST);
    }
#endif

    //if (bClose)
    //    Erase();

    if (bClose)
        _li(TerminateProcess)(_li(GetCurrentProcess)(), 0);
}

__forceinline bool IsAddrInLoadedModule(void* addr)
{
    fuckIda;
    if (uint64_t(addr) >= uint64_t(gameBase) && uint64_t(addr) <= uint64_t(gameBase) + gameSize) [[unlikely]]
        return true;
    if (uint64_t(addr) >= uint64_t(__ThisBase) && uint64_t(addr) <= uint64_t(__ThisBase) + __ThisSize) [[unlikely]]
        return true;

    auto PEB = (li::detail::win::PEB_T*)__readgsqword(0x60);
    auto Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;
    auto Head = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)PEB->Ldr->InLoadOrderModuleList.Flink;

    do
    {
        if (addr >= Entry->DllBase && addr <= Entry->DllBase + Entry->SizeOfImage) [[unlikely]]
            return true;
    }
    while ((Entry = (li::detail::win::LDR_DATA_TABLE_ENTRY_T*)Entry->InLoadOrderLinks.Flink) && Entry != Head);

    return false;
}

#if defined(__clang__)
__forceinline void* _AddressOfNextInstruction()
{
    void* addr;
    __asm__ __volatile__("lea %0, rip" : "=r"(addr));
    return addr;
}
#endif

inline __forceinline void Erase()
{

    DWORD a;
    _li(VirtualProtect)(__ThisBase, __ThisSize, PAGE_EXECUTE_READWRITE, &a);
    auto b = (__int64(_AddressOfNextInstruction()) - __int64(__ThisBase));
    auto c = b + 0x400;
    for (int i = 0; i < __ThisSize; i++)
    {
        if (i < b || i > c)
            *(uint8*)(__int64(__ThisBase) + i) = rand() & 0xff;
    }

    DWORD d;
    _li(VirtualProtect)(gameBase, gameSize, PAGE_EXECUTE_READWRITE, &d);
    for (int i = 0; i < gameSize; i++)
    {
        *(uint8*)(__int64(gameBase) + i) = rand() & 0xff;
    }
}

template <typename _Is>
__forceinline void Patch(uintptr_t ptr, _Is byte)
{
    DWORD og;
    _li(VirtualProtect)(LPVOID(ptr), sizeof(_Is), PAGE_EXECUTE_READWRITE, &og);
    *(_Is*)ptr = byte;
    _li(VirtualProtect)(LPVOID(ptr), sizeof(_Is), og, &og);
}

inline void PatchBytes(uint64 addr, const std::vector<uint8_t>& Bytes)
{
    if (!addr)
        return;

    for (int i = 0; i < Bytes.size(); i++)
        Patch<uint64>(addr + i, Bytes.at(i));
}

template <typename _Ot = void*>
__forceinline void ExecHook(UFunction* _Fn, void* _Detour, _Ot& _Orig = __nullptrForHook)
{
    if (!_Fn)
        return;
    if (!std::is_same_v<_Ot, void*>)
        _Orig = (_Ot)_Fn->ExecFunction;

    _Fn->ExecFunction = _Detour;
}

enum EArcDetection
{
    UnsignedDLLLoaded,
    DebuggerDetected,
    ImGuiInitialization,
    CreatedOverlay,
    ProcessEventCall,
    ExecFunctionHooked,
    ManualMappedDLL,
    ThreadDidntCreate,
    ThreadDespawned,
    EngineRenderHooked,
    BadThreadCreate,
    PlayerControllerHooked,
    SuspiciousPakLoad,
    GuardPageException,
    DetectedBreakpoint,
    FunctionUnhooked,
    AntiCheatPatched,
    RDataPatched,
    ThreadChecksHooked,
    ManualMapReverted,
    WinTrustPatched,
    ThreadTamperedWith,
    PEDataModified,
    DroppedHook,
    HWIDHook
};

inline void* Bro = nullptr;
__forceinline void SpawnThread(void* StartAddress, bool bVerifyStatus = false, bool bVerifyCtx = false)
{
    /*auto shc = (uint8_t*)_("\x00\x48\x8D\x15\xF8\xFF\xFF\xFF\xFF\xE1");

    Bro = malloc(10);

    DWORD og;
    VirtualProtect(Bro, 10, PAGE_EXECUTE_READWRITE, &og);

    memcpy(Bro, shc, 10);
    DWORD thrId = 0;
    auto thr = _li(CreateThread)(0, 0, (LPTHREAD_START_ROUTINE)Bro, StartAddress, 0, &thrId);

    if (*(uint8_t*)Bro == 0)
        while (*(uint8_t*)Bro == 0)
            Sleep(10);

    free(Bro);

    Bro = nullptr;*/
    DWORD thrId = 0;
    auto thr = _li(CreateThread)(0, 0, (LPTHREAD_START_ROUTINE)StartAddress, 0, 0, &thrId);

    DWORD thrFlags;
    auto Ret = _li(GetHandleInformation)(thr, &thrFlags);
    if (!thr || !thrId || !Ret)
    {
        // thr didnt start. means we've been hooked!

        json DetectionInfo;

        DetectionInfo[_("type")] = _("detection");
        DetectionInfo[_("code")] = ThreadDidntCreate;
        DetectionInfo[_("ban")] = true;
        SendDetectionReport(DetectionInfo);
    }

    if (bVerifyStatus)
        AntiCheatThreads.push_back(thr);

    if (bVerifyCtx)
        VerifyCtxThreads.push_back(thr);
}

inline Configuration Config = {};
inline json ServerConfiguration = {};

/// <summary>
/// Below is used for pak mounting checks (if we ever move to multi engine we screwed lol) - andr1ww
/// <summary>

struct Pak
{
    std::filesystem::file_time_type LastModified {};
    std::filesystem::file_time_type LastModifiedSig {};
    std::uintmax_t SigSize = 0;
    bool HasSig = false;
    bool bWhitelisted = false;
};

struct WhitelistedPak
{
    std::string Name;
    std::uint64_t Size = 0;
};
inline std::vector<WhitelistedPak> WhitelistedPaks;


__forceinline void Freeze()
{
    fuckIda;
    auto thrHandle = _li(GetCurrentThread)();
    auto currentThr = _li(GetThreadId)(thrHandle);
    auto currentPrc = _li(GetProcessIdOfThread)(thrHandle);
    HANDLE h = _li(CreateToolhelp32Snapshot)(TH32CS_SNAPTHREAD, 0);
    if (h != INVALID_HANDLE_VALUE)
    {
        THREADENTRY32 te;
        te.dwSize = sizeof(te);
        if (_li(Thread32First)(h, &te))
        {
            do
            {
                if (te.dwSize >= FIELD_OFFSET(THREADENTRY32, th32OwnerProcessID) + sizeof(te.th32OwnerProcessID))
                {
                    if (te.th32ThreadID != currentThr && te.th32OwnerProcessID == currentPrc)
                    {
                        auto thr = _li(OpenThread)(THREAD_ALL_ACCESS, false, te.th32ThreadID);
                        CONTEXT thrCtx {};
                        GetThreadContext(thr, &thrCtx);
                        if ((void*)thrCtx.Rip < __ThisBase || thrCtx.Rip >= __int64(__ThisBase) + __ThisSize)
                            _li(SuspendThread)(thr);
                        _li(CloseHandle)(thr);
                    }
                }
                te.dwSize = sizeof(te);
            }
            while (_li(Thread32Next)(h, &te));
        }
        _li(CloseHandle)(h);
    }
}

__forceinline void Unfreeze()
{
    auto thrHandle = _li(GetCurrentThread)();
    auto currentThr = _li(GetThreadId)(thrHandle);
    auto currentPrc = _li(GetProcessIdOfThread)(thrHandle);
    HANDLE h = _li(CreateToolhelp32Snapshot)(TH32CS_SNAPTHREAD, 0);
    if (h != INVALID_HANDLE_VALUE)
    {
        THREADENTRY32 te;
        te.dwSize = sizeof(te);
        if (_li(Thread32First)(h, &te))
        {
            do
            {
                if (te.dwSize >= FIELD_OFFSET(THREADENTRY32, th32OwnerProcessID) + sizeof(te.th32OwnerProcessID))
                {
                    if (te.th32ThreadID != currentThr && te.th32OwnerProcessID == currentPrc)
                    {
                        auto thr = _li(OpenThread)(THREAD_SUSPEND_RESUME, false, te.th32ThreadID);
                        _li(ResumeThread)(thr);
                        _li(CloseHandle)(thr);
                    }
                }
                te.dwSize = sizeof(te);
            }
            while (_li(Thread32Next)(h, &te));
        }
        _li(CloseHandle)(h);
    }
}

inline BOOL(__stdcall* VirtualProtectOG)(LPVOID lpAddress, SIZE_T dwSize, DWORD flNewProtect, PDWORD lpflOldProtect) = nullptr;
__declspec(noinline) inline void __WipeFunction(void* _AddrStart, void* _AddrEnd)
{
    GUARD;
    fuckIda;
    int inc = 0;
    for (int i = 0; i < 0x10; i++)
        if (*(uint8*)(__int64(_AddrEnd) + i) == 0xe8)
        {
            inc = i;
            break;
        }

    auto next = __int64(_AddrEnd) + inc;
    auto start = __int64(_AddrStart);
    auto sz = next - start;
    DWORD o;
    (VirtualProtectOG ? VirtualProtectOG : VirtualProtect)((void*)start, sz, PAGE_EXECUTE_READWRITE, &o);
    bResetLock = true;
    for (int i = 0; i < sz; i++)
        *(uint8*)(start + i) = rand() & 0xff;
    bResetHash = true;
    bResetLock = false;
}
//#define wipeFunction(curr) __WipeFunction(curr, _AddressOfNextInstruction());
#define wipeFunction(curr)

void IntegrityThr(void*, uint8_t* ThrLdr);


template <typename CVarT>
CVarT* FindCVar(const wchar_t* CVarStr)
{
    auto sRef = Memcury::Scanner::FindStringRef(CVarStr);

    if (!sRef.IsValid())
        return nullptr;

    uint64_t BeforeVars = 0;

    for (int i = 0; i < 2000; i++)
    {
        auto Ptr = (uint8_t*)(sRef.Get() - i);

        if (*Ptr == 0x48 && *(Ptr + 1) == 0x83 && *(Ptr + 2) == 0xEC)
        {
            BeforeVars = uint64_t(Ptr);
            break;
        }
        else if (*Ptr == 0x48 && *(Ptr + 1) == 0x81 && *(Ptr + 2) == 0xEC)
        {
            BeforeVars = uint64_t(Ptr);
            break;
        }
    }


    for (int i = 0; i < 2000; i++)
    {
        auto Ptr = (uint8_t*)(BeforeVars + i);

        if (*Ptr == 0x4C && *(Ptr + 1) == 0x8D && *(Ptr + 2) == 0x05)
            return Memcury::Scanner(Ptr).RelativeOffset(3).GetAs<CVarT*>();
    }

    return nullptr;
}

inline __forceinline bool IsHooked(void* Addr)
{
    auto Stream = (uint8_t*)Addr;

    while (*Stream == 0x90)
        Stream++;

    return *Stream == 0xE9 || *Stream == 0xEB || *(uint16_t*)Stream == 0x25FF || (*Stream & 0xFC) == 0xCC || *Stream == 0xF1 || (*Stream == 0xE8 && *(Stream + 5) == 0xC3)
        || (*(uint16_t*)Stream == 0x15FF && *(Stream + 6) == 0xC3);
}



inline PIMAGE_SECTION_HEADER GetSect(void* Buf, const char* Name)
{
    auto DosHeader = (IMAGE_DOS_HEADER*)Buf;
    auto PeHeader = (IMAGE_NT_HEADERS*)(__int64(Buf) + DosHeader->e_lfanew);
    auto sects_start = (PIMAGE_SECTION_HEADER)(PeHeader + 1);
    PIMAGE_SECTION_HEADER sect = nullptr;

    for (int i = 0; i < PeHeader->FileHeader.NumberOfSections; i++)
    {
        auto section = sects_start + i;
        char* real_name = (char*)section->Name;

        if (strncmp(real_name, Name, 8) == 0)
        {
            sect = section;
            break;
        }
    }

    return sect;
}

inline void* GetShcRegion(LPVOID pOrigin)
{
    void* pBlock = nullptr;
    ULONG_PTR minAddr;
    ULONG_PTR maxAddr;

    SYSTEM_INFO si;
    GetSystemInfo(&si);
    minAddr = (ULONG_PTR)si.lpMinimumApplicationAddress;
    maxAddr = (ULONG_PTR)si.lpMaximumApplicationAddress;

    if ((ULONG_PTR)pOrigin > MAX_MEMORY_RANGE && minAddr < (ULONG_PTR)pOrigin - MAX_MEMORY_RANGE)
        minAddr = (ULONG_PTR)pOrigin - MAX_MEMORY_RANGE;

    if (maxAddr > (ULONG_PTR)pOrigin + MAX_MEMORY_RANGE)
        maxAddr = (ULONG_PTR)pOrigin + MAX_MEMORY_RANGE;

    maxAddr -= MEMORY_BLOCK_SIZE - 1;

    {
        LPVOID pAlloc = pOrigin;
        while ((ULONG_PTR)pAlloc >= minAddr)
        {
            pAlloc = MinHook::FindPrevFreeRegion(pAlloc, (LPVOID)minAddr, si.dwAllocationGranularity);
            if (pAlloc == NULL)
                break;

            pBlock = VirtualAlloc(pAlloc, MEMORY_BLOCK_SIZE, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
            if (pBlock != NULL)
                break;
        }
    }

    if (pBlock == NULL)
    {
        LPVOID pAlloc = pOrigin;
        while ((ULONG_PTR)pAlloc <= maxAddr)
        {
            pAlloc = MinHook::FindNextFreeRegion(pAlloc, (LPVOID)maxAddr, si.dwAllocationGranularity);
            if (pAlloc == NULL)
                break;

            pBlock = VirtualAlloc(pAlloc, MEMORY_BLOCK_SIZE, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
            if (pBlock != NULL)
                break;
        }
    }

    return pBlock;
}

void Loader__Init();
void AntiDebug__Init();
inline bool(__stdcall* FlushInstructionCacheOG)(HANDLE hProcess, LPCVOID lpBaseAddress, SIZE_T dwSize);
bool __stdcall FlushInstructionCacheHook(HANDLE hProcess, LPCVOID lpBaseAddress, SIZE_T dwSize);

__forceinline BOOL VerifyEmbeddedSignature(LPCWSTR pwszSourceFile)
{
    LONG lStatus;
    GUID WintrustVerifyGuid = WINTRUST_ACTION_GENERIC_VERIFY_V2;
    GUID DriverActionGuid = DRIVER_ACTION_VERIFY;
    HANDLE hFile;
    DWORD dwHash;
    BYTE bHash[100];
    HCATINFO hCatInfo;
    HCATADMIN hCatAdmin;

    WINTRUST_DATA wd = { 0 };
    WINTRUST_FILE_INFO wfi = { 0 };
    WINTRUST_CATALOG_INFO wci = { 0 };

    wfi.cbStruct = sizeof(WINTRUST_FILE_INFO);
    wfi.pcwszFilePath = pwszSourceFile;
    wfi.hFile = NULL;
    wfi.pgKnownSubject = NULL;

    wd.cbStruct = sizeof(WINTRUST_DATA);
    wd.dwUnionChoice = WTD_CHOICE_FILE;
    wd.pFile = &wfi;
    wd.dwUIChoice = WTD_UI_NONE;
    wd.fdwRevocationChecks = WTD_REVOKE_WHOLECHAIN;
    wd.dwStateAction = 0;
    wd.dwProvFlags = 0;
    wd.hWVTStateData = NULL;
    wd.pwszURLReference = NULL;
    wd.pPolicyCallbackData = NULL;
    wd.pSIPClientData = NULL;
    wd.dwUIContext = 0;
    // wd.dwProvFlags = WTD_CACHE_ONLY_URL_RETRIEVAL;

    lStatus = _li(WinVerifyTrust)(NULL, &WintrustVerifyGuid, &wd);

    wd.dwStateAction = WTD_STATEACTION_CLOSE;

    _li(WinVerifyTrust)(NULL, &WintrustVerifyGuid, &wd);

    wd.hWVTStateData = NULL;

    if (lStatus != ERROR_SUCCESS) [[unlikely]]
    {
        hFile = _li(CreateFileW)(pwszSourceFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hFile == INVALID_HANDLE_VALUE)
            return FALSE;

        if (!_li(CryptCATAdminAcquireContext2)(&hCatAdmin, NULL, _(BCRYPT_SHA256_ALGORITHM), NULL, 0))
        {
            _li(CloseHandle)(hFile);
            return FALSE;
        }

        dwHash = sizeof(bHash);
        if (!_li(CryptCATAdminCalcHashFromFileHandle2)(hCatAdmin, hFile, &dwHash, bHash, 0))
        {
            _li(CloseHandle)(hFile);
            return FALSE;
        }

        LPWSTR pszMemberTag = (LPWSTR) new wchar_t[(dwHash * 2 + 1) * sizeof(wchar_t)];
        for (DWORD dw = 0; dw < dwHash; ++dw)
        {
            _li(wsprintfW)(&pszMemberTag[dw * 2], _(L"%02X"), bHash[dw]);
        }

        hCatInfo = _li(CryptCATAdminEnumCatalogFromHash)(hCatAdmin, bHash, dwHash, 0, NULL);

        if (hCatInfo)
        {
            CATALOG_INFO ci = { 0 };
            _li(CryptCATCatalogInfoFromContext)(hCatInfo, &ci, 0);

            wci.cbStruct = sizeof(WINTRUST_CATALOG_INFO);
            wci.pcwszCatalogFilePath = ci.wszCatalogFile;
            wci.pcwszMemberFilePath = pwszSourceFile;
            wci.pcwszMemberTag = pszMemberTag;

            wd = {};
            wd.cbStruct = sizeof(WINTRUST_DATA);
            wd.dwUnionChoice = WTD_CHOICE_CATALOG;
            wd.pCatalog = &wci;
            wd.dwUIChoice = WTD_UI_NONE;
            wd.fdwRevocationChecks = WTD_REVOKE_WHOLECHAIN;
            wd.dwProvFlags = 0;
            wd.hWVTStateData = NULL;
            wd.pwszURLReference = NULL;
            wd.pPolicyCallbackData = NULL;
            wd.pSIPClientData = NULL;
            wd.dwUIContext = 0;
            // wd.dwProvFlags = WTD_CACHE_ONLY_URL_RETRIEVAL;

            lStatus = _li(WinVerifyTrust)(NULL, &WintrustVerifyGuid, &wd);

            wd.dwStateAction = WTD_STATEACTION_CLOSE;

            _li(WinVerifyTrust)(NULL, &WintrustVerifyGuid, &wd);

            wd.hWVTStateData = NULL;

            _li(CryptCATAdminReleaseCatalogContext)(hCatAdmin, hCatInfo, 0);
        }

        _li(CryptCATAdminReleaseContext)(hCatAdmin, 0);
        delete pszMemberTag;
        _li(CloseHandle)(hFile);
    }

    if (lStatus != ERROR_SUCCESS) [[unlikely]]
        return false;
    else
        return true;
}