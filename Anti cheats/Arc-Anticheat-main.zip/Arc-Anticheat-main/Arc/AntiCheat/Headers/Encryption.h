#pragma once

namespace ProjectArc
{
    namespace Encryption
    {
        inline uint8_t* signingKey = nullptr;
        __declspec(noinline) std::vector<unsigned char> EncryptMessage(const char* str, uint8* sig);
        __declspec(noinline) const char* DecryptMessage(std::vector<unsigned char> data);
    }
}