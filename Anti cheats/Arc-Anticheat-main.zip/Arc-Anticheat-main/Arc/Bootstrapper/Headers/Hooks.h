#pragma once
#include "../../pch.h"

namespace ProjectArc
{
    namespace Bootstrapper
    {
        namespace Hooks
        {
            inline DWORD(WINAPI* GetModuleFileNameA_OG)(HMODULE hModule, LPSTR lpFilename, DWORD nSize);
            DWORD WINAPI GetModuleFileNameA_Hk(HMODULE hModule, LPSTR lpFilename, DWORD nSize);

            inline DWORD(WINAPI* GetModuleFileNameW_OG)(HMODULE hModule, LPWSTR lpFilename, DWORD nSize);
            DWORD WINAPI GetModuleFileNameW_Hk(HMODULE hModule, LPWSTR lpFilename, DWORD nSize);

            DWORD WINAPI GetModuleFileNameExA_Hk(HANDLE hProcess, HMODULE hModule, LPSTR lpFilename, DWORD nSize);
            DWORD WINAPI GetModuleFileNameExW_Hk(HANDLE hProcess, HMODULE hModule, LPWSTR lpFilename, DWORD nSize);
            BOOL WINAPI GetVersionExW_Hk(LPOSVERSIONINFOW lpVersionInformation);

            inline BOOL(WINAPI* GetModuleHandleExA_OG)(DWORD dwFlags, LPCSTR lpModuleName, HMODULE* phModule);
            BOOL WINAPI GetModuleHandleExA_Hk(DWORD dwFlags, LPCSTR lpModuleName, HMODULE* phModule);

            inline BOOL(WINAPI* GetModuleHandleExW_OG)(DWORD dwFlags, LPCWSTR lpModuleName, HMODULE* phModule);
            BOOL WINAPI GetModuleHandleExW_Hk(DWORD dwFlags, LPCWSTR lpModuleName, HMODULE* phModule);

            DWORD WINAPI GetModuleBaseNameW_Hk(HANDLE hProcess, HMODULE hModule, LPWSTR lpBaseName, DWORD nSize);
            BOOL WINAPI QueryFullProcessImageNameW_Hk(HANDLE hProcess, DWORD dwFlags, LPWSTR lpExeName, PDWORD lpdwSize);

            void Init();
        }
    }
}