#pragma once
#include "../../pch.h"

namespace ProjectArc
{
    namespace Bootstrapper
    {
        namespace TLS
        {
            void* Allocate();
            void Free();
            bool HasData();

            void CallbackHandler(PVOID hModule, DWORD dwReason, PVOID pContext);
        }
    }
}