#pragma once
#include "../../pch.h"

struct Configuration
{
    std::string ClientID = "";
    std::string Executable = "";
    std::string Splash = "";
    double Version = 0.8; // should never be changed unless updated
};

namespace ProjectArc
{
    namespace Bootstrapper
    {
        Configuration LoadConfiguration();
    }
}

#ifdef __clang__
#define WITH_SOCKET 1
#else
#define WITH_SOCKET 0
#endif