#pragma once

class FCrashReporter
{
public:
    static void Register();
};