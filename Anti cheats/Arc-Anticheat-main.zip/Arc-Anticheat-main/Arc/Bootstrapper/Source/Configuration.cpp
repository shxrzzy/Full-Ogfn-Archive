#include "pch.h"
#include "../Headers/Configuration.h"
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include "../../AntiCheat/Headers/Shared.h"

Configuration ProjectArc::Bootstrapper::LoadConfiguration()
{
    GUARD_RET({});
    fuckIda;
    char buffer[2048];
    GetModuleFileNameA(NULL, buffer, 2048);
    std::filesystem::path exeDir = std::filesystem::path(buffer).parent_path();

    std::ifstream file(exeDir / _("Config.json"), std::ios::binary);
    if (!file.is_open())
        return Config;

    std::stringstream ss;
    ss << file.rdbuf();
    const std::string text = ss.str();

    try
    {
        const json j = json::parse(text);

        if (j.contains(_("ClientID")) && j[_("ClientID")].is_string())
            Config.ClientID = j[_("ClientID")].get<std::string>();

        if (j.contains(_("Executable")) && j[_("Executable")].is_string())
            Config.Executable = j[_("Executable")].get<std::string>();

        if (j.contains(_("Splash")) && j[_("Splash")].is_string())
            Config.Splash = j[_("Splash")].get<std::string>();
    }
    catch (...)
    {
        return Config;
    }

    return Config;
}
