#include "pch.h"
#include "../Headers/Hooks.h"
#include "../../AntiCheat/Headers/Shared.h"
#include "../../MinHook.h"
#include "../Headers/Shared.h"
#include "Psapi.h"
using namespace ProjectArc::Bootstrapper;

DWORD WINAPI Hooks::GetModuleFileNameA_Hk(HMODULE hModule, LPSTR lpFilename, DWORD nSize)
{
    if (hModule == nullptr || hModule == gameBase)
    {
        auto Len = strlen(exePath);

        if (Len + 1 > nSize)
        {
            SetLastError(ERROR_INSUFFICIENT_BUFFER);
            strncpy_s(lpFilename, nSize, exePath, _TRUNCATE);
            return nSize;
        }

        strncpy_s(lpFilename, nSize, exePath, _TRUNCATE);
        return (DWORD)(Len + 1);
    }

    return GetModuleFileNameA_OG(hModule, lpFilename, nSize);
}

DWORD WINAPI Hooks::GetModuleFileNameW_Hk(HMODULE hModule, LPWSTR lpFilename, DWORD nSize)
{
    if (hModule == nullptr || hModule == gameBase)
    {
        std::string exeStr(exePath);
        std::wstring widePath(exeStr.begin(), exeStr.end());

        auto Len = widePath.length() + 1;
        if (Len + 1 > nSize)
        {
            SetLastError(ERROR_INSUFFICIENT_BUFFER);

            wcsncpy_s(lpFilename, nSize, widePath.c_str(), _TRUNCATE);
            return nSize;
        }

        wcsncpy_s(lpFilename, nSize, widePath.c_str(), _TRUNCATE);
        return (DWORD)(widePath.length() + 1);
    }

    return GetModuleFileNameW_OG(hModule, lpFilename, nSize);
}

DWORD WINAPI Hooks::GetModuleFileNameExA_Hk(HANDLE hProcess, HMODULE hModule, LPSTR lpFilename, DWORD nSize)
{
    if (hModule == nullptr || hModule == gameBase)
    {
        strncpy_s(lpFilename, nSize, exePath, _TRUNCATE);
        return (DWORD)(strlen(exePath) + 1);
    }

    return _li(K32GetModuleFileNameExA)(hProcess, hModule, lpFilename, nSize);
}

DWORD WINAPI Hooks::GetModuleFileNameExW_Hk(HANDLE hProcess, HMODULE hModule, LPWSTR lpFilename, DWORD nSize)
{
    if (hModule == nullptr || hModule == gameBase)
    {
        std::string exeStr(exePath);
        std::wstring widePath(exeStr.begin(), exeStr.end());

        wcsncpy_s(lpFilename, nSize, widePath.c_str(), _TRUNCATE);
        return (DWORD)(widePath.length() + 1);
    }

    return _li(K32GetModuleFileNameExW)(hProcess, hModule, lpFilename, nSize);
}

extern "C" NTSTATUS RtlGetVersion(LPOSVERSIONINFOW);
BOOL WINAPI Hooks::GetVersionExW_Hk(LPOSVERSIONINFOW lpVersionInformation)
{
#pragma warning(push)
#pragma warning(disable : 4996)
    auto rt = RtlGetVersion(lpVersionInformation) == 0; // bypasses windows manifestation
#pragma warning(pop)
    return rt;
}

BOOL WINAPI Hooks::GetModuleHandleExA_Hk(DWORD dwFlags, LPCSTR lpModuleName, HMODULE* phModule)
{
    if ((dwFlags & 4) != 0 && lpModuleName >= gameBase && lpModuleName < LPVOID(__int64(gameBase) + gameSize))
    {
        *phModule = HMODULE(gameBase);
        return true; // fixes openssl bs
    }

    return GetModuleHandleExA_OG(dwFlags, lpModuleName, phModule);
}

BOOL WINAPI Hooks::GetModuleHandleExW_Hk(DWORD dwFlags, LPCWSTR lpModuleName, HMODULE* phModule)
{
    if ((dwFlags & 4) != 0 && lpModuleName >= gameBase && lpModuleName < LPVOID(__int64(gameBase) + gameSize))
    {
        *phModule = HMODULE(gameBase);
        return true; // fixes openssl bs
    }

    return GetModuleHandleExW_OG(dwFlags, lpModuleName, phModule);
}

HANDLE CurrentProcess = 0;
std::wstring ArcFolder;
BOOL WINAPI Hooks::QueryFullProcessImageNameW_Hk(HANDLE hProcess, DWORD dwFlags, LPWSTR lpExeName, PDWORD lpdwSize)
{
    auto Ret = _li(QueryFullProcessImageNameW)(hProcess, dwFlags, lpExeName, lpdwSize);

    std::wstring ImageName(lpExeName);

    if (Ret && ImageName.ends_with(_(L"FortniteLauncher.exe")) || ImageName.ends_with(_(L"FortniteClient-Win64-Shipping_EAC.exe"))
        || ImageName.ends_with(_(L"FortniteClient-Win64-Shipping_BE.exe")))
    {
        std::wstring s = ArcFolder;
        s += ImageName.substr(ImageName.rfind('\\'));

        wcsncpy_s(lpExeName, 4096, s.data(), _TRUNCATE); // the buffer actually allocated is 4096, *lpdwSize is wrong. seems to be self modifying.
        *lpdwSize = DWORD(s.size()) + 1;
    }

    return Ret;
}

void Hooks::Init()
{
    fuckIda;
    CurrentProcess = _li(GetCurrentProcess)();
    wchar_t ArcPath[2048];
    _li(GetModuleFileNameW)(HMODULE(__ThisBase), ArcPath, 2048);
    auto ArcPathWS = std::wstring(ArcPath);
    ArcFolder = ArcPathWS.substr(0, ArcPathWS.rfind('\\'));

    ADD_IMPORT_HOOK(K32GetModuleFileNameExA, GetModuleFileNameExA_Hk);
    ADD_IMPORT_HOOK(K32GetModuleFileNameExW, GetModuleFileNameExW_Hk);
    if (bIsFortnite)
        ADD_IMPORT_HOOK(QueryFullProcessImageNameW, QueryFullProcessImageNameW_Hk);


    Hook(_li(GetModuleFileNameA), GetModuleFileNameA_Hk, GetModuleFileNameA_OG);
    Hook(_li(GetModuleFileNameW), GetModuleFileNameW_Hk, GetModuleFileNameW_OG);
    Hook(_li(GetModuleHandleExA), GetModuleHandleExA_Hk, GetModuleHandleExA_OG);
    Hook(_li(GetModuleHandleExW), GetModuleHandleExW_Hk, GetModuleHandleExW_OG);

    for (auto& Initter : ModuleInits)
        Initter();

    // MinHook::MH_EnableHook(MH_ALL_HOOKS);
    wipeFunction(Init);
}
