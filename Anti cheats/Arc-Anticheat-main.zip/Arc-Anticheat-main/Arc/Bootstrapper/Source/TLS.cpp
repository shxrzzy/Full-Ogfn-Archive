#include "pch.h"
#include "../Headers/TLS.h"
#include "../../AntiCheat/Headers/Shared.h"
#include "../Headers/Shared.h"
using namespace ProjectArc::Bootstrapper;

void* TLS::Allocate()
{
    auto dosHeader = (IMAGE_DOS_HEADER*)gameBase;
    auto peHeader = (IMAGE_NT_HEADERS*)(__int64(gameBase) + dosHeader->e_lfanew);

    if (peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].Size)
    {
        auto* pTLS = reinterpret_cast<IMAGE_TLS_DIRECTORY*>(__int64(gameBase) + peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].VirtualAddress);
        auto tlsPtr = (void**)__readgsqword(0x58);

        size_t rawDataSize = (BYTE*)pTLS->EndAddressOfRawData - (BYTE*)pTLS->StartAddressOfRawData;
        size_t rawSizeWithZeroFill = rawDataSize + pTLS->SizeOfZeroFill;

        if (rawSizeWithZeroFill)
        {
            LPVOID tlsBlock = VirtualAlloc(nullptr, rawSizeWithZeroFill, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);

            if (tlsBlock)
            {
                memcpy(tlsBlock, (void*)pTLS->StartAddressOfRawData, rawDataSize);
                memset((BYTE*)tlsBlock + rawDataSize, 0, pTLS->SizeOfZeroFill);

                if (gameTlsIndex < 64)
                {
                    NtCurrentTeb()->TlsSlots[gameTlsIndex] = tlsBlock;
                    tlsPtr[gameTlsIndex] = tlsBlock;
                }
                else
                {
                    PVOID*& tlsArray = (PVOID*&)NtCurrentTeb()->TlsExpansionSlots;
                    if (!tlsArray)
                        tlsArray = (PVOID*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(PVOID) * 1024);

                    if (tlsArray)
                        tlsArray[gameTlsIndex - 64] = tlsBlock;
                }

#ifdef WITH_LOGS
                printf("[Arc] TLS: Allocated %lld bytes at 0x%llx\n", rawSizeWithZeroFill, __int64(tlsBlock));
#endif
                return tlsBlock;
            }
        }
    }

    return nullptr;
}

void TLS::Free()
{
    auto dosHeader = (IMAGE_DOS_HEADER*)gameBase;
    auto peHeader = (IMAGE_NT_HEADERS*)(__int64(gameBase) + dosHeader->e_lfanew);

    if (peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].Size)
    {
        auto* pTLS = reinterpret_cast<IMAGE_TLS_DIRECTORY*>(__int64(gameBase) + peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].VirtualAddress);
        auto tlsPtr = (void**)__readgsqword(0x58);

        if (gameTlsIndex < 64)
        {
            if (NtCurrentTeb()->TlsSlots[gameTlsIndex])
            {
#ifdef WITH_LOGS
                printf("[Arc] TLS: Freed 0x%llx\n", __int64(tlsPtr[gameTlsIndex]));
#endif
                VirtualFree(tlsPtr[gameTlsIndex], 0, MEM_RELEASE);
                NtCurrentTeb()->TlsSlots[gameTlsIndex] = nullptr;
                tlsPtr[gameTlsIndex] = nullptr;
            }
        }
        else
        {
            PVOID*& tlsArray = (PVOID*&)NtCurrentTeb()->TlsExpansionSlots;

            if (tlsArray && tlsArray[gameTlsIndex - 64])
            {
#ifdef WITH_LOGS
                printf("[Arc] TLS: Freed 0x%llx\n", __int64(tlsArray[gameTlsIndex - 64]));
#endif
                VirtualFree(tlsArray[gameTlsIndex - 64], 0, MEM_RELEASE);
                tlsArray[gameTlsIndex - 64] = nullptr;
            }
        }
    }
}

bool TLS::HasData()
{
    if (gameTlsIndex < 64)
    {
        if (NtCurrentTeb()->TlsSlots[gameTlsIndex])
            return true;
    }
    else
    {
        PVOID*& tlsArray = (PVOID*&)NtCurrentTeb()->TlsExpansionSlots;

        if (tlsArray && tlsArray[gameTlsIndex - 64])
            return true;
    }

    return false;
}

void NTAPI TLS::CallbackHandler(PVOID hModule, DWORD dwReason, PVOID pContext)
{
    if (!bSetupGame)
        return;

    auto dosHeader = (IMAGE_DOS_HEADER*)gameBase;
    auto peHeader = (IMAGE_NT_HEADERS*)(__int64(gameBase) + dosHeader->e_lfanew);

    if (peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].Size)
    {
        auto* pTLS = reinterpret_cast<IMAGE_TLS_DIRECTORY*>(__int64(gameBase) + peHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_TLS].VirtualAddress);
        auto tlsPtr = (void**)__readgsqword(0x58);

        if (dwReason == DLL_THREAD_ATTACH)
            TLS::Allocate();

        if (TLS::HasData())
        {
            auto* pCallback = reinterpret_cast<PIMAGE_TLS_CALLBACK*>(pTLS->AddressOfCallBacks);
            for (; pCallback && *pCallback; ++pCallback)
                (*pCallback)(gameBase, dwReason, pContext);
        }

        if (dwReason == DLL_THREAD_DETACH)
            TLS::Free();
    }
}

#pragma comment(linker, "/INCLUDE:_tls_used")
#pragma comment(linker, "/INCLUDE:tls_callback_func")
#pragma const_seg(".CRT$XLB")
EXTERN_C const PIMAGE_TLS_CALLBACK tls_callback_func = (PIMAGE_TLS_CALLBACK)TLS::CallbackHandler;
#pragma const_seg()
